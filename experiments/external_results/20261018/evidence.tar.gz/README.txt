Q-Rust external community benchmark evidence, 2026-10-18

This archive retains the exact frozen protocol, original community inputs and
derived static circuits, official timed/warmup/validated outputs from both
sessions, analysis JSON/CSV, source/licensing provenance, and independent audit
receipts. It includes failed outcomes as well as successful outputs.

The study contract and limitations are in study/protocol.json. Corpus selection
and source-to-common-input normalization are recorded in corpus/manifest.json.
The experiment scripts whose hashes were frozen in the protocol are under
harness/experiments/. The compiler itself is identified by revision and binary
hash in the protocol; compiler binaries are not redistributed here.

Receipts include a development-pilot receipt only. Development-pilot output
artifacts, preliminary corpus builds, logs, caches and draft prose are excluded.
Original MQT circuit inputs use QPY where necessary. The pinned MQT upstream
source archive and source mirror are included with their original licenses.

MANIFEST.json contains SHA256 and size for each payload file. The accompanying
evidence_manifest.json additionally binds the archive hash and records an
independent extraction/hash verification. File bytes are preserved; tar owner,
permissions and timestamps are normalized for reproducible packaging.
