#!/usr/bin/env python3
"""Postflight two-qubit diagnostics, never replacements for frozen trial rows."""
import hashlib
import json
import os
from pathlib import Path
import sys

BASE = Path(__file__).resolve().parent
REPO = BASE.parent / "qrust_pr_publish"
sys.path.insert(0, str(REPO / "experiments"))
from comparison_study import THREAD_ENV, Worker
os.environ.update(THREAD_ENV)
import cirq
import numpy as np
from cirq.contrib.qasm_import import circuit_from_qasm
from comparison_cirq import compile_one, _to_cx, SYNTHESIS_ATOL
from diagnose_compiler_tradeoffs import cirq_trial


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    study = BASE / "study"
    protocol = json.loads((study / "protocol.json").read_text())
    binary = BASE.parent / "qrust_numerical_correctness_20261017/comparison_runner_final"
    assert digest(binary) == protocol["qrust_binary_sha256"]
    observations = []
    directory = BASE / "postflight_failure_probe"
    directory.mkdir(exist_ok=False)
    worker = Worker("qrust", binary, directory)
    try:
        for angle in ("pi", "0.37"):
            qasm = f'OPENQASM 2.0; include "qelib1.inc"; qreg q[2]; cu1({angle}) q[0],q[1];'
            request = dict(qasm=qasm, n_logical=2, physical_width=2,
                           edges=[[0, 1]], topology="all_to_all", seed=20261018)
            native = worker.call(request, 60)
            record = {"angle": angle, "input_qasm": qasm, "qrust": native, "cirq_recipes": {}}
            for label in ("cirq", "cirq_one_pass"):
                try:
                    result = compile_one(**request) if label == "cirq" else cirq_trial(request, label)
                    record["cirq_recipes"][label] = {"status": "compiled", "output_qasm": result["out_qasm"]}
                except Exception as error:
                    record["cirq_recipes"][label] = {"status": "error", "error": f"{type(error).__name__}: {error}"}
            parsed = circuit_from_qasm(qasm)
            parsed = parsed.transform_qubits({q: cirq.LineQubit(int(q.name.split("_")[-1])) for q in parsed.all_qubits()})
            op = next(parsed.all_operations())
            gateset = cirq.CZTargetGateset(atol=SYNTHESIS_ATOL, allow_partial_czs=False,
                preserve_moment_structure=False, reorder_operations=True)
            before = cirq.unitary(parsed)
            optimized = cirq.optimize_for_target_gateset(parsed, gateset=gateset,
                max_num_passes=2, ignore_failures=False)
            closed = _to_cx(optimized, cirq)
            record["cirq_internal_representation"] = {
                "imported_operation": str(op), "imported_gate_type": type(op.gate).__name__,
                "is_CZPowGate": isinstance(op.gate, cirq.CZPowGate),
                "accepted_by_CZTargetGateset": op in gateset,
                "matrix_max_abs_difference_from_CZ": float(np.max(np.abs(cirq.unitary(op) - cirq.unitary(cirq.CZ)))),
                "optimized_operations": [str(op) for op in optimized.all_operations()],
                "after_adapter_CZ_to_CX_operations": [str(op) for op in closed.all_operations()],
                "optimization_preserves_unitary_up_to_phase": bool(cirq.linalg.allclose_up_to_global_phase(before, cirq.unitary(optimized), atol=1e-12)),
                "adapter_conversion_preserves_unitary_up_to_phase": bool(cirq.linalg.allclose_up_to_global_phase(before, cirq.unitary(closed), atol=1e-12)),
            }
            observations.append(record)
    finally:
        worker.close()
    measured = json.loads((BASE / "warmup_validation_receipt.json").read_text())["measured_failure_groups"]
    report = {"scope": "Postflight diagnostic on two newly constructed two-qubit cases; no frozen outputs, metrics or failure classifications were replaced",
        "study_protocol_sha256": digest(study / "protocol.json"), "source_sha256": digest(Path(__file__)),
        "binary_sha256": digest(binary), "observations": observations,
        "measured_failure_groups": measured,
        "classification": {
            "qrust": {"stage": "parse_qasm input resolution, before transpilation", "reason": "cu1 is a standard controlled-phase spelling retained by the shared frontend but absent from Q-Rust's accepted built-in gate vocabulary",
                "distinct_failed_fixtures": 9, "distinct_failed_cells": 18, "failed_trials_per_session": 126,
                "implication": "Compatibility/coverage failure, not evidence of poor routing or output-quality optimization. The shared normalization handles CRZ/RZZ but does not expand CU1, so common-source compatibility must be reported separately from paired successful compilation."},
            "cirq": {"stage": "adapter _serialize after native compile timer", "reason": "Cirq's CZ target accepts a controlled QasmUGate equivalent to CZ up to global phase; the adapter conversion only recognizes CZPowGate instances, leaving a correct CZ-equivalent operation that its final CX-only serializer rejects",
                "distinct_failed_cells_primary": 3, "distinct_failed_cells_light": 4,
                "failed_trials_per_session_primary": 21, "failed_trials_per_session_light": 28,
                "implication": "Adapter basis-closure limitation, not evidence that Cirq cannot synthesize or preserve the input unitary. The frozen study must retain the failures; later generalized canonicalization requires a separately declared comparison."}},
        "critical_reporting_limits": [
            "Do not characterize these as numerical correctness failures; all retained compiled outputs passed the independent oracle.",
            "Q-Rust primary paired performance excludes nine controlled-phase-containing fixtures and is therefore conditional on supported input vocabulary.",
            "Cirq reported success coverage includes an adapter-induced limitation. Do not turn it into a broad Cirq capability claim.",
            "No CU1 decomposition or serializer repair was inserted into the completed study after observing results."]}
    (BASE / "external_failure_diagnosis.json").write_text(json.dumps(report, indent=2, sort_keys=True) + "\n")
    print(json.dumps({"diagnostic_cases": len(observations), "observations": observations}, indent=2))


if __name__ == "__main__":
    main()
