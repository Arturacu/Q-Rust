# Independent external-study audit

Status: PASS. The frozen study and reported point summaries are internally consistent. This audit did not change compiler, adapter, corpus or measurement files. It independently traversed raw records and recomputed summaries with Python's standard library, without importing the study runner or analyzer. It checked 410 aggregate/profile/near-best assertions and 596 subgroup/session-drift assertions. Bootstrap intervals were not independently recomputed.

The protocol SHA256 is `ddb4fd217613a77638a6fcc20d4b6b72872ed6132f646759683bedfdea821645`. The corpus SHA256 is `2d14203e785b133a9e9d7cacf85b5c8222ce81774988488051beb2cb7288f1ce`. The measured Q-Rust worker remains `004ca5c49481ef7eed018bb33686ee0e8f27e6504758ba0b0d804783ee90d047`, from compiler commit `dbc4645f3183b2d44dc076f431b98932510c9a20`.

## Integrity and coverage

Both sessions contain the complete prescribed 4,200-row timed grid: 50 source circuits, two targets, six recipes and seven trials. Schedules, trial seeds and identities, source/build-input hashes, corpus mappings, connectivity, session completion receipts, raw/validated file hashes, timed output hashes and layout-bound artifact hashes match. Validation did not change any original measurement field. Timing-component sums and full-request residual accounting are consistent.

| Recipe | Successful case-target cells, each session | Timed successes, each session |
|---|---:|---:|
| Q-Rust | 82/100 | 574/700 |
| Qiskit | 100/100 | 700/700 |
| Cirq primary | 97/100 | 679/700 |
| Cirq one-pass | 96/100 | 672/700 |
| TKET primary | 100/100 | 700/700 |
| TKET light | 100/100 | 700/700 |

Q-Rust rejects nine fixtures on both targets with `Unknown gate: cu1`. These are input acceptance failures of the frozen compiler. They are not incorrect-unitary outputs. Cirq's three/four failed cells leave a controlled `QasmUGate` that the declared common-basis serializer refuses. These are fixed-recipe/adapter failures, not evidence that the entire SDK cannot compile the circuit. No timed failure was replaced with another case or dropped from the recorded denominator.

All Cirq failures are within the Q-Rust-failed set. Consequently every Q-Rust comparison uses the same 82 successful cells, corresponding to 41 distinct fixtures. Support is 32/34 selected QASMBench fixtures and 9/16 selected MQT fixtures. This particularly limits claims about MQT workload coverage. The 100 other ledger entries excluded before timing are a separate selection denominator, not compiler failures.

All 8,050 successfully emitted timed outputs across both sessions passed the numerical oracle. There are 605 distinct layout-bound artifacts: 408 full numerical isometry checks and 197 sampled checks. Worst residual is 4.5309512666641535e-9, below the unchanged 1e-7 threshold. Larger sampled checks remain finite numerical evidence, not proofs. Every corresponding successful same-seed output in the second session is identical in QASM and layouts (4,025 pairs), and all 175 non-success outcomes recur. This demonstrates repeatability on this host, not independent-host reproducibility.

## Timing summaries on the common 82 successful cells

Values below are geometric means of paired baseline/Q-Rust case-median times. They exclude unsupported cases and must not be presented as full selected-corpus speed averages.

| Recipe | Compile ratio, session 1 | Compile ratio, session 2 | Full-request ratio, session 1 | Full-request ratio, session 2 |
|---|---:|---:|---:|---:|
| Qiskit | 4.491791 | 4.522835 | 4.115297 | 4.129029 |
| Cirq primary | 88.318460 | 89.126524 | 82.034086 | 82.632807 |
| TKET primary | 243.147532 | 247.497673 | 188.100384 | 190.827290 |
| Cirq one-pass | 54.030297 | 53.946956 | 54.184309 | 53.921475 |
| TKET light | 29.642120 | 29.846787 | 25.420600 | 25.555373 |

The full request includes parsing, compilation, serialization, layout/report handling, interpreter work and IPC in persistent workers. It is not process startup or an isolated serialization measurement. The primary and light views reuse the same Q-Rust and Qiskit rows; they are not additional trials. Selected recipes spend different search effort, and the light helpers include stage-clock bookkeeping. The differences cannot establish a causal effect of implementation language.

For absolute context, the median across the 82 case-median compile times is:

| Recipe | Session 1, ms | Session 2, ms |
|---|---:|---:|
| Q-Rust | 0.415895 | 0.405979 |
| Qiskit | 2.554792 | 2.569583 |
| Cirq primary | 43.511292 | 43.700437 |
| TKET primary | 134.875438 | 138.329479 |
| Cirq one-pass | 30.940292 | 30.334292 |
| TKET light | 14.688458 | 14.510938 |

These absolute medians should not be divided to reconstruct paired geometric ratios. Q-Rust is not faster on every case: SAT-11 on a line takes 72.275/71.679 ms versus Qiskit's 13.878/13.632 ms, a 5.21–5.26-fold Q-Rust slowdown. DNN-8 all-to-all and HHL-7 line are also substantial Qiskit wins.

## Output quality and tails

In the primary profile, Q-Rust's CX count is at or better than the best baseline in 62/82 cells, within 5% in 65/82, and within 10% in 68/82. Total depth is within 10% in 65/82. The light profile gives 75/82 within 10% for CX and depth, but its comparison set contains lighter baseline recipes. These are proportions of successful cases meeting a band against an observed baseline, not a percentage of optimal quality.

The worst primary CX gap is `error_correctiond3_n5__all_to_all`: Q-Rust produces 47 CX and depth 76, compared with TKET's 9 CX and depth 13. This is 5.22 times as many CX and 5.85 times the depth. On a line the same fixture uses 65 versus 20 CX and depth 86 versus 25. The basis-test circuit also has a twofold primary CX gap (10 versus 5) on both targets. Such tails should appear alongside aggregate ratios.

Against primary recipes, the aggregate CX ratios Q-Rust/baseline are 1.021242 for Qiskit, 0.790439 for Cirq and 1.026028 for TKET. Depth ratios are 0.957203, 0.635483 and 1.063964 respectively. They are identical across sessions because output quality is identical. The two all-zero CX cells remain in win/tie/band counts but are excluded from log-ratio means.

## Strata and limits

Qiskit-relative compile ratios fall from 6.81–6.86 at widths 2–6 to about 1.76 at widths 7–10 and 1.34–1.37 at widths 11–14. These groups contain 58, 18 and only six eligible cells respectively, and width is confounded with workload composition. This is not an isolated scaling law. On QASMBench, the primary geometric mean of positive paired Q-Rust/TKET ratios is 1.071 for CX and 1.103 for depth; the supported MQT subset has ratios below one for both. The 18-cell supported MQT subset excludes seven of the sixteen selected MQT fixtures.

All results are conditional on the stated static-unitary-prefix extraction, common lowered input, abstract U/CX costs, ideal bidirectional connectivity, 2–14 qubits, pinned recipes and this host. They do not establish full-suite rankings, hardware duration/fidelity, globally optimal output, or language-causal speedups. No additional blocking integrity finding remains.

Detailed independent results are in `independent_postflight_audit.json` and `independent_postflight_detail.json`. The first records hashes, failures, numeric comparisons and residual coverage; the second retains full-request ratios, absolute timings, subgroup summaries and worst timing cases.
