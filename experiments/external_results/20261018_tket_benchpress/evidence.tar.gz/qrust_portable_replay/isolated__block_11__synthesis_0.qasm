OPENQASM 2.0;
include "qelib1.inc";

qreg q[2];

cx q[0], q[1];
u(1.5707963267948966, 0, 3.141592653589793) q[1];
cx q[0], q[1];
