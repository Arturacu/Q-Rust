# Evidence package

This package preserves the investigation's raw outcomes and provenance.
`tket/` and `qrust/` hold the five-qubit causal controls. `benchpress/`
contains completed native runs, earlier instrumentation failures, frozen
inputs and source manifests. `matched/` contains the separate four-compiler
campaign and validation. `verification/` contains additional independent
checks. `harness/experiments/` holds the frozen adapters and verification code.

No compiler binary, virtual environment or credentials are included.
`benchpress/upstream_reference/` is a source excerpt, not the full executable
upstream tree; retrieve the exact source archive and verify its recorded hash
for native reruns. Upstream LICENSE files accompany redistributed sources.

Every file except this manifest itself is bound by `manifest.json`. This is
an integrity manifest, not a signature. Original absolute paths in the frozen
protocols remain intact as provenance. Portable replay commands are in the
repository's TKET_CLIFFORD_INVESTIGATION.md and BENCHPRESS_PILOT.md reports.
Use new output paths; never overwrite archived evidence.
