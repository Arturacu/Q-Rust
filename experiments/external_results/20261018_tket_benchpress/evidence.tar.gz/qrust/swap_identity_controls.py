"""Exact source-level SWAP recognition intervention; diagnostic, not production."""
from pathlib import Path
import sys,json,hashlib,subprocess,itertools
import numpy as np
root=Path(__file__).resolve().parents[2]
repo=root/'qrust_pr_publish';sys.path.insert(0,str(repo/'experiments'))
from comparison_validation import validate_output,parse_qasm,common_metrics,simulate,Gate
work=Path(__file__).resolve().parent
source=(root/'qrust_external_20261018/corpus/qasmbench__error_correctiond3_n5.normalized.qasm').read_text()
binary=root/'qrust_external_retention_20261018/comparison_runner_fixed'
n,gates=parse_qasm(source)
def dump(gates):
 s='OPENQASM 2.0;\ninclude "qelib1.inc";\nqreg q[5];\n'
 for g in gates:
  s+=g.name+('('+','.join(repr(p) for p in g.params)+')' if g.params else '')+' '+','.join(f'q[{q}]' for q in g.qubits)+';\n'
 return s
matches=[]
i=0
while i+6<len(gates):
 b=gates[i:i+7];pair=b[0].qubits
 if b[0].name=='cx' and b[2+1]==b[0] and b[6]==b[0] and all(x.name=='h' for x in [b[1],b[2],b[4],b[5]]) and {b[1].qubits[0],b[2].qubits[0]}==set(pair)=={b[4].qubits[0],b[5].qubits[0]}:
  matches.append({'start_op':i,'end_op':i+6,'pair':list(pair)});i+=7
 else:i+=1
variants=[('source',set(),False),('all_swaps',set(range(len(matches))),True),('all_reversed_cx',set(range(len(matches))),False)]
variants += [(f'swap_only_{j}',{j},True) for j in range(len(matches))]
rows=[];requests=[]
for name,chosen,emit_swap in variants:
 out=[];i=0
 selected={m['start_op']:(j,m) for j,m in enumerate(matches) if j in chosen}
 while i<len(gates):
  if i in selected:
   j,m=selected[i]; a,b=m['pair']
   out.extend([Gate('swap',(),(a,b))] if emit_swap else [Gate('cx',(),(a,b)),Gate('cx',(),(b,a)),Gate('cx',(),(a,b))]);i+=7
  else:out.append(gates[i]);i+=1
 qasm=dump(out);(work/(name+'.input.qasm')).write_text(qasm)
 u=simulate(n,gates,np.eye(1<<n,dtype=complex));v=simulate(n,tuple(out),np.eye(1<<n,dtype=complex));ov=np.vdot(u,v);phase=ov/abs(ov);res=float(np.max(np.linalg.norm(v-phase*u,axis=0)))
 assert res<1e-12,(name,res)
 requests.append({'qasm':qasm,'topology':'all_to_all','physical_width':5,'n_logical':5,'edges':list(itertools.combinations(range(5),2)),'profile_passes':True})
 rows.append({'name':name,'selected_matches':sorted(chosen),'input_sha256':hashlib.sha256(qasm.encode()).hexdigest(),'rewrite_full_unitary_max_residual':res,'rewrite_input_columns':1<<n,'emitted_explicit_swap':emit_swap})
p=subprocess.run([str(binary)],input=''.join(json.dumps(r)+'\n' for r in requests),capture_output=True,text=True,check=True)
responses=[json.loads(x) for x in p.stdout.splitlines()];assert responses.pop(0)['ready']
for row,response in zip(rows,responses,strict=True):
 assert response['status']=='compiled',response
 validation=validate_output(source,response['out_qasm'],5,5,None,response['initial_layout'],response['final_layout'])
 assert validation['passed'],validation
 row.update(response=response,validation=validation)
 (work/(row['name']+'.output.qasm')).write_text(response['out_qasm'])
 print(row['name'],validation['metrics'],'maps',response['initial_layout'],response['final_layout'])
(work/'swap_identity_controls.json').write_text(json.dumps({'schema_version':1,'source_sha256':hashlib.sha256(source.encode()).hexdigest(),'binary_sha256':hashlib.sha256(binary.read_bytes()).hexdigest(),'matches':matches,'rows':rows,'purpose':'exact input-representation controlled diagnostic; not changes to historical benchmark input'},indent=2)+'\n')
