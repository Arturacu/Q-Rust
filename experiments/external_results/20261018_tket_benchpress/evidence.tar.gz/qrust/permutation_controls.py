"""Separate source SWAP recognition from output-permutation semantics."""
from pathlib import Path
import sys,json,hashlib,itertools,subprocess
root=Path(__file__).resolve().parents[2];repo=root/'qrust_pr_publish';sys.path.insert(0,str(repo/'experiments'))
from comparison_validation import validate_output
work=Path(__file__).resolve().parent;source=(work/'source.input.qasm').read_text();all_swaps=(work/'all_swaps.input.qasm').read_text();binary=root/'qrust_external_retention_20261018/comparison_runner_fixed'
requests=[{'qasm':qasm,'topology':'all_to_all','physical_width':5,'n_logical':5,'edges':list(itertools.combinations(range(5),2)),'profile_passes':True,'elide_output_permutations':elide} for qasm,elide in [(source,False),(all_swaps,False),(all_swaps,True)]]
p=subprocess.run([str(binary)],input=''.join(json.dumps(r)+'\n' for r in requests),text=True,capture_output=True,check=True)
r=[json.loads(x) for x in p.stdout.splitlines()];assert r.pop(0)['ready'];rows=[]
for name,req,response in zip(['source_no_elision','swaps_no_elision','swaps_with_elision'],requests,r,strict=True):
 v=validate_output(source,response['out_qasm'],5,5,None,response['initial_layout'],response['final_layout']);assert v['passed'],v
 rows.append({'name':name,'request':req,'response':response,'validation':v});(work/(name+'.output.qasm')).write_text(response['out_qasm'])
 print(name,v['metrics'],response['final_layout'])
last=rows[-1]['response'];assert last['initial_layout']==[0,1,2,3,4] and last['final_layout']==[0,1,4,3,2]
qasm=last['out_qasm']+'\ncx q[2],q[4];\ncx q[4],q[2];\ncx q[2],q[4];\n'
v=validate_output(source,qasm,5,5,None,list(range(5)),list(range(5)));assert v['passed'],v
rows.append({'name':'swaps_with_elision_restored_identity_outputs','append':'CX(2,4); CX(4,2); CX(2,4)','out_qasm':qasm,'initial_layout':list(range(5)),'final_layout':list(range(5)),'validation':v});(work/'swaps_with_elision_restored_identity_outputs.qasm').write_text(qasm)
print(rows[-1]['name'],v['metrics'])
(work/'permutation_controls.json').write_text(json.dumps({'schema_version':1,'binary_sha256':hashlib.sha256(binary.read_bytes()).hexdigest(),'source_sha256':hashlib.sha256(source.encode()).hexdigest(),'rows':rows,'purpose':'all-to-all source-identity diagnostics; appended restoration is not optimized and is not an optimality claim'},indent=2)+'\n')
