from pathlib import Path
import sys,json,hashlib,subprocess,itertools
root=Path(__file__).resolve().parents[2]
repo=root/'qrust_pr_publish'
sys.path.insert(0,str(repo/'experiments'))
from comparison_validation import validate_output,parse_qasm,common_metrics
work=Path(__file__).resolve().parent
source=(root/'qrust_external_20261018/corpus/qasmbench__error_correctiond3_n5.normalized.qasm').read_text()
binary=root/'qrust_external_retention_20261018/comparison_runner_fixed'
requests=[]
for block,phase,fusion in itertools.product([True,False],repeat=3):
    name=f'block_{int(block)}_phase_{int(phase)}_fusion_{int(fusion)}'
    requests.append((name,{'qasm':source,'topology':'all_to_all','physical_width':5,'n_logical':5,'edges':list(itertools.combinations(range(5),2)),'profile_passes':True,'two_qubit_block_synthesis':block,'recover_phase_gadgets':phase,'post_block_fusion':fusion}))
p=subprocess.run([str(binary)],input=''.join(json.dumps(r)+'\n' for _,r in requests),capture_output=True,text=True,check=True)
responses=[json.loads(x) for x in p.stdout.splitlines()]
assert responses.pop(0)['ready']
rows=[]
for (name,request),response in zip(requests,responses,strict=True):
    assert response['status']=='compiled',response
    validation=validate_output(source,response['out_qasm'],5,5,None,response['initial_layout'],response['final_layout'])
    assert validation['passed'],validation
    (work/(name+'.qasm')).write_text(response['out_qasm'])
    rows.append({'name':name,'request':request,'response':response,'validation':validation})
result={'schema_version':1,'source_sha256':hashlib.sha256(source.encode()).hexdigest(),'binary_sha256':hashlib.sha256(binary.read_bytes()).hexdigest(),'oracle_sha256':hashlib.sha256((repo/'experiments/comparison_validation.py').read_bytes()).hexdigest(),'source_metrics':common_metrics(*parse_qasm(source)),'rows':rows,'purpose':'controlled untimed pass diagnostics; elapsed_ns not claimed as benchmark speed'}
(work/'frozen_controls.json').write_text(json.dumps(result,indent=2)+'\n')
for r in rows:
 print(r['name'],r['validation']['metrics'],r['response']['two_qubit_block_stats'],r['response']['initial_layout'],r['response']['final_layout'])
for p in rows[0]['response']['pass_diagnostics']:print(p)
