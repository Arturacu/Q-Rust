from pathlib import Path
import json,hashlib
work=Path(__file__).resolve().parent;root=work.parents[1]
frozen=json.loads((work/'frozen_controls.json').read_text());swaps=json.loads((work/'swap_identity_controls.json').read_text());permutation=json.loads((work/'permutation_controls.json').read_text());blocks=json.loads((work/'block_boundaries.json').read_text())
isolated=json.loads((work/'isolated_block_controls.json').read_text());audit=json.loads((work/'independent_clifford_audit.json').read_text())
assert all(r['validation']['passed'] and r['validation']['checked_input_count']==4 for r in isolated['rows'])
original=frozen['rows'][0]['response'];matching=[]
for session in ['session_01','session_02']:
 p=root/'qrust_external_retention_20261018/study'/session/'timed.jsonl'
 for line in p.open():
  r=json.loads(line)
  if r['case_id']=='qasmbench__error_correctiond3_n5__all_to_all' and r.get('tool')=='qrust':
   assert r['out_qasm']==original['out_qasm'] and r['initial_layout']==original['initial_layout'] and r['final_layout']==original['final_layout']
   matching.append({'session':session,'id':r['id'],'output_sha256':r['output_sha256'],'artifact_sha256':r['artifact_sha256']})
assert len(matching)==14,len(matching)
checks=[r['validation'] for r in frozen['rows']+swaps['rows']+permutation['rows']]
assert len(checks)==26 and all(v['passed'] and v['checked_input_count']==32 for v in checks)
notes={
 'schema_version':1,'production_changed':False,'historical_results_changed':False,'fixture':'qasmbench__error_correctiond3_n5','topology':'all_to_all','official_output_identity_checks':matching,
 'full_unitary_validation':{'compiled_output_checks':len(checks),'input_columns_each':32,'passed':True,'max_input_residual':max(v['max_input_residual'] for v in checks),'input_rewrite_checks':len(swaps['rows']),'max_rewrite_residual':max(r['rewrite_full_unitary_max_residual'] for r in swaps['rows'])},
 'isolated_two_qubit_block_checks':{'count':len(isolated['rows']),'input_columns_each':4,'passed':True,'observed_reductions':[[r['block'],r['block_cx'],r['validation']['metrics']['cx_count']] for r in isolated['rows'] if r['block_synthesis_enabled']]},
 'scalable_checker_independent_audit':{k:v for k,v in audit.items() if k!='rows'},
 'findings':[
  {'claim':'Current optimize/layout/route passes retain 49 input CX. No physical routing SWAPs or layout changes are responsible for this gap.','evidence':'frozen_controls.json rows[0].response.pass_diagnostics'},
  {'claim':'Two-qubit block synthesis alone removes 2 CX. It considers 14 blocks: two with 2 CX and twelve with 3 CX. Two replacements are accepted; twelve fail the strict CX-improvement condition. None fails the numerical guard.','evidence':['frozen_controls.json','block_boundaries.json','isolated_block_controls.json'],'qualification':'Block boundaries are reconstructed by a read-only transcription of production collection logic; count matches frozen compiler counters, not an instrumented block log.'},
  {'claim':'Eleven explicit seven-gate patterns encode SWAP, using (H tensor H) CX(a,b) (H tensor H) = CX(b,a) and the three-CX SWAP identity. Replacing only those exact patterns with named SWAP lets the unchanged compiler relabel logical wires before routing.','evidence':'swap_identity_controls.json matches and rows','individual_effect':'Each of eleven isolated replacements changes 47 CX to 44 CX.'},
  {'claim':'Replacing all eleven patterns yields 14 CX / depth 17 with final logical-to-physical map [0,1,4,3,2]. Disabling permutation elision returns 47 CX / depth 54. Merely reversing the middle CX without naming SWAP also retains 47 CX / depth 54.','evidence':['swap_identity_controls.json','permutation_controls.json']},
  {'claim':'Restoring output wire identity explicitly costs three additional CX, giving a numerically equivalent 17-CX / depth-20 circuit. Thus the gain is not explained solely by a free final output relabeling.','evidence':'permutation_controls.json rows[-1]','qualification':'The appended restoring swap is not optimized; this is an upper-bound construction, not an optimum.'},
  {'claim':'The compiler recognizes explicit SWAP operations for logical permutation extraction, but does not recover these encoded SWAPs before that pass. Its later two-wire synthesis operates after routing and accepts only strictly lower CX counts, so it cannot capture this representation-dependent opportunity.','source_locations':['src/transpiler/mod.rs build_pass_manager_for','src/transpiler/optimization.rs ExtractOutputPermutationPass','src/transpiler/block_synthesis.rs collect_block and strict cx_after >= cx_before rejection']}
 ],
 'limits':['These are untimed causal diagnostics on a single all-to-all Clifford fixture, not new speed benchmarks.','Recognition is a diagnostic source rewrite, not a production optimization or general recommended rewrite policy.','TKET\'s remaining gap requires Clifford transformations across the two-wire block boundaries; consult the separate TKET pass-trace controls.','Nine CX is an achieved heuristic output, not an established minimum.'],
 'artifact_sha256':{p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(work.iterdir()) if p.is_file() and p.name not in {'causal_summary.json','write_causal_summary.py'}}
}
(work/'causal_summary.json').write_text(json.dumps(notes,indent=2)+'\n');print(notes['full_unitary_validation']);print('14 official historical outputs exactly matched')
