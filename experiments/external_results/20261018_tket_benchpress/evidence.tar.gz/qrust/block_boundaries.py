"""Read-only transcription of Q-Rust's dependency block collection for diagnostics.
The frozen compiler's own counters provide an independent count cross-check.
"""
from pathlib import Path
import json,sys
root=Path(__file__).resolve().parents[2];sys.path.insert(0,str(root/'qrust_pr_publish/experiments'))
from comparison_validation import parse_qasm
work=Path(__file__).resolve().parent
source=work/'block_0_phase_1_fusion_1.qasm';n,g=parse_qasm(source.read_text())
succ=[[None,None] for _ in g];prev=[[None,None] for _ in g];nxt=[None]*n;last=[None]*n
for i in range(len(g)-1,-1,-1):
 for operand,q in enumerate(g[i].qubits):succ[i][operand]=nxt[q];nxt[q]=i
for i,op in enumerate(g):
 for operand,q in enumerate(op.qubits):prev[i][operand]=last[q];last[q]=i
processed=[False]*len(g);blocks=[]
for i,op in enumerate(g):
 if processed[i] or op.name!='cx':continue
 pair=sorted(op.qubits);pending=[i,i];body=[];boundary=None
 while any(x is not None for x in pending):
  j=min(x for x in pending if x is not None)
  if any(q not in pair for q in g[j].qubits):boundary=j;break
  body.append(j)
  for operand,q in enumerate(g[j].qubits):pending[pair.index(q)]=succ[j][operand]
 for j in body:processed[j]=True
 cx=sum(g[j].name=='cx' for j in body)
 if cx<2:continue
 leading=[]
 for previous in prev[i]:
  while previous is not None and not processed[previous] and g[previous].name=='u3':
   leading.append(previous);previous=prev[previous][0]
 leading.sort()
 for j in leading:processed[j]=True
 blocks.append({'block':len(blocks),'pair':pair,'cx_count':cx,'leading_u_indices':leading,'body_indices':body,'boundary_op_index':boundary,'boundary_qubits':list(g[boundary].qubits) if boundary is not None else None,'operations':[{'index':j,'gate':g[j].name,'qubits':list(g[j].qubits),'params':list(g[j].params)} for j in leading+body]})
frozen=json.loads((work/'frozen_controls.json').read_text())
assert len(blocks)==frozen['rows'][0]['response']['two_qubit_block_stats']['blocks_considered']
result={'schema_version':1,'input':'block_0_phase_1_fusion_1.qasm','collector_source':'src/transpiler/block_synthesis.rs: wire_successors, wire_predecessors, collect_block, leading_u_indices','checked_count_matches_compiler':True,'blocks':blocks}
(work/'block_boundaries.json').write_text(json.dumps(result,indent=2)+'\n')
print([(b['pair'],b['cx_count'],b['boundary_qubits']) for b in blocks])
