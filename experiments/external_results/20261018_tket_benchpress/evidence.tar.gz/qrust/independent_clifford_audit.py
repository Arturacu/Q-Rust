"""Independent small-case audit of the scalable checker against dense analytic QASM.
All expectations are computed by the pre-existing frozen NumPy simulator,
not from the proposed Clifford checker's algebra.
"""
from pathlib import Path
import sys,json,hashlib,random,math,itertools
root=Path(__file__).resolve().parents[2];repo=root/'qrust_pr_publish';work=Path(__file__).resolve().parent;checker=root/'qrust_tket_benchpress_20261018/verification/scalable_clifford.py'
sys.path[:0]=[str(repo/'experiments'),str(checker.parent)]
from comparison_validation import validate_output
from scalable_clifford import validate_clifford,State,canonical,multiply,representatives
rng=random.Random(2026101807)
def emit(width,ops):
 lines=['OPENQASM 2.0;','include "qelib1.inc";',f'qreg q[{width}];']
 for name,qs in ops:lines.append(name+' '+','.join(f'q[{q}]' for q in qs)+';')
 return '\n'.join(lines)+'\n'
def basis(ops):
 out=[]
 for name,qs in ops:
  if name=='h':out.append(('u(pi/2,0,pi)',qs))
  elif name=='s':out.append(('u(0,0,pi/2)',qs))
  elif name=='sdg':out.append(('u(0,0,-pi/2)',qs))
  elif name=='x':out.append(('u(pi,0,pi)',qs))
  elif name=='y':out.append(('u(pi,pi/2,pi/2)',qs))
  elif name=='z':out.append(('u(0,0,pi)',qs))
  elif name=='cx':out.append((name,qs))
  elif name=='cy':out.extend(basis([('sdg',(qs[1],)),('cx',qs),('s',(qs[1],))]))
  elif name=='cz':out.extend(basis([('h',(qs[1],)),('cx',qs),('h',(qs[1],))]))
  elif name=='swap':out.extend([('cx',qs),('cx',tuple(reversed(qs))),('cx',qs)])
  else:raise ValueError(name)
 return out
rows=[]
for case in range(120):
 n=rng.randrange(1,5);p=rng.randrange(n,min(6,n+2)+1);initial=rng.sample(range(p),n);final=rng.sample(range(p),n)
 ops=[]
 for _ in range(rng.randrange(0,55)):
  if n>1 and rng.random()<.5:ops.append((rng.choice(['cx','cy','cz','swap']),tuple(rng.sample(range(n),2))))
  else:ops.append((rng.choice(['h','s','sdg','x','y','z']),(rng.randrange(n),)))
 physical=[(name,tuple(initial[q] for q in qs)) for name,qs in ops];where=list(initial)
 for logical,target in enumerate(final):
  now=where[logical]
  if now!=target:
   physical.append(('swap',(now,target)));where=[target if q==now else now if q==target else q for q in where]
 assert where==final
 source=emit(n,ops);output=basis(physical);variants=[('equivalent',output,True),('wrong_logical_x',output+basis([('x',(final[0],))]),False)]
 spare=next((q for q in range(p) if q not in final),None)
 if spare is not None:
  variants += [('clean_ancilla_z',output+basis([('z',(spare,))]),True),('dirty_ancilla_x',output+basis([('x',(spare,))]),False),('dirty_entangled_ancilla',output+[('cx',(final[0],spare))],False),('clean_ancilla_control',output+[('cx',(spare,final[0]))],True)]
 for name,candidate,expected in variants:
  qasm=emit(p,candidate)
  dense=validate_output(source,qasm,n,p,None,initial,final)
  scalable=validate_clifford(source,qasm,n,p,initial,final)
  assert dense['passed']==expected,(case,name,dense)
  assert scalable['passed']==dense['passed'],(case,name,scalable,dense)
  rows.append({'case':case,'variant':name,'logical_width':n,'physical_width':p,'source_sha256':hashlib.sha256(source.encode()).hexdigest(),'output_sha256':hashlib.sha256(qasm.encode()).hexdigest(),'initial_layout':initial,'final_layout':final,'expected':expected,'dense_max_input_residual':dense['max_input_residual'],'scalable_passed':scalable['passed'],'recognition_error_sum':scalable.get('reconstruction_error_sum')})
# Canonical row reduction must ignore generator basis/order while keeping signs.
for case in range(40):
 state=State(5)
 for _ in range(30):
  if rng.random()<.5:state.apply(rng.choice(['h','s']),rng.randrange(5))
  else:state.apply('cx',*rng.sample(range(5),2))
 target=canonical(state.rows,5);altered=list(state.rows)
 for _ in range(30):
  i,j=rng.sample(range(5),2);altered[i]=multiply(altered[i],altered[j])
 rng.shuffle(altered);assert canonical(altered,5)==target
result={'schema_version':1,'seed':2026101807,'checker_sha256':hashlib.sha256(checker.read_bytes()).hexdigest(),'oracle_sha256':hashlib.sha256((repo/'experiments/comparison_validation.py').read_bytes()).hexdigest(),'compiled_isometry_cases':len(rows),'passed':True,'positive':sum(r['expected'] for r in rows),'negative':sum(not r['expected'] for r in rows),'canonical_generator_basis_trials':40,'clifford_representative_count':len(representatives()),'rows':rows}
(work/'independent_clifford_audit.json').write_text(json.dumps(result,indent=2)+'\n')
print({k:v for k,v in result.items() if k!='rows'})
