from pathlib import Path
import json,sys,subprocess,hashlib
work=Path(__file__).resolve().parent;root=work.parents[1];sys.path.insert(0,str(root/'qrust_pr_publish/experiments'))
from comparison_validation import validate_output
blocks=json.loads((work/'block_boundaries.json').read_text())['blocks'];binary=root/'qrust_external_retention_20261018/comparison_runner_fixed';requests=[];rows=[]
for block in blocks:
 pair=block['pair'];qasm='OPENQASM 2.0;\ninclude "qelib1.inc";\nqreg q[2];\n'
 for op in block['operations']:
  qasm+=op['gate']+('('+','.join(repr(p) for p in op['params'])+')' if op['params'] else '')+' '+','.join('q['+str(pair.index(q))+']' for q in op['qubits'])+';\n'
 for enabled in [False,True]:
  request={'qasm':qasm,'topology':'all_to_all','physical_width':2,'n_logical':2,'edges':[[0,1]],'profile_passes':True,'two_qubit_block_synthesis':enabled,'elide_output_permutations':False}
  requests.append(request);rows.append({'block':block['block'],'block_cx':block['cx_count'],'block_synthesis_enabled':enabled,'input_qasm':qasm})
p=subprocess.run([str(binary)],input=''.join(json.dumps(r)+'\n' for r in requests),capture_output=True,text=True,check=True);responses=[json.loads(x) for x in p.stdout.splitlines()];assert responses.pop(0)['ready']
for row,response in zip(rows,responses,strict=True):
 assert response['status']=='compiled';validation=validate_output(row['input_qasm'],response['out_qasm'],2,2,None,response['initial_layout'],response['final_layout']);assert validation['passed'];row.update(response=response,validation=validation)
 if row['block_synthesis_enabled']:print(row['block'],row['block_cx'],validation['metrics']['cx_count'],response['two_qubit_block_stats'])
result={'schema_version':1,'binary_sha256':hashlib.sha256(binary.read_bytes()).hexdigest(),'purpose':'compile each original collected two-wire block in isolation, paired with synthesis disabled; no output permutation elision','rows':rows}
(work/'isolated_block_controls.json').write_text(json.dumps(result,indent=2)+'\n')
