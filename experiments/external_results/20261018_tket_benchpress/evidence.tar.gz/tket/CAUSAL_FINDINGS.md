# TKET's error-correction reduction

This is a compiler diagnostic. It does not change Q-Rust or the historical benchmark results.

The normalized five-qubit input contains 49 CX, 62 H, two Sdg and one identity operation. It is a static Clifford unitary. In this comparison, the error-correction name does not imply that measurement, reset, classical feedback, or a noisy correction cycle was tested.

## Exact source reconstruction

The installed compiler is pytket 2.18.5. The matching upstream tag resolves to commit `4a554cbc2699de2f95da18eb3c30ff0961bcc536`. Seven downloaded implementation/binding files were checked against their Git blob identifiers in the pinned source tree.

Python callbacks expose only the outer `FullPeepholeOptimise` standard pass. The internal Transform sequence was therefore reconstructed from `tket/src/Transformations/OptimisationPass.cpp:44` using the installed public Transform bindings. It produces an exactly equal TKET Circuit object to the actual FullPeepholeOptimise result, including its phase and implicit permutation. This is not a substitution of the composite `ThreeQubitSquash` pass, which itself includes additional transformations.

| Step | CX | Depth after U3/CX snapshot lowering |
|---|---:|---:|
| Input | 49 | 77 |
| Remove redundancies and initial synthesis | 49 | 77 |
| Two-qubit squash, swaps disallowed | 47 | 76 |
| First Clifford simplification | 10 | 15 |
| Synthesis, swap-aware two-qubit squash, raw three-qubit squash | 10 | 15 |
| Second Clifford simplification | 9 | 13 |
| Final synthesis | 9 | 13 |

The final nine-CX result has identity initial and final maps and identity implicit permutation. Its advantage is not an uncounted final output swap.

## What actually accounts for the reduction

The input encodes eleven explicit SWAP identities as `CX(a,b); H(a); H(b); CX(a,b); H(a); H(b); CX(a,b)`. The middle H-conjugated CX reverses control and target, so the sequence is the standard three-CX SWAP. Q-Rust's separate diagnostic proves that recognizing these identities before its existing logical-SWAP handling reduces 47 CX to 14 with a final permutation, or 17 when that permutation is physically restored. This identifies a large missed permutation-recognition opportunity independently of TKET.

TKET's Clifford reduction is more general than a literal SWAP-pattern matcher. Its pinned implementation tracks the Pauli axes and signs of maximally entangling interactions through local Clifford gates and other gates with which the relevant axis commutes. Matching interactions are replaced with fewer interactions. When both local axes change, a permitted replacement includes a SWAP; the pass then absorbs swaps as wire permutations. `allow_swaps=False` excludes these rewrites, even if the final permutation would ultimately be identity. Source locations: `CliffordReductionPass.cpp:52` (interaction replacement), `:173` and `:234` (forward/backward propagation), `:299` (swap-enabled eligibility), `:311` (substitution), and `:750` (swap absorption).

Controlled results:

- Two CliffordSimp applications alone produce exactly the same nine-CX circuit as FullPeepholeOptimise.
- Omitting both two-qubit squash stages produces exactly the same nine-CX circuit.
- Omitting raw three-qubit squash produces exactly the same nine-CX circuit. It is a no-op on this trajectory.
- Omitting both Clifford simplifications still permits swap-aware KAK to reach 11 CX. The mechanisms can substitute for each other; reductions cannot be added as independent contributions.
- KAK alone with swaps disallowed gives 47 CX, matching Q-Rust's CX count; permitting swaps gives 11 CX on the original input.
- One CliffordSimp with swaps allowed gives 10 CX; disabling swaps gives 34 CX. FullPeepholeOptimise with swaps disabled gives 22 CX, since other stages can still help.

These measurements do not identify a general language-speed advantage or establish that nine CX is globally optimal.

## The final 10-to-9 reduction crosses block boundaries

After the first CliffordSimp, `CX(4,1)` occurs at command index 5 and `CX(1,4)` at index 23, with operations involving other qubits between them. An identity barrier on wires 1 and 4 inserted at every possible cut from 6 through 23 prevents the second round from reducing below 10 CX. Barriers outside that interval retain the nine-CX result. Every fenced output still represents the same complete unitary.

A separate local witness, consisting of those endpoint interactions and the intervening local rotations on wires 1 and 4, reduces two CX to one and passes its own complete-unitary comparison. Together with the exact source implementation, these interventions support a Clifford interaction rewrite that depends on commuting across intervening block boundaries. They do not expose internal per-rewrite C++ callbacks, and the local witness is a different circuit checked against itself.

## Representation and pass-order sensitivity

Feeding Q-Rust's already optimized 47-CX U3/CX output into TKET FullPeephole produces 10 CX, whereas feeding its 49-CX output with two-qubit block synthesis disabled produces nine. Both represent the same source unitary. The difference is heuristic sensitivity to the local representation/order, not a correctness failure.

On the input with the eleven SWAP identities made explicit, TKET FullPeephole still gives nine CX with identity output mapping. On Q-Rust's 14-CX output, TKET reduces to 10 CX; its implicit swap composes with Q-Rust's output map to give identity relative to the original fixture. These maps are composed explicitly in the independent checker.

A raw KAK stage can retain explicit SWAP operations on an explicitly SWAP-containing input. Raw `n_gates_of_type(CX)` alone then undercounts the final target cost: the corresponding U3/CX snapshot contains 44 CX, not the raw count of 11. All reported output-quality values here come from the same final U3/CX basis.

## Evidence and checks

- `evidence/trace_summary.json`: 51 pass snapshots, omissions, standalone-pass tests and matched-representation controls; all 32 computational-basis columns checked, with one shared global phase per comparison. Maximum residual against the original fixture is approximately 1.66e-15.
- `boundaries/boundary_summary.json`: 26 identity-fence outputs and one separate local witness, each checked on all 32 columns.
- `trace_tket.py` and `trace_clifford_boundary.py`: reproducible generators that refuse to overwrite output directories.
- `test_trace_tket.py`: seven passing regression tests for source reconstruction, causal omissions, Clifford rounds, barriers, permutation semantics, deleted-CX rejection and source integrity.
- Complete native Circuit JSON preserves phases, barriers and implicit permutations; normalized QASM and explicit maps preserve the independently validated emitted representation.

The checker uses analytic NumPy gate matrices and imports no competing compiler. Complete numerical unitary evidence is stronger than state-preparation-only testing, but remains numerical evidence rather than a formal proof. No new timing conclusions are drawn from these diagnostic runs.
