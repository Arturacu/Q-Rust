# TKET diagnostic archive inventory

Confirmed archive root layout: `tket/`, `qrust/`, `harness/experiments/`.

## Required for the exact TKET replay commands

- `tket/trace_tket.py`
- `tket/trace_clifford_boundary.py`
- `tket/test_trace_tket.py`
- `tket/source_tree.json`
- `tket/PassLibrary.cpp`
- `tket/PassGenerators.cpp`
- `tket/OptimisationPass.cpp`
- `tket/CliffordOptimisation.cpp`
- `tket/ThreeQubitSquash.cpp`
- `tket/CliffordReductionPass.cpp`
- `tket/transform.cpp`
- `tket/LICENSE.upstream`
- `tket/UPSTREAM_SOURCE_NOTICE.txt`
- `tket/evidence/input.qasm`
- `harness/experiments/comparison_validation.py`
- `qrust/block_1_phase_1_fusion_1.qasm`
- `qrust/block_0_phase_1_fusion_1.qasm`
- `qrust/all_swaps.input.qasm`
- `qrust/all_reversed_cx.input.qasm`
- `qrust/all_swaps.output.qasm`
- `qrust/swaps_with_elision_restored_identity_outputs.qasm`

Runtime dependencies for these commands are Python, NumPy and pytket 2.18.5. The seven upstream source snapshots are integrity/provenance inputs; they are not compiled during replay. The tests read the original input from `tket/evidence/input.qasm`, with the harness root passed through `QRUST_REPO`.

## Preserve as measured evidence, not merely replay inputs

Include every file in `tket/evidence/` and `tket/boundaries/`. These retain the 51 original TKET trace/control artifacts and their native phases/permutations, the 26 identity-fence artifacts and one separate local witness, summaries and exact inputs. Include `trace_run.log`, `boundary_run.log`, `tests.log`, and `CAUSAL_FINDINGS.md`. No executable binary is required for TKET replay.

Exclude `__pycache__/` and `.pyc` files. Do not overwrite the old evidence folders during replay; the generators require new destination directories.

## Upstream licensing

All seven C++ source/binding snapshots retain their original Quantinuum copyright and Apache-2.0 header. The upstream root LICENSE was fetched at pinned commit `4a554cbc2699de2f95da18eb3c30ff0961bcc536` into `LICENSE.upstream`; its Git blob SHA-1 matches `d9a10c0d8e868ebf8da0b3dc95bb0be634c34bfe` in the retained source tree. That recursive source tree contains no NOTICE or COPYING file. `UPSTREAM_SOURCE_NOTICE.txt` is a local provenance notice, not an invented upstream notice.
