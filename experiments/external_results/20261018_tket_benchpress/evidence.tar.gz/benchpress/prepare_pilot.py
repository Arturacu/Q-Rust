"""Freeze a bounded Benchpress pilot before compiling any selected circuit."""
from pathlib import Path
import hashlib
import importlib.metadata as metadata
import json
import platform
import sys

ROOT = Path(__file__).resolve().parent
REV = 'b695f30e83a32bac05b9b4d8e98d37ba9aae5236'
UPSTREAM = ROOT / ('benchpress-' + REV)
WORKING = ROOT.parents[1]
REPO = WORKING / 'qrust_pr_publish'
sys.path[:0] = [str(UPSTREAM), str(REPO / 'experiments')]
from qiskit import qasm2
from benchpress.utilities.backends import FlexibleBackend
from benchpress.qiskit_gym.circuits.circuits import bv_all_ones
from qiskit_ibm_runtime.fake_provider import FakeTorino
from external_corpus import canonical_source, unitary_prefix


def digest(data):
    return hashlib.sha256(data).hexdigest()


def write(path, obj):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(obj, indent=2, sort_keys=True) + '\n')


def main():
    out = ROOT / 'frozen'
    out.mkdir(exist_ok=False)
    tree = json.loads((WORKING / 'qrust_external_20261018/sources/benchpress_tree.json').read_text())
    checked = []
    for entry in tree['tree']:
        if entry['type'] != 'blob':
            continue
        data = (UPSTREAM / entry['path']).read_bytes()
        blob = hashlib.sha1(b'blob ' + str(len(data)).encode() + b'\0' + data).hexdigest()
        assert blob == entry['sha'], entry['path']
        checked.append({'path':entry['path'], 'sha256':digest(data), 'git_blob_sha1':blob})
    write(out / 'source_manifest.json', {'revision':REV, 'archive_sha256':digest((ROOT/'upstream.tar.gz').read_bytes()), 'files':checked})
    specs = [
        ('cat22', 'benchpress/qasm/qasmbench-medium/cat_state_n22/cat_state_n22.qasm'),
        ('ghz23', 'benchpress/qasm/qasmbench-medium/ghz_state_n23/ghz_state_n23.qasm'),
        ('clifford20', 'benchpress/qasm/clifford/clifford_20_12345.qasm'),
        ('bv100', None),
    ]
    cases = []
    inputs = []
    for label, path in specs:
        circuit = qasm2.load(str(UPSTREAM/path), custom_instructions=qasm2.LEGACY_CUSTOM_INSTRUCTIONS) if path else bv_all_ones(100)
        raw = (UPSTREAM/path).read_text() if path else qasm2.dumps(circuit) + '\n'
        (out / (label+'_raw.qasm')).write_text(raw)
        prefix, removed = unitary_prefix(circuit)
        canonical, expanded = canonical_source(prefix, max_gates=200000)
        (out / (label+'.qasm')).write_text(canonical)
        inp = {'id':label, 'n_logical':prefix.num_qubits, 'source_path':path or 'benchpress/qiskit_gym/circuits/circuits.py:bv_all_ones(100)', 'raw_sha256':digest(raw.encode()), 'qasm_sha256':digest(canonical.encode()), 'qasm_file':label+'.qasm', 'removed':removed, 'expanded':dict(expanded), 'input_gate_counts':dict(prefix.count_ops())}
        inputs.append(inp)
        for topology in ('square','heavy-hex'):
            backend = FlexibleBackend(prefix.num_qubits, topology)
            edges = sorted({tuple(sorted(e)) for e in backend.coupling_map.get_edges()})
            cases.append({'id':label+'_'+topology, 'family':label, 'qasm':canonical, 'n_logical':prefix.num_qubits, 'physical_width':backend.num_qubits, 'topology':topology.replace('-','_'), 'edges':edges, 'qasm_sha256':inp['qasm_sha256'], 'target_kind':'Benchpress FlexibleBackend topology; no calibration used in matched extension', 'source':inp})
    fake = FakeTorino()
    snapshots = []
    for name in (fake.conf_filename, fake.props_filename):
        p = Path(fake.dirname)/name
        (out/name).write_bytes(p.read_bytes())
        snapshots.append({'path':name, 'sha256':digest(p.read_bytes())})
    write(out/'fake_torino_snapshot.json', {'provider':'qiskit-ibm-runtime', 'provider_version':metadata.version('qiskit-ibm-runtime'), 'num_qubits':fake.num_qubits, 'operation_names':list(fake.operation_names), 'directed_edges':list(fake.coupling_map.get_edges()), 'files':snapshots})
    write(out/'cases.json', cases)
    packages = sorted(({'name':d.metadata['Name'], 'version':d.version} for d in metadata.distributions()),key=lambda r:r['name'].lower())
    write(out/'environment.json', {'python':sys.version, 'platform':platform.platform(), 'packages':packages, 'benchmark_fork':json.loads(metadata.distribution('pytest-benchmark').read_text('direct_url.json'))})
    protocol = {
        'study_kind':'bounded execution pilot, not comprehensive Benchpress score or holdout generalization',
        'benchpress_revision':REV, 'inputs':inputs,
        'native': {'workouts':['QASMBench medium cat_state_n22/ghz_state_n23 square/heavy-hex','device BV_100 on frozen FakeTorino'], 'sdks':['qiskit','tket','cirq'], 'basis':['id','sx','x','rz','cz'], 'qiskit_level':2, 'tket_level':2, 'repeat_sessions':2, 'minimum_rounds':3, 'benchmark_max_time_seconds':0.01, 'timeout_per_test_seconds':90, 'memory_soft_limit_gib':3.5, 'source_edits':False, 'capture':'returned final output after benchmark, outside timed region; native harness does not retain every timed artifact', 'native_validation':'upstream basis/topology checks; does not establish semantic equivalence', 'cirq_expected_status':'abstract and device tests unimplemented in pinned upstream gym; skip status preserved', 'seed_note':'unaltered upstream default stochastic transpiler settings; native GenericBackend properties are not seeded'},
        'extension': {'label':'Benchpress-sourced matched U/CX adapter extension', 'case_count':len(cases), 'sdks':['qrust','qiskit','cirq','tket'], 'source_adaptation':'remove only terminal measurement suffix and barriers; independently checked primitive definitions; no source optimization', 'topologies':['square','heavy_hex'], 'basis':['u3','cx'], 'validation':'map- and ancilla-aware signed-Clifford Choi-state equivalence; fail closed for non-Clifford local gates; independent local matrix recognition; structural basis/topology checks', 'sampling_note':'Clifford subset chosen for polynomial semantic validation, not representative of arbitrary non-Clifford compilation'},
        'resource_note':'8GiB host: execute subprocesses serially, enforce timeout and sampled RSS cap; keep failures/timeouts; no full-suite claim. Upstream recommends 96+GB for full multi-SDK suite.',
        'hardware_claims':'offline compiler results; device snapshots are not hardware execution or measured fidelity',
        'preservation':'all previous campaign paths read-only; new artifacts exclusively this experiment directory',
    }
    write(out/'protocol.json',protocol)
    print(json.dumps({'cases':len(cases), 'source_blobs_verified':len(checked), 'protocol_sha256':digest((out/'protocol.json').read_bytes())},indent=2))


if __name__ == '__main__':
    main()
