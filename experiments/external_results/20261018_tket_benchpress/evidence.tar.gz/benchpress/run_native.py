"""Serial resource-bounded execution of unedited native Benchpress workouts."""
from pathlib import Path
import hashlib
import json
import os
import random
import signal
import subprocess
import time
import psutil
import sys

ROOT=Path(__file__).resolve().parent
UPSTREAM=ROOT/'benchpress-b695f30e83a32bac05b9b4d8e98d37ba9aae5236'
PYTHON=ROOT/'env/bin/python'


def write(path,obj):
    path.write_text(json.dumps(obj,indent=2,sort_keys=True)+'\n')


def main():
    out=ROOT/(sys.argv[1] if len(sys.argv)>1 else 'native_results')
    out.mkdir(exist_ok=False)
    write(out/'driver_process.json',{'pid':os.getpid()})
    env=dict(os.environ, PYTHONPATH=str(ROOT)+os.pathsep+str(UPSTREAM),
             OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1',MKL_NUM_THREADS='1',
             VECLIB_MAXIMUM_THREADS='1',NUMEXPR_NUM_THREADS='1',RAYON_NUM_THREADS='1',
             QISKIT_PARALLEL='FALSE',QISKIT_NUM_PROCS='1',PYTHONHASHSEED='20261018')
    entries=[]
    for session in (1,2):
        jobs=[]
        for tool in ('qiskit','tket','cirq'):
            jobs.append((tool,'abstract', f'benchpress/{tool}_gym/abstract_transpile/test_qasmbench.py','(cat_state_n22 or ghz_state_n23) and (square or heavy-hex)'))
            jobs.append((tool,'device', f'benchpress/{tool}_gym/device_transpile/test_summit.py','BV_100_transpile'))
        random.Random(20261018+session).shuffle(jobs)
        for tool,kind,path,expression in jobs:
            label=f's{session}_{tool}_{kind}'
            capture=out/(label+'_artifacts')
            env['BENCHPRESS_CAPTURE_DIR']=str(capture)
            cmd=[str(PYTHON),'-m','pytest',path,'-k',expression,'-p','native_capture',
                '--benchmark-min-rounds=3','--benchmark-min-time=0.000000001',
                '--benchmark-max-time=0.000000001','--benchmark-calibration-precision=1',
                '--benchmark-warmup=on','--benchmark-warmup-iterations=1',
                '--benchmark-json='+str(out/(label+'.json')),
                '--benchmark-save-data','--timeout=90','--timeout-method=thread']
            log=out/(label+'.log')
            started=time.monotonic()
            reason=None;peak=0
            with log.open('w') as stream:
                process=subprocess.Popen(cmd,cwd=UPSTREAM,env=env,stdout=stream,stderr=subprocess.STDOUT,start_new_session=True)
                while process.poll() is None:
                    time.sleep(.25)
                    try:
                        rss=psutil.Process(process.pid).memory_info().rss
                        peak=max(peak,rss)
                    except psutil.NoSuchProcess: pass
                    if peak>int(3.5*2**30): reason='sampled_rss_limit_3.5GiB'
                    if time.monotonic()-started>400: reason='process_wall_timeout_400s'
                    if reason:
                        os.killpg(process.pid,signal.SIGKILL);process.wait();break
            entry={'session':session,'tool':tool,'kind':kind,'command':cmd,'returncode':process.returncode,'stop_reason':reason,'elapsed_seconds':time.monotonic()-started,'sampled_parent_peak_rss_bytes':peak,'memory_note':'0.25s psutil samples of pytest parent; not allocator accounting; no compiler child processes expected with disabled parallelism','log_sha256':hashlib.sha256(log.read_bytes()).hexdigest()}
            entries.append(entry)
            write(out/'execution_receipt.json',{'runs':entries,'thread_caps':{k:v for k,v in env.items() if k.endswith('NUM_THREADS') or k in ('QISKIT_PARALLEL','QISKIT_NUM_PROCS','PYTHONHASHSEED')},'upstream_files_edited':False})
            print(json.dumps({k:entry[k] for k in ('session','tool','kind','returncode','stop_reason','elapsed_seconds')},sort_keys=True),flush=True)
    print('native pilot complete',flush=True)


if __name__=='__main__': main()
