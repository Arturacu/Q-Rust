"""Capture native Benchpress's returned artifact after its timing completes.

No upstream source is edited. This plugin wraps only the reporting callback.
TKET mapping replay is additional untimed work and must match the artifact.
"""
import hashlib
import inspect
import json
import math
import os
from pathlib import Path


def _num(x):
    return format(float(x), '.17g')


def _dump(path, obj):
    path.write_text(json.dumps(obj, indent=2, sort_keys=True, default=str)+'\n')


def _qiskit(circuit, source, backend):
    from qiskit import qasm2
    width = circuit.num_qubits
    lines = ['OPENQASM 2.0;', 'include "qelib1.inc";', f'qreg q[{width}];']
    reads=[]
    for inst in circuit.data:
        name=inst.operation.name
        qs=[circuit.find_bit(q).index for q in inst.qubits]
        if name=='measure':
            reads.append([qs[0],circuit.find_bit(inst.clbits[0]).index]); continue
        if name=='barrier': continue
        params='('+','.join(_num(p) for p in inst.operation.params)+')' if inst.operation.params else ''
        lines.append(name+params+' '+','.join(f'q[{q}]' for q in qs)+';')
    initial=list(range(source.num_qubits)); final=list(initial)
    if circuit.layout:
        initial=circuit.layout.initial_index_layout(filter_ancillas=True)
        final=circuit.layout.final_index_layout(filter_ancillas=True)
    clocks=[0.0]*width
    missing=[]
    durations=[]
    for inst in circuit.data:
        name=inst.operation.name
        qs=[circuit.find_bit(q).index for q in inst.qubits]
        start=max((clocks[q] for q in qs),default=0.0)
        if name=='barrier':
            for q in qs: clocks[q]=start
            continue
        try:
            properties=backend.target[name][tuple(qs)]
            duration=properties.duration
        except (KeyError,TypeError,AttributeError): duration=None
        if duration is None:
            missing.append({'gate':name,'qubits':qs})
            continue
        durations.append({'gate':name,'qubits':qs,'duration_seconds':duration})
        for q in qs: clocks[q]=start+duration
    timing={'weighted_asap_duration_seconds':max(clocks) if not missing else None,
            'missing_duration_instructions':missing,'instruction_durations':durations,
            'model':'earliest start respecting emitted qubit order and barriers; target instruction durations; includes terminal measurement; excludes crosstalk, dynamic alignment constraints, queueing, shots and classical control',
            'interpretation':'offline model prediction, not measured device runtime or fidelity',
            'target_kind':'recorded FakeTorino device snapshot' if 'torino' in str(backend.name).lower() else 'synthetic GenericBackend durations'}
    return {'out_qasm':'\n'.join(lines)+'\n', 'source_qasm':qasm2.dumps(source), 'initial_layout':initial, 'final_layout':final, 'readout':reads, 'output_qubits':width, 'mapping_status':'direct_from_returned_artifact', 'native_contract':'default Qiskit zero-initialized semantics; terminal measurements retained in original artifact', 'native_qasm':qasm2.dumps(circuit), 'duration_model':timing}


def _tket(circuit, source, backend, pm):
    from pytket.predicates import CompilationUnit
    from pytket.qasm import circuit_to_qasm_str
    unit=CompilationUnit(source.copy())
    pm.apply(unit)
    same=unit.circuit.to_dict()==circuit.to_dict()
    originals=list(source.qubits)
    width=backend._backend.num_qubits
    def ix(q):
        assert q.reg_name in ('q','node') and len(q.index)==1
        return int(q.index[0])
    lines=['OPENQASM 2.0;', 'include "qelib1.inc";', f'qreg q[{width}];']
    reads=[]
    for cmd in circuit.get_commands():
        name=cmd.op.type.name.lower()
        qs=[ix(q) for q in cmd.qubits]
        if name=='measure':
            reads.append([qs[0],str(cmd.bits[0])]); continue
        if name in ('barrier','phase'): continue
        name={'noop':'id','u3':'u3'}.get(name,name)
        params='('+','.join(_num(float(p)*math.pi) for p in cmd.op.params)+')' if cmd.op.params else ''
        lines.append(name+params+' '+','.join(f'q[{q}]' for q in qs)+';')
    result={'out_qasm':'\n'.join(lines)+'\n', 'source_qasm':circuit_to_qasm_str(source), 'readout':reads, 'output_qubits':width, 'native_contract':'native default compilation pass with terminal measurements; source initialized in all-zero state', 'native_dict':circuit.to_dict(), 'replay_exact_artifact_equal':same, 'mapping_status':'bound_by_exact_untimed_replay' if same else 'unbound_replay_mismatch'}
    if same:
        inverse={b:a for a,b in circuit.implicit_qubit_permutation().items()}
        result['initial_layout']=[ix(unit.initial_map[q]) for q in originals]
        result['final_layout']=[ix(inverse[unit.final_map[q]]) for q in originals]
    return result


def pytest_configure(config):
    from benchpress.utilities import io
    from benchpress.config import Configuration
    original=io.output_circuit_properties
    def capture(circuit, two_q_gate, benchmark):
        caller=inspect.currentframe().f_back
        scope=caller.f_locals
        source=scope['circuit']
        backend=scope.get('backend',caller.f_globals.get('BACKEND'))
        original(circuit,two_q_gate,benchmark)
        tool=Configuration.gym_name
        info=_qiskit(circuit,source,backend) if tool=='qiskit' else _tket(circuit,source,backend,scope['pm'])
        info['tool']=tool
        info['nodeid']=benchmark.fullname
        info['output_qasm_sha256']=hashlib.sha256(info['out_qasm'].encode()).hexdigest()
        info['extra_info']=dict(benchmark.extra_info)
        if tool=='qiskit':
            info['target_edges']=list(backend.coupling_map.get_edges())
        else:
            info['target_edges']=list(backend._backend.coupling_map.get_edges())
        directory=Path(os.environ['BENCHPRESS_CAPTURE_DIR'])
        directory.mkdir(exist_ok=True,parents=True)
        name=hashlib.sha256(benchmark.fullname.encode()).hexdigest()[:20]+'.json'
        _dump(directory/name,info)
    io.output_circuit_properties=capture

