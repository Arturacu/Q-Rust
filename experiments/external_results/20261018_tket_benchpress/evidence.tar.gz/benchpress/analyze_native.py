"""Summarize completed native Benchpress output without concealing skips."""
from pathlib import Path
import argparse
import hashlib
import json
import re

ROOT=Path(__file__).resolve().parent


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--results',type=Path,default=ROOT/'native_results_v2')
    parser.add_argument('--output',type=Path,default=ROOT/'native_summary.json')
    args=parser.parse_args()
    RESULTS=args.results.resolve()
    receipt=json.loads((RESULTS/'execution_receipt.json').read_text())
    assert len(receipt['runs'])==12
    cells=[]
    statuses=[]
    artifacts=[]
    for run in receipt['runs']:
        label=f"s{run['session']}_{run['tool']}_{run['kind']}"
        raw=RESULTS/(label+'.json')
        log=(RESULTS/(label+'.log')).read_text()
        assert run['returncode']==0 and run['stop_reason'] is None,(label,run)
        data=json.loads(raw.read_text()) if raw.exists() and raw.stat().st_size else {}
        if run['tool']=='cirq':
            expected=4 if run['kind']=='abstract' else 1
            assert f'{expected} skipped' in log,label
            assert not data.get('benchmarks'),label
            statuses.append({'session':run['session'],'tool':run['tool'],'kind':run['kind'],'passed':0,'skipped':expected,'failed':0,'reason':'Not implemented in pinned upstream gym'})
            continue
        expected=4 if run['kind']=='abstract' else 1
        benchmarks=data['benchmarks']
        assert len(benchmarks)==expected
        assert f'{expected} passed' in log,label
        statuses.append({'session':run['session'],'tool':run['tool'],'kind':run['kind'],'passed':expected,'skipped':0,'failed':0})
        returned={}
        for f in sorted((RESULTS/(label+'_artifacts')).glob('*.json')):
            a=json.loads(f.read_text())
            returned[a['nodeid']]=a
            artifacts.append({'path':str(f.relative_to(ROOT)), 'sha256':hashlib.sha256(f.read_bytes()).hexdigest(), 'output_qasm_sha256':a['output_qasm_sha256'],'mapping_status':a['mapping_status']})
        for b in benchmarks:
            stats=b['stats']
            assert stats['rounds']==3 and stats['iterations']==1,(label,stats)
            a=returned[b['fullname']]
            info=b['extra_info']
            cells.append({'session':run['session'],'tool':run['tool'],'kind':run['kind'],'test':b['fullname'],'median_compile_seconds':stats['median'],'min_compile_seconds':stats['min'],'max_compile_seconds':stats['max'],'samples_seconds':stats['data'],'rounds':3,'iterations':1,'output_two_qubit_count':info['output_gate_count_2q'],'output_two_qubit_depth':info['output_depth_2q'],'output_operation_counts':info['output_circuit_operations'],'physical_qubits':a['output_qubits'],'logical_qubits':info['input_num_qubits'],'mapping_status':a['mapping_status'],'duration_model':a.get('duration_model'),'quality_artifact_note':'native final additional return invocation; quality is not paired with every stochastic timed sample'})
    totals={key:sum(r[key] for r in statuses) for key in ('passed','skipped','failed')}
    summary={'scope':'native unmodified Benchpress workloads with separate capture plugin', 'results_directory':str(RESULTS.relative_to(ROOT)), 'totals':totals,'timed_compilations':len(cells)*3,'cells':cells,'statuses':statuses,'artifacts':artifacts,'resource_observations':receipt['runs'],'limits':['native basis/topology validation is not semantic verification','captures represent final extra untimed invocation; do not infer semantics of all timed outputs','native default state-initialization assumptions and U/CZ native basis differ from matched U/CX unitary extension','only five selected workouts, two sessions, three rounds; not a complete Benchpress ranking','Cirq skips mean pinned harness lacks implementation, not that SDK routing is impossible','weightedASAPduration is an offline target model, not measured quantum runtime or fidelity'],'prior_attempts':{'native_failed_launch_01':'RSS ps invocation prohibited by sandbox; first Cirq test skipped, no supported compilation benchmark','native_results':'partial first measured attempt stopped after TKET100q source-export capture failure at maxwidth32; compilation succeeded, instrumentation failed; preserved without including in completed campaign summary'}}
    out=args.output
    assert not out.exists()
    out.write_text(json.dumps(summary,indent=2,sort_keys=True)+'\n')
    print(json.dumps({'totals':totals,'cells':len(cells),'timed_compilations':len(cells)*3,'peak_sampled_parent_rss_bytes':max(r['sampled_parent_peak_rss_bytes'] for r in receipt['runs'])},indent=2))


if __name__=='__main__': main()
