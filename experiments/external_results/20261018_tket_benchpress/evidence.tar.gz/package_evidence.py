#!/usr/bin/env python3
"""Package this investigation without modifying any prior result."""
from pathlib import Path
import gzip
import hashlib
import json
import shutil
import tarfile

ROOT = Path(__file__).resolve().parent
REPO = ROOT.parent / 'qrust_pr_publish'
STAGE = ROOT / 'archive_stage'
DEST = REPO / 'experiments/external_results/20261018_tket_benchpress'


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def copy(source, name):
    target = STAGE / name
    target.parent.mkdir(parents=True, exist_ok=True)
    shutil.copyfile(source, target)


def main():
    preserved = json.loads((ROOT / 'original_preservation.json').read_text())
    for entry in preserved['files']:
        if sha(REPO / entry['path']) != entry['sha256']:
            raise ValueError('Previous result changed: ' + entry['path'])
    STAGE.mkdir(exist_ok=False)
    DEST.mkdir(exist_ok=False)
    for folder in ('tket', 'qrust', 'verification', 'matched', 'qrust_portable_replay', 'block_probe', 'block_probe_v2'):
        for source in sorted((ROOT / folder).rglob('*')):
            if source.is_file() and not any(part in ('__pycache__', 'matplotlib_cache') for part in source.parts):
                copy(source, source.relative_to(ROOT))
    bench = ROOT / 'benchpress'
    for source in sorted(bench.iterdir()):
        if source.is_file() and source.suffix in ('.py', '.json', '.txt', '.log'):
            copy(source, source.relative_to(ROOT))
        elif source.is_dir() and (source.name == 'frozen' or source.name.startswith('native_') or source.name.endswith('_artifacts')):
            for child in sorted(source.rglob('*')):
                if child.is_file() and '__pycache__' not in child.parts:
                    copy(child, child.relative_to(ROOT))
    upstream = bench / 'benchpress-b695f30e83a32bac05b9b4d8e98d37ba9aae5236'
    for source in sorted(upstream.rglob('*')):
        if source.is_file() and (source.suffix == '.py' or source.name in ('README.md', 'LICENSE.txt', 'requirements.txt', 'pyproject.toml', 'setup.py', 'pytest.ini')):
            copy(source, Path('benchpress/upstream_reference') / source.relative_to(upstream))
    for source in sorted((REPO / 'experiments').glob('*.py')):
        copy(source, Path('harness/experiments') / source.name)
    for source in sorted((REPO / 'experiments/external_sources').rglob('*')):
        if source.is_file():
            copy(source, Path('harness') / source.relative_to(REPO))
    copy(REPO / 'experiments/external_sources.json', 'harness/experiments/external_sources.json')
    for name in ('requirements-comparison.txt', 'requirements.txt'):
        copy(REPO / 'experiments' / name, Path('harness/experiments') / name)
    for name in ('LICENSE', 'Cargo.toml', 'Cargo.lock'):
        source = REPO / name
        if source.exists():
            copy(source, Path('harness') / name)
    for name in ('original_preservation.json', 'python_preflight.log', 'matched_session_1.log', 'matched_session_2.log', 'matched_validation.log', 'matched_replay.log', 'audit_tests.log', 'qrust_portable_replay.log', 'block_probe.log', 'block_probe_v2.log', 'block_probe_receipt.json', 'package_evidence.py', 'final_tests.log'):
        source = ROOT / name
        if source.exists():
            copy(source, name)
    readme = '''# Evidence package

This package preserves the investigation's raw outcomes and provenance.
`tket/` and `qrust/` hold the five-qubit causal controls. `benchpress/`
contains completed native runs, earlier instrumentation failures, frozen
inputs and source manifests. `matched/` contains the separate four-compiler
campaign and validation. `verification/` contains additional independent
checks. `harness/experiments/` holds the frozen adapters and verification code.

No compiler binary, virtual environment or credentials are included.
`benchpress/upstream_reference/` is a source excerpt, not the full executable
upstream tree; retrieve the exact source archive and verify its recorded hash
for native reruns. Upstream LICENSE files accompany redistributed sources.

Every file except this manifest itself is bound by `manifest.json`. This is
an integrity manifest, not a signature. Original absolute paths in the frozen
protocols remain intact as provenance. Portable replay commands are in the
repository's TKET_CLIFFORD_INVESTIGATION.md and BENCHPRESS_PILOT.md reports.
Use new output paths; never overwrite archived evidence.
'''
    (STAGE / 'README.md').write_text(readme)
    members = {str(p.relative_to(STAGE)): {'bytes': p.stat().st_size, 'sha256': sha(p)}
               for p in sorted(STAGE.rglob('*')) if p.is_file()}
    (STAGE / 'manifest.json').write_text(json.dumps({'schema': 1, 'files': members}, indent=2, sort_keys=True) + '\n')
    archive = DEST / 'evidence.tar.gz'
    with archive.open('xb') as stream, gzip.GzipFile(fileobj=stream, mode='wb', filename='', mtime=0) as zipped, tarfile.open(fileobj=zipped, mode='w') as tar:
        for source in sorted(STAGE.rglob('*')):
            if source.is_file():
                info = tar.gettarinfo(source, arcname=str(source.relative_to(STAGE)))
                info.uid = info.gid = info.mtime = 0
                info.uname = info.gname = ''
                info.mode = 0o644
                with source.open('rb') as data:
                    tar.addfile(info, data)
    outputs = {'original_preservation.json': ROOT / 'original_preservation.json',
               'matched_summary.json': ROOT / 'matched/summary.json',
               'matched_protocol.json': ROOT / 'matched/protocol.json',
               'native_summary.json': bench / 'native_summary.json',
               'qrust_causal_summary.json': ROOT / 'qrust/causal_summary.json'}
    for name, source in outputs.items():
        shutil.copyfile(source, DEST / name)
    checksums = {p.name: {'bytes': p.stat().st_size, 'sha256': sha(p)} for p in sorted(DEST.iterdir()) if p.is_file()}
    (DEST / 'checksums.json').write_text(json.dumps({'schema': 1, 'files': checksums,
        'archive_member_count': len(members) + 1,
        'preserved_previous_files': len(preserved['files']),
        'production_compiler_unchanged': True}, indent=2, sort_keys=True) + '\n')
    print(json.dumps(checksums, indent=2))


if __name__ == '__main__':
    main()
