Q-Rust external candidate-retention evidence, 2026-10-18

This separately recorded study evaluates bounded routing candidates using
finished output costs while retaining a canonical incumbent. It keeps the
same 50 community fixtures, 100 target cells, six recipes, seeds, schedules,
packages, numerical oracle and trial design. All three earlier studies and
their reports remain unchanged.

The archive contains byte-exact protocol/corpus, both timed/warmup/validated
sessions, complete analysis JSON/CSV, cross-run analysis, frozen harness,
changed compiler and regression files, report and figures. It retains
exact-source policy ablations, the preliminary development probes, 80 new
synthetic stress cases and complete-column checks of all twelve focal cells.
Numerical checks and prespecified structural quality ceilings are separate
records. Source hashes and the compiler Git commit bind the full project;
executables, worker logs, caches and unrelated files are excluded. The two
explicit preflight test/build logs are retained and bound by their receipt.

BASELINE_REFERENCES.json binds all three preserved archives. The routing
archive is the immediate before/after baseline; the compatibility archive
provides the three recovery references; the original archive contains
upstream source, raw community circuits and licenses. Their payloads are
not duplicated here. The new protocol embeds every source and normalized
QASM input.

New-study replay: safely extract this archive; rename study/analysis to
study/recorded_analysis. In the pinned Python environment run:
python harness/experiments/analyze_external_comparison.py study
Compare external_summary.json and four CSV files byte-for-byte with recorded
copies. Existing output directories are rejected.

Cross-run replay: hash-check and extract the routing archive into
baseline_routing/. Run:
python harness/experiments/analyze_external_retention.py
baseline_routing/study study --plan receipts/investigation_plan.json
--output replayed_retention_analysis
Compare retention_comparison.json byte-for-byte with
retention_analysis/retention_comparison.json. Both analyzers use 2,000
bootstrap draws and retain separate sessions. The archived replay utility
safely extracts and verifies all four archives and compares all six outputs.
The optional analyzer preservation argument was not used: the independent
postflight and packaging receipts separately bind all 43 earlier files.

Every case and regression stays in the fixed cohort. Unchanged compiler
timings are descriptive host-drift controls. Exact-source policy ablations
supply separate mechanism evidence. CX count and depth are structural costs,
not proven optima or execution fidelity. Complete-column checking supplies
numerical evidence, not a formal proof. These fixtures informed the fixes;
they are not an untouched holdout. Synthetic coverage remains separate.

MANIFEST.json records every payload size and SHA256. The adjacent repository
evidence_manifest.json binds the archive hash and fresh extraction checks.
Archive metadata is normalized while all input bytes are preserved. All 43
earlier result/report files are hash-checked before and after packaging.
Existing archives, absent required receipts or changed frozen inputs fail.
