#!/usr/bin/env python3
"""Verify and replay the candidate-retention follow-up using only extracted evidence files."""
from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path, PurePosixPath
import subprocess
import sys
import tarfile

WORK = Path(__file__).resolve().parent
BASELINES = {
    "baseline_routing": ("20261018_routing", "39d4d8a5ab9e70e642c6e56de7bfca5ffd13a99bbaa59ad0fe9767084380b6c2"),
    "baseline_compatibility": ("20261018_compatibility", "edd32f94666b28c2c101cfe0487950c327e4f848cff001e39fb3da7e91ac2e1d"),
    "baseline_original": ("20261018", "d45176c9cbcf1c7645dfed44a343ec704fb34b9ab55002dcef4c62248285716f"),
}


def sha(path):
    if path.is_symlink() or not path.is_file():
        raise ValueError("Expected regular file: " + str(path))
    return hashlib.sha256(path.read_bytes()).hexdigest()


def safe_name(name):
    path = PurePosixPath(name)
    if (not name or path.is_absolute() or ".." in path.parts or "\\" in name
            or path.as_posix() != name or name == "."):
        raise ValueError("Unsafe archive path: " + name)
    return name


def extract(archive, manifest_path, target, expected_sha=None):
    manifest = json.loads(manifest_path.read_text())
    observed = sha(archive)
    if observed != manifest["archive_sha256"] or (expected_sha and observed != expected_sha):
        raise ValueError("Archive hash mismatch: " + str(archive))
    expected = {}
    for entry in manifest["files"]:
        name = safe_name(entry["path"])
        if name in expected:
            raise ValueError("Duplicate manifest entry")
        expected[name] = entry
    target.mkdir(parents=True, exist_ok=False)
    with tarfile.open(archive, "r:gz") as packaged:
        members = packaged.getmembers()
        names = [member.name for member in members]
        if len(names) != len(set(names)) or set(names) != set(expected):
            raise ValueError("Archive member inventory mismatch")
        for member in members:
            name = safe_name(member.name)
            if not member.isfile() or member.size != expected[name]["bytes"]:
                raise ValueError("Unexpected archive member type/size: " + name)
            data = packaged.extractfile(member).read()
            if hashlib.sha256(data).hexdigest() != expected[name]["sha256"]:
                raise ValueError("Archive payload hash mismatch: " + name)
            destination = target / name
            destination.parent.mkdir(parents=True, exist_ok=True)
            with destination.open("xb") as stream:
                stream.write(data)
    embedded = json.loads((target / "MANIFEST.json").read_text())
    listed = {entry["path"]: entry for entry in embedded["files"]}
    if len(listed) != len(embedded["files"]) or set(listed) != set(expected) - {"MANIFEST.json"}:
        raise ValueError("Embedded manifest inventory differs")
    for name, entry in listed.items():
        if entry != expected[name] or sha(target / name) != entry["sha256"]:
            raise ValueError("Embedded and external manifests disagree")
    return {"archive_sha256": observed, "payload_files": len(expected)}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--repo", type=Path, default=WORK.parent / "qrust_pr_publish")
    parser.add_argument("--output", type=Path, default=WORK / "archive_replay")
    args = parser.parse_args()
    root = args.repo / "experiments/external_results"
    destination = root / "20261018_retention"
    receipt_path = destination / "archive_reanalysis_receipt.json"
    if receipt_path.exists():
        raise FileExistsError("Replay receipt already exists")
    if (WORK / "study/active.lock").exists():
        raise ValueError("Cannot replay during active timing")
    args.output.mkdir(parents=True, exist_ok=False)
    counts = {}
    archives = {"retention": ("20261018_retention", None), **BASELINES}
    for label, (directory, expected_sha) in archives.items():
        counts[label] = extract(root / directory / "evidence.tar.gz", root / directory / "evidence_manifest.json",
                                args.output / label, expected_sha)
    new = args.output / "retention"
    routing = args.output / "baseline_routing"
    references = json.loads((new / "BASELINE_REFERENCES.json").read_text())
    for label in ("routing", "compatibility", "original"):
        if references[label]["archive_sha256"] != counts["baseline_" + label]["archive_sha256"]:
            raise ValueError("Archived baseline reference mismatch")
    recorded = json.loads((new / "retention_analysis/retention_comparison.json").read_text())
    if recorded["original_preservation"] is not None:
        raise ValueError("Recorded analyzer options do not permit extracted-only byte-exact replay")
    (new / "study/analysis").rename(new / "study/recorded_analysis")
    commands = [
        [sys.executable, str(new / "harness/experiments/analyze_external_comparison.py"), str(new / "study")],
        [sys.executable, str(new / "harness/experiments/analyze_external_retention.py"),
         str(routing / "study"), str(new / "study"), "--plan", str(new / "receipts/investigation_plan.json"),
         "--output", str(new / "replayed_retention_analysis")],
    ]
    for command in commands:
        subprocess.run(command, check=True)
    checks = []
    for name in ("external_summary.json", "session_1_primary_cells.csv", "session_1_light_cells.csv",
                 "session_2_primary_cells.csv", "session_2_light_cells.csv"):
        before, after = new / "study/recorded_analysis" / name, new / "study/analysis" / name
        if before.read_bytes() != after.read_bytes():
            raise ValueError("Replay differs: " + name)
        checks.append({"path": "study/analysis/" + name, "sha256": sha(before), "byte_identical": True})
    before = new / "retention_analysis/retention_comparison.json"
    after = new / "replayed_retention_analysis/retention_comparison.json"
    if before.read_bytes() != after.read_bytes():
        raise ValueError("Cross-run retention replay differs")
    checks.append({"path": "retention_analysis/retention_comparison.json", "sha256": sha(before), "byte_identical": True})
    receipt = {
        "passed": True, "scope": "Fresh safe extraction of all four hash-bound archives; full new-study and cross-run analysis rerun using only extracted evidence",
        "archives": counts, "outputs": checks, "bootstrap_draws": 2000,
        "sessions_analyzed_separately": True, "script_sha256": sha(Path(__file__)),
    }
    with receipt_path.open("x") as stream:
        stream.write(json.dumps(receipt, indent=2) + "\n")
    print(json.dumps(receipt, indent=2))


if __name__ == "__main__":
    main()
