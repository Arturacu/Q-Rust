#!/usr/bin/env python3
"""Independent standard-library recount of frozen candidate-retention evidence.

No benchmark/analyzer/validation module is imported. Emitted U/CX QASM is
reparsed for quality metrics; existing numerical evidence is integrity-checked,
not independently simulated here. Session observations are never pooled.
"""
import argparse
from collections import Counter, defaultdict
import hashlib
import json
import math
from pathlib import Path
import re
import statistics


def sha(data):
    return hashlib.sha256(data.encode() if isinstance(data, str) else data).hexdigest()


def file_sha(path):
    return sha(path.read_bytes())


def canon(value):
    return json.dumps(value, sort_keys=True, separators=(",", ":"), allow_nan=False)


def rows(path):
    with path.open() as handle:
        for line in handle:
            if line.strip():
                yield json.loads(line)


def require(condition, message):
    if not condition:
        raise AssertionError(message)


QUALITY = ("cx_count", "gate_count", "depth", "two_q_depth")
METRICS = ("compile_ns", "request_wall_ns", *QUALITY)
FOCAL = {"mqtbench__ae_n10", "mqtbench__qpeexact_n10", "mqtbench__qpeinexact_n10",
         "qasmbench__basis_trotter_n4", "qasmbench__pea_n5", "qasmbench__qft_n4"}
ALLOWED = {"src/transpiler/" + x for x in ("layout.rs", "mod.rs", "candidate_selection.rs", "numerical_policy.rs", "routing.rs")} | {
    "tests/routing_candidate_regressions.rs"}


def emitted_metrics(source, width, case):
    one = [0] * width
    two = [0] * width
    gates = cx = 0
    edges = {frozenset(edge) for edge in case["edges"]}
    for statement in re.sub(r"//[^\n]*", "", source).split(";"):
        statement = statement.strip()
        if not statement:
            continue
        if statement.startswith(("OPENQASM ", "include ")):
            continue
        if statement.startswith("qreg "):
            declaration = re.fullmatch(r"qreg\s+q\[(\d+)\]", statement)
            require(declaration and int(declaration[1]) == width, "QASM width mismatch")
            continue
        parsed = re.fullmatch(r"(u3|u|cx)(?:\([^)]*\))?\s+(.+)", statement)
        require(parsed is not None, "Unexpected emitted basis statement: " + statement)
        gate, operands = parsed.groups()
        wires = [int(x) for x in re.findall(r"q\[(\d+)\]", operands)]
        require(len(wires) == (2 if gate == "cx" else 1), "Operand arity mismatch")
        require(len(set(wires)) == len(wires) and all(0 <= x < width for x in wires), "Invalid operand")
        require(re.fullmatch(r"q\[\d+\](?:\s*,\s*q\[\d+\])?", operands), "Unexpected operand syntax")
        level = max(one[q] for q in wires) + 1
        for q in wires:
            one[q] = level
        gates += 1
        if gate == "cx":
            require(frozenset(wires) in edges, "CX violates coupling graph")
            cx += 1
            level = max(two[q] for q in wires) + 1
            for q in wires:
                two[q] = level
    return dict(cx_count=cx, gate_count=gates, depth=max(one, default=0), two_q_depth=max(two, default=0))


def audit_study(path, protocol, checksum):
    case_by_id = {c["id"]: c for c in protocol["cases"]}
    result, inputs, unique_metrics, unique_artifacts = {}, {}, {}, {}
    receipt = json.loads((path / "validation_summary.json").read_text())
    require(receipt["protocol_sha256"] == checksum, "Validation protocol mismatch")
    require(receipt["oracle_sha256"] == protocol["source_sha256"]["experiments/comparison_validation.py"], "Oracle mismatch")
    inputs["validation_summary.json"] = file_sha(path / "validation_summary.json")
    require(not (path / "active.lock").exists(), "Study remains active")
    for session in (1, 2):
        folder = path / f"session_{session:02d}"
        metadata = json.loads((folder / "session.json").read_text())
        startup = json.loads((folder / "startup.json").read_text())
        require(not startup.get("errors"), "Worker startup failed")
        require(metadata["completed"] and metadata["session"] == session and metadata["protocol_sha256"] == checksum, "Session mismatch")
        require(file_sha(folder / "protocol.json") == checksum, "Session frozen protocol mismatch")
        for name in ("timed", "warmup"):
            require(file_sha(folder / (name + ".jsonl")) == metadata[name + "_sha256"], "Recorded rows changed")
        validated_receipt = next(s for s in receipt["sessions"] if s["session"] == folder.name)
        require(file_sha(folder / "validated.jsonl") == validated_receipt["validated_sha256"], "Validated rows changed")
        for name in ("session.json", "startup.json", "protocol.json", "timed.jsonl", "warmup.jsonl", "validated.jsonl"):
            inputs[folder.name + "/" + name] = file_sha(folder / name)
        grouped = defaultdict(list)
        identities = {}
        warm = {}
        outcome = Counter()
        for mode, output in (("timed", identities), ("warmup", warm)):
            schedule = [x for x in protocol["schedules"][str(session)] if (x["trial"] < 0) == (mode == "warmup")]
            actual = list(rows(folder / (mode + ".jsonl")))
            require(len(actual) == len(schedule) == (4200 if mode == "timed" else 600), "Wrong prescribed row count")
            for row, request in zip(actual, schedule):
                require(all(row.get(k) == v for k, v in request.items()), "Schedule/order changed")
                key = (row["case_id"], row["tool"], row["trial"])
                require(key not in output and row["session"] == session, "Duplicate or wrong-session row")
                require(row["id"] == f"{key[0]}__{key[1]}__{key[2]}", "Trial ID mismatch")
                require(row["seed"] == protocol["master_seed"] + max(0, row["trial"]), "Seed mismatch")
                require(row["status"] == "compiled", "Non-compiling row: " + row["id"])
                outcome[mode + "_compiled"] += 1
                case = case_by_id[row["case_id"]]
                width = case["physical_width"]
                require(row["output_qubits"] == width, "Output width mismatch")
                for field in ("initial_layout", "final_layout"):
                    layout = row[field]
                    require(len(layout) == case["n_logical"] and len(set(layout)) == len(layout)
                            and all(type(q) is int and 0 <= q < width for q in layout), "Invalid layout")
                require(sha(row["out_qasm"]) == row["output_sha256"], "Output hash mismatch")
                bound = {"source": case["source_sha256"], "normalized": case["normalized_sha256"],
                         "physical_width": width, "topology": case["topology"], "edges": case["edges"],
                         "output": row["output_sha256"], "initial_layout": row["initial_layout"],
                         "final_layout": row["final_layout"], "output_qubits": row["output_qubits"]}
                require(sha(canon(bound)) == row["artifact_sha256"], "Artifact/layout hash mismatch")
                metric_key = row["output_sha256"], case["topology"], width
                if metric_key not in unique_metrics:
                    unique_metrics[metric_key] = emitted_metrics(row["out_qasm"], width, case)
                metrics = unique_metrics[metric_key]
                require(all(type(row[m]) is int and row[m] > 0 for m in ("compile_ns", "request_wall_ns")), "Invalid timing")
                require(row["request_wall_ns"] == row["compile_ns"] + row["parse_ns"] + row["noncompile_nonparse_request_ns"], "Request decomposition mismatch")
                output[key] = {
                    "raw_sha256": sha(canon(row)), "artifact_sha256": row["artifact_sha256"],
                    "output_sha256": row["output_sha256"], "initial_layout": row["initial_layout"],
                    "final_layout": row["final_layout"], "metrics": metrics,
                }
                if mode == "timed":
                    grouped[row["case_id"], row["tool"]].append({
                        **metrics, "compile_ns": row["compile_ns"], "request_wall_ns": row["request_wall_ns"]})
        checked = list(rows(folder / "validated.jsonl"))
        require(len(checked) == 4200, "Missing validated rows")
        validated_keys = set()
        validation_counts = Counter()
        max_residual = defaultdict(float)
        for row in checked:
            key = (row["case_id"], row["tool"], row["trial"])
            require(key not in validated_keys and key in identities, "Unknown/duplicate validated row")
            validated_keys.add(key)
            raw = {k: v for k, v in row.items() if k not in {"validation", "validation_cache_key"}}
            require(sha(canon(raw)) == identities[key]["raw_sha256"], "Validation changed raw measurements")
            evidence = row["validation"]
            require(evidence["passed"] and evidence["basis_legal"] and evidence["coupling_legal"], "Validation failed")
            require(evidence["metrics"] == identities[key]["metrics"], "Independent quality recount differs")
            expected_class = "full_isometry" if case_by_id[key[0]]["n_logical"] <= 6 else "sampled_isometry"
            require(evidence["evidence_class"] == expected_class, "Incorrect validation class")
            unique_artifacts[row["artifact_sha256"]] = expected_class
            validation_counts[row["tool"] + "_passed"] += 1
            max_residual[row["tool"]] = max(max_residual[row["tool"]], evidence["max_input_residual"])
        require(dict(validation_counts) == validated_receipt["counts"], "Validation count receipt mismatch")
        medians = {}
        for key, values in grouped.items():
            require(len(values) == 7, "Incomplete recipe-case cell")
            medians[key] = {m: statistics.median(v[m] for v in values) for m in METRICS}
        require(len(medians) == 600, "Wrong recipe-case grid")
        result[session] = dict(medians=medians, identities=identities, warmup=warm,
                               counts=dict(outcome), max_residual=dict(max_residual), session_metadata=metadata)
    require(len(unique_artifacts) == receipt["unique_artifacts"], "Unique artifact count mismatch")
    require(dict(Counter(unique_artifacts.values())) == receipt["unique_evidence_classes"], "Unique evidence count mismatch")
    return result, inputs, receipt


def ratio_stats(pairs):
    zeros = Counter({"both_zero": 0, "numerator_zero": 0, "denominator_zero": 0})
    logs = []
    for numerator, denominator in pairs:
        if numerator == 0 or denominator == 0:
            zeros["both_zero" if numerator == denominator else "numerator_zero" if numerator == 0 else "denominator_zero"] += 1
        else:
            logs.append(math.log(numerator / denominator))
    return dict(paired_cells=len(pairs), positive_ratio_cells=len(logs), zero_cases=dict(zeros),
                geomean=math.exp(math.fsum(logs) / len(logs)) if logs else None)


def same(actual, expected, where):
    if actual is None or expected is None:
        require(actual == expected, "Aggregate mismatch: " + where)
    else:
        require(math.isclose(actual, expected, rel_tol=2e-12, abs_tol=1e-13), "Aggregate mismatch: " + where)


def audit_quality_targets(plan, cases, old, new):
    """Recount trial-level ceilings from the independently reparsed output metrics."""
    declared = plan["predeclared_quality_ceilings"]
    focal = {key for key, case in cases.items() if case["fixture"] in FOCAL}
    require(len(declared) == 12 and {item["case_id"] for item in declared} == focal,
            "Predeclared target grid differs")
    target_metrics = ("cx_count", "depth", "two_q_depth")
    targets, regressions = [], []
    for session in (1, 2):
        for key, output in sorted(new[session]["identities"].items()):
            if key[1] != "qrust":
                continue
            previous = old[session]["identities"][key]["metrics"]
            exceeded = {metric: {"before": previous[metric], "after": output["metrics"][metric]}
                        for metric in target_metrics if output["metrics"][metric] > previous[metric]}
            if exceeded:
                regressions.append({"session": session, "case_id": key[0], "trial": key[2],
                                    "regressed_metrics": exceeded})
        for target in sorted(declared, key=lambda item: item["case_id"]):
            case_id, cap = target["case_id"], target["reference_metrics"]
            records = [(key, output["metrics"]) for key, output in new[session]["identities"].items()
                       if key[0] == case_id and key[1] == "qrust"]
            require(len(records) == 7 and set(cap) == set(target_metrics), "Target trial grid/metrics differs")
            if target["reference_study"] == "routing":
                require(all(all(old[session]["identities"][key]["metrics"][m] == cap[m] for m in cap)
                            for key, _ in records), "Retention ceiling is not the measured baseline")
            failed = [{"trial": key[2], "metrics": metrics,
                       "exceeded_metrics": [m for m in target_metrics if metrics[m] > cap[m]]}
                      for key, metrics in records if any(metrics[m] > cap[m] for m in target_metrics)]
            targets.append({"session": session, "case_id": case_id, "passed": not failed,
                            "trials_checked": len(records), "failed_trials": sorted(failed, key=lambda row: row["trial"]),
                            "observed_ranges": {m: {"min": min(values[m] for _, values in records),
                                                     "max": max(values[m] for _, values in records)} for m in target_metrics}})
    return {"metrics": list(target_metrics), "focal_case_count": 12, "focal_session_cells": len(targets),
            "focal_trials_checked": sum(t["trials_checked"] for t in targets), "focal_targets": targets,
            "all_focal_targets_passed": all(t["passed"] for t in targets),
            "full_cohort_trials_checked": 1400, "full_cohort_regressed_trials": regressions,
            "full_cohort_nonworsening_passed": not regressions}


def audit(repo, baseline, candidate, work):
    for name in ("independent_postflight_detail.json", "independent_postflight_receipt.json"):
        require(not (work / name).exists(), "Refusing to overwrite completed audit: " + name)
    require((work / "retention_analysis/retention_comparison.json").is_file(), "Retention analysis must finish before this audit")
    require((candidate / "analysis/external_summary.json").is_file(), "External analysis must finish before this audit")
    p = json.loads((candidate / "protocol.json").read_text())
    oldp = json.loads((baseline / "protocol.json").read_text())
    psha, oldsha = file_sha(candidate / "protocol.json"), file_sha(baseline / "protocol.json")
    require(psha == (candidate / "protocol.sha256").read_text().strip(), "Protocol checksum mismatch")
    require(oldsha == (baseline / "protocol.sha256").read_text().strip(), "Baseline protocol checksum mismatch")
    variables = {"created_utc", "compiler_commit", "compiler_provenance", "qrust_binary_sha256", "source_sha256", "machine_note"}
    require(p.keys() == oldp.keys(), "Protocol fieldset differs")
    require(all(p[k] == oldp[k] for k in p if k not in variables), "Fixed protocol settings changed")
    require(p["source_sha256"] == oldp["source_sha256"], "Frozen harness changed")
    sourcehash = p["compiler_provenance"]["compiler_source_sha256"]
    oldsource = oldp["compiler_provenance"]["compiler_source_sha256"]
    changed = {k for k in sourcehash.keys() | oldsource.keys() if sourcehash.get(k) != oldsource.get(k)}
    require(changed <= ALLOWED and "src/transpiler/candidate_selection.rs" in changed, "Unexpected compiler source diff")
    for name, expected in {**p["source_sha256"], **sourcehash}.items():
        require(file_sha(repo / name) == expected, "Source differs from frozen hash: " + name)
    require(sha(canon(sourcehash)) == p["compiler_provenance"]["compiler_source_manifest_sha256"], "Compiler manifest hash mismatch")
    require(file_sha(work / "comparison_runner_fixed") == p["qrust_binary_sha256"], "Compiler binary changed")
    require(file_sha(candidate / "corpus_manifest.json") == p["corpus_manifest_sha256"], "Corpus hash mismatch")
    require((candidate / "corpus_manifest.json").read_bytes() == (baseline / "corpus_manifest.json").read_bytes(), "Corpus bytes changed")
    require(file_sha(work / "original_preservation.json") == "61818c58b3bcb043dd427d0bba7173ff1edca6c00d9aef71dc3fb1c03410d38c", "Preservation receipt changed")
    require(file_sha(work / "investigation_plan.json") == "29799fcc11fd5b4b74cc095b0a8e9b00209bbf76220aa1ecb9e9d8511fd27416", "Prespecified plan changed")
    plan = json.loads((work / "investigation_plan.json").read_text())
    require(plan["baseline_protocol_sha256"] == oldsha, "Plan baseline protocol mismatch")
    require(plan["baseline_binary_sha256"] == oldp["qrust_binary_sha256"], "Plan baseline binary mismatch")
    require(plan["corpus_manifest_sha256"] == p["corpus_manifest_sha256"], "Plan corpus mismatch")
    preserved = json.loads((work / "original_preservation.json").read_text())
    require(len(preserved["sha256"]) == 43, "Unexpected preservation inventory")
    for name, expected in preserved["sha256"].items():
        require(file_sha(repo / name) == expected, "Original artifact changed: " + name)
    old, oldinputs, oldvalidation = audit_study(baseline, oldp, oldsha)
    new, newinputs, newvalidation = audit_study(candidate, p, psha)
    archived_manifest = json.loads((repo / "experiments/external_results/20261018_routing/evidence_manifest.json").read_text())
    archived_hashes = {item["path"]: item["sha256"] for item in archived_manifest["files"]}
    baseline_bindings = {**oldinputs, "protocol.json": oldsha,
                         "corpus_manifest.json": file_sha(baseline / "corpus_manifest.json")}
    for name, checksum in baseline_bindings.items():
        require(archived_hashes["study/" + name] == checksum, "Baseline input differs from preserved archive: " + name)
    for study in (old, new):
        require(study[1]["session_metadata"]["finished_utc"] <= study[2]["session_metadata"]["started_utc"],
                "Timing sessions overlap")
    cases = {c["id"]: c for c in p["cases"]}
    require(len(cases) == 100, "Wrong case count")
    focal = [k for k, c in cases.items() if c["fixture"] in FOCAL]
    require(len(focal) == 12 and len({cases[k]["fixture"] for k in focal}) == 6, "Wrong focal cohort")
    detail = {"sessions": {}}
    receipt = dict(schema=1, passed=True, protocol_sha256=psha, baseline_protocol_sha256=oldsha,
                   original_preserved_files=43, changed_compiler_paths=sorted(changed), frozen_harness_files=len(p["source_sha256"]),
                   baseline_inputs_matching_preserved_archive=len(baseline_bindings),
                   compiler_source_files=len(sourcehash), baseline_input_sha256=oldinputs, candidate_input_sha256=newinputs,
                   candidate_validation_summary=newvalidation, source_sha256=file_sha(Path(__file__)),
                   independent_metric_recount="Standard-library parse of every unique emitted U/CX QASM; ASAP depth and CX-only depth independently recounted.",
                   numerical_limit="Existing numerical evidence checked for hash/identity/coverage only; no independent simulation rerun by this audit.",
                   sessions={})
    detail["quality_acceptance"] = audit_quality_targets(plan, cases, old, new)
    receipt["investigation_plan_sha256"] = file_sha(work / "investigation_plan.json")
    for session in (1, 2):
        om, nm = old[session]["medians"], new[session]["medians"]
        cells, before_after, pairwise, adverse = {}, {}, {}, {}
        identity_counts = Counter()
        for key, row in new[session]["identities"].items():
            other = old[session]["identities"][key]
            changed_fields = [field for field in ("artifact_sha256", "output_sha256", "initial_layout", "final_layout", "metrics") if row[field] != other[field]]
            identity_counts[key[1] + ("_changed" if changed_fields else "_identical")] += 1
            if key[1] != "qrust":
                require(not changed_fields, "Unchanged compiler output differs: " + str(key))
        for recipe in p["tools"]:
            before_after[recipe] = {}
            cells[recipe] = []
            adverse[recipe] = {m: [] for m in METRICS}
            for case in cases:
                left, right = om[case, recipe], nm[case, recipe]
                cells[recipe].append(dict(case_id=case, before=left, after=right))
                for metric in METRICS:
                    if right[metric] > left[metric]:
                        adverse[recipe][metric].append(dict(case_id=case, before=left[metric], after=right[metric],
                                                           ratio=right[metric] / left[metric] if left[metric] else None))
            for cohort, selected in (("all_100", list(cases)), ("focal_12", focal),
                                     ("focal_linear_6", [c for c in focal if cases[c]["topology"] == "linear"])):
                before_after[recipe][cohort] = {m: ratio_stats([(nm[c, recipe][m], om[c, recipe][m]) for c in selected]) for m in METRICS}
            for metric in METRICS:
                adverse[recipe][metric].sort(key=lambda r: (r["ratio"] is None, r["ratio"] or 0), reverse=True)
        for recipe in p["tools"]:
            if recipe == "qrust":
                continue
            pairwise[recipe] = {}
            for metric in METRICS:
                observations = [(nm[c, recipe][metric], nm[c, "qrust"][metric]) if metric.endswith("_ns") else
                                (nm[c, "qrust"][metric], nm[c, recipe][metric]) for c in cases]
                pairwise[recipe][metric] = ratio_stats(observations)
        detail["sessions"][str(session)] = dict(before_after=before_after, pairwise=pairwise, cells=cells, adverse=adverse,
                                                 focal={c: {r: dict(before=om[c, r], after=nm[c, r]) for r in p["tools"]} for c in focal})
        receipt["sessions"][str(session)] = dict(counts=new[session]["counts"], max_residual=new[session]["max_residual"],
                                                  before_after_identity_counts=dict(identity_counts),
                                                  qrust_adverse_counts={m: len(adverse["qrust"][m]) for m in METRICS},
                                                  baseline_adverse_quality_counts={r: {m: len(adverse[r][m]) for m in QUALITY} for r in p["tools"] if r != "qrust"})
    consistent = Counter()
    for key, one in new[1]["identities"].items():
        two = new[2]["identities"][key]
        require(all(one[f] == two[f] for f in ("artifact_sha256", "output_sha256", "initial_layout", "final_layout", "metrics")), "Same-seed output changed across sessions")
        consistent[key[1]] += 1
    receipt["same_seed_session_identity"] = dict(consistent)
    artifact_set = {r["artifact_sha256"] for session in new.values() for r in session["identities"].values()}
    receipt["warmup_artifacts_matching_timed"] = sum(row["artifact_sha256"] in artifact_set for session in new.values() for row in session["warmup"].values())
    analysis_path = work / "retention_analysis/retention_comparison.json"
    if analysis_path.exists():
        analysis = json.loads(analysis_path.read_text())
        require(analysis["analysis"] == "routing_retention_followup", "Wrong analysis kind")
        require(analysis["original_protocol_sha256"] == oldsha and analysis["followup_protocol_sha256"] == psha,
                "Analyzer protocol hashes differ")
        require(analysis["investigation_plan_sha256"] == receipt["investigation_plan_sha256"], "Analyzer plan hash differs")
        require(analysis["analysis_source_sha256"] == file_sha(repo / "experiments/analyze_external_retention.py"),
                "Analyzer source changed")
        for name, checksum in analysis["analysis_dependency_sha256"].items():
            require(file_sha(repo / "experiments" / name) == checksum, "Analyzer dependency changed: " + name)
        require(analysis["non_qrust_identity"]["paired_trials"] == 7000
                and analysis["non_qrust_identity"]["identical_trials"] == 7000
                and analysis["non_qrust_identity"]["all_identical"], "Unchanged SDK identity total differs")
        for name, study in (("original", old), ("followup", new)):
            count = sum(all(row[field] == study[2]["identities"][key][field] for field in
                            ("artifact_sha256", "output_sha256", "initial_layout", "final_layout", "metrics"))
                        for key, row in study[1]["identities"].items())
            reported = analysis["same_seed_session_identity"][name]
            require(reported["paired_trials"] == 4200 and reported["identical_trials"] == count
                    and reported["all_identical"] == (count == 4200), "Cross-session identity count differs")
        independent_targets = detail["quality_acceptance"]
        reported_targets = analysis["quality_acceptance"]
        for key in ("metrics", "focal_case_count", "focal_session_cells", "focal_trials_checked",
                    "all_focal_targets_passed", "full_cohort_trials_checked", "full_cohort_nonworsening_passed"):
            require(independent_targets[key] == reported_targets[key], "Target acceptance summary differs: " + key)
        reported_cells = {(row["session"], row["case_id"]): row for row in reported_targets["focal_targets"]}
        require(len(reported_cells) == 24, "Target acceptance cells differ")
        for row in independent_targets["focal_targets"]:
            expected = reported_cells[row["session"], row["case_id"]]
            for key in ("passed", "trials_checked", "observed_ranges"):
                require(row[key] == expected[key], "Per-trial target acceptance differs: " + key)
            strip_seed = [{k: v for k, v in trial.items() if k != "seed"} for trial in expected["failed_trials"]]
            require(row["failed_trials"] == sorted(strip_seed, key=lambda item: item["trial"]), "Failed target trials differ")
        strip_seed = [{k: v for k, v in row.items() if k != "seed"}
                      for row in reported_targets["full_cohort_regressed_trials"]]
        require(independent_targets["full_cohort_regressed_trials"] == strip_seed, "Full-cohort regressed trials differ")
        receipt["quality_target_recomputation"] = {"passed": True, "focal_trials_checked": 168,
                                                   "full_cohort_trials_checked": 1400}
        comparisons = 0
        for session in ("1", "2"):
            for recipe in p["tools"]:
                for cohort, field in (("all_100", "recipes"), ("focal_12", "recipes_on_focal")):
                    for metric in METRICS:
                        actual = detail["sessions"][session]["before_after"][recipe][cohort][metric]
                        expected = analysis["sessions"][session][field][recipe]["ratios"][metric]
                        same(actual["geomean"], expected["geomean"], f"{session}/{recipe}/{cohort}/{metric}")
                        for name in ("paired_cells", "positive_ratio_cells", "zero_cases"):
                            require(actual[name] == expected[name], "Aggregate denominators differ")
                        comparisons += 1
                for cell in analysis["sessions"][session]["case_changes"][recipe]["cells"]:
                    case = cell["case_id"]
                    for metric, item in cell["metrics"].items():
                        same(old[int(session)]["medians"][case, recipe][metric], item["before"], "before case median")
                        same(new[int(session)]["medians"][case, recipe][metric], item["after"], "after case median")
                        comparisons += 2
                for metric in QUALITY:
                    actual = len(detail["sessions"][session]["adverse"][recipe][metric])
                    expected = analysis["sessions"][session]["case_changes"][recipe]["outcomes"][metric]["regressed"]
                    require(actual == expected, "Adverse count mismatch")
            for recipe, profile, alias in (("qiskit", "primary", "qiskit"), ("cirq", "primary", "cirq"),
                                            ("tket", "primary", "tket"), ("cirq_one_pass", "light", "cirq"),
                                            ("tket_light", "light", "tket")):
                for metric in ("compile_ns", *QUALITY):
                    expected = analysis["sessions"][session]["profiles"][profile]["followup_on_all_common"]["pairwise"][alias][metric]
                    actual = detail["sessions"][session]["pairwise"][recipe][metric]
                    same(actual["geomean"], expected["geomean"], f"paired/{session}/{recipe}/{metric}")
                    for name in ("paired_cells", "positive_ratio_cells", "zero_cases"):
                        require(actual[name] == expected[name], "Pairwise denominators differ")
                    comparisons += 1
        receipt["retention_analysis_recomputation"] = dict(passed=True, numerical_comparisons=comparisons,
                                                         input_sha256=file_sha(analysis_path))
    else:
        receipt["retention_analysis_recomputation"] = {"passed": None, "reason": "Analyzer output not yet present; rerun audit to compare."}
    external_path = candidate / "analysis/external_summary.json"
    if external_path.exists():
        external = json.loads(external_path.read_text())
        require(external["protocol_sha256"] == psha, "External analysis protocol mismatch")
        comparisons = 0
        for session in ("1", "2"):
            nm = new[int(session)]["medians"]
            for profile, mapping in (("primary", {"qrust": "qrust", "qiskit": "qiskit", "cirq": "cirq", "tket": "tket"}),
                                     ("light", {"qrust": "qrust", "qiskit": "qiskit", "cirq": "cirq_one_pass", "tket": "tket_light"})):
                stats = external["sessions"][session][profile]
                require(stats["complete_case_quality"]["complete_all_four_cells"] == 100, "External common cohort mismatch")
                for alias, recipe in mapping.items():
                    if alias == "qrust":
                        continue
                    for metric in ("compile_ns", *QUALITY):
                        expected = stats["pairwise"]["aggregate"][alias][metric]
                        actual = detail["sessions"][session]["pairwise"][recipe][metric]
                        same(actual["geomean"], expected["geomean"], "External pairwise point")
                        for name in ("paired_cells", "positive_ratio_cells", "zero_cases"):
                            require(actual[name] == expected[name], "External pairwise denominators differ")
                        comparisons += 1
                for metric in ("cx_count", "depth", "two_q_depth"):
                    counts = Counter({"at_best": 0, "within_5_percent": 0, "within_10_percent": 0, "best_zero": 0, "all_zero": 0})
                    for case in cases:
                        values = [nm[case, recipe][metric] for recipe in mapping.values()]
                        best = min(values)
                        qrust = nm[case, "qrust"][metric]
                        counts["at_best"] += qrust == best
                        counts["within_5_percent"] += qrust <= best * 1.05
                        counts["within_10_percent"] += qrust <= best * 1.10
                        counts["best_zero"] += best == 0
                        counts["all_zero"] += max(values) == 0
                    expected = stats["complete_case_quality"]["near_best_counts"][metric]
                    require(all(expected[k] == v for k, v in counts.items()), "External near-best count mismatch")
                    comparisons += len(counts)
                for label, objectives in (("speed_cx", ("compile_ns", "cx_count")), ("speed_depth", ("compile_ns", "depth")),
                                          ("speed_cx_depth", ("compile_ns", "cx_count", "depth"))):
                    counts = Counter({alias: 0 for alias in mapping})
                    for case in cases:
                        for alias, recipe in mapping.items():
                            vector = [nm[case, recipe][metric] for metric in objectives]
                            dominated = False
                            for other in mapping.values():
                                other_vector = [nm[case, other][metric] for metric in objectives]
                                dominated |= all(a <= b for a, b in zip(other_vector, vector)) and any(a < b for a, b in zip(other_vector, vector))
                            counts[alias] += not dominated
                    require(dict(counts) == stats["complete_case_quality"]["pareto_counts"][label], "External Pareto count mismatch")
                    comparisons += len(counts)
        receipt["external_analysis_recomputation"] = dict(passed=True, point_and_count_comparisons=comparisons,
                                                          input_sha256=file_sha(external_path), confidence_intervals_recomputed=False)
    detail_path = work / "independent_postflight_detail.json"
    with detail_path.open("x") as stream:
        stream.write(json.dumps(detail, indent=2, allow_nan=False) + "\n")
    receipt["detail_sha256"] = file_sha(detail_path)
    with (work / "independent_postflight_receipt.json").open("x") as stream:
        stream.write(json.dumps(receipt, indent=2, allow_nan=False) + "\n")
    print(json.dumps({"passed": receipt["passed"], "sessions": receipt["sessions"],
                      "warmup_artifacts_matching_timed": receipt["warmup_artifacts_matching_timed"],
                      "retention_analysis_recomputation": receipt["retention_analysis_recomputation"]}, indent=2))


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--repo", type=Path, required=True)
    parser.add_argument("--baseline", type=Path, required=True)
    parser.add_argument("--candidate", type=Path, required=True)
    parser.add_argument("--work", type=Path, required=True)
    args = parser.parse_args()
    audit(args.repo, args.baseline, args.candidate, args.work)
