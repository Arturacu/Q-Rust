"""Build exact-source policy controls in an isolated target directory."""
from pathlib import Path
import hashlib, io, json, shutil, subprocess, tarfile
w=Path(__file__).resolve().parent;r=w.parent/'qrust_pr_publish'
v=w/'variants';v.mkdir(exist_ok=False)
scratch=w/'ablation_source';scratch.mkdir(exist_ok=False)
base=subprocess.check_output(['git','rev-parse','HEAD'],cwd=r,text=True).strip()
data=subprocess.check_output(['git','archive',base,'Cargo.toml','Cargo.lock','src','examples','experiments/Cargo.toml','experiments/src'],cwd=r)
with tarfile.open(fileobj=io.BytesIO(data)) as archive:
 archive.extractall(scratch,filter='data')
paths=['src/transpiler/mod.rs','src/transpiler/routing.rs']
original={p:(r/p).read_text() for p in paths}
variants={
 'full':{},
 'disabled':{'src/transpiler/mod.rs':('retain_routing_candidates: true,','retain_routing_candidates: false,')},
 'no_equal_swap':{'src/transpiler/routing.rs':('if let Some(candidate) = depth_candidate {','if let Some(candidate) = depth_candidate.filter(|_| false) {')},
 'no_refined_layout':{'src/transpiler/routing.rs':('if let Some(alternate) = alternate {','if let Some(alternate) = alternate.filter(|_| false) {')},
 'no_local_sequence':{'src/transpiler/mod.rs':('if retain_local {','if retain_local && false {')},
}
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
records={}
for label,edits in variants.items():
 for p in paths:
  source=original[p]
  if p in edits:
   old,new=edits[p]
   assert source.count(old)==1,(p,old,source.count(old))
   source=source.replace(old,new)
  (scratch/p).write_text(source)
 if label=='full':
  shutil.copy2(w/'comparison_runner_fixed',v/label)
 else:
  with (v/f'{label}_build.log').open('x') as log:
   subprocess.run(['cargo','build','--locked','--release','-p','qrust-bench','--bin','comparison_runner','--target-dir',str(w/'ablation_target')],cwd=scratch,stdout=log,stderr=subprocess.STDOUT,check=True)
  shutil.copy2(w/'ablation_target/release/comparison_runner',v/label)
 records[label]={'binary_sha256':sha(v/label),'modified_sources':{p:sha(scratch/p) for p in paths},'edits':edits}
 print(label,records[label]['binary_sha256'],flush=True)
shutil.copy2(w.parent/'qrust_external_routing_20261018/comparison_runner_fixed',v/'preserved_baseline')
records['preserved_baseline']={'binary_sha256':sha(v/'preserved_baseline'),'compiler_commit':'17e81b0249b3c6402057ad731608bf1acb4f4153'}
(v/'manifest.json').write_text(json.dumps({'base_commit':base,'scope':'One-policy-at-a-time diagnostic ablations. Same canonical pipeline and fixed search budgets. Builds use an isolated target; official binary is never replaced.','variants':records},indent=2)+'\n')
