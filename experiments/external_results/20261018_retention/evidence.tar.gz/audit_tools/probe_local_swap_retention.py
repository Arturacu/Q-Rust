"""Development diagnostics; instrumented elapsed values are not timing evidence."""
from collections import Counter
import hashlib
import json
from pathlib import Path
import sys

WORK = Path(__file__).resolve().parent
REPO = WORK.parent / "qrust_pr_publish"
BASELINE = WORK.parent / "qrust_external_routing_20261018"
sys.path.insert(0, str(REPO / "experiments"))
from comparison_study import Worker
from comparison_validation import validate_output, parse_qasm


def block(a, b):
    return [f"ry(0.21) q[{a}];", f"rz(0.17) q[{b}];", f"cx q[{a}],q[{b}];",
            f"ry(0.31) q[{a}];", f"cx q[{b}],q[{a}];", f"rz(0.47) q[{b}];",
            f"cx q[{a}],q[{b}];", f"swap q[{a}],q[{b}];"]


def main():
    protocol = json.loads((BASELINE / "study/protocol.json").read_text())
    cases = [c for c in protocol["cases"] if c["id"] == "qasmbench__basis_trotter_n4__linear"]
    for index, edges in enumerate([
        [(0, 1), (1, 2)], [(0, 1), (1, 2), (0, 1)],
        [(0, 1), (2, 3), (1, 2)], [(0, 1), (2, 3), (1, 2), (0, 1), (2, 3)],
    ]):
        width = max(max(pair) for pair in edges) + 1
        qasm = f'OPENQASM 2.0;\ninclude "qelib1.inc";\nqreg q[{width}];\n'
        qasm += "\n".join(line for a, b in edges for line in block(a, b)) + "\n"
        cases.append(dict(id=f"generated_local_swap_blocks_{index}", qasm=qasm, source_qasm=qasm,
                          physical_width=width, n_logical=width, topology="linear",
                          edges=[[q, q+1] for q in range(width-1)]))
    folder = WORK / "local_swap_probe_workers"
    folder.mkdir(exist_ok=False)
    binary = BASELINE / "comparison_runner_fixed"
    worker = Worker("qrust", binary, folder)
    outputs = []
    try:
        for case in cases:
            request = {k: case[k] for k in ("qasm", "n_logical", "physical_width", "edges", "topology")}
            for absorb in (True, False):
                result = worker.call({**request, "seed": 20261018, "profile_passes": True,
                                      "elide_output_permutations": absorb}, 60)
                assert result["status"] == "compiled", result
                outputs.append(dict(case_id=case["id"], absorb=absorb, result=result))
    finally:
        worker.close()
    by_id = {c["id"]: c for c in cases}
    for row in outputs:
        case = by_id[row["case_id"]]
        result = row["result"]
        edges = [pair for a, b in case["edges"] for pair in ((a, b), (b, a))]
        checked = validate_output(case["source_qasm"], result["out_qasm"], case["n_logical"], case["physical_width"],
                                  edges, result["initial_layout"], result["final_layout"])
        assert checked["passed"] and checked["evidence_class"] == "full_isometry"
        row["validation"] = checked
        stages = [{k: s[k] for k in ("pass", "swaps", "two_qubit_gates", "depth")}
                  for s in result["pass_diagnostics"] if s["pass"] in ("SabreLayoutPass", "BeamSabrePass", "TwoQubitBlockSynthesisPass")]
        print(json.dumps(dict(case=row["case_id"], absorb=row["absorb"], metrics=checked["metrics"], stages=stages)))
    output = dict(scope="Development diagnostics; single profiled requests. No timing claims.",
                  binary_sha256=hashlib.sha256(binary.read_bytes()).hexdigest(),
                  script_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(), cases=cases, rows=outputs,
                  all_full_input_checks_passed=True,
                  max_input_residual=max(r["validation"]["max_input_residual"] for r in outputs))
    with (WORK / "local_swap_retention_probe.json").open("x") as stream:
        json.dump(output, stream, indent=2)
        stream.write("\n")


if __name__ == "__main__":
    main()
