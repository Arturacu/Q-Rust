from pathlib import Path
import hashlib,json,subprocess,sys
w=Path(__file__).resolve().parent;r=w.parent/'qrust_pr_publish'
commands=[['cargo','fmt','--all','--','--check'],['cargo','test','--workspace','--all-features'],[str(w.parent/'qrust_comparison_env/bin/python'),'-m','unittest','discover','-s','experiments','-p','test_*.py']]
with (w/'preflight.log').open('x') as log:
 for cmd in commands:
  log.write('COMMAND '+repr(cmd)+'\n');log.flush()
  subprocess.run(cmd,cwd=r,stdout=log,stderr=subprocess.STDOUT,check=True)
with (w/'rust_checks.log').open('x') as log:
 for cmd in [['cargo','clippy','--workspace','--all-targets','--all-features','--','-D','warnings'],['cargo','build','--locked','--release','-p','qrust-bench','--bin','comparison_runner']]:
  log.write('COMMAND '+repr(cmd)+'\n');log.flush()
  subprocess.run(cmd,cwd=r,stdout=log,stderr=subprocess.STDOUT,check=True)
print('All preflight tests, lint checks and release build passed',flush=True)
