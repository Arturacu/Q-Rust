#!/usr/bin/env python3
"""Package the candidate-retention follow-up without replacing original evidence.

Run only after both official sessions, validation and independent audits finish.
Every input is explicit; absent receipts and changed frozen files are errors.
"""
from collections import Counter
import gzip
import hashlib
import io
import json
import os
from pathlib import Path, PurePosixPath
import re
import shutil
import tarfile
import tempfile


WORK = Path(__file__).resolve().parent
REPO = WORK.parent / "qrust_pr_publish"
STUDY = WORK / "study"
DEST = REPO / "experiments/external_results/20261018_retention"
ROUTING_DEST = REPO / "experiments/external_results/20261018_routing"
ROUTING_ARCHIVE_SHA256 = "39d4d8a5ab9e70e642c6e56de7bfca5ffd13a99bbaa59ad0fe9767084380b6c2"
PRESERVATION_SHA256 = "61818c58b3bcb043dd427d0bba7173ff1edca6c00d9aef71dc3fb1c03410d38c"
PLAN_SHA256 = "29799fcc11fd5b4b74cc095b0a8e9b00209bbf76220aa1ecb9e9d8511fd27416"
COMPATIBILITY_DEST = REPO / "experiments/external_results/20261018_compatibility"
COMPATIBILITY_ARCHIVE_SHA256 = "edd32f94666b28c2c101cfe0487950c327e4f848cff001e39fb3da7e91ac2e1d"
ORIGINAL_DEST = REPO / "experiments/external_results/20261018"
ORIGINAL_ARCHIVE_SHA256 = "d45176c9cbcf1c7645dfed44a343ec704fb34b9ab55002dcef4c62248285716f"
FILES = {}
GENERATED = {}


def sha(data):
    return hashlib.sha256(data).hexdigest()


def encoded_json(value):
    return (json.dumps(value, indent=2, sort_keys=True, allow_nan=False) + "\n").encode()


def safe_name(name):
    path = PurePosixPath(name)
    if (not name or path.is_absolute() or ".." in path.parts or "\\" in name
            or path.as_posix() != name or name == "."):
        raise ValueError("Unsafe archive path: " + name)
    return name


def read_regular(path):
    path = Path(path)
    if not path.is_file() or path.is_symlink():
        raise ValueError("Missing regular input: " + str(path))
    return path.read_bytes()


def add(path, archive_path):
    name = safe_name(archive_path)
    if name in FILES or name in GENERATED:
        raise ValueError("Duplicate archive path: " + name)
    path = Path(path)
    if not path.is_file() or path.is_symlink():
        raise ValueError("Missing regular input: " + str(path))
    FILES[name] = path


def generate(name, data):
    safe_name(name)
    if name in FILES or name in GENERATED:
        raise ValueError("Duplicate generated archive path: " + name)
    GENERATED[name] = data


def preserve_originals():
    receipt = json.loads(read_regular(WORK / "original_preservation.json"))
    if sha(read_regular(WORK / "original_preservation.json")) != PRESERVATION_SHA256:
        raise ValueError("Preservation receipt changed")
    if len(receipt.get("sha256", {})) != 43:
        raise ValueError("Expected all 43 preserved files from the three earlier studies")
    checks = []
    for relative, expected in sorted(receipt["sha256"].items()):
        safe_name(relative)
        observed = sha(read_regular(REPO / relative))
        if observed != expected:
            raise ValueError("Preserved result/report changed: " + relative)
        checks.append({"path": relative, "sha256": observed, "unchanged": True})
    for directory, expected in ((ORIGINAL_DEST, ORIGINAL_ARCHIVE_SHA256),
                                (COMPATIBILITY_DEST, COMPATIBILITY_ARCHIVE_SHA256),
                                (ROUTING_DEST, ROUTING_ARCHIVE_SHA256)):
        if sha(read_regular(directory / "evidence.tar.gz")) != expected:
            raise ValueError("Preserved evidence archive hash changed")
    return receipt, checks


def bound_field(receipt, names, expected):
    values = [receipt[name] for name in names if name in receipt]
    if not values or any(value != expected for value in values):
        raise ValueError("Missing or mismatching receipt field: " + "/".join(names))


def collect():
    if (STUDY / "active.lock").exists():
        raise ValueError("Study is active; packaging is prohibited")
    if (DEST / "evidence.tar.gz").exists() or (DEST / "evidence_manifest.json").exists():
        raise FileExistsError("Recorded evidence must never be overwritten")
    original_preservation, original_checks = preserve_originals()
    import sys
    sys.path.insert(0, str(REPO / "experiments"))
    from analyze_external_retention import load_study
    protocol, protocol_sha, _records = load_study(STUDY)
    corpus_sha = sha(read_regular(STUDY / "corpus_manifest.json"))
    if corpus_sha != protocol["corpus_manifest_sha256"]:
        raise ValueError("Frozen corpus checksum mismatch")
    required_receipts = (
        "investigation_plan.json", "original_preservation.json", "environment_receipt.json",
        "freeze_receipt.json", "preflight_receipt.json", "independent_postflight_receipt.json",
        "independent_postflight_detail.json", "retention_causal_notes.json",
        "warmup_validation_receipt.json", "warmup_validation_artifacts.jsonl",
    )
    for name in required_receipts:
        add(WORK / name, "receipts/" + name)
    plan = json.loads(read_regular(WORK / "investigation_plan.json"))
    if sha(read_regular(WORK / "investigation_plan.json")) != PLAN_SHA256:
        raise ValueError("Prespecified investigation plan changed")
    freeze = json.loads(read_regular(WORK / "freeze_receipt.json"))
    bound_field(freeze, ("new_protocol_sha256", "protocol_sha256"), protocol_sha)
    bound_field(freeze, ("new_binary_sha256", "binary_sha256", "qrust_binary_sha256"), protocol["qrust_binary_sha256"])
    bound_field(freeze, ("new_compiler_commit", "compiler_commit"), protocol["compiler_commit"])
    bound_field(freeze, ("new_compiler_full_sha",), protocol["compiler_provenance"]["git_head"])
    if (freeze["after_compiler_provenance"] != protocol["compiler_provenance"]
            or freeze["frozen_harness_sha256"] != protocol["source_sha256"]):
        raise ValueError("Freeze receipt source provenance differs from the protocol")
    preflight = json.loads(read_regular(WORK / "preflight_receipt.json"))
    environment = json.loads(read_regular(WORK / "environment_receipt.json"))
    if (environment["protocol_sha256"] != protocol_sha or not environment["captured_before_timing"]
            or environment["preflight_receipt_sha256"] != sha(read_regular(WORK / "preflight_receipt.json"))
            or environment["versions"] != protocol["versions"]
            or environment["worker_thread_environment"] != protocol["thread_environment"]):
        raise ValueError("Environment receipt does not bind the frozen protocol/preflight settings")
    for name, field in (("preflight.log", "preflight_log_sha256"), ("rust_checks.log", "rust_clippy_build_log_sha256")):
        if sha(read_regular(WORK / name)) != preflight[field]:
            raise ValueError("Test log no longer matches its preflight receipt: " + name)
        add(WORK / name, "test_logs/" + name)
    validation = json.loads(read_regular(STUDY / "validation_summary.json"))
    if validation["protocol_sha256"] != protocol_sha:
        raise ValueError("Validation receipt belongs to another protocol")
    postflight = json.loads(read_regular(WORK / "independent_postflight_receipt.json"))
    if (not postflight["passed"] or postflight["protocol_sha256"] != protocol_sha
            or postflight["detail_sha256"] != sha(read_regular(WORK / "independent_postflight_detail.json"))
            or postflight["source_sha256"] != sha(read_regular(WORK / "independent_postflight_audit.py"))):
        raise ValueError("Independent audit source, detail or protocol binding differs")
    for field in ("retention_analysis_recomputation", "external_analysis_recomputation", "quality_target_recomputation"):
        if postflight[field]["passed"] is not True:
            raise ValueError("Independent postflight check incomplete: " + field)
    if postflight["original_preserved_files"] != 43 or postflight["investigation_plan_sha256"] != PLAN_SHA256:
        raise ValueError("Independent preservation/plan check differs")
    warmup = json.loads(read_regular(WORK / "warmup_validation_receipt.json"))
    if (warmup["protocol_sha256"] != protocol_sha
            or warmup["official_validation_receipt_sha256"] != sha(read_regular(STUDY / "validation_summary.json"))
            or warmup["artifact_rows_sha256"] != sha(read_regular(WORK / "warmup_validation_artifacts.jsonl"))
            or warmup["audit_source_sha256"] != sha(read_regular(WORK / "audit_warmups.py"))):
        raise ValueError("Warmup audit binding differs")
    if (warmup["total_warmup_rows"] != 1200 or warmup["passed_warmups"] != 1200
            or warmup["failed_numerical_warmups"] or warmup["not_compiled_warmups"]):
        raise ValueError("Warmup correctness coverage is incomplete")
    for name in ("protocol.json", "protocol.sha256", "corpus_manifest.json", "validation_summary.json"):
        add(STUDY / name, "study/" + name)
    for number in (1, 2):
        directory = f"session_{number:02d}"
        for name in ("protocol.json", "session.json", "startup.json", "timed.jsonl", "warmup.jsonl", "validated.jsonl"):
            add(STUDY / directory / name, "study/" + directory + "/" + name)
    for name in ("external_summary.json", "session_1_primary_cells.csv", "session_1_light_cells.csv",
                 "session_2_primary_cells.csv", "session_2_light_cells.csv"):
        add(STUDY / "analysis" / name, "study/analysis/" + name)
    comparison_path = WORK / "retention_analysis/retention_comparison.json"
    add(comparison_path, "retention_analysis/retention_comparison.json")
    comparison = json.loads(read_regular(comparison_path))
    if (comparison["followup_protocol_sha256"] != protocol_sha
            or comparison["original_protocol_sha256"] != plan["baseline_protocol_sha256"]):
        raise ValueError("Cross-run analysis does not bind the planned studies")
    if comparison["investigation_plan_sha256"] != PLAN_SHA256 or comparison["original_preservation"] is not None:
        raise ValueError("Cross-run plan/options differ from the declared extracted-only replay")
    if comparison["non_qrust_identity"]["identical_trials"] != 7000:
        raise ValueError("Expected all 7,000 unchanged-compiler before/after identities")
    for checks in comparison["same_seed_session_identity"].values():
        if checks["identical_trials"] != 4200 or not checks["all_identical"]:
            raise ValueError("Same-seed cross-session output identity is incomplete")
    analysis = json.loads(read_regular(STUDY / "analysis/external_summary.json"))
    if (analysis["protocol_sha256"] != protocol_sha
            or analysis["source_sha256"] != protocol["source_sha256"]["experiments/analyze_external_comparison.py"]):
        raise ValueError("Study analysis source/protocol mismatch")
    if len(protocol["source_sha256"]) != 11:
        raise ValueError("Unexpected frozen harness inventory")
    for relative, expected in protocol["source_sha256"].items():
        safe_name(relative)
        if sha(read_regular(REPO / relative)) != expected:
            raise ValueError("Frozen harness changed: " + relative)
        add(REPO / relative, "harness/" + relative)
    for relative in (
        "experiments/analyze_external_followup.py", "experiments/analyze_external_routing.py",
        "experiments/analyze_external_retention.py", "experiments/test_analyze_external_retention.py",
        "experiments/test_analyze_external_followup.py", "experiments/test_analyze_external_comparison.py",
        "experiments/test_analyze_comparison_study.py", "experiments/render_external_retention.py",
    ):
        add(REPO / relative, "harness/" + relative)
    if comparison["analysis_source_sha256"] != sha(read_regular(REPO / "experiments/analyze_external_retention.py")):
        raise ValueError("Retention analyzer changed since the recorded analysis")
    for name, expected in comparison["analysis_dependency_sha256"].items():
        if sha(read_regular(REPO / "experiments" / name)) != expected:
            raise ValueError("Retention analysis dependency changed: " + name)
    for relative in (
        "src/transpiler/layout.rs", "src/transpiler/mod.rs", "src/transpiler/candidate_selection.rs",
        "src/transpiler/numerical_policy.rs", "src/transpiler/routing.rs", "tests/routing_candidate_regressions.rs",
    ):
        expected = protocol["compiler_provenance"]["compiler_source_sha256"][relative]
        if sha(read_regular(REPO / relative)) != expected:
            raise ValueError("Frozen compiler/regression source changed: " + relative)
        add(REPO / relative, "compiler_changes/" + relative)
    for name in ("LICENSE-MIT", "LICENSE-APACHE"):
        add(REPO / name, name)
    add(REPO / "experiments/EXTERNAL_RETENTION_FOLLOWUP.md", "reports/EXTERNAL_RETENTION_FOLLOWUP.md")
    for name in ("summary.json", "comparison.png", "comparison.svg", "focal_linear.png", "focal_linear.svg",
                 "FIGURE_NOTES.md", "validation_summary.json", "session_1_primary_cells.csv", "session_1_light_cells.csv",
                 "session_2_primary_cells.csv", "session_2_light_cells.csv"):
        add(DEST / name, "presentation/" + name)
    for name in ("candidate_retention_validation.json", "local_swap_retention_probe.json", "generic_u_probe.json",
                 "variants/manifest.json", "ablations/rows.jsonl", "ablations/profile_rows.jsonl",
                 "ablations/summary.json", "ablations/validation.json"):
        add(WORK / name, "diagnostics/" + name)
    variants = json.loads(read_regular(WORK / "variants/manifest.json"))["variants"]
    if (variants["full"]["binary_sha256"] != protocol["qrust_binary_sha256"]
            or variants["preserved_baseline"]["binary_sha256"] != plan["baseline_binary_sha256"]):
        raise ValueError("Ablation binaries do not bind the official candidate and preserved baseline")
    for relative, expected in variants["full"]["modified_sources"].items():
        if protocol["compiler_provenance"]["compiler_source_sha256"][relative] != expected:
            raise ValueError("Ablation full-variant source differs from the official compiler")
    ablation = json.loads(read_regular(WORK / "ablations/validation.json"))
    expected_ablation_cells = {(item["case_id"], variant)
                               for item in plan["predeclared_quality_ceilings"] for variant in variants}
    observed_ablation_cells = {(item["case_id"], item["variant"]) for item in ablation["checks"]}
    if (not ablation["complete_columns"] or not ablation["disabled_policy_matches_preserved_baseline"]
            or len(ablation["checks"]) != len(expected_ablation_cells)
            or observed_ablation_cells != expected_ablation_cells
            or not all(item["validation"]["passed"] for item in ablation["checks"])):
        raise ValueError("Ablation full-column coverage or incumbent identity is incomplete")
    for directory, names in (
        ("supplemental_candidate", ("cases.json", "compiled_rows.json", "artifacts.jsonl", "bindings.json", "quality_ceiling_checks.json", "receipt.json")),
        ("supplemental_official", ("artifacts.jsonl", "bindings.json", "quality_ceiling_checks.json", "receipt.json")),
    ):
        for name in names:
            add(WORK / directory / name, "supplemental/" + directory + "/" + name)
        receipt = json.loads(read_regular(WORK / directory / "receipt.json"))
        if not receipt["all_passed"] or receipt["oracle_sha256"] != validation["oracle_sha256"]:
            raise ValueError("Supplemental validation incomplete or oracle changed")
        if receipt["script_sha256"] != sha(read_regular(WORK / "supplemental_validation.py")):
            raise ValueError("Supplemental checker changed since its recorded validation")
        for name, field in (("artifacts.jsonl", "artifacts_sha256"), ("bindings.json", "bindings_sha256")):
            if sha(read_regular(WORK / directory / name)) != receipt["complete_column_results"][field]:
                raise ValueError("Supplemental receipt/artifact mismatch")
        ceilings = receipt["declared_quality_results"]
        if (not ceilings["all_passed"] or ceilings["observed_cases"] != 12
                or ceilings["investigation_plan_sha256"] != PLAN_SHA256
                or ceilings["quality_ceiling_checks_sha256"] != sha(read_regular(WORK / directory / "quality_ceiling_checks.json"))):
            raise ValueError("Supplemental quality-ceiling evidence is incomplete or changed")
        expected_rows, expected_unique = (92, 92) if directory == "supplemental_candidate" else (168, 12)
        if (receipt["complete_column_results"]["row_count"] != expected_rows
                or receipt["complete_column_results"]["unique_artifacts"] != expected_unique):
            raise ValueError("Supplemental complete-column coverage differs from the prescribed cases")
        if directory == "supplemental_candidate":
            if (receipt["binary_sha256"] != protocol["qrust_binary_sha256"]
                    or receipt["compiled_rows_sha256"] != sha(read_regular(WORK / directory / "compiled_rows.json"))):
                raise ValueError("Pre-freeze supplemental outputs do not bind the official candidate")
        if directory == "supplemental_official" and receipt["protocol_sha256"] != protocol_sha:
            raise ValueError("Supplemental official check belongs to another protocol")
        if directory == "supplemental_official":
            for session in (1, 2):
                timed = STUDY / f"session_{session:02d}/timed.jsonl"
                if receipt["timed_files"][str(session)]["sha256"] != sha(read_regular(timed)):
                    raise ValueError("Supplemental checks do not bind the official timed outputs")
    for name in ("build_ablations.py", "run_ablations.py", "supplemental_validation.py", "run_preflight.py",
                 "probe_local_swap_retention.py", "independent_postflight_audit.py",
                 "audit_warmups.py", "package_retention_evidence.py", "replay_archives.py"):
        add(WORK / name, "audit_tools/" + name)
    references = {}
    for label, directory, expected in (
        ("routing", ROUTING_DEST, ROUTING_ARCHIVE_SHA256),
        ("compatibility", COMPATIBILITY_DEST, COMPATIBILITY_ARCHIVE_SHA256),
        ("original", ORIGINAL_DEST, ORIGINAL_ARCHIVE_SHA256),
    ):
        manifest = json.loads(read_regular(directory / "evidence_manifest.json"))
        if manifest["archive_sha256"] != expected or manifest["corpus_manifest_sha256"] != corpus_sha:
            raise ValueError("Earlier archive manifest does not bind the unchanged corpus")
        if label == "routing" and manifest["protocol_sha256"] != plan["baseline_protocol_sha256"]:
            raise ValueError("Immediate routing baseline protocol mismatch")
        if label == "compatibility" and manifest["protocol_sha256"] != plan["compatibility_reference_protocol_sha256"]:
            raise ValueError("Compatibility recovery reference protocol mismatch")
        add(directory / "evidence_manifest.json", "baseline/" + label + "_evidence_manifest.json")
        relative = str((directory / "evidence.tar.gz").relative_to(REPO))
        references[label] = {
            "archive_repo_path": relative, "archive_sha256": expected,
            "source_commit": original_preservation["source_commit"],
            "archive_url": "https://github.com/Arturacu/Q-Rust/blob/" + original_preservation["source_commit"] + "/" + relative,
            "protocol_sha256": manifest["protocol_sha256"], "corpus_manifest_sha256": corpus_sha,
            "purpose": "Preserved earlier results and original corpus/source/licensing evidence; no duplicated payload.",
        }
    generate("BASELINE_REFERENCES.json", encoded_json(references))
    generate("receipts/packaging_original_preservation_check.json", encoded_json({
        "status": "passed", "source_commit": original_preservation["source_commit"], "files": original_checks,
    }))
    generate("README.txt", README.encode())
    return protocol_sha, corpus_sha, references, original_checks


# High-confidence credential shapes only. Findings contain names and detector
# labels, never secret values or surrounding contents. No configuration files,
# unrelated files, compiler binaries, logs or cached data are collected.
SECRET_PATTERNS = {
    "private_key": re.compile(rb"-----BEGIN (?:RSA |EC |OPENSSH |DSA )?PRIVATE KEY-----"),
    "github_token": re.compile(rb"\b(?:gh[pousr]_[A-Za-z0-9]{30,}|github_pat_[A-Za-z0-9_]{40,})\b"),
    "openai_token": re.compile(rb"\bsk-(?:proj-|svcacct-)?[A-Za-z0-9_-]{35,}\b"),
    "aws_access_key": re.compile(rb"\b(?:AKIA|ASIA)[A-Z0-9]{16}\b"),
    "slack_token": re.compile(rb"\bxox[baprs]-[A-Za-z0-9-]{20,}\b"),
    "credential_url": re.compile(rb"https?://[^\s/:]{2,100}:[^\s/@]{4,100}@"),
}
NATIVE_HEADERS = {b"\x7fELF", b"\xcf\xfa\xed\xfe", b"\xfe\xed\xfa\xcf", b"\xca\xfe\xba\xbe"}


README = """Q-Rust external candidate-retention evidence, 2026-10-18

This separately recorded study evaluates bounded routing candidates using
finished output costs while retaining a canonical incumbent. It keeps the
same 50 community fixtures, 100 target cells, six recipes, seeds, schedules,
packages, numerical oracle and trial design. All three earlier studies and
their reports remain unchanged.

The archive contains byte-exact protocol/corpus, both timed/warmup/validated
sessions, complete analysis JSON/CSV, cross-run analysis, frozen harness,
changed compiler and regression files, report and figures. It retains
exact-source policy ablations, the preliminary development probes, 80 new
synthetic stress cases and complete-column checks of all twelve focal cells.
Numerical checks and prespecified structural quality ceilings are separate
records. Source hashes and the compiler Git commit bind the full project;
executables, worker logs, caches and unrelated files are excluded. The two
explicit preflight test/build logs are retained and bound by their receipt.

BASELINE_REFERENCES.json binds all three preserved archives. The routing
archive is the immediate before/after baseline; the compatibility archive
provides the three recovery references; the original archive contains
upstream source, raw community circuits and licenses. Their payloads are
not duplicated here. The new protocol embeds every source and normalized
QASM input.

New-study replay: safely extract this archive; rename study/analysis to
study/recorded_analysis. In the pinned Python environment run:
python harness/experiments/analyze_external_comparison.py study
Compare external_summary.json and four CSV files byte-for-byte with recorded
copies. Existing output directories are rejected.

Cross-run replay: hash-check and extract the routing archive into
baseline_routing/. Run:
python harness/experiments/analyze_external_retention.py
baseline_routing/study study --plan receipts/investigation_plan.json
--output replayed_retention_analysis
Compare retention_comparison.json byte-for-byte with
retention_analysis/retention_comparison.json. Both analyzers use 2,000
bootstrap draws and retain separate sessions. The archived replay utility
safely extracts and verifies all four archives and compares all six outputs.
The optional analyzer preservation argument was not used: the independent
postflight and packaging receipts separately bind all 43 earlier files.

Every case and regression stays in the fixed cohort. Unchanged compiler
timings are descriptive host-drift controls. Exact-source policy ablations
supply separate mechanism evidence. CX count and depth are structural costs,
not proven optima or execution fidelity. Complete-column checking supplies
numerical evidence, not a formal proof. These fixtures informed the fixes;
they are not an untouched holdout. Synthetic coverage remains separate.

MANIFEST.json records every payload size and SHA256. The adjacent repository
evidence_manifest.json binds the archive hash and fresh extraction checks.
Archive metadata is normalized while all input bytes are preserved. All 43
earlier result/report files are hash-checked before and after packaging.
Existing archives, absent required receipts or changed frozen inputs fail.
"""


def main():
    protocol_sha, corpus_sha, baseline_reference, original_checks = collect()
    payloads = {name: read_regular(path) for name, path in FILES.items()}
    payloads.update(GENERATED)
    findings = []
    for name, data in sorted(payloads.items()):
        if data[:4] in NATIVE_HEADERS or data[:2] == b"MZ":
            raise ValueError("Unexpected executable: " + name)
        for detector, pattern in SECRET_PATTERNS.items():
            if pattern.search(data):
                findings.append({"path": name, "detector": detector})
    if findings:
        print(json.dumps({"credential_scan": "review_required", "findings": findings}, indent=2))
        raise SystemExit(2)
    entries = [{"path": name, "bytes": len(data), "sha256": sha(data)}
               for name, data in sorted(payloads.items())]
    content_manifest = {
        "schema": 1, "files": entries, "protocol_sha256": protocol_sha,
        "corpus_manifest_sha256": corpus_sha,
        "original_evidence_archive_sha256": ORIGINAL_ARCHIVE_SHA256,
        "compatibility_evidence_archive_sha256": COMPATIBILITY_ARCHIVE_SHA256,
        "routing_evidence_archive_sha256": ROUTING_ARCHIVE_SHA256,
    }
    payloads["MANIFEST.json"] = encoded_json(content_manifest)
    expected = {entry["path"]: entry for entry in entries}
    expected["MANIFEST.json"] = {"path": "MANIFEST.json", "bytes": len(payloads["MANIFEST.json"]),
                                 "sha256": sha(payloads["MANIFEST.json"])}
    DEST.mkdir(parents=True, exist_ok=True)
    if DEST.is_symlink():
        raise ValueError("Destination must not be a symlink")
    with tempfile.TemporaryDirectory(prefix=".retention-package-", dir=DEST) as temporary:
        staging = Path(temporary)
        archive = staging / "evidence.tar.gz"
        with archive.open("xb") as stream:
            with gzip.GzipFile(filename="", mode="wb", fileobj=stream, mtime=0, compresslevel=9) as compressed:
                with tarfile.open(fileobj=compressed, mode="w", format=tarfile.PAX_FORMAT) as output:
                    for name, data in sorted(payloads.items()):
                        item = tarfile.TarInfo(name)
                        item.size, item.mtime, item.mode = len(data), 0, 0o644
                        item.uid = item.gid = 0
                        item.uname = item.gname = ""
                        output.addfile(item, io.BytesIO(data))
        extraction = staging / "verified_extraction"
        extraction.mkdir()
        with tarfile.open(archive, "r:gz") as packaged:
            members = packaged.getmembers()
            names = [member.name for member in members]
            if len(names) != len(set(names)) or set(names) != set(expected):
                raise ValueError("Archive member inventory mismatch")
            for member in members:
                safe_name(member.name)
                if not member.isfile() or member.size != expected[member.name]["bytes"]:
                    raise ValueError("Unsafe member or recorded-size mismatch: " + member.name)
                path = extraction / member.name
                path.parent.mkdir(parents=True, exist_ok=True)
                with path.open("xb") as target:
                    shutil.copyfileobj(packaged.extractfile(member), target)
            for name, entry in expected.items():
                data = read_regular(extraction / name)
                if len(data) != entry["bytes"] or sha(data) != entry["sha256"]:
                    raise ValueError("Extracted payload mismatch: " + name)
        for name, path in FILES.items():
            if sha(read_regular(path)) != expected[name]["sha256"]:
                raise ValueError("Input changed during packaging: " + name)
        _, final_original_checks = preserve_originals()
        if final_original_checks != original_checks:
            raise ValueError("Original results changed during packaging")
        receipt = {
            "schema": 1, "archive": "evidence.tar.gz", "archive_bytes": archive.stat().st_size,
            "archive_sha256": sha(archive.read_bytes()), "payload_file_count": len(expected),
            "uncompressed_payload_bytes": sum(entry["bytes"] for entry in expected.values()),
            "protocol_sha256": protocol_sha, "corpus_manifest_sha256": corpus_sha,
            "baseline_references": baseline_reference,
            "files": [expected[name] for name in sorted(expected)],
            "extraction_integrity": {
                "status": "passed", "files_verified": len(expected),
                "method": "Fresh extraction; exact inventory, regular files, safe paths, every size and SHA256 verified; inputs and preserved original files rechecked.",
            },
            "original_preservation": {"status": "passed", "files_verified": len(original_checks)},
            "credential_review": {
                "status": "no_high_confidence_credential_patterns_detected", "scanned_payload_files": len(payloads) - 1,
                "detectors": sorted(SECRET_PATTERNS),
                "scope": "Explicit new-study/source/receipt allowlist; baseline archive is hash-bound and its previously recorded scan retained in baseline/*_evidence_manifest.json. Legitimate recorded paths retained as provenance.",
            },
            "excluded": ["worker logs", "caches and bytecode", "compiler executables", "unrelated preliminary outputs",
                         "draft prose", "unrelated workspace files", "duplicated original corpus/source bytes"],
            "top_level_file_counts": dict(Counter(name.split("/")[0] for name in expected)),
        }
        manifest = staging / "evidence_manifest.json"
        manifest.write_bytes(encoded_json(receipt))
        # Hard-link installation is atomic per file and refuses to replace an
        # existing destination; both staged files have been fully verified.
        os.link(archive, DEST / archive.name)
        os.link(manifest, DEST / manifest.name)
    print(json.dumps({key: value for key, value in receipt.items() if key != "files"}, indent=2))


if __name__ == "__main__":
    main()
