from pathlib import Path
import hashlib,json,shutil,subprocess,tarfile,io
w=Path(__file__).resolve().parent;r=w.parent/'qrust_pr_publish'
v=w/'variants';v.mkdir(exist_ok=True)
base='c805c5e4a2be878049df77b03d9d2b0e673a3201'
paths=['src/transpiler/routing.rs','src/transpiler/optimization.rs','src/transpiler/layout.rs']
old={p:subprocess.check_output(['git','show',f'{base}:{p}'],cwd=r) for p in paths}
fixed={p:(r/p).read_bytes() for p in paths}
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
shutil.copy2(r/'target/release/comparison_runner',v/'111')
shutil.copy2(w.parent/'qrust_external_followup_20261018/comparison_runner_fixed',v/'000')
records={}
scratch=w/'ablation_source';scratch.mkdir(exist_ok=True)
archive=subprocess.check_output(['git','archive',base],cwd=r)
with tarfile.open(fileobj=io.BytesIO(archive)) as t:t.extractall(scratch,filter='data')
for bits in ['000','100','010','001','110','101','011','111']:
 for bit,p in zip(bits,paths):(scratch/p).write_bytes(fixed[p] if bit=='1' else old[p])
 if bits not in ('000','111'):
  with (v/f'{bits}_build.log').open('w') as log:
   subprocess.run(['cargo','build','--locked','--release','-p','qrust-bench','--bin','comparison_runner','--target-dir',str(r/'target')],cwd=scratch,stdout=log,stderr=subprocess.STDOUT,check=True)
  shutil.copy2(r/'target/release/comparison_runner',v/bits)
 records[bits]={'binary_sha256':sha(v/bits),'changed_sources':{p:sha(scratch/p) for p in paths}}
 print(bits,records[bits]['binary_sha256'],flush=True)
shutil.copy2(v/'111',w/'comparison_runner_fixed')
(v/'manifest.json').write_text(json.dumps({'base_commit':base,'bit_order':['cu1_diagonal','logical_swap_absorption','layout_memoization'],'scope':'Exact source-factorial development diagnostics; unchanged search budgets and other passes','variants':records},indent=2)+'\n')
