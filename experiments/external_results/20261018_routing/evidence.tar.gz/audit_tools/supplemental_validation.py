#!/usr/bin/env python3
"""Supplemental complete-column checks; never alters the frozen study oracle.

Candidate mode compiles synthetic stress cases and the six focal external cells.
Official mode validates the actual retained timed outputs, without recompiling.
This script is diagnostic: its recorded compile times are not benchmark results.
"""
from __future__ import annotations

import argparse
from datetime import datetime, timezone
import hashlib
import json
import math
import os
from pathlib import Path
import random
import sys

HERE = Path(__file__).resolve().parent
REPO = HERE.parent / "qrust_pr_publish"
sys.path.insert(0, str(REPO / "experiments"))
from comparison_study import THREAD_ENV, Worker
os.environ.update(THREAD_ENV)
import numpy as np
import comparison_validation as oracle

SEED = 2026101803
FOCAL = {"mqtbench__ae_n10", "mqtbench__qpeexact_n10", "mqtbench__qpeinexact_n10"}
EXPECTED_ORACLE = "55de70f9fe47d9fcaeb1497bd04b377e5582afc9289e6948dc6c32ebe5bda6d4"


def digest(value):
    return hashlib.sha256(value.encode() if isinstance(value, str) else value).hexdigest()


def save(path, value):
    with path.open("x") as stream:
        json.dump(value, stream, indent=2)
        stream.write("\n")


def qasm(width, operations):
    return f'OPENQASM 2.0;\ninclude "qelib1.inc";\nqreg q[{width}];\n' + "\n".join(operations) + "\n"


def stress_cases():
    """Independent fixed-seed structures, without MQT data or output feedback."""
    rng = random.Random(SEED)
    angles = (0.0, 1e-15, -1e-15, 0.37, -0.37, math.pi/2, -math.pi/2,
              math.pi, -math.pi, 2*math.pi, -2*math.pi)
    result = []
    for width in (3, 4, 5, 6):
        for index in range(10):
            operations = [f"h q[{q}];" for q in range(width)]
            for layer in range(3):
                if index % 3 == 0:
                    pairs = [(a, b) for a in range(width) for b in range(a+1, width)]
                elif index % 3 == 1:
                    center = (index+layer) % width
                    pairs = [(center, b) for b in range(width) if b != center]
                else:
                    path = list(range(width))
                    rng.shuffle(path)
                    pairs = list(zip(path, path[1:]))
                rng.shuffle(pairs)
                for j, (a, b) in enumerate(pairs):
                    if rng.randrange(2):
                        a, b = b, a
                    theta = angles[(index + 3*layer+j) % len(angles)]
                    operations.append(f"cu1({theta!r}) q[{a}],q[{b}];")
                    if j % 3 == 0:
                        operations.append(f"rz({angles[(j+index+1)%len(angles)]!r}) q[{b}];")
                a, b = rng.sample(range(width), 2)
                operations.extend((f"swap q[{a}],q[{b}];",
                                   f"u3({angles[(index+layer)%len(angles)]!r},0.23,-0.17) q[{a}];"))
                c = next(q for q in range(width) if q not in (a, b))
                operations.extend((f"cx q[{b}],q[{c}];", f"h q[{a}];",
                                   f"rx({0.19*(layer+1)!r}) q[{b}];",
                                   f"cz q[{a}],q[{c}];", f"rzz(-0.43) q[{c}],q[{b}];"))
            source = qasm(width, operations)
            # The worker accepts native RZZ; the source oracle is independent.
            for topology in ("all_to_all", "linear"):
                edges = ([[a,b] for a in range(width) for b in range(a+1,width)]
                         if topology == "all_to_all" else [[a,a+1] for a in range(width-1)])
                result.append({"id":f"synthetic_w{width}_{index:02d}__{topology}",
                               "fixture":f"synthetic_w{width}_{index:02d}",
                               "n_logical":width,"physical_width":width,"topology":topology,
                               "edges":edges,"qasm":source,"source_qasm":source,
                               "normalized_sha256":digest(source),"source_sha256":digest(source)})
    return result


def batches(dim, chunk):
    for start in range(0, dim, chunk):
        count = min(chunk, dim-start)
        inputs = np.zeros((dim, count), dtype=np.complex128)
        inputs[np.arange(start, start+count), np.arange(count)] = 1.0
        yield start, inputs


def complete_columns(case, output, chunk=32):
    """Two passes ensure a single global phase across every column and batch."""
    n, physical = case["n_logical"], case["physical_width"]
    source_width, source = oracle.parse_qasm(case["source_qasm"])
    output_width, compiled = oracle.parse_qasm(output["out_qasm"])
    if (source_width, output_width) != (n, physical):
        raise ValueError("width mismatch")
    edges = None if case["topology"] == "all_to_all" else [
        pair for a,b in case["edges"] for pair in ((a,b),(b,a))]
    standard = oracle.validate_output(case["source_qasm"], output["out_qasm"], n, physical,
                                     edges, output["initial_layout"], output["final_layout"])
    if not standard["basis_legal"] or not standard["coupling_legal"]:
        return {"passed":False,"standard_check":standard,"error":"illegal output"}
    initial = oracle._layout_indices(n, physical, output["initial_layout"])
    final = oracle._layout_indices(n, physical, output["final_layout"])
    dim = 1 << n

    def evolve(inputs):
        expected = np.zeros((1<<physical, inputs.shape[1]), dtype=np.complex128)
        expected[final] = oracle.simulate(n, source, inputs)
        physical_inputs = np.zeros_like(expected)
        physical_inputs[initial] = inputs
        actual = oracle.simulate(physical, compiled, physical_inputs)
        return expected, actual

    overlap = 0j
    for _, inputs in batches(dim, chunk):
        expected, actual = evolve(inputs)
        overlap += np.vdot(expected, actual)
    phase = overlap/abs(overlap) if abs(overlap) else 1.0+0j
    residual_max, residual_square_sum, worst_basis = 0.0, 0.0, 0
    max_leakage = 0.0
    for start, inputs in batches(dim, chunk):
        expected, actual = evolve(inputs)
        residuals = np.linalg.norm(actual-phase*expected, axis=0)
        where = int(np.argmax(residuals))
        if residuals[where] > residual_max:
            residual_max, worst_basis = float(residuals[where]), start+where
        residual_square_sum += float(np.sum(residuals**2))
        if physical > n:
            unused = np.ones(1<<physical, dtype=bool)
            unused[final] = False
            max_leakage = max(max_leakage, float(np.max(np.sum(np.abs(actual[unused])**2,axis=0))))
    return {"passed":bool(standard["passed"] and math.isfinite(residual_max) and residual_max<oracle.TOLERANCE),
            "evidence_class":"supplemental_full_isometry", "checked_input_count":dim,
            "logical_qubits":n,"physical_qubits":physical,"chunk_columns":chunk,
            "phase_scope":"one phase from all columns; shared across every batch",
            "shared_global_phase_real":float(np.real(phase)),"shared_global_phase_imag":float(np.imag(phase)),
            "max_input_residual":residual_max,"worst_basis_input":worst_basis,
            "normalized_frobenius_residual":math.sqrt(residual_square_sum/dim),
            "max_ancilla_leakage_probability":max_leakage,"tolerance":oracle.TOLERANCE,
            "standard_check":standard}


def check_raw_qpy(cases, corpus_dir, chunk):
    """Compare retained original unitary-prefix QPY with analytic source QASM."""
    from qiskit import qpy
    from qiskit.quantum_info import Operator
    from external_corpus import unitary_prefix
    rows=[]
    seen=set()
    for case in cases:
        if case["fixture"] in seen:
            continue
        seen.add(case["fixture"])
        path=corpus_dir/case["raw_artifact"]
        if digest(path.read_bytes()) != case["raw_source_sha256"]:
            raise ValueError("retained QPY hash mismatch")
        with path.open("rb") as stream:
            circuits=qpy.load(stream)
        if len(circuits)!=1:
            raise ValueError("expected one original circuit")
        original,removed=unitary_prefix(circuits[0])
        matrix=Operator(original).data
        width,gates=oracle.parse_qasm(case["source_qasm"])
        dim=1<<width
        overlap=0j
        for start,inputs in batches(dim,chunk):
            overlap+=np.vdot(matrix[:,start:start+inputs.shape[1]],oracle.simulate(width,gates,inputs))
        phase=overlap/abs(overlap) if abs(overlap) else 1.0+0j
        residual=0.0
        for start,inputs in batches(dim,chunk):
            expected=matrix[:,start:start+inputs.shape[1]]
            actual=oracle.simulate(width,gates,inputs)
            residual=max(residual,float(np.max(np.linalg.norm(actual-phase*expected,axis=0))))
        row={"fixture":case["fixture"],"raw_source_sha256":case["raw_source_sha256"],
             "source_sha256":case["source_sha256"],"removed":removed,
             "checked_input_count":dim,"evidence_class":"full_original_qpy_to_analytic_source",
             "phase_scope":"one phase across every column and batch", "max_input_residual":residual,
             "tolerance":oracle.TOLERANCE,"passed":bool(math.isfinite(residual) and residual<oracle.TOLERANCE)}
        rows.append(row)
        print(json.dumps({"original_qpy":case["fixture"],"passed":row["passed"],"residual":residual}),flush=True)
    return rows


def validate_rows(cases,rows,outdir,chunk):
    indexed={case["id"]:case for case in cases}
    cache={}
    bindings=[]
    with (outdir/"artifacts.jsonl").open("x") as artifacts:
        for index,row in enumerate(rows):
            case=indexed[row["case_id"]]
            binding={"row_id":row.get("id",index),"case_id":case["id"],
                     "session":row.get("session"),"trial":row.get("trial"),"seed":row.get("seed"),
                     "row_sha256":digest(json.dumps(row,sort_keys=True))}
            if row.get("status")!="compiled":
                bindings.append({**binding,"passed":False,
                                 "status":row.get("status"),"error":row.get("error")})
                continue
            key=digest(json.dumps([case["source_sha256"],case["physical_width"],case["edges"],
                                   row["out_qasm"],row["initial_layout"],row["final_layout"]],sort_keys=True))
            if key not in cache:
                evidence=complete_columns(case,row,chunk)
                artifact={"key":key,"case_id":case["id"],"source_sha256":case["source_sha256"],
                          "output_sha256":digest(row["out_qasm"]),"initial_layout":row["initial_layout"],
                          "final_layout":row["final_layout"],"validation":evidence}
                cache[key]=artifact
                artifacts.write(json.dumps(artifact)+"\n")
                artifacts.flush()
                print(json.dumps({"validated":len(cache),"case":case["id"],"passed":evidence["passed"],
                                  "residual":evidence.get("max_input_residual")}),flush=True)
            bindings.append({**binding,"artifact_key":key,
                             "passed":cache[key]["validation"]["passed"]})
    save(outdir/"bindings.json",bindings)
    return {"row_count":len(rows),"unique_artifacts":len(cache),"all_passed":all(x["passed"] for x in bindings),
            "max_input_residual":max((x["validation"].get("max_input_residual",math.inf) for x in cache.values()),default=None),
            "checked_columns_per_artifact":sorted({x["validation"].get("checked_input_count") for x in cache.values()}),
            "artifacts_sha256":digest((outdir/"artifacts.jsonl").read_bytes()),
            "bindings_sha256":digest((outdir/"bindings.json").read_bytes())}


def self_test():
    case={"n_logical":3,"physical_width":3,"topology":"all_to_all","edges":[],
          "source_qasm":qasm(3,[])}
    good={"out_qasm":qasm(3,[]),"initial_layout":[0,1,2],"final_layout":[0,1,2]}
    bad={**good,"out_qasm":qasm(3,["u3(0,0,0.37) q[2];"])}
    assert complete_columns(case,good,3)["passed"]
    bad_check=complete_columns(case,bad,4)
    # Each four-column batch has a constant phase. Per-batch or per-column
    # alignment would incorrectly return zero; assert our own complete residual.
    assert not bad_check["passed"] and bad_check["max_input_residual"]>0.1
    global_phase={**good,"out_qasm":qasm(3,[f"u3({2*math.pi!r},0,0) q[0];"])}
    assert complete_columns(case,global_phase,3)["passed"]
    case["source_qasm"]=qasm(3,["swap q[0],q[1];","swap q[1],q[2];"])
    permuted={**good,"final_layout":[1,2,0]}
    assert complete_columns(case,permuted,3)["passed"]
    wrong=complete_columns(case,{**permuted,"final_layout":[2,0,1]},3)
    assert not wrong["passed"] and wrong["max_input_residual"]>1.0
    generated=stress_cases()
    assert len(generated)==80 and len({row["id"] for row in generated})==80
    assert generated==stress_cases()
    for row in generated:
        assert oracle.parse_qasm(row["source_qasm"])[0]==row["n_logical"]
    print("Supplemental checker self-tests passed",flush=True)


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument("mode",choices=("candidate","official","self-test"))
    parser.add_argument("--protocol",type=Path,default=HERE.parent/"qrust_external_followup_20261018/study/protocol.json")
    parser.add_argument("--study",type=Path)
    parser.add_argument("--binary",type=Path)
    parser.add_argument("--output",type=Path)
    parser.add_argument("--skip-stress",action="store_true")
    parser.add_argument("--check-qpy",action="store_true")
    parser.add_argument("--corpus",type=Path,default=HERE.parent/"qrust_external_20261018/corpus")
    parser.add_argument("--chunk-columns",type=int,default=32)
    args=parser.parse_args()
    if digest(Path(oracle.__file__).read_bytes())!=EXPECTED_ORACLE:
        raise ValueError("independent oracle source changed")
    if args.chunk_columns<1:
        parser.error("chunk size must be positive")
    self_test()
    if args.mode=="self-test":
        return
    if args.output is None:
        parser.error("--output required")
    if any((study/"active.lock").exists() for study in (HERE/"study",HERE.parent/"qrust_external_followup_20261018/study")):
        raise RuntimeError("main benchmark active: do not run simulation concurrently")
    if args.mode=="official":
        if args.study is None:
            parser.error("--study required")
        if (args.study/"active.lock").exists():
            raise RuntimeError("study is active")
        args.protocol=args.study/"protocol.json"
    protocol=json.loads(args.protocol.read_text())
    if args.mode=="official":
        from external_comparison import check_rows, load_protocol
        checked_protocol,_=load_protocol(args.study)
        if checked_protocol!=protocol:
            raise ValueError("loaded protocol mismatch")
    cases=[c for c in protocol["cases"] if c["fixture"] in FOCAL]
    if len(cases)!=6:
        raise ValueError("expected six focal cases")
    for case in cases:
        for source,checksum in (("qasm","normalized_sha256"),("source_qasm","source_sha256")):
            if digest(case[source])!=case[checksum]:
                raise ValueError("protocol source hash mismatch")
    args.output.mkdir(parents=True,exist_ok=False)
    receipt={"kind":"supplemental complete-column routing validation","created_utc":datetime.now(timezone.utc).isoformat(),
             "mode":args.mode,"script_sha256":digest(Path(__file__).read_bytes()),"oracle_sha256":EXPECTED_ORACLE,
             "protocol_sha256":digest(args.protocol.read_bytes()),"chunk_columns":args.chunk_columns,
             "global_phase_policy":"one phase across all input columns and all batches",
             "limitation":"Numerical complete-basis checks are not a formal proof; synthetic stress cases are separate from community benchmark coverage."}
    if args.mode=="candidate":
        if args.binary is None:
            parser.error("--binary required")
        if not args.skip_stress:
            cases+=stress_cases()
        save(args.output/"cases.json",cases)
        receipt.update(binary_sha256=digest(args.binary.read_bytes()),synthetic_seed=SEED,
                       synthetic_circuits=0 if args.skip_stress else 40)
        rows=[]
        worker=Worker("qrust",args.binary.resolve(),args.output)
        try:
            for case in cases:
                request={key:case[key] for key in ("qasm","n_logical","physical_width","edges","topology")}
                result=worker.call({**request,"seed":20261018},60)
                rows.append({"case_id":case["id"],"id":case["id"]+"__candidate",**result})
        finally:
            worker.close()
        save(args.output/"compiled_rows.json",rows)
        receipt["compiled_rows_sha256"]=digest((args.output/"compiled_rows.json").read_bytes())
    else:
        rows=[]
        receipt["timed_files"]={}
        for session in (1,2):
            path=args.study/f"session_{session:02d}"/"timed.jsonl"
            allrows=[json.loads(line) for line in path.read_text().splitlines()]
            check_rows(protocol,session,allrows)
            rows.extend(row for row in allrows if row["tool"]=="qrust" and row["case_id"] in {c["id"] for c in cases})
            receipt["timed_files"][str(session)]={"sha256":digest(path.read_bytes()),"row_count":len(allrows)}
        if len(rows)!=6*protocol["trials"]*protocol["sessions"]:
            raise ValueError("focal timed row grid incomplete")
    receipt["complete_column_results"]=validate_rows(cases,rows,args.output,args.chunk_columns)
    if args.check_qpy:
        receipt["retained_original_source_checks"]=check_raw_qpy([c for c in cases if c["fixture"] in FOCAL],args.corpus,args.chunk_columns)
    receipt["all_passed"]=receipt["complete_column_results"]["all_passed"] and all(
        row["passed"] for row in receipt.get("retained_original_source_checks",[]))
    save(args.output/"receipt.json",receipt)
    print(json.dumps(receipt,indent=2),flush=True)
    if not receipt["all_passed"]:
        raise SystemExit("supplemental validation failed")


if __name__=="__main__":
    main()
