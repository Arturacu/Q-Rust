from pathlib import Path
import json,sys,statistics,hashlib
w=Path(__file__).resolve().parent;repo=w.parent/'qrust_pr_publish'
sys.path.insert(0,str(repo/'experiments'))
from comparison_study import Worker
p=json.loads((w.parent/'qrust_external_followup_20261018/study/protocol.json').read_text())
choices=[c for c in p['cases'] if c['fixture'] in ['mqtbench__ae_n10','mqtbench__qpeexact_n10','mqtbench__qpeinexact_n10']]
variants={'default':{},'layout1x1':{'layout_trials':1,'layout_iterations':1},'layout1x3':{'layout_trials':1},'no_diagonal_commutation':{'commute_diagonal':False},'no_block_synthesis':{'two_qubit_block_synthesis':False},'no_phase_recovery':{'recover_phase_gadgets':False}}
out=w/'baseline_probes';out.mkdir(exist_ok=False)
binary=w.parent/'qrust_external_followup_20261018/comparison_runner_fixed'
worker=Worker('qrust',binary,out);rows=[]
try:
 for c in choices:
  req={k:c[k] for k in ['qasm','n_logical','physical_width','edges','topology']};req.update(seed=20261018,profile_passes=True)
  for label,opts in variants.items():
   for trial in range(3):
    result=worker.call({**req,**opts},60)
    rows.append({'case':c['id'],'variant':label,'trial':trial,'result':result})
finally:worker.close()
(w/'baseline_stage_probes.json').write_text(json.dumps({'binary_sha256':hashlib.sha256(binary.read_bytes()).hexdigest(),'scope':'Untuned development diagnostics; profiler enabled; not official measurements','rows':rows},indent=2)+'\n')
for c in choices:
 print(c['id'])
 for v in variants:
  r=[r['result'] for r in rows if r['case']==c['id'] and r['variant']==v]
  print(v,round(statistics.median(x['compile_ns'] for x in r)/1e6,3),[(x['pass'],round(x['elapsed_ns']/1e6,3),x['two_qubit_gates'],x['swaps'],x['layout_route_evaluations']) for x in r[1]['pass_diagnostics'] if x['elapsed_ns']>100000 or x['pass'] in ['SabreLayoutPass','BeamSabrePass']])
