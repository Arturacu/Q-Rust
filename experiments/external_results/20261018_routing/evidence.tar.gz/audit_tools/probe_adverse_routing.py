"""Post-study, single-request diagnostics for every observed quality regression.

Exact eight source variants isolate the three changes. A separately labeled
broad commutation control disables all diagonal freedom, not CU1 alone.
Profiling is diagnostic; these requests are not performance measurements.
"""
from collections import Counter
from pathlib import Path
import hashlib
import json
import sys

WORK = Path(__file__).resolve().parent
REPO = WORK.parent / "qrust_pr_publish"
sys.path.insert(0, str(REPO / "experiments"))
from comparison_study import Worker
from comparison_validation import parse_qasm, validate_output


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    output = WORK / "adverse_probes.json"
    if output.exists():
        raise FileExistsError(output)
    protocol_path = WORK.parent / "qrust_external_followup_20261018/study/protocol.json"
    protocol = json.loads(protocol_path.read_text())
    wanted = {"qasmbench__basis_trotter_n4", "qasmbench__pea_n5", "qasmbench__qft_n4"}
    cases = {c["id"]: c for c in protocol["cases"]
             if c["fixture"] in wanted and c["topology"] == "linear"}
    assert len(cases) == 3
    manifest_path = WORK / "variants/manifest.json"
    manifest = json.loads(manifest_path.read_text())
    logdir = WORK / "adverse_workers"
    logdir.mkdir(exist_ok=False)
    rows = []
    for bits, metadata in sorted(manifest["variants"].items()):
        binary = WORK / "variants" / bits
        assert sha(binary) == metadata["binary_sha256"]
        folder = logdir / bits
        folder.mkdir()
        worker = Worker("qrust", binary, folder)
        try:
            for key, case in cases.items():
                request = {k: case[k] for k in ["qasm", "n_logical", "physical_width", "edges", "topology"]}
                request.update(seed=20261018, profile_passes=True)
                result = worker.call(request, 60)
                rows.append({"case_id": key, "variant": bits, "control": "exact_factorial",
                             "request_overrides": {"profile_passes": True}, "result": result})
                if bits == "111":
                    result = worker.call({**request, "commute_diagonal": False}, 60)
                    rows.append({"case_id": key, "variant": bits, "control": "all_diagonal_commutation_disabled",
                                 "request_overrides": {"profile_passes": True, "commute_diagonal": False},
                                 "result": result})
        finally:
            worker.close()
    # Keep verification separate from every diagnostic compilation request.
    for row in rows:
        case = cases[row["case_id"]]
        result = row["result"]
        assert result["status"] == "compiled", result
        edges = [edge for a, b in case["edges"] for edge in [(a, b), (b, a)]]
        row["validation"] = validate_output(
            case["source_qasm"], result["out_qasm"], case["n_logical"], case["physical_width"],
            edges, result["initial_layout"], result["final_layout"])
        assert row["validation"]["passed"], row["validation"]
        assert row["validation"]["checked_input_count"] == 2 ** case["n_logical"]
    exact = {(r["case_id"], r["variant"]): r for r in rows if r["control"] == "exact_factorial"}
    identities = []
    for key in cases:
        for prefix in ["00", "01", "10", "11"]:
            a, b = exact[key, prefix + "0"]["result"], exact[key, prefix + "1"]["result"]
            equal = all(a[k] == b[k] for k in ["out_qasm", "initial_layout", "final_layout"])
            identities.append({"case_id": key, "variants": [prefix + "0", prefix + "1"],
                               "qasm_and_layouts_identical": equal})
            assert equal, "memoization changed output"
    report = {
        "scope": "Post-study diagnostic of all three observed quality regressions; one profiled compilation per exact source variant and a separately labeled broad control. No production changes or official rerun.",
        "timing_interpretation": "Single instrumented requests; elapsed values are diagnostic only, with no repeated-trial speed claim.",
        "bit_order": manifest["bit_order"],
        "provenance": {"protocol_sha256": sha(protocol_path), "variant_manifest_sha256": sha(manifest_path),
                       "script_sha256": sha(Path(__file__)), "oracle_sha256": sha(REPO / "experiments/comparison_validation.py")},
        "input_gate_counts": {key: dict(Counter(g.name for g in parse_qasm(c["qasm"])[1])) for key, c in cases.items()},
        "binary_sha256": {bits: m["binary_sha256"] for bits, m in manifest["variants"].items()},
        "cache_identity_checks": identities,
        "all_validation_passed": all(r["validation"]["passed"] for r in rows),
        "max_input_residual": max(r["validation"]["max_input_residual"] for r in rows),
        "rows": rows,
    }
    with output.open("x") as stream:
        json.dump(report, stream, indent=2)
        stream.write("\n")
    for row in rows:
        result = row["result"]
        stages = [{k: stage[k] for k in ["pass", "two_qubit_gates", "swaps", "depth", "layout_route_evaluations"]}
                  for stage in result["pass_diagnostics"]
                  if stage["pass"] in ["ExtractOutputPermutationPass", "SabreLayoutPass", "BeamSabrePass", "TwoQubitBlockSynthesisPass"]]
        print(json.dumps({"case": row["case_id"], "variant": row["variant"], "control": row["control"],
                          "metrics": row["validation"]["metrics"], "initial": result["initial_layout"],
                          "final": result["final_layout"], "phase_recovery": result["phase_gadgets_recovered"],
                          "block_stats": result["two_qubit_block_stats"], "stages": stages}))
    print(json.dumps({"saved": str(output), "checks": len(rows), "all_passed": report["all_validation_passed"],
                      "cache_output_identity": True, "max_input_residual": report["max_input_residual"]}))


if __name__ == "__main__":
    main()
