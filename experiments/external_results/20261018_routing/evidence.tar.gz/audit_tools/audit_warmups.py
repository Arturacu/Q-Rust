#!/usr/bin/env python3
"""Supplemental artifact audit after the frozen external timing/validation run."""
from collections import Counter, defaultdict
import hashlib
import json
from pathlib import Path
import sys

BASE = Path(__file__).resolve().parent
REPO = BASE.parent / "qrust_pr_publish"
sys.path.insert(0, str(REPO / "experiments"))
from external_comparison import artifact_hash, check_rows, load_protocol
from comparison_validation import validate_output


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def rows(path):
    return [json.loads(line) for line in path.read_text().splitlines() if line.strip()]


def main():
    study = BASE / "study"
    if (study / "active.lock").exists():
        raise RuntimeError("Cannot audit during active benchmark timing")
    for name in ("warmup_validation_artifacts.jsonl", "warmup_validation_receipt.json"):
        if (BASE / name).exists():
            raise FileExistsError("Audit result already exists: " + name)
    protocol, protocol_sha = load_protocol(study)
    receipt_path = study / "validation_summary.json"
    official = json.loads(receipt_path.read_text())
    assert official["protocol_sha256"] == protocol_sha
    oracle = REPO / "experiments/comparison_validation.py"
    assert digest(oracle) == official["oracle_sha256"] == protocol["source_sha256"]["experiments/comparison_validation.py"]
    cases = {case["id"]: case for case in protocol["cases"]}
    cache, inherited_keys, failure_groups, session_checks, sources = {}, set(), defaultdict(list), [], {}
    for session in range(1, protocol["sessions"] + 1):
        directory = study / f"session_{session:02d}"
        meta = json.loads((directory / "session.json").read_text())
        assert meta["completed"] and meta["protocol_sha256"] == protocol_sha
        entry = next(entry for entry in official["sessions"] if entry["session"] == directory.name)
        for name in ("timed", "warmup"):
            assert digest(directory / f"{name}.jsonl") == meta[f"{name}_sha256"]
        assert digest(directory / "validated.jsonl") == entry["validated_sha256"]
        timed = rows(directory / "timed.jsonl")
        validated = rows(directory / "validated.jsonl")
        check_rows(protocol, session, timed)
        check_rows(protocol, session, validated)
        assert len(timed) == len(validated)
        for original, checked in zip(timed, validated):
            assert all(checked[key] == value for key, value in original.items())
            if checked["status"] == "compiled":
                key = artifact_hash(cases[checked["case_id"]], checked)
                assert key == checked["artifact_sha256"] == checked["validation_cache_key"]
                if key in cache:
                    assert cache[key] == checked["validation"]
                cache[key] = checked["validation"]
                inherited_keys.add(key)
            else:
                failure_groups[checked["tool"], checked.get("error", "unknown")].append(
                    {"session": session, "case_id": checked["case_id"], "trial": checked["trial"]})
        sources[directory.name] = {name: digest(directory / name) for name in
            ("session.json", "timed.jsonl", "warmup.jsonl", "validated.jsonl")}

    checks, simulated = [], set()
    for session in range(1, protocol["sessions"] + 1):
        directory = study / f"session_{session:02d}"
        warmed = rows(directory / "warmup.jsonl")
        initial = [row for row in warmed if row.get("reason") != "worker_restart"]
        expected = [entry for entry in protocol["schedules"][str(session)] if entry["trial"] == -1]
        assert len(initial) == len(expected)
        for row, planned in zip(initial, expected):
            assert all(row[key] == value for key, value in planned.items())
            assert row["session"] == session
            assert row["id"] == f"{row['case_id']}__{row['tool']}__-1"
        counts = Counter()
        for index, row in enumerate(warmed):
            case = cases[row["case_id"]]
            check = {"session": session, "warmup_index": index, "case_id": row["case_id"],
                     "tool": row["tool"], "reason": row.get("reason", "initial"), "status": row["status"]}
            if row["status"] != "compiled":
                check.update(outcome="not_compiled", error=row.get("error"))
                counts[f"{row['tool']}_not_compiled"] += 1
            else:
                actual_hash = hashlib.sha256(row["out_qasm"].encode()).hexdigest()
                if "output_sha256" in row:
                    assert actual_hash == row["output_sha256"]
                # Restart records omit these derived fields in the frozen
                # harness; their complete text is still bound by warmup_sha256.
                with_hash = {**row, "output_sha256": actual_hash}
                key = artifact_hash(case, with_hash)
                if "artifact_sha256" in row:
                    assert key == row["artifact_sha256"]
                if key not in cache:
                    edges = None if case["topology"] == "all_to_all" else [
                        pair for a, b in case["edges"] for pair in ((a, b), (b, a))]
                    cache[key] = validate_output(case["source_qasm"], row["out_qasm"],
                        case["n_logical"], case["physical_width"], edges,
                        row["initial_layout"], row["final_layout"])
                    simulated.add(key)
                check.update(outcome="passed" if cache[key]["passed"] is True else "failed",
                    artifact_sha256=key, output_sha256=actual_hash,
                    evidence_source="exact_timed_artifact_reuse" if key in inherited_keys else "fresh_warmup_artifact_simulation",
                    validation=cache[key])
                counts[f"{row['tool']}_{check['outcome']}"] += 1
            checks.append(check)
        session_checks.append({"session": session, "initial_warmups": len(initial),
            "restart_warmups": len(warmed) - len(initial), "counts": dict(counts)})
    checks_path = BASE / "warmup_validation_artifacts.jsonl"
    with checks_path.open("x") as stream:
        stream.write("".join(json.dumps(row, sort_keys=True) + "\n" for row in checks))
    failed_measured = []
    for (tool, error), records in sorted(failure_groups.items()):
        stage = "input parser" if tool == "qrust" and error == "Unknown gate: cu1" else (
            "output basis-closure serialization" if tool in {"cirq", "cirq_one_pass"} and error.startswith("ValueError: Cirq output is not closed") else "unclassified")
        failed_measured.append({"tool": tool, "error": error, "stage": stage,
            "total_trials": len(records), "cases": sorted({row["case_id"] for row in records}),
            "per_session_trials": dict(Counter(str(row["session"]) for row in records))})
    report = {"protocol_sha256": protocol_sha, "official_validation_receipt_sha256": digest(receipt_path),
        "audit_source_sha256": digest(Path(__file__)), "oracle_sha256": digest(oracle),
        "session_files_sha256": sources, "scope": "Supplemental post-timing warmup audit; no compiler rerun or replacement of measured failures",
        "reused_evidence_rule": "Only exact matching original source, normalized source, topology, physical width, edges, output QASM, output width and both layouts reuse a fully checksum-bound timed artifact validation",
        "sessions": session_checks, "total_warmup_rows": len(checks),
        "compiled_warmups": sum(row["status"] == "compiled" for row in checks),
        "passed_warmups": sum(row["outcome"] == "passed" for row in checks),
        "failed_numerical_warmups": sum(row["outcome"] == "failed" for row in checks),
        "not_compiled_warmups": sum(row["outcome"] == "not_compiled" for row in checks),
        "unique_warmup_artifacts": len({row["artifact_sha256"] for row in checks if "artifact_sha256" in row}),
        "new_artifacts_simulated": len(simulated),
        "max_warmup_residual": max((row.get("validation", {}).get("max_input_residual", 0) for row in checks), default=0),
        "artifact_rows_sha256": digest(checks_path), "measured_failure_groups": failed_measured,
        "limitations": "The unchanged oracle uses full numerical isometries through six physical qubits and eight sampled inputs above six; these are numerical evidence, not proofs."}
    destination = BASE / "warmup_validation_receipt.json"
    with destination.open("x") as stream:
        stream.write(json.dumps(report, indent=2, sort_keys=True) + "\n")
    print(json.dumps({key: report[key] for key in ("total_warmup_rows", "compiled_warmups", "passed_warmups", "failed_numerical_warmups", "not_compiled_warmups", "unique_warmup_artifacts", "new_artifacts_simulated", "max_warmup_residual")}))


if __name__ == "__main__":
    main()
