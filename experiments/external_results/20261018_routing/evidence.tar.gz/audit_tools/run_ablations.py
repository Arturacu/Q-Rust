from pathlib import Path
import hashlib,json,random,statistics,sys
w=Path(__file__).resolve().parent;r=w.parent/'qrust_pr_publish'
sys.path.insert(0,str(r/'experiments'))
from comparison_study import Worker
p=json.loads((w.parent/'qrust_external_followup_20261018/study/protocol.json').read_text())
cases={c['id']:c for c in p['cases'] if c['fixture'] in ['mqtbench__ae_n10','mqtbench__qpeexact_n10','mqtbench__qpeinexact_n10']}
variants=json.loads((w/'variants/manifest.json').read_text())['variants']
out=w/'factorial';out.mkdir(exist_ok=False)
workers={};rows=[];profiles=[]
try:
 for bits in variants:
  folder=out/bits;folder.mkdir();workers[bits]=Worker('qrust',w/'variants'/bits,folder)
 rng=random.Random(2026101804)
 with (out/'rows.jsonl').open('x') as log:
  for trial in range(-1,7):
   order=[(bits,case) for bits in variants for case in cases];rng.shuffle(order)
   for bits,key in order:
    c=cases[key];request={k:c[k] for k in ['qasm','n_logical','physical_width','edges','topology']}
    result=workers[bits].call({**request,'seed':20261018},60)
    row={'variant':bits,'case_id':key,'trial':trial,'result':result};rows.append(row)
    log.write(json.dumps(row)+'\n');log.flush()
 with (out/'profile_rows.jsonl').open('x') as log:
  for bits in variants:
   for key,c in cases.items():
    request={k:c[k] for k in ['qasm','n_logical','physical_width','edges','topology']}
    result=workers[bits].call({**request,'seed':20261018,'profile_passes':True},60)
    row={'variant':bits,'case_id':key,'result':result};profiles.append(row);log.write(json.dumps(row)+'\n')
finally:
 for worker in workers.values():worker.close()
# Simulations only after every timing and profiling request has completed.
from supplemental_validation import complete_columns
from comparison_validation import parse_qasm,common_metrics
checks=[];summary=[]
for key,c in cases.items():
 for bits in variants:
  group=[x for x in rows if x['case_id']==key and x['variant']==bits]
  artifacts={json.dumps([x['result'].get(k) for k in ['out_qasm','initial_layout','final_layout']],sort_keys=True) for x in group}
  assert len(artifacts)==1 and all(x['result']['status']=='compiled' for x in group)
  result=group[0]['result'];check=complete_columns(c,result)
  checks.append({'case_id':key,'variant':bits,'validation':check})
  assert check['passed']
  profile=next(x['result'] for x in profiles if x['case_id']==key and x['variant']==bits)
  assert all(profile[k]==result[k] for k in ['out_qasm','initial_layout','final_layout'])
  metrics=common_metrics(*parse_qasm(result['out_qasm']))
  timing=[x['result']['compile_ns']/1e6 for x in group if x['trial']>=0]
  summary.append({'case_id':key,'variant':bits,'compile_ms_median':statistics.median(timing),'compile_ms_min':min(timing),'compile_ms_max':max(timing),'metrics':metrics,'profile':profile['pass_diagnostics']})
 for prefix in ['00','01','10','11']:
  a=next(x['result'] for x in rows if x['case_id']==key and x['variant']==prefix+'0')
  b=next(x['result'] for x in rows if x['case_id']==key and x['variant']==prefix+'1')
  assert all(a[k]==b[k] for k in ['out_qasm','initial_layout','final_layout']), 'cache changed output'
 print(key,[(x['variant'],round(x['compile_ms_median'],3),x['metrics']) for x in summary if x['case_id']==key],flush=True)
(out/'validation.json').write_text(json.dumps({'full_columns_per_artifact':1024,'checks':checks,'cache_output_identity':True},indent=2)+'\n')
(out/'summary.json').write_text(json.dumps({'scope':'Six focal development cells, exact-source factorial; seven interleaved timed trials, one warmup; profiling and full-column validation follow timing. Not a held-out study.','seed':2026101804,'bit_order':['cu1_diagonal','logical_swap_absorption','layout_memoization'],'rows':summary},indent=2)+'\n')
