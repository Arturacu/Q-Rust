Q-Rust external routing follow-up evidence, 2026-10-18

This separately recorded study changes exact CU1 diagonal classification,
absorbs logical SWAPs into operand/output mappings, and memoizes repeated
layout evaluations. It keeps the same 50 community fixtures, 100 target cells,
six recipes, seeds, schedules, packages, numerical oracle and trial design.
The two earlier studies and their reports remain unchanged.

The archive contains byte-exact protocol/corpus, both timed/warmup/validated
sessions, complete analysis JSON/CSV, cross-run analysis, frozen harness,
changed compiler and regression files, report and figures. It also retains
the full 8-variant source-factorial diagnostics, baseline pass probes,
synthetic stress checks and complete 1,024-column focal validation. Source
hashes and the compiler Git commit bind the complete project; executables,
worker logs, caches and unrelated workspace files are excluded. The two
explicit preflight test/build logs are retained and bound by their receipt.

BASELINE_REFERENCES.json binds the preserved compatibility archive used for
before/after comparison and the original archive containing upstream source,
raw community circuits and licenses. Their payloads are not duplicated here.
The new study protocol embeds every original and normalized QASM input.

New-study replay: safely extract this archive; rename study/analysis to
study/recorded_analysis. In the pinned Python environment run:
python harness/experiments/analyze_external_comparison.py study
Compare external_summary.json and four CSV files byte-for-byte with recorded
copies. Existing output directories are rejected.

Cross-run replay: also hash-check and extract the compatibility archive into
baseline_compatibility/. Run:
python harness/experiments/analyze_external_routing.py
baseline_compatibility/study study --output replayed_routing_analysis
Compare routing_comparison.json byte-for-byte with
routing_analysis/routing_comparison.json. Both analyzers use 2,000 bootstrap
draws by default and keep the two sessions separate. The archived
replay_archives.py additionally extracts/verifies the original archive.

The same 100-cell cohort is compared before and after. Every case-level
regression remains in the analysis. Unchanged compiler timings are descriptive
host-drift controls; exact source-factorial diagnostics provide separate
mechanism evidence. CX count and depth are structural costs, not proven
optima or execution fidelity. Complete-column checks are numerical evidence,
not a formal proof. These circuits informed development and are not an
untouched holdout. Synthetic stress results remain distinct from community
benchmark coverage.

MANIFEST.json records every payload size and SHA256. The repository's adjacent
evidence_manifest.json binds the archive hash and fresh extraction checks.
Archive metadata is normalized while input bytes are preserved. All 28 earlier
result/report files are hash-checked before and after packaging. Existing
archives, missing required receipts, or changed frozen inputs cause failure.
