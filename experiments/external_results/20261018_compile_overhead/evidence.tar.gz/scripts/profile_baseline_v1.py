#!/usr/bin/env python3
"""Bounded pass diagnostics with profiling-on/off controls; not formal timing."""
import argparse
from collections import Counter, defaultdict
import hashlib
import json
from pathlib import Path
import statistics
import sys
import time


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def save(path, value):
    with path.open('x') as stream:
        json.dump(value, stream, indent=2, sort_keys=True, allow_nan=False)
        stream.write('\n')


def main():
    p = argparse.ArgumentParser(description=__doc__)
    for name in ('repo', 'binary', 'baseline', 'output'):
        p.add_argument('--' + name, type=Path, required=True)
    a = p.parse_args()
    for name, value in vars(a).items():
        setattr(a, name, value.resolve())
    sys.path.insert(0, str(a.repo / 'experiments'))
    import paired_campaign as campaign
    from paired_analysis import checked_artifact
    ext, _ = campaign.modules(a.repo)
    protocols = {suite: json.loads((a.baseline / suite / 'protocol.json').read_text())
                 for suite in ('external', 'matched')}
    expected = protocols['external']['qrust_binary_sha256']
    assert sha(a.binary) == expected == protocols['matched']['binary_sha256']
    selected = {
        'external': ['qasmbench__error_correctiond3_n5__all_to_all', 'qasmbench__error_correctiond3_n5__linear',
                     'qasmbench__qec_en_n5__all_to_all', 'qasmbench__qec_en_n5__linear',
                     'mqtbench__ae_n10__linear', 'mqtbench__qpeexact_n10__linear',
                     'mqtbench__qpeexact_n5__all_to_all', 'qasmbench__basis_trotter_n4__linear'],
        'matched': ['cat22_square', 'cat22_heavy-hex', 'ghz23_square', 'ghz23_heavy-hex',
                    'bv100_square', 'bv100_heavy-hex']}
    cases = [(suite, next(case for case in protocols[suite]['cases'] if case['id'] == name))
             for suite, names in selected.items() for name in names]
    a.output.mkdir(parents=True, exist_ok=False)
    schedule = []
    for index, (suite, case) in enumerate(cases):
        for repeat in range(4):
            order = [False, True] if (repeat + index) % 2 == 0 else [True, False]
            for mode in order:
                request = {k: case[k] for k in ('qasm', 'n_logical', 'physical_width', 'edges', 'topology')}
                request.update(profile_passes=mode, seed=20261018)
                schedule.append({'suite': suite, 'case_id': case['id'], 'phase': 'warmup' if repeat == 0 else 'diagnostic',
                                 'repeat': repeat, 'profile_passes': mode, 'request': request})
    save(a.output / 'protocol.json', {'scope': __doc__, 'binary_sha256': expected,
         'compiler_commit': protocols['external']['compiler_commit'], 'script_sha256': sha(__file__),
         'baseline_protocol_sha256': {s: sha(a.baseline / s / 'protocol.json') for s in protocols},
         'schedule': schedule, 'cases': {s: [c for suite, c in cases if suite == s] for s in protocols},
         'request_timeout_seconds': 30, 'whole_compilation_limit_seconds': 120,
         'repetitions': 3, 'warmup_per_mode_per_case': 1,
         'order': 'One shared worker, consecutive modes alternated by repeat and case. Includes mode-specific warmups. Warm-cache diagnostic only; not a formal speed comparison.',
         'pass_accounting_limit': 'Returned pass traces can describe the selected continuation and omit discarded work; they are not assumed to partition total compilation time.'})
    (a.output / 'worker').mkdir()
    rows = []
    worker = ext.ProfileWorker('qrust', a.binary, a.output / 'worker')
    start = time.monotonic()
    try:
        with (a.output / 'raw.jsonl').open('x') as stream:
            for slot in schedule:
                if time.monotonic() - start > 120:
                    raise TimeoutError('Bounded compilation phase exceeded 120 seconds')
                result = ext.timed_request(worker, slot['request'], 30)
                row = dict(slot, result=result)
                stream.write(campaign.canonical(row) + '\n'); stream.flush()
                rows.append(row)
                if result.get('status') != 'compiled':
                    raise RuntimeError('Profile request did not compile; raw outcome preserved')
                if len(rows) % 8 == 0:
                    print(json.dumps({'case_done': slot['case_id'], 'requests': len(rows),
                        'elapsed_seconds': round(time.monotonic() - start, 3)}), flush=True)
    finally:
        worker.close()
    compilation_wall = time.monotonic() - start
    from comparison_validation import validate_output, parse_qasm, common_metrics
    from scalable_clifford import validate_clifford
    cache, counts, grouped = {}, Counter(), defaultdict(list)
    case_lookup = {(s, c['id']): c for s, c in cases}
    with (a.output / 'validated.jsonl').open('x') as stream:
        for row in rows:
            key = row['suite'], row['case_id']
            status, cache_key, validation = checked_artifact(case_lookup[key], row['result'], row['suite'],
                cache, validate_output, validate_clifford, parse_qasm, common_metrics)
            enriched = dict(row, outcome=status, validation_cache_key=cache_key, validation=validation)
            stream.write(campaign.canonical(enriched) + '\n')
            counts[status] += 1; grouped[key].append(enriched)
    summary = []
    ignored = {'compile_ns', 'parse_ns', 'request_wall_ns', 'noncompile_nonparse_request_ns', 'pass_diagnostics'}
    for (suite, case_id), values in grouped.items():
        fingerprints = {campaign.canonical({k: v for k, v in row['result'].items() if k not in ignored}) for row in values}
        assert len(fingerprints) == 1, 'Profiling or repeated execution changed non-timing output: ' + case_id
        measurements = [row for row in values if row['phase'] == 'diagnostic']
        modes = {str(mode): statistics.median(row['result']['compile_ns'] for row in measurements
                    if row['profile_passes'] == mode) for mode in (False, True)}
        passes = defaultdict(list)
        for row in measurements:
            if row['profile_passes']:
                for index, entry in enumerate(row['result']['pass_diagnostics']):
                    passes[index, entry['pass']].append(entry['elapsed_ns'])
        trace = [{'index': index, 'pass': name, 'median_ns': statistics.median(times)}
                 for (index, name), times in sorted(passes.items())]
        sample = measurements[0]
        summary.append({'suite': suite, 'case_id': case_id, 'outcomes': dict(Counter(r['outcome'] for r in values)),
            'all_nontiming_outputs_identical': True, 'compile_ns_median': modes,
            'profiling_on_over_off': modes['True'] / modes['False'], 'pass_medians': trace,
            'pass_median_sum_ns': sum(t['median_ns'] for t in trace),
            'metrics': sample['validation']['metrics'],
            'clifford_retention_stats': sample['result']['clifford_retention_stats'],
            'clifford_simplification_stats': sample['result']['clifford_simplification_stats']})
    save(a.output / 'summary.json', {'scope': __doc__, 'protocol_sha256': sha(a.output/'protocol.json'),
         'raw_sha256': sha(a.output/'raw.jsonl'), 'validated_sha256': sha(a.output/'validated.jsonl'),
         'compilation_wall_seconds': compilation_wall, 'requests': len(rows), 'counts': dict(counts),
         'unique_artifacts': len(cache), 'cases': summary})
    if any(key != 'passed' for key in counts):
        raise RuntimeError('Validation has a nonpassing output; inspect preserved evidence')
    print(json.dumps({'completed': True, 'requests': len(rows), 'counts': dict(counts),
        'compilation_wall_seconds': compilation_wall}), flush=True)


if __name__ == '__main__':
    main()
