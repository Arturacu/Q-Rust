#!/usr/bin/env python3
"""Derive diagnostic trace changes and exact saved-output parity without timing."""
import hashlib
import json
from pathlib import Path
import sys
BASE = Path(__file__).resolve().parent
sys.path.insert(0, str(BASE/'verification'))
from result_parity import compare_results

def sha(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()

def main():
    names=['baseline_profile_v2','pass_only_profile','final_profile']
    summaries={n: json.loads((BASE/n/'summary.json').read_text()) for n in names}
    traces={n: {c['case_id']: c for c in s['cases']} for n,s in summaries.items()}
    cases=[]
    for case_id in traces[names[0]]:
        row={'case_id': case_id, 'variants':{}}
        for n in names:
            c=traces[n][case_id]
            selected={k:[{'pass':p['pass'],'median_ns':p['median_ns']} for p in c['pass_medians'] if p['pass'].split('::')[-1]==k]
                      for k in ['SabreLayoutPass','BeamSabrePass','ReuseRoutingCheckpoint','CliffordSimplificationPass']}
            row['variants'][n]={'unprofiled_compile_median_ns':c['compile_ns_median']['False'], 'profiled_compile_median_ns':c['compile_ns_median']['True'], 'passes':selected}
        cases.append(row)
    old=[json.loads(x) for x in (BASE/names[0]/'raw.jsonl').read_text().splitlines()]
    new=[json.loads(x) for x in (BASE/names[-1]/'raw.jsonl').read_text().splitlines()]
    assert len(old)==len(new)==112
    checks=[]
    envelope={'request_wall_ns','noncompile_nonparse_request_ns','output_sha256'}
    for a,b in zip(old,new):
        assert {k:v for k,v in a.items() if k!='result'}=={k:v for k,v in b.items() if k!='result'}
        ar={k:v for k,v in a['result'].items() if k not in envelope}
        br={k:v for k,v in b['result'].items() if k not in envelope}
        check=compare_results(ar,br)
        checks.append({'case_id':a['case_id'],'phase':a['phase'],'repeat':a['repeat'],'profile_passes':a['profile_passes'],**check})
    receipt={'schema':1,'scope':'Separate bounded diagnostic runs with three repetitions per profile mode. Pass medians are diagnostic and are not a partition of total compilation time; retained and alternate paths are included. Formal speed claims require the isolated paired campaign.',
             'source_sha256':{str(p.relative_to(BASE)):sha(p) for n in names for p in [BASE/n/'summary.json',BASE/n/'raw.jsonl']},
             'transport_envelope_fields_removed':sorted(envelope),'exact_result_excluded_fields':['compile_ns','parse_ns','pass_diagnostics'],
             'strict_saved_result_parity':{'requests':len(checks),'passed':sum(c['passed'] for c in checks),'checks':checks},'cases':cases}
    assert all(c['passed'] for c in checks), 'Saved native output parity failed'
    with (BASE/'profile_evidence.json').open('x') as stream:
        json.dump(receipt,stream,indent=2,sort_keys=True);stream.write('\n')
    print(json.dumps({'parity_passed':len(checks),'cases':len(cases)}))

if __name__=='__main__':main()
