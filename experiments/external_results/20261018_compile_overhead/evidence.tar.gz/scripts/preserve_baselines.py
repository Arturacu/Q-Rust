#!/usr/bin/env python3
"""Preserve all earlier evidence and the completed immediate baseline campaign."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import subprocess

BASE = Path(__file__).resolve().parent
WORKING = BASE.parent
REPO = WORKING / 'qrust_pr_publish'
PREVIOUS = WORKING / 'qrust_clifford_quality_20261018'
EXCLUDED = {'__pycache__', 'matplotlib_cache', '.pytest_cache', '.git', 'target',
            '.venv', 'venv', 'node_modules'}


def sha(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def selected_files():
    previous = json.loads((PREVIOUS / 'original_preservation.json').read_text())
    files = set()
    for record in previous['files']:
        path = WORKING / record['path']
        if path.stat().st_size != record['bytes'] or sha(path) != record['sha256']:
            raise ValueError('Earlier preserved evidence changed: ' + record['path'])
        files.add(path)
    tracked = subprocess.check_output(['git', 'ls-files', '-z'], cwd=REPO).decode().split('\0')
    files.update(REPO / name for name in tracked if name and (
        name.startswith('experiments/external_results/') or
        name.startswith('experiments/') and name.endswith('.md')))
    # The previous campaign is evidence; its staging/extraction scratch trees
    # are redundant archive copies and are deliberately not traversed.
    for root, directories, names in os.walk(PREVIOUS, followlinks=False):
        directories[:] = sorted(name for name in directories if name not in EXCLUDED
                                and not name.startswith(('package_audit', 'packaging_scratch', 'packaging_attempt')))
        folder = Path(root)
        for name in names:
            path = folder / name
            if name.endswith(('.pyc', '.pyo')) or name == '.DS_Store':
                continue
            if path.is_symlink():
                raise ValueError('Unexpected symlink in baseline: ' + str(path))
            if path.is_file():
                files.add(path)
    return sorted(files), previous


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('action', choices=['freeze', 'check'])
    args = parser.parse_args()
    destination = BASE / 'original_preservation.json'
    if args.action == 'freeze':
        files, previous = selected_files()
        manifest = {'schema': 1, 'baseline_git_head': subprocess.check_output(
            ['git', 'rev-parse', 'HEAD'], cwd=REPO, text=True).strip(),
            'scope': 'Union of every previous preservation entry, all currently tracked experiment Markdown reports and external result artifacts, and the complete immediate baseline work evidence excluding redundant packaging attempts, staging/extraction and caches. No previous file is edited.',
            'previous_manifest_sha256': sha(PREVIOUS / 'original_preservation.json'),
            'previous_preserved_files': len(previous['files']),
            'files': [{'path': str(path.relative_to(WORKING)), 'bytes': path.stat().st_size,
                       'sha256': sha(path)} for path in files]}
        with destination.open('x') as stream:
            json.dump(manifest, stream, indent=2, sort_keys=True)
            stream.write('\n')
    else:
        manifest = json.loads(destination.read_text())
        for record in manifest['files']:
            path = WORKING / record['path']
            if not path.is_file() or path.stat().st_size != record['bytes'] or sha(path) != record['sha256']:
                raise ValueError('Preserved baseline changed: ' + record['path'])
    print(json.dumps({'action': args.action, 'preserved_files': len(manifest['files']),
                      'manifest_sha256': sha(destination)}))


if __name__ == '__main__':
    main()
