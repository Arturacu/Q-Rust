#!/usr/bin/env python3
"""Package completed evidence, audit a fresh extraction, and replay its analysis.

Run only after timing, postflight validation, and the final report are complete.
Every destination is new; input records and frozen harnesses remain unchanged.
Fresh verifier durations are the sole canonical replay exclusion. Compiler,
parser, transport, resource and structural metrics remain byte-exact.
"""
from __future__ import annotations

import argparse
import gzip
import hashlib
import json
import os
from pathlib import Path, PurePosixPath
import re
import shutil
import subprocess
import sys
import tarfile


EXCLUDED_PARTS = {'.git', '__pycache__', '.pytest_cache', '.mypy_cache', '.ruff_cache',
                  'venv', '.venv', 'env', 'node_modules', 'target', 'matplotlib_cache'}
ROOT_RECEIPTS = {
    'prepare_command.json', 'timing_commands.json', 'timing_completion.json',
    'postflight_commands.json', 'postflight_receipt.json', 'canonical_replay_receipt.json',
    'original_preservation.json', 'helper_source_provenance.json',
}
ROOT_HELPERS = {
    'paired_campaign.py', 'paired_analysis.py', 'quality_preflight.py',
    'test_paired_campaign.py', 'test_paired_analysis.py', 'test_quality_preflight.py',
    'preserve_baselines.py', 'run_campaign.py', 'run_postflight.py', 'run_postflight_v1.py',
    'canonical_replay.py', 'test_canonical_replay.py', 'package_evidence.py',
    'test_package_evidence.py',
    'compute_report_metrics.py',
    'profile_baseline.py', 'profile_baseline_v1.py', 'profile_variant.py',
    'strict_quality_preflight.py', 'derive_profile_evidence.py', 'derive_case_timings.py',
}


def sha(path: Path) -> str:
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def dump_new(path: Path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open('x') as stream:
        json.dump(value, stream, indent=2, sort_keys=True, allow_nan=False)
        stream.write('\n')


def require(condition, message):
    if not condition:
        raise ValueError(message)


def relative_name(value: str) -> str:
    path = PurePosixPath(value)
    require('\\' not in value and ':' not in value and path.as_posix() == value
            and not path.is_absolute() and path.parts and all(part not in ('', '.', '..') for part in path.parts),
            'Unsafe archive member: ' + value)
    return path.as_posix()


def evidence_trees(args):
    """Require explicit development evidence roots, without nested duplicates."""
    names = ['campaign', 'analysis_replay']
    for value in args.evidence_tree:
        name = relative_name(value)
        require(Path(name).parts[0] not in ('analysis', 'scripts', 'receipts', 'harness', 'binaries', 'report',
                                           'compiler_source', 'baseline_protocols', 'corpus', 'benchpress', 'upstream_legal',
                                           'abandoned_configurations'),
                'Reserved archive evidence name: ' + name)
        require(not any(Path(name).is_relative_to(Path(old)) or Path(old).is_relative_to(Path(name))
                        for old in names), 'Repeated or overlapping evidence directory: ' + name)
        names.append(name)
    return names


def check_completion_identity(receipts, campaign, protocol_sha):
    for receipt in receipts:
        require(receipt.get('campaign') == str(campaign) and receipt.get('paired_protocol_sha256') == protocol_sha,
                'Completion receipt belongs to another campaign')


def sanitize_packaging_command(receipt):
    """Keep reproducible arguments while omitting local text-policy values."""
    require(isinstance(receipt, dict) and isinstance(receipt.get('command'), list),
            'Invalid packaging command receipt')
    command = receipt['command']
    result, omitted, index = [], 0, 0
    while index < len(command):
        require(isinstance(command[index], str), 'Nontext packaging argument')
        if command[index] == '--reject-text':
            require(index + 1 < len(command) and isinstance(command[index + 1], str),
                    'Missing local text-policy value')
            omitted += 1
            index += 2
        else:
            result.append(command[index])
            index += 1
    sanitized = dict(receipt)
    sanitized['command'] = result
    sanitized['omitted_local_text_policy_argument_pairs'] = omitted
    sanitized['receipt_scope'] = 'Only local text-policy flag/value pairs are omitted. The complete original invocation remains outside the repository; all benchmark and packaging inputs are preserved.'
    return sanitized


def copy_file(source: Path, target: Path):
    require(source.is_file() and not source.is_symlink(), 'Missing or symlinked input: ' + str(source))
    target.parent.mkdir(parents=True, exist_ok=True)
    with source.open('rb') as incoming, target.open('xb') as outgoing:
        shutil.copyfileobj(incoming, outgoing)
    target.chmod(0o755 if os.access(source, os.X_OK) else 0o644)


def copy_tree(source: Path, target: Path):
    require(source.is_dir() and not source.is_symlink(), 'Missing or symlinked directory: ' + str(source))
    for root, directories, filenames in os.walk(source, followlinks=False):
        directories[:] = sorted(name for name in directories if name not in EXCLUDED_PARTS)
        root = Path(root)
        for directory in directories:
            require(not (root / directory).is_symlink(), 'Symlinked directory in input tree')
        for name in sorted(filenames):
            if name.endswith(('.pyc', '.pyo')) or name == '.DS_Store':
                continue
            relative = (root / name).relative_to(source)
            copy_file(root / name, target / relative)


def verify_completed(args):
    require(not args.destination.exists(), 'Destination exists; refusing to overwrite it')
    require(not args.scratch.exists(), 'Scratch directory exists; choose a fresh path')
    require(not args.destination.is_relative_to(args.scratch) and not args.scratch.is_relative_to(args.destination),
            'Destination and scratch must be separate directory trees')
    copied_trees = [args.campaign if name == 'campaign' else args.followup / name
                    for name in evidence_trees(args)]
    copied_trees += args.abandoned_campaign
    copied_trees += [args.analysis, args.corpus, args.matched_frozen]
    require(not any(args.scratch.is_relative_to(source) or args.destination.is_relative_to(source)
                    for source in copied_trees), 'Output directory lies inside an input evidence tree')
    require(not (args.campaign / 'active.lock').exists(), 'A timing session is active')
    completion = json.loads((args.followup / 'timing_completion.json').read_text())
    require(completion.get('all_four_sessions_completed') is True, 'Timing is not complete')
    postflight = json.loads((args.followup / 'postflight_receipt.json').read_text())
    require(postflight.get('all_stages_completed') is True, 'Postflight validation is not complete')
    python_stage = [stage for stage in postflight.get('stages', [])
                    if stage.get('name') == 'python_final_with_binary']
    require(len(python_stage) == 1 and python_stage[0].get('exit_code') == 0,
            'Final Python suite with the frozen binary has not passed')
    require(sha(args.followup / 'python_final_with_binary.log') == python_stage[0]['log_sha256'],
            'Final Python validation log changed')
    require(args.report.is_file(), 'Final report must exist before packaging')
    require(args.analysis.is_dir() and (args.analysis / 'summary.json').is_file(), 'Missing final analysis')
    pair_path = args.campaign / 'paired_protocol.json'
    pair = json.loads(pair_path.read_text())
    require(sha(pair_path) == (args.campaign / 'paired_protocol.sha256').read_text().strip(),
            'Paired protocol checksum changed')
    check_completion_identity((completion, postflight), args.campaign, sha(pair_path))
    require(sha(args.old_binary) == pair['old_binary_sha256'], 'Old compiler is not the frozen baseline')
    require(sha(args.new_binary) == pair['candidate_binary_sha256'], 'New compiler is not the timed candidate')
    for suite, directory in [('external', args.external_baseline), ('matched', args.matched_baseline)]:
        require(sha(directory / 'protocol.json') == pair['baseline_protocol_sha256'][suite],
                'Baseline protocol changed: ' + suite)
    for name, field in [('paired_analysis.py', 'analysis_source_sha256'), ('paired_campaign.py', 'controller_sha256')]:
        require(sha(args.repo / 'experiments' / name) == pair[field], 'Frozen source changed: ' + name)
    preservation_path = args.followup / 'original_preservation.json'
    preservation = json.loads(preservation_path.read_text())
    for record in preservation['files']:
        source = args.preservation_root / relative_name(record['path'])
        require(source.is_file() and not source.is_symlink() and source.stat().st_size == record['bytes']
                and sha(source) == record['sha256'], 'Preserved historical evidence changed: ' + record['path'])
    return pair, {'files_verified': len(preservation['files']), 'manifest_sha256': sha(preservation_path)}


def stage_inputs(args, stage: Path, pair):
    for name in evidence_trees(args):
        copy_tree(args.campaign if name == 'campaign' else args.followup / name, stage / name)
    abandoned = []
    for source in args.abandoned_campaign:
        require(source != args.campaign and not (source / 'active.lock').exists(),
                'Abandoned configuration is active or is the selected campaign')
        require(not list(source.rglob('session_*.jsonl')) and not list(source.rglob('timed.jsonl')),
                'Abandoned configuration unexpectedly contains timing records')
        protocol_path = source / 'paired_protocol.json'
        require(sha(protocol_path) == (source / 'paired_protocol.sha256').read_text().strip(),
                'Abandoned configuration checksum changed')
        old_pair = json.loads(protocol_path.read_text())
        binary = Path(old_pair['candidate_binary'])
        require(sha(binary) == old_pair['candidate_binary_sha256'], 'Abandoned frozen binary changed')
        target = stage / 'abandoned_configurations' / relative_name(source.name)
        require(not target.exists(), 'Repeated abandoned configuration name')
        copy_tree(source, target)
        copy_file(binary, target / 'candidate_binary')
        abandoned.append({'archive_path': str(target.relative_to(stage)),
                          'paired_protocol_sha256': sha(protocol_path),
                          'candidate_binary_sha256': sha(binary), 'formal_timing_executed': False})
    copy_tree(args.analysis, stage / 'analysis')
    receipts = ROOT_RECEIPTS | {path.name for path in args.followup.glob('*.json')}
    for name in sorted(receipts):
        source = args.followup / name
        if source.is_file():
            if re.fullmatch(r'package_command(?:_v\d+)?\.json', name):
                sanitized = sanitize_packaging_command(json.loads(source.read_text()))
                sanitized['original_local_receipt_sha256'] = sha(source)
                dump_new(stage / 'receipts' / name, sanitized)
            else:
                copy_file(source, stage / 'receipts' / name)
    require((stage / 'receipts/original_preservation.json').is_file(), 'Missing preservation manifest')
    helpers = ROOT_HELPERS | {path.name for path in args.followup.glob('*_v*.py')
                              if re.fullmatch(r'(?:run_campaign|run_postflight|canonical_replay|package_evidence|test_package_evidence)_v\d+\.py', path.name)}
    for name in sorted(helpers):
        source = args.followup / name
        if source.is_file():
            copy_file(source, stage / 'scripts' / name)
    for source in sorted(args.followup.glob('*.log')):
        copy_file(source, stage / 'logs' / source.name)
    for source in sorted((args.repo / 'experiments').glob('*.py')):
        copy_file(source, stage / 'harness/experiments' / source.name)
    for source in sorted((args.repo / 'experiments').glob('requirements*.txt')):
        copy_file(source, stage / 'harness/experiments' / source.name)
    copy_file(args.new_binary, stage / 'binaries/current/comparison_runner')
    copy_file(args.old_binary, stage / 'binaries/baseline/comparison_runner')
    for suite, directory in [('external', args.external_baseline), ('matched', args.matched_baseline)]:
        for name in ('protocol.json', 'protocol.sha256', 'corpus_manifest.json', 'validation_summary.json', 'summary.json'):
            source = directory / name
            if source.is_file():
                copy_file(source, stage / 'baseline_protocols' / suite / name)
    copy_tree(args.corpus, stage / 'corpus')
    copy_tree(args.matched_frozen, stage / 'benchpress/frozen')
    for spec in args.upstream_source:
        require('=' in spec, '--upstream-source requires LABEL=PATH')
        label, raw_path = spec.split('=', 1)
        require(re.fullmatch(r'[A-Za-z0-9_-]+', label) is not None, 'Invalid upstream label')
        source = Path(raw_path).resolve()
        require(source.is_dir(), 'Missing upstream source directory')
        legal = [p for p in source.iterdir() if p.is_file() and
                 p.name.lower().startswith(('license', 'notice', 'copying', 'readme'))]
        require(any(p.name.lower().startswith(('license', 'copying')) for p in legal),
                'No upstream license found: ' + label)
        for path in sorted(legal):
            copy_file(path, stage / 'upstream_legal' / label / path.name)
    copy_file(args.report, stage / 'report' / args.report.name)
    for name in ('LICENSE', 'LICENSE-MIT', 'LICENSE-APACHE'):
        source = args.repo / name
        if source.is_file():
            copy_file(source, stage / 'compiler_source' / name)
    external = json.loads((args.campaign / 'external/protocol.json').read_text())
    source_manifest = external['compiler_provenance']['compiler_source_sha256']
    require(source_manifest, 'Missing frozen compiler source manifest')
    for name, expected in source_manifest.items():
        relative_name(name)
        require(sha(args.repo / name) == expected, 'Frozen compiler source changed: ' + name)
        copy_file(args.repo / name, stage / 'compiler_source' / name)
    dump_new(stage / 'evidence_index.json', {
        'schema': 1,
        'compiler_commit': pair['compiler_commit'],
        'candidate_binary_sha256': pair['candidate_binary_sha256'],
        'old_binary_sha256': pair['old_binary_sha256'],
        'old_compiler_commit': pair['old_compiler_commit'],
        'authoritative_timing': 'campaign/',
        'authoritative_frozen_analysis_and_adapters': 'harness/experiments/',
        'final_analysis': 'analysis/',
        'fresh_prepackage_analysis_replay': 'analysis_replay/',
        'development_evidence_trees': args.evidence_tree,
        'abandoned_frozen_configurations': abandoned,
        'development_diagnostics': 'Explicitly selected development trees retain mechanism, ablation and preflight records. Durations there are diagnostics, not benchmark results. Source revisions recorded within those trees must not be substituted with final frozen harness sources.',
        'outside_helpers': 'scripts/ preserves numbered timing, postflight, canonical replay and packaging helper revisions and their tests. All root JSON receipts and logs are retained. Absolute historical paths are provenance, not portable replay inputs.',
        'final_python_validation': 'logs/python_final_with_binary.log and receipts/postflight_receipt.json retain the final suite executed with QRUST_COMPARISON_BINARY explicitly bound to the frozen candidate. Earlier development logs are not substituted for it.',
        'compiler_source_scope': 'Every Rust source and Cargo file bound by the frozen external protocol source manifest, plus available root licenses. Each copied source hash is rechecked before packaging.',
        'dependencies': 'Use harness/experiments/requirements-comparison.txt for this campaign. requirements.txt is an older baseline lock retained for provenance.',
        'portable_replay': 'python harness/experiments/paired_analysis.py --repo harness --campaign campaign --output NEW_ANALYSIS_DIRECTORY',
        'portable_comparison': 'python scripts/canonical_replay.py --reference analysis --replay NEW_ANALYSIS_DIRECTORY --output NEW_RECEIPT.json',
        'replay_exclusion': 'Only fresh validation.validation_ns is excluded; derived summary row hashes use canonical rows. Raw analyses and compiler/parse/request timings remain unchanged.',
        'binary_portability': 'Frozen native binaries retain their original host architecture. Analysis replay uses Python and does not execute them.',
    })


def audit_prose(stage: Path, rejected_text):
    for path in stage.rglob('*'):
        if not path.is_file() or path.suffix.lower() not in ('.py', '.md', '.txt', '.rst', '.json', '.jsonl', '.log', '.qasm', '.sha256'):
            continue
        text = path.read_text(errors='strict')
        require(not any(phrase.casefold() in text.casefold() for phrase in rejected_text),
                'Rejected text in staged file: ' + str(path.relative_to(stage)))


def manifest_and_archive(stage: Path, archive: Path):
    records = {}
    for path in sorted(stage.rglob('*')):
        if path.is_file():
            records[path.relative_to(stage).as_posix()] = {'bytes': path.stat().st_size, 'sha256': sha(path)}
    manifest = {'schema': 1, 'files': records,
                'scope': 'Every archive payload file except this self-referential manifest. The manifest and whole archive are independently bound by checksums.json.'}
    dump_new(stage / 'sha256_manifest.json', manifest)
    with archive.open('xb') as raw:
        with gzip.GzipFile(filename='', mode='wb', fileobj=raw, mtime=0) as compressed:
            with tarfile.open(fileobj=compressed, mode='w') as tar:
                for path in sorted(stage.rglob('*')):
                    if not path.is_file():
                        continue
                    info = tar.gettarinfo(str(path), arcname=path.relative_to(stage).as_posix())
                    info.uid = info.gid = info.mtime = 0
                    info.uname = info.gname = ''
                    info.mode = 0o755 if os.access(path, os.X_OK) else 0o644
                    with path.open('rb') as stream:
                        tar.addfile(info, stream)
    return manifest


def extract_and_audit(archive: Path, destination: Path):
    destination.mkdir(parents=True, exist_ok=False)
    names = set()
    with tarfile.open(archive, 'r:gz') as tar:
        for member in tar:
            name = relative_name(member.name)
            require(member.isfile() and name not in names, 'Nonregular or duplicate archive member')
            names.add(name)
            target = destination / name
            target.parent.mkdir(parents=True, exist_ok=True)
            source = tar.extractfile(member)
            require(source is not None, 'Missing archive payload')
            with source, target.open('xb') as output:
                shutil.copyfileobj(source, output)
            target.chmod(0o755 if member.mode & 0o111 else 0o644)
    manifest = json.loads((destination / 'sha256_manifest.json').read_text())
    require(names == set(manifest['files']) | {'sha256_manifest.json'}, 'Archive file inventory differs from manifest')
    for name, record in manifest['files'].items():
        relative_name(name)
        path = destination / name
        require(path.stat().st_size == record['bytes'] and sha(path) == record['sha256'],
                'Extracted file mismatch: ' + name)
    return {'all_payload_hashes_match': True, 'payload_files': len(manifest['files']),
            'manifest_sha256': sha(destination / 'sha256_manifest.json')}


def run_command(command, cwd, log, env, timeout):
    with log.open('x') as stream:
        result = subprocess.run(command, cwd=cwd, env=env, stdout=stream, stderr=subprocess.STDOUT,
                                timeout=timeout)
    require(result.returncode == 0, 'Archived replay failed; inspect ' + str(log))
    return {'command': command, 'exit_code': result.returncode, 'log_sha256': sha(log)}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    for name in ('repo', 'followup', 'campaign', 'old-binary', 'new-binary', 'external-baseline',
                 'matched-baseline', 'corpus', 'matched-frozen', 'report', 'destination', 'scratch'):
        parser.add_argument('--' + name, type=Path, required=True)
    parser.add_argument('--analysis', type=Path)
    parser.add_argument('--preservation-root', type=Path)
    parser.add_argument('--python', type=Path, default=Path(sys.executable))
    parser.add_argument('--upstream-source', action='append', default=[], metavar='LABEL=PATH')
    parser.add_argument('--evidence-tree', action='append', required=True, metavar='RELATIVE_DIRECTORY',
                        help='Development evidence directory relative to --followup; may be repeated.')
    parser.add_argument('--abandoned-campaign', type=Path, action='append', default=[],
                        help='Untimed frozen configuration to preserve separately, including its bound binary.')
    parser.add_argument('--export', action='append', default=[], metavar='NAME=PAYLOAD_PATH',
                        help='Additional verified payload file to expose next to the archive.')
    parser.add_argument('--reject-text', action='append', default=[], metavar='PHRASE')
    parser.add_argument('--replay-timeout', type=int, default=3600)
    args = parser.parse_args()
    for name, value in vars(args).items():
        if isinstance(value, Path):
            # Resolving a venv's interpreter symlink changes sys.prefix and
            # silently selects the base environment without its dependencies.
            setattr(args, name, value.absolute() if name == 'python' else value.resolve())
    args.analysis = args.analysis or args.followup / 'analysis'
    args.abandoned_campaign = [path.resolve() for path in args.abandoned_campaign]
    args.preservation_root = args.preservation_root or args.repo.parent
    require(args.replay_timeout > 0, 'Replay timeout must be positive')
    pair, preservation = verify_completed(args)
    args.scratch.mkdir(parents=True, exist_ok=False)
    stage = args.scratch / 'staged'
    stage.mkdir()
    stage_inputs(args, stage, pair)
    audit_prose(stage, args.reject_text)
    archive = args.scratch / 'evidence.tar.gz'
    manifest_and_archive(stage, archive)
    extracted = args.scratch / 'extracted'
    extraction = extract_and_audit(archive, extracted)
    env = dict(os.environ, PYTHONDONTWRITEBYTECODE='1', MPLCONFIGDIR=str(args.scratch / 'matplotlib_cache'))
    env.pop('PYTHONPATH', None)
    for name in ('OMP_NUM_THREADS', 'OPENBLAS_NUM_THREADS', 'MKL_NUM_THREADS', 'NUMEXPR_NUM_THREADS', 'VECLIB_MAXIMUM_THREADS'):
        env[name] = '1'
    replay = args.scratch / 'fresh_analysis'
    command = [str(args.python), str(extracted / 'harness/experiments/paired_analysis.py'),
               '--repo', str(extracted / 'harness'), '--campaign', str(extracted / 'campaign'),
               '--output', str(replay)]
    analysis_run = run_command(command, extracted, args.scratch / 'archive_replay.log', env, args.replay_timeout)
    comparison_path = args.scratch / 'canonical_replay_receipt.json'
    comparison_run = run_command([str(args.python), str(extracted / 'scripts/canonical_replay.py'),
        '--reference', str(extracted / 'analysis'), '--replay', str(replay), '--output', str(comparison_path)],
        extracted, args.scratch / 'archive_comparison.log', env, args.replay_timeout)
    comparison = json.loads(comparison_path.read_text())
    require(comparison.get('passed') is True, 'Archived semantic replay did not pass')
    args.destination.mkdir(parents=True, exist_ok=False)
    copy_file(archive, args.destination / 'evidence.tar.gz')
    copies = {
        'sha256_manifest.json': extracted / 'sha256_manifest.json',
        'summary.json': extracted / 'analysis/summary.json',
        'original_preservation.json': extracted / 'receipts/original_preservation.json',
        'postflight_receipt.json': extracted / 'receipts/postflight_receipt.json',
        'python_final_with_binary.log': extracted / 'logs/python_final_with_binary.log',
        'canonical_replay_receipt.json': comparison_path,
        'archive_replay.log': args.scratch / 'archive_replay.log',
        'archive_comparison.log': args.scratch / 'archive_comparison.log',
    }
    for spec in args.export:
        require('=' in spec, '--export requires NAME=PAYLOAD_PATH')
        name, payload = spec.split('=', 1)
        require(relative_name(name) == Path(name).name and name not in copies
                and name not in {'evidence.tar.gz', 'external_summary.json', 'packaging_receipt.json', 'checksums.json'},
                'Repeated, unsafe or reserved export name: ' + name)
        copies[name] = extracted / relative_name(payload)
    for name, source in copies.items():
        copy_file(source, args.destination / name)
    for source in (extracted / 'campaign/external').rglob('external_summary.json'):
        copy_file(source, args.destination / 'external_summary.json')
    receipt = {'schema': 1, 'completed': True, 'archive_sha256': sha(archive),
               'extraction_audit': extraction, 'historical_preservation_audit': preservation, 'analysis_run': analysis_run,
               'comparison_run': comparison_run, 'canonical_summary_sha256': comparison['canonical_summary_sha256'],
               'replay_scope': 'Fresh archived analysis is canonically byte-equal after excluding only verifier duration; all recorded compiler/parse/request timings remain exact.',
               'preserved_fresh_analysis': 'Fresh replay outputs remain in the explicitly selected scratch/fresh_analysis directory.',
               'packaging_source_sha256': sha(Path(__file__))}
    dump_new(args.destination / 'packaging_receipt.json', receipt)
    checksums = {path.name: {'bytes': path.stat().st_size, 'sha256': sha(path)}
                 for path in sorted(args.destination.iterdir()) if path.is_file()}
    dump_new(args.destination / 'checksums.json', {
        'schema': 1, 'files': checksums,
        'scope': 'Every deliverable except this self-referential checksum file. sha256_manifest.json binds each archive payload file.'})
    print(json.dumps({'destination': str(args.destination), 'archive_sha256': receipt['archive_sha256'],
                      'payload_files': extraction['payload_files'], 'canonical_replay_passed': True}))


if __name__ == '__main__':
    main()
