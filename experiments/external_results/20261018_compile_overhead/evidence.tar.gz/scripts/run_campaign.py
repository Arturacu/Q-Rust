#!/usr/bin/env python3
"""Execute the four frozen timing sessions sequentially, without validation."""
from pathlib import Path
import argparse
import hashlib
import json
import os
import subprocess
import sys
import time

base = Path(__file__).resolve().parent
parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--campaign', type=Path, required=True)
args = parser.parse_args()
campaign = args.campaign.resolve()
protocol = json.loads((campaign / 'paired_protocol.json').read_text())
repo = Path(protocol['repo'])
common = [sys.executable, str(repo / 'experiments/paired_campaign.py'), 'time',
          '--repo', str(repo), '--binary', protocol['candidate_binary'],
          '--old-binary', protocol['old_binary'],
          '--output', str(campaign)]
commands = [dict(suite=suite, session=session, command=common + ['--suite', suite, '--session', str(session)])
            for suite, session in [('external', 1), ('external', 2), ('matched', 1), ('matched', 2)]]
with (base / 'timing_commands.json').open('x') as stream:
    json.dump(commands, stream, indent=2)
    stream.write('\n')
env = dict(os.environ, MPLCONFIGDIR=str(base / 'matplotlib_cache'))
receipts = []
for entry in commands:
    name = f"{entry['suite']}_session_{entry['session']}"
    log_path = base / (name + '.log')
    started = time.time()
    print(json.dumps({'starting': name, 'utc': time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime(started))}), flush=True)
    with log_path.open('x') as log:
        result = subprocess.run(entry['command'], stdout=log, stderr=subprocess.STDOUT, env=env)
    receipt = {'suite': entry['suite'], 'session': entry['session'], 'exit_code': result.returncode,
               'whole_process_wall_seconds': time.time() - started,
               'log_sha256': hashlib.sha256(log_path.read_bytes()).hexdigest()}
    receipts.append(receipt)
    with (base / (name + '_process_receipt.json')).open('x') as stream:
        json.dump(receipt, stream, indent=2)
        stream.write('\n')
    print(json.dumps(receipt), flush=True)
    if result.returncode:
        print(log_path.read_text()[-4000:], flush=True)
        raise SystemExit(result.returncode)
with (base / 'timing_completion.json').open('x') as stream:
    json.dump({'all_four_sessions_completed': True, 'sessions': receipts,
               'campaign': str(campaign),
               'paired_protocol_sha256': hashlib.sha256((campaign / 'paired_protocol.json').read_bytes()).hexdigest()}, stream, indent=2)
    stream.write('\n')
print('All four timing sessions completed; no validation started.', flush=True)
