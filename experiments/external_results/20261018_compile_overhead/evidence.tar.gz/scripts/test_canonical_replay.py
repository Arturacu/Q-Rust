"""Small archive corruption controls; no compiler, SDK or numerical simulation.

Only fresh verifier-duration values may differ. Every semantic mutation below
rebinds the edited row file's summary hash unless the hash binding itself is the
subject of the test, so a hash mismatch cannot mask weak canonical comparison.
"""
from __future__ import annotations

import copy
import hashlib
import json
from pathlib import Path
import shutil
import tempfile
import unittest

from canonical_replay import compare_analyses


def digest(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def encoded(value) -> bytes:
    return (json.dumps(value, sort_keys=True, separators=(',', ':'), allow_nan=False) + '\n').encode()


class CanonicalReplayTests(unittest.TestCase):
    def setUp(self):
        self.temporary = tempfile.TemporaryDirectory()
        self.addCleanup(self.temporary.cleanup)
        self.root = Path(self.temporary.name)
        self.reference = self.root / 'reference'
        self.replay = self.root / 'replay'
        self.reference.mkdir()
        summary = {'schema': 1, 'suites': {}, 'scope': 'synthetic comparison contract'}
        for suite in ('external', 'matched'):
            summary['suites'][suite] = {'sessions': {}}
            for session in (1, 2):
                observations = [
                    {'suite': suite, 'session': session, 'index': index, 'phase': phase,
                     'compile_ns': 100 + index, 'parse_ns': 5, 'request_wall_ns': 200,
                     'status': 'compiled', 'outcome': 'passed',
                     'metrics': {'cx_count': 3, 'depth': 5},
                     'validation': {'passed': True, 'max_input_residual': 1e-15,
                                    'validation_ns': 10 + index}}
                    for index, phase in enumerate(('warmup', 'timed'))
                ]
                observations.append({'suite': suite, 'session': session, 'index': 2,
                                     'phase': 'timed', 'status': 'timeout', 'outcome': 'timeout'})
                data = b''.join(encoded(row) for row in observations)
                (self.reference / f'{suite}_session_{session}.jsonl').write_bytes(data)
                summary['suites'][suite]['sessions'][str(session)] = {
                    'validated_rows_sha256': digest(data),
                    'cells': [{'eligible': False, 'timed_outcomes': {'passed': 1, 'timeout': 1}}],
                }
        (self.reference / 'summary.json').write_bytes(encoded(summary))
        shutil.copytree(self.reference, self.replay)

    def rows(self, name='external_session_1.jsonl'):
        return [json.loads(line) for line in (self.replay / name).read_bytes().splitlines()]

    def rebind(self, name='external_session_1.jsonl'):
        suite, _, session = name.removesuffix('.jsonl').split('_')
        path = self.replay / 'summary.json'
        summary = json.loads(path.read_bytes())
        summary['suites'][suite]['sessions'][session]['validated_rows_sha256'] = digest((self.replay / name).read_bytes())
        path.write_bytes(encoded(summary))

    def write_rows(self, observations, name='external_session_1.jsonl', rebind=True):
        (self.replay / name).write_bytes(b''.join(encoded(row) for row in observations))
        if rebind:
            self.rebind(name)

    def assert_rejected(self, pattern=None):
        if pattern is None:
            with self.assertRaises(ValueError):
                compare_analyses(self.reference, self.replay)
        else:
            with self.assertRaisesRegex(ValueError, pattern):
                compare_analyses(self.reference, self.replay)

    def test_identical_analyses_bind_raw_summary_and_every_raw_row_file(self):
        result = compare_analyses(self.reference, self.replay)
        self.assertTrue(result['passed'])
        self.assertEqual(result['reference_summary_sha256'], digest((self.reference / 'summary.json').read_bytes()))
        self.assertEqual(result['replay_summary_sha256'], digest((self.replay / 'summary.json').read_bytes()))
        self.assertEqual(len(result['row_files']), 4)
        for name, info in result['row_files'].items():
            self.assertEqual(info['reference']['raw_sha256'], digest((self.reference / name).read_bytes()))
            self.assertEqual(info['replay']['raw_sha256'], digest((self.replay / name).read_bytes()))
            self.assertEqual(info['reference']['rows'], 3)
            self.assertEqual(info['reference']['verifier_timer_fields_excluded'], 2)

    def test_only_verifier_duration_values_change_and_raw_inputs_are_preserved(self):
        for suite in ('external', 'matched'):
            for session in (1, 2):
                name = f'{suite}_session_{session}.jsonl'
                observations = self.rows(name)
                for row in observations:
                    if 'validation' in row:
                        row['validation']['validation_ns'] += 12345
                self.write_rows(observations, name)
        before = {path: path.read_bytes() for directory in (self.reference, self.replay) for path in directory.iterdir()}
        result = compare_analyses(self.reference, self.replay)
        self.assertTrue(result['passed'])
        self.assertFalse(result['raw_summaries_byte_equal'])
        for info in result['row_files'].values():
            self.assertNotEqual(info['reference']['raw_sha256'], info['replay']['raw_sha256'])
            self.assertEqual(info['reference']['canonical_sha256'], info['replay']['canonical_sha256'])
        self.assertTrue(all(path.read_bytes() == value for path, value in before.items()))

    def test_missing_verifier_duration_is_not_normalized_away(self):
        observations = self.rows()
        del observations[1]['validation']['validation_ns']
        self.write_rows(observations)
        self.assert_rejected('differs beyond verifier duration')

    def test_new_verifier_duration_on_previously_unvalidated_row_is_rejected(self):
        observations = self.rows()
        observations[2]['validation'] = {'validation_ns': 999}
        self.write_rows(observations)
        self.assert_rejected('differs beyond verifier duration')

    def test_invalid_verifier_duration_types_and_sign_are_rejected(self):
        original = self.rows()
        for value in (-1, True, 1.5, None, '10'):
            with self.subTest(value=value):
                observations = copy.deepcopy(original)
                observations[0]['validation']['validation_ns'] = value
                self.write_rows(observations)
                self.assert_rejected('Invalid verifier timer')

    def test_compiler_parser_and_request_timings_remain_exact(self):
        original = self.rows()
        for field in ('compile_ns', 'parse_ns', 'request_wall_ns'):
            with self.subTest(field=field):
                observations = copy.deepcopy(original)
                observations[1][field] += 1
                self.write_rows(observations)
                self.assert_rejected('differs beyond verifier duration')

    def test_semantic_verdict_phase_and_structural_metrics_remain_exact(self):
        original = self.rows()
        changes = [
            ('phase', lambda row: row.update(phase='warmup')),
            ('outcome', lambda row: row.update(outcome='unverified_output')),
            ('passed', lambda row: row['validation'].update(passed=False)),
            ('residual', lambda row: row['validation'].update(max_input_residual=2e-15)),
            ('cx_count', lambda row: row['metrics'].update(cx_count=2)),
            ('depth', lambda row: row['metrics'].update(depth=4)),
        ]
        for label, change in changes:
            with self.subTest(field=label):
                observations = copy.deepcopy(original)
                change(observations[1])
                self.write_rows(observations)
                self.assert_rejected('differs beyond verifier duration')

    def test_validation_ns_at_other_paths_is_not_excluded(self):
        original = self.rows()
        for field in ('validation_ns', 'diagnostic'):
            with self.subTest(field=field):
                observations = copy.deepcopy(original)
                observations[0][field] = 42 if field == 'validation_ns' else {'validation_ns': 42}
                self.write_rows(observations)
                self.assert_rejected('differs beyond verifier duration')

    def test_row_order_and_missing_extra_or_duplicate_rows_are_rejected(self):
        original = self.rows()
        altered = [list(reversed(original)), original[:-1], original + [copy.deepcopy(original[0])],
                   [original[0], original[0], original[2]]]
        for observations in altered:
            with self.subTest(indices=[row['index'] for row in observations]):
                self.write_rows(observations)
                self.assert_rejected('differs beyond verifier duration')

    def test_duplicate_row_json_keys_are_rejected_even_when_last_value_matches(self):
        name = 'external_session_1.jsonl'
        original = (self.replay / name).read_bytes()
        for old, new in [(b'"compile_ns":101', b'"compile_ns":999,"compile_ns":101'),
                         (b'"validation_ns":11', b'"validation_ns":999,"validation_ns":11')]:
            with self.subTest(key=old):
                self.assertIn(old, original)
                (self.replay / name).write_bytes(original.replace(old, new, 1))
                self.rebind(name)
                self.assert_rejected('Duplicate JSON key')

    def test_duplicate_summary_json_keys_are_rejected_even_when_last_value_matches(self):
        path = self.replay / 'summary.json'
        original = path.read_bytes()
        for old, new in [(b'"schema":1', b'"schema":999,"schema":1'),
                         (b'"eligible":false', b'"eligible":true,"eligible":false')]:
            with self.subTest(key=old):
                self.assertIn(old, original)
                path.write_bytes(original.replace(old, new, 1))
                self.assert_rejected('Duplicate JSON key')

    def test_row_tampering_without_rebound_summary_hash_is_rejected(self):
        observations = self.rows()
        observations[0]['validation']['validation_ns'] += 1
        self.write_rows(observations, rebind=False)
        self.assert_rejected('Summary does not bind raw rows')

    def test_summary_raw_hash_and_derived_claim_tampering_are_rejected(self):
        path = self.replay / 'summary.json'
        original = json.loads(path.read_bytes())
        for field in ('validated_rows_sha256', 'cells'):
            with self.subTest(field=field):
                summary = copy.deepcopy(original)
                session = summary['suites']['external']['sessions']['1']
                if field == 'validated_rows_sha256':
                    session[field] = '0' * 64
                else:
                    session[field][0]['eligible'] = True
                path.write_bytes(encoded(summary))
                self.assert_rejected('Summary does not bind raw rows' if field == 'validated_rows_sha256' else 'Summary differs')

    def test_reference_and_replay_must_be_distinct(self):
        with self.assertRaisesRegex(ValueError, 'distinct directories'):
            compare_analyses(self.reference, self.reference)


if __name__ == '__main__':
    unittest.main()
