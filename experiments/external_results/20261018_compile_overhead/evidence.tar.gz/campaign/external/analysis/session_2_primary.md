# Corrected-fixture compiler comparison

The prescribed corpus contains 50 fixtures and 100 fixture–topology cells. The study retained 2800 timed trials and 2800 validation records; 0 compiler–cell combinations were ineligible for paired analysis.

Only cells with every prescribed trial successful and independently validated contribute to comparisons. Results below use per-cell medians. Brackets are 95% fixture-cluster bootstrap intervals; they preserve the relationship between multiple topologies of the same fixture.

## Compilation speed

Ratios are baseline time divided by Q-Rust time; a value above 1 favors Q-Rust. These are warm API compilation measurements. Parsing is reported separately; startup, imports, serialization and validation are excluded.

| Baseline | Paired cells | Compile speed ratio [95% CI] | Parse + compile ratio [95% CI] | Q-Rust compile win/tie/loss |
|---|---:|---:|---:|---:|
| qiskit | 100 | 2.72 [1.85, 3.87] | 2.88 [2.09, 4.1] | 74/0/26 |
| cirq | 100 | 62.8 [53.3, 74] | 70.7 [60.8, 82.3] | 100/0/0 |
| tket | 100 | 169 [139, 205] | 162 [135, 196] | 100/0/0 |

## Output quality

Ratios are Q-Rust divided by the baseline; a value below 1 favors Q-Rust. CX count and depth are structural cost measures, not execution fidelity. Zero/zero and one-sided-zero comparisons remain in win/tie/loss counts but are excluded from geometric means.

| Baseline | CX ratio [95% CI] | CX win/tie/loss | Depth ratio [95% CI] | Depth win/tie/loss | CX zero cases (both / Q-Rust / baseline) |
|---|---:|---:|---:|---:|---:|
| qiskit | 0.915 [0.849, 0.974] | 25/68/7 | 0.869 [0.796, 0.926] | 47/46/7 | 2/0/0 |
| cirq | 0.715 [0.658, 0.772] | 65/35/0 | 0.601 [0.54, 0.659] | 82/16/2 | 2/0/0 |
| tket | 0.895 [0.84, 0.951] | 28/66/6 | 0.95 [0.906, 0.998] | 30/50/20 | 2/0/0 |

## Secondary family-balanced comparison

The primary tables weight each eligible cell equally. This secondary summary first averages log ratios within each family, then weights the represented families equally. Its intervals resample fixture clusters within each fixed family. Families with no positive ratios for a metric are excluded from that metric and recorded in the JSON.

| Baseline | Compile speed ratio [95% CI] | CX ratio [95% CI] | Depth ratio [95% CI] | Families (speed / CX / depth) |
|---|---:|---:|---:|---:|
| qiskit | 3.13 [2.83, 3.46] | 0.903 [0.89, 0.918] | 0.867 [0.858, 0.876] | 38 / 37 / 38 |
| cirq | 61.7 [59.7, 64] | 0.719 [0.707, 0.731] | 0.615 [0.605, 0.625] | 38 / 37 / 38 |
| tket | 166 [161, 172] | 0.896 [0.882, 0.911] | 0.952 [0.941, 0.964] | 38 / 37 / 38 |

Among the 100 cells eligible for all four tools:

| Metric | Q-Rust at or better than best baseline | Within 5% of best baseline | Within 10% of best baseline | Best baseline is zero |
|---|---:|---:|---:|---:|
| cx_count | 90/100 (90.0%) | 95/100 (95.0%) | 96/100 (96.0%) | 2/100 |
| depth | 78/100 (78.0%) | 82/100 (82.0%) | 88/100 (88.0%) | 0/100 |
| two_q_depth | 92/100 (92.0%) | 94/100 (94.0%) | 95/100 (95.0%) | 2/100 |

The observed best baseline is the minimum median among Qiskit, Cirq and TKET, not a proven optimum. When the best baseline count is zero, only a zero-count Q-Rust result is within 5% or 10%. The JSON additionally records ratios and bands against the best of all four tools.

## Topology and family breakdowns

| Group | Baseline | Cells | Compile speed ratio [95% CI] | CX ratio [95% CI] | Depth ratio [95% CI] |
|---|---|---:|---:|---:|---:|
| all_to_all | qiskit | 50 | 3.7 [2.64, 5.1] | 0.94 [0.868, 1] | 0.906 [0.826, 0.971] |
| all_to_all | cirq | 50 | 66.8 [55.9, 79.7] | 0.851 [0.784, 0.915] | 0.75 [0.681, 0.816] |
| all_to_all | tket | 50 | 259 [215, 313] | 1.02 [1, 1.06] | 1.04 [1.01, 1.07] |
| linear | qiskit | 50 | 2 [1.28, 3.07] | 0.891 [0.831, 0.951] | 0.834 [0.767, 0.898] |
| linear | cirq | 50 | 59.1 [47.4, 73.8] | 0.6 [0.537, 0.666] | 0.481 [0.419, 0.547] |
| linear | tket | 50 | 110 [84.5, 144] | 0.785 [0.692, 0.878] | 0.871 [0.799, 0.944] |
| adder | qiskit | 4 | 3.07 [1.61, 5.88] | 1 [1, 1] | 0.97 [0.942, 1] |
| adder | cirq | 4 | 128 [103, 159] | 0.729 [0.651, 0.816] | 0.531 [0.499, 0.566] |
| adder | tket | 4 | 250 [195, 320] | 0.952 [0.933, 0.97] | 0.917 [0.896, 0.939] |
| ae | qiskit | 4 | 0.766 [0.446, 1.32] | 0.904 [0.901, 0.906] | 0.923 [0.915, 0.932] |
| ae | cirq | 4 | 46.4 [42.2, 51.1] | 0.589 [0.554, 0.626] | 0.673 [0.657, 0.69] |
| ae | tket | 4 | 123 [117, 128] | 0.745 [0.721, 0.769] | 0.896 [0.854, 0.941] |
| basis_change | qiskit | 2 | 4.93 | 1 | 1 |
| basis_change | cirq | 2 | 60.8 | 0.953 | 0.956 |
| basis_change | tket | 2 | 222 | 1 | 1 |
| basis_trotter | qiskit | 4 | 0.577 [0.113, 2.94] | 1.34 [1.08, 1.67] | 1.23 [1.05, 1.44] |
| basis_trotter | cirq | 4 | 46.1 [19.4, 109] | 0.431 [0.341, 0.546] | 0.397 [0.295, 0.534] |
| basis_trotter | tket | 4 | 84.5 [41.2, 173] | 1.38 [0.953, 2] | 1.44 [1.11, 1.86] |
| bell | qiskit | 2 | 6.09 | 1 | 1 |
| bell | cirq | 2 | 59.9 | 0.674 | 0.577 |
| bell | tket | 2 | 178 | 1 | 1.17 |
| bv | qiskit | 2 | 2.55 | 1 | 0.728 |
| bv | cirq | 2 | 69.8 | 0.562 | 0.346 |
| bv | tket | 2 | 466 | 0.372 | 0.547 |
| cat_state | qiskit | 2 | 23.3 | 1 | 1 |
| cat_state | cirq | 2 | 198 | 0.48 | 0.33 |
| cat_state | tket | 2 | 424 | 1 | 1 |
| deutsch | qiskit | 2 | 22.7 | 1 | 1 |
| deutsch | cirq | 2 | 48.1 | 1 | 1 |
| deutsch | tket | 2 | 114 | 1 | 1 |
| dj | qiskit | 4 | 4.3 [2.96, 6.24] | 0.832 [0.775, 0.894] | 0.711 [0.697, 0.726] |
| dj | cirq | 4 | 50.8 [49.4, 52.2] | 0.795 [0.73, 0.866] | 0.485 [0.42, 0.56] |
| dj | tket | 4 | 309 [235, 406] | 0.553 [0.45, 0.679] | 0.69 [0.583, 0.816] |
| dnn | qiskit | 4 | 0.542 [0.22, 1.33] | 1 [1, 1] | 1 [1, 1] |
| dnn | cirq | 4 | 18.8 [18, 19.7] | 0.974 [0.949, 1] | 0.828 [0.685, 1] |
| dnn | tket | 4 | 50.1 [49.5, 50.7] | 0.993 [0.987, 1] | 1.01 [1, 1.02] |
| error_correctiond3 | qiskit | 2 | 1.5 | 0.293 | 0.213 |
| error_correctiond3 | cirq | 2 | 69.3 | 0.29 | 0.182 |
| error_correctiond3 | tket | 2 | 133 | 0.922 | 0.802 |
| fredkin | qiskit | 2 | 4.91 | 1 | 0.97 |
| fredkin | cirq | 2 | 68.4 | 0.894 | 0.625 |
| fredkin | tket | 2 | 111 | 0.926 | 0.903 |
| grover | qiskit | 4 | 2.08 [0.495, 8.77] | 0.707 [0.5, 1] | 0.746 [0.6, 0.928] |
| grover | cirq | 4 | 45.2 [31.6, 64.8] | 0.694 [0.5, 0.964] | 0.691 [0.6, 0.796] |
| grover | tket | 4 | 100 [69, 146] | 0.941 [0.886, 1] | 0.95 [0.902, 1] |
| hhl | qiskit | 2 | 0.317 | 0.929 | 1.04 |
| hhl | cirq | 2 | 33.8 | 0.931 | 0.825 |
| hhl | tket | 2 | 82.4 | 0.874 | 1.04 |
| hs4 | qiskit | 2 | 6.71 | 0.5 | 0.6 |
| hs4 | cirq | 2 | 58.6 | 0.316 | 0.308 |
| hs4 | tket | 2 | 76.8 | 1 | 1 |
| ising | qiskit | 2 | 0.887 | 0.931 | 1.26 |
| ising | cirq | 2 | 78.7 | 0.796 | 0.855 |
| ising | tket | 2 | 256 | 0.931 | 1.26 |
| iswap | qiskit | 2 | 10.1 | 0.5 | 0.6 |
| iswap | cirq | 2 | 33.7 | 0.5 | 0.6 |
| iswap | tket | 2 | 76.7 | 1 | 1 |
| linearsolver | qiskit | 2 | 10.2 | 1 | 1 |
| linearsolver | cirq | 2 | 80.8 | 0.756 | 0.775 |
| linearsolver | tket | 2 | 229 | 1 | 1 |
| lpn | qiskit | 2 | 17.8 | 1 | 1 |
| lpn | cirq | 2 | 73.3 | 1 | 0.8 |
| lpn | tket | 2 | 376 | 1 | 1 |
| multiply | qiskit | 2 | 1.36 | 1 | 0.892 |
| multiply | cirq | 2 | 95.9 | 0.658 | 0.495 |
| multiply | tket | 2 | 144 | 0.743 | 0.72 |
| pea | qiskit | 2 | 1.78 | 0.833 | 0.84 |
| pea | cirq | 2 | 48 | 0.884 | 0.867 |
| pea | tket | 2 | 138 | 0.811 | 0.911 |
| qaoa | qiskit | 2 | 0.589 | 0.972 | 0.921 |
| qaoa | cirq | 2 | 28.3 | 0.9 | 0.746 |
| qaoa | tket | 2 | 92.4 | 0.842 | 1.03 |
| qec_en | qiskit | 2 | 2.92 | 0.943 | 0.791 |
| qec_en | cirq | 2 | 54 | 0.853 | 0.489 |
| qec_en | tket | 2 | 128 | 1 | 1 |
| qft | qiskit | 2 | 3.96 | 0.939 | 0.965 |
| qft | cirq | 2 | 62.4 | 0.889 | 0.965 |
| qft | tket | 2 | 165 | 0.845 | 1.01 |
| qnn | qiskit | 4 | 7.26 [5.73, 9.21] | 1 [1, 1] | 0.621 [0.579, 0.667] |
| qnn | cirq | 4 | 98.4 [88.6, 109] | 0.698 [0.688, 0.707] | 0.443 [0.404, 0.485] |
| qnn | tket | 4 | 361 [344, 379] | 1 [1, 1] | 1 [1, 1] |
| qpeexact | qiskit | 4 | 0.985 [0.524, 1.85] | 0.871 [0.81, 0.937] | 0.831 [0.795, 0.869] |
| qpeexact | cirq | 4 | 45.9 [41, 51.4] | 0.716 [0.7, 0.732] | 0.676 [0.63, 0.725] |
| qpeexact | tket | 4 | 112 [102, 123] | 0.757 [0.697, 0.821] | 0.871 [0.803, 0.946] |
| qpeinexact | qiskit | 4 | 0.895 [0.492, 1.63] | 0.909 [0.88, 0.939] | 0.839 [0.808, 0.871] |
| qpeinexact | cirq | 4 | 46 [41.8, 50.6] | 0.714 [0.708, 0.72] | 0.688 [0.642, 0.737] |
| qpeinexact | tket | 4 | 115 [106, 125] | 0.756 [0.693, 0.826] | 0.849 [0.79, 0.912] |
| qrng | qiskit | 2 | 27.7 | undefined (no positive pairs) | 1 |
| qrng | cirq | 2 | 20.5 | undefined (no positive pairs) | 1 |
| qrng | tket | 2 | 148 | undefined (no positive pairs) | 1 |
| quantumwalks | qiskit | 2 | 11.8 | 1 | 1 |
| quantumwalks | cirq | 2 | 40.9 | 1 | 1 |
| quantumwalks | tket | 2 | 209 | 1 | 1 |
| qwalk | qiskit | 2 | 0.275 | 1.02 | 0.981 |
| qwalk | cirq | 2 | 52.7 | 0.902 | 0.762 |
| qwalk | tket | 2 | 116 | 0.93 | 0.936 |
| sat | qiskit | 4 | 0.698 [0.462, 1.06] | 0.983 [0.982, 0.985] | 0.917 [0.913, 0.92] |
| sat | cirq | 4 | 95.3 [91.2, 99.6] | 0.756 [0.756, 0.757] | 0.574 [0.568, 0.58] |
| sat | tket | 4 | 120 [105, 137] | 0.875 [0.84, 0.912] | 0.88 [0.852, 0.908] |
| simon | qiskit | 2 | 2.93 | 1 | 0.96 |
| simon | cirq | 2 | 80.6 | 0.844 | 0.783 |
| simon | tket | 2 | 120 | 0.92 | 0.935 |
| teleportation | qiskit | 2 | 18.7 | 1 | 0.8 |
| teleportation | cirq | 2 | 96.4 | 0.816 | 0.676 |
| teleportation | tket | 2 | 331 | 1 | 1 |
| toffoli | qiskit | 2 | 6.09 | 1 | 0.931 |
| toffoli | cirq | 2 | 69.7 | 0.837 | 0.822 |
| toffoli | tket | 2 | 132 | 0.882 | 0.901 |
| variational | qiskit | 2 | 4.86 | 1 | 1 |
| variational | cirq | 2 | 72.6 | 0.73 | 0.67 |
| variational | tket | 2 | 267 | 1 | 1.08 |
| vqe_real_amp | qiskit | 4 | 6.6 [5.19, 8.4] | 1 [1, 1] | 1 [1, 1] |
| vqe_real_amp | cirq | 4 | 220 [194, 250] | 0.721 [0.688, 0.756] | 0.44 [0.394, 0.492] |
| vqe_real_amp | tket | 4 | 784 [689, 892] | 1 [1, 1] | 1 [1, 1] |
| vqe_su2 | qiskit | 4 | 4.24 [3.26, 5.53] | 1 [1, 1] | 0.876 [0.857, 0.895] |
| vqe_su2 | cirq | 4 | 147 [134, 161] | 0.721 [0.688, 0.756] | 0.44 [0.394, 0.492] |
| vqe_su2 | tket | 4 | 569 [520, 624] | 1 [1, 1] | 1 [1, 1] |
| wstate | qiskit | 2 | 3.36 | 0.894 | 0.825 |
| wstate | cirq | 2 | 52.3 | 0.608 | 0.544 |
| wstate | tket | 2 | 90.3 | 0.816 | 0.858 |

## Tradeoffs and failure tails

A pipeline is on the Pareto frontier when no other measured pipeline is at least as good on every listed metric and strictly better on one. Frontiers use per-cell medians and count tied pipelines separately.

| Objectives | Q-Rust | Qiskit | Cirq | TKET |
|---|---:|---:|---:|---:|
| speed_cx | 84/100 | 29/100 | 0/100 | 6/100 |
| speed_depth | 88/100 | 28/100 | 2/100 | 17/100 |
| speed_cx_depth | 90/100 | 29/100 | 2/100 | 19/100 |

| Baseline | Worst CX excess case | Q-Rust CX / baseline CX | Slowest relative case | Baseline / Q-Rust time |
|---|---|---:|---|---:|
| qiskit | qasmbench__basis_test_n4__all_to_all | 10 / 6 | qasmbench__basis_trotter_n4__linear | 0.0847 |
| cirq | mqtbench__dj_n10__all_to_all | 9 / 9 | qasmbench__qrng_n4__all_to_all | 15.9 |
| tket | qasmbench__basis_test_n4__all_to_all | 10 / 5 | qasmbench__basis_trotter_n4__linear | 22.2 |

## Measurement scope

The measurements support comparisons of the specified compiler recipes on these corrected, static circuits and target graphs, under the recorded single-machine conditions. Speed is summarized by paired runtime ratios; output size and depth are reported separately, including cases where Q-Rust performs worse. The per-family and per-topology tables can identify useful subsets, but a subset selected after viewing these results is exploratory and needs a separate confirmation corpus.

The experiment does not isolate the effect of Rust: the tools differ in algorithms, search effort, representations and API overhead, and competitors have native implementations. Seven trials equalize repetitions, not optimization work or runtime budgets. These recipes are documented choices, not a search over every available competitor pipeline. The fixed corpus and limited widths do not establish general scalability, hardware fidelity, or closeness to a mathematical optimum. Numerical validation is evidence for the measured outputs; sampled checks are not proofs of equivalence.

## Eligibility and reproducibility

Expected trial records: 2800. Eligible cells by tool: qrust 100, qiskit 100, cirq 100, tket 100.

Validation evidence classes: `{"full_isometry": 1960, "sampled_isometry": 840}`.

Every excluded cell and its individual trial failures are listed in `summary.json`; missing trials are explicit. `cell_summary.csv` contains all compiler–cell combinations, including exclusions. The JSON also retains zero cases, subgroup intervals, Pareto membership and the ten worst tails per baseline. Aggregate geometric means give equal weight to eligible cells, so fixtures with more target topologies contribute more cells. Bootstrap intervals resample fixture clusters and condition on positive-ratio cells; they do not correct corpus-selection bias or multiple comparisons.
