//! End-to-end verification suite for well-known quantum algorithms.

use q_rust::backend::{Backend, BackendConfig};
use q_rust::error::QRustError;
use q_rust::ir::Circuit;
use q_rust::parser::parse_qasm;
use q_rust::transpiler::pass::Pass;
use q_rust::transpiler::property_set::PropertySet;
use q_rust::transpiler::routing::{BeamSabrePass, LookaheadStrategy};
use q_rust::transpiler::target_basis::validate_circuit_basis;
use q_rust::transpiler::{transpile, transpile_with_report, TranspilerConfig};
use q_rust::verify::{verify_equivalence_with_layout, Verdict};
use std::collections::HashSet;

fn load_backend(name: &str) -> Backend {
    let path = format!("tests/fixtures/{name}");
    let json = std::fs::read_to_string(&path).unwrap_or_else(|_| panic!("missing fixture: {path}"));
    let cfg: BackendConfig = serde_json::from_str(&json).unwrap();
    Backend::from_config(cfg)
}

fn basis(gates: &[&str]) -> HashSet<String> {
    gates.iter().map(|s| s.to_string()).collect()
}

fn load_circuit(fixture: &str) -> Circuit {
    let path = format!("tests/fixtures/{fixture}");
    let qasm = std::fs::read_to_string(&path).unwrap_or_else(|_| panic!("missing fixture: {path}"));
    parse_qasm(&qasm).unwrap_or_else(|e| panic!("parse failed for {fixture}: {e:?}"))
}

fn verify_basis_only(label: &str, circuit: &Circuit, target_basis: HashSet<String>) {
    let b = Backend::all_to_all(circuit.num_qubits);
    let expected_basis = target_basis.clone();

    let cfg = TranspilerConfig::builder()
        .optimization_level(2)
        .decompose_basis(true)
        .backend(b)
        .target_basis(target_basis)
        .build();

    let (compiled, report) = transpile_with_report(circuit, Some(cfg))
        .unwrap_or_else(|e| panic!("[{label}] transpile failed: {e}"));
    validate_circuit_basis(&compiled, &expected_basis)
        .unwrap_or_else(|e| panic!("[{label}] output basis is not closed: {e}"));

    // Even all-to-all routing can absorb source SWAPs into the output layout.
    // Preserve terminal measurements and validate their classical destinations
    // through the reported layout before comparing the unitary prefixes.
    let initial = report.initial_layout.as_deref().expect("initial layout");
    let final_layout = report.final_layout.as_deref().expect("final layout");
    let verdict = verify_equivalence_with_layout(circuit, &compiled, initial, final_layout)
        .unwrap_or_else(|e| panic!("[{label}] basis-translation verification failed: {e}"));
    assert!(
        matches!(verdict, Verdict::ExactlyEquivalent { fidelity } if (fidelity - 1.0).abs() < 1e-6),
        "[{label}] basis-translation verification: {verdict:?}"
    );
}

fn verify_routed(label: &str, circuit: &Circuit, backend: &Backend, target_basis: HashSet<String>) {
    let expected_basis = target_basis.clone();

    // Keep the router's default classical-SABRE lookahead strategy explicit.
    let router = BeamSabrePass {
        backend: backend.clone(),
        beam_width: 4,
        branch_factor: 3,
        bidir_iterations: 2,
        lookahead_strategy: LookaheadStrategy::default(),
    };
    let mut props = PropertySet::new();
    let routed = router.run(circuit, &mut props);

    let initial: Vec<usize> = props
        .get::<Vec<usize>>("initial_layout")
        .cloned()
        .unwrap_or_else(|| (0..circuit.num_qubits).collect());
    let final_l: Vec<usize> = props
        .get::<Vec<usize>>("final_layout")
        .cloned()
        .unwrap_or_else(|| (0..circuit.num_qubits).collect());

    let cfg = TranspilerConfig::builder()
        .optimization_level(1)
        .decompose_basis(true)
        .target_basis(target_basis)
        .build();
    let translated = transpile(&routed, Some(cfg))
        .unwrap_or_else(|e| panic!("[{label}] basis translation failed: {e}"));
    validate_circuit_basis(&translated, &expected_basis)
        .unwrap_or_else(|e| panic!("[{label}] output basis is not closed: {e}"));

    let mut padded = translated.clone();
    padded.num_qubits = backend.num_qubits;
    // Check measurement destinations through the final layout as well as the
    // routed unitary, including the requirement that unused wires stay clean.
    let verdict = verify_equivalence_with_layout(circuit, &padded, &initial, &final_l)
        .unwrap_or_else(|e| panic!("[{label}] routed verification failed: {e}"));
    assert!(
        matches!(verdict, Verdict::ExactlyEquivalent { fidelity } if (fidelity - 1.0).abs() < 1e-6),
        "[{label}] routed verification: {verdict:?}"
    );
}

// ===========================================================================
// Bell State
// ===========================================================================

#[test]
fn test_e2e_bell_basis_rz_rx_cx() {
    verify_basis_only(
        "bell/{rz,rx,cx}",
        &load_circuit("bell_state.qasm"),
        basis(&["rz", "rx", "cx"]),
    );
}

#[test]
fn test_e2e_bell_basis_u_cx() {
    verify_basis_only(
        "bell/{u,cx}",
        &load_circuit("bell_state.qasm"),
        basis(&["u", "cx"]),
    );
}

#[test]
fn test_e2e_bell_routed_quito_rz_rx_cx() {
    verify_routed(
        "bell/ibm_quito/{rz,rx,cx}",
        &load_circuit("bell_state.qasm"),
        &load_backend("ibm_quito_5q.json"),
        basis(&["rz", "rx", "cx"]),
    );
}

#[test]
fn test_e2e_bell_routed_linear3_u_cx() {
    verify_routed(
        "bell/linear-3/{u,cx}",
        &load_circuit("bell_state.qasm"),
        &Backend::linear(3),
        basis(&["u", "cx"]),
    );
}

// ===========================================================================
// GHZ-3
// ===========================================================================

#[test]
fn test_e2e_ghz3_basis_rz_rx_cx() {
    verify_basis_only(
        "ghz3/{rz,rx,cx}",
        &load_circuit("ghz_3.qasm"),
        basis(&["rz", "rx", "cx"]),
    );
}

#[test]
fn test_e2e_ghz3_basis_u_cx() {
    verify_basis_only(
        "ghz3/{u,cx}",
        &load_circuit("ghz_3.qasm"),
        basis(&["u", "cx"]),
    );
}

#[test]
fn test_e2e_ghz3_routed_nairobi_rz_rx_cx() {
    verify_routed(
        "ghz3/ibm_nairobi/{rz,rx,cx}",
        &load_circuit("ghz_3.qasm"),
        &load_backend("ibm_nairobi_7q.json"),
        basis(&["rz", "rx", "cx"]),
    );
}

#[test]
fn test_e2e_ghz3_routed_linear5_u_cx() {
    verify_routed(
        "ghz3/linear-5/{u,cx}",
        &load_circuit("ghz_3.qasm"),
        &Backend::linear(5),
        basis(&["u", "cx"]),
    );
}

// ===========================================================================
// Grover 2-qubit
// ===========================================================================

#[test]
fn test_e2e_grover2_basis_rz_rx_cx() {
    verify_basis_only(
        "grover2/{rz,rx,cx}",
        &load_circuit("grover_2.qasm"),
        basis(&["rz", "rx", "cx"]),
    );
}

#[test]
fn test_e2e_grover2_basis_u_cx() {
    verify_basis_only(
        "grover2/{u,cx}",
        &load_circuit("grover_2.qasm"),
        basis(&["u", "cx"]),
    );
}

#[test]
fn test_e2e_grover2_routed_quito_rz_rx_cx() {
    verify_routed(
        "grover2/ibm_quito/{rz,rx,cx}",
        &load_circuit("grover_2.qasm"),
        &load_backend("ibm_quito_5q.json"),
        basis(&["rz", "rx", "cx"]),
    );
}

// ===========================================================================
// QFT-3
// ===========================================================================

#[test]
fn test_e2e_qft3_basis_rz_rx_cx() {
    verify_basis_only(
        "qft3/{rz,rx,cx}",
        &load_circuit("qft_3.qasm"),
        basis(&["rz", "rx", "cx"]),
    );
}

#[test]
fn test_e2e_qft3_basis_u_cx() {
    verify_basis_only(
        "qft3/{u,cx}",
        &load_circuit("qft_3.qasm"),
        basis(&["u", "cx"]),
    );
}

#[test]
fn test_e2e_qft3_routed_nairobi_rz_rx_cx() {
    verify_routed(
        "qft3/ibm_nairobi/{rz,rx,cx}",
        &load_circuit("qft_3.qasm"),
        &load_backend("ibm_nairobi_7q.json"),
        basis(&["rz", "rx", "cx"]),
    );
}

// ===========================================================================
// Deutsch-Jozsa
// ===========================================================================

#[test]
fn test_e2e_dj_basis_rz_rx_cx() {
    verify_basis_only(
        "dj/{rz,rx,cx}",
        &load_circuit("deutsch_jozsa.qasm"),
        basis(&["rz", "rx", "cx"]),
    );
}

#[test]
fn test_e2e_dj_basis_u_cx() {
    verify_basis_only(
        "dj/{u,cx}",
        &load_circuit("deutsch_jozsa.qasm"),
        basis(&["u", "cx"]),
    );
}

#[test]
fn test_e2e_dj_routed_linear5_rz_rx_cx() {
    verify_routed(
        "dj/linear-5/{rz,rx,cx}",
        &load_circuit("deutsch_jozsa.qasm"),
        &Backend::linear(5),
        basis(&["rz", "rx", "cx"]),
    );
}

// ===========================================================================
// Bernstein-Vazirani
// ===========================================================================

#[test]
fn test_e2e_bv_basis_rz_rx_cx() {
    verify_basis_only(
        "bv/{rz,rx,cx}",
        &load_circuit("bernstein_vazirani.qasm"),
        basis(&["rz", "rx", "cx"]),
    );
}

#[test]
fn test_e2e_bv_basis_u_cx() {
    verify_basis_only(
        "bv/{u,cx}",
        &load_circuit("bernstein_vazirani.qasm"),
        basis(&["u", "cx"]),
    );
}

#[test]
fn test_e2e_bv_routed_nairobi_rz_rx_cx() {
    verify_routed(
        "bv/ibm_nairobi/{rz,rx,cx}",
        &load_circuit("bernstein_vazirani.qasm"),
        &load_backend("ibm_nairobi_7q.json"),
        basis(&["rz", "rx", "cx"]),
    );
}

// ===========================================================================
// VQE ansatz
// ===========================================================================

#[test]
fn test_e2e_vqe_basis_rz_rx_cx() {
    verify_basis_only(
        "vqe/{rz,rx,cx}",
        &load_circuit("vqe_ansatz.qasm"),
        basis(&["rz", "rx", "cx"]),
    );
}

#[test]
fn test_e2e_vqe_basis_u_cx() {
    verify_basis_only(
        "vqe/{u,cx}",
        &load_circuit("vqe_ansatz.qasm"),
        basis(&["u", "cx"]),
    );
}

// ===========================================================================
// QPE
// ===========================================================================

#[test]
fn test_e2e_qpe_basis_rz_rx_cx() {
    verify_basis_only(
        "qpe/{rz,rx,cx}",
        &load_circuit("qpe_2.qasm"),
        basis(&["rz", "rx", "cx"]),
    );
}

#[test]
fn test_e2e_qpe_routed_quito_rz_rx_cx() {
    verify_routed(
        "qpe/ibm_quito/{rz,rx,cx}",
        &load_circuit("qpe_2.qasm"),
        &load_backend("ibm_quito_5q.json"),
        basis(&["rz", "rx", "cx"]),
    );
}

// ===========================================================================
// Deep Clifford
// ===========================================================================

#[test]
fn test_e2e_clifford_basis_rz_rx_cx() {
    verify_basis_only(
        "clifford/{rz,rx,cx}",
        &load_circuit("deep_clifford.qasm"),
        basis(&["rz", "rx", "cx"]),
    );
}

#[test]
fn test_e2e_clifford_basis_u_cx() {
    verify_basis_only(
        "clifford/{u,cx}",
        &load_circuit("deep_clifford.qasm"),
        basis(&["u", "cx"]),
    );
}

#[test]
fn test_e2e_clifford_routed_nairobi_u_cx() {
    verify_routed(
        "clifford/ibm_nairobi/{u,cx}",
        &load_circuit("deep_clifford.qasm"),
        &load_backend("ibm_nairobi_7q.json"),
        basis(&["u", "cx"]),
    );
}

// ===========================================================================
// QFT-5
// ===========================================================================

#[test]
fn test_e2e_qft5_basis_rz_rx_cx() {
    verify_basis_only(
        "qft5/{rz,rx,cx}",
        &load_circuit("qft_5.qasm"),
        basis(&["rz", "rx", "cx"]),
    );
}

#[test]
fn test_e2e_qft5_basis_u_cx() {
    verify_basis_only(
        "qft5/{u,cx}",
        &load_circuit("qft_5.qasm"),
        basis(&["u", "cx"]),
    );
}

// ===========================================================================
// Gate-set validation
// ===========================================================================

#[test]
fn test_gateset_rejects_clifford_only() {
    let c = load_circuit("bell_state.qasm");
    let cfg = TranspilerConfig::builder()
        .optimization_level(1)
        .decompose_basis(true)
        .target_basis(["h", "s", "cx"].iter().map(|s| s.to_string()))
        .build();
    let result = transpile(&c, Some(cfg));
    assert!(
        matches!(result, Err(QRustError::NonUniversalBasisGateSet { .. })),
        "expected NonUniversalBasisGateSet, got: {result:?}"
    );
}

#[test]
fn test_gateset_rejects_no_entangler() {
    let c = load_circuit("bell_state.qasm");
    let cfg = TranspilerConfig::builder()
        .optimization_level(1)
        .decompose_basis(true)
        .target_basis(["rz", "rx", "ry"].iter().map(|s| s.to_string()))
        .build();
    let result = transpile(&c, Some(cfg));
    assert!(
        matches!(result, Err(QRustError::NonUniversalBasisGateSet { .. })),
        "expected NonUniversalBasisGateSet, got: {result:?}"
    );
}

#[test]
fn test_gateset_rejects_unimplemented_clifford_t_lowering() {
    let c = load_circuit("bell_state.qasm");
    let b = Backend::all_to_all(2);
    let cfg = TranspilerConfig::builder()
        .optimization_level(1)
        .decompose_basis(true)
        .backend(b)
        .target_basis(["h", "t", "cx"].iter().map(|s| s.to_string()))
        .build();
    let result = transpile(&c, Some(cfg));
    assert!(
        matches!(result, Err(QRustError::UntranslatableGate { .. })),
        "Clifford+T is universal, but exact arbitrary-angle synthesis is not implemented: {result:?}"
    );
}

#[test]
fn test_gateset_rejects_single_rotation_axis() {
    let c = load_circuit("bell_state.qasm");
    let b = Backend::all_to_all(2);
    let cfg = TranspilerConfig::builder()
        .optimization_level(1)
        .decompose_basis(true)
        .backend(b)
        .target_basis(["rz", "cx"].iter().map(|s| s.to_string()))
        .build();
    assert!(matches!(
        transpile(&c, Some(cfg)),
        Err(QRustError::NonUniversalBasisGateSet { .. })
    ));
}

// ===========================================================================
// Permissive mode
// ===========================================================================

#[test]
fn test_permissive_mode_no_basis() {
    let c = load_circuit("bell_state.qasm");
    let cfg = TranspilerConfig::builder()
        .optimization_level(1)
        .decompose_basis(false)
        .build();
    let result = transpile(&c, Some(cfg));
    assert!(
        result.is_ok(),
        "permissive mode should not error: {result:?}"
    );
    assert!(!result.unwrap().operations.is_empty());
}
