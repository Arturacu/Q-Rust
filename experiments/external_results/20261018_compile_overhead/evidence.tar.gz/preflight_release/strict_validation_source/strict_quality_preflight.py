#!/usr/bin/env python3
"""Run the unchanged 100+8 preflight, then require exact native-result parity."""
import argparse
import hashlib
import json
from pathlib import Path
import subprocess
import sys

sys.path.insert(0, str(Path(__file__).resolve().parent / 'verification'))
from result_parity import compare_results, EXCLUDED_FIELDS


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    for name in ('repo', 'binary', 'old-binary', 'external-baseline', 'matched-baseline', 'output'):
        parser.add_argument('--' + name, type=Path, required=True)
    args = parser.parse_args()
    for name, value in vars(args).items():
        setattr(args, name, value.resolve())
    command = [sys.executable, str(args.repo / 'experiments/quality_preflight.py')]
    for name, value in vars(args).items():
        command += ['--' + name.replace('_', '-'), str(value)]
    subprocess.run(command, check=True)
    raw_path = args.output / 'raw.jsonl'
    rows = [json.loads(line) for line in raw_path.read_text().splitlines()]
    lookup = {(row['suite'], row['case_id'], row['variant']): row for row in rows}
    assert len(rows) == len(lookup) == 216
    summary = json.loads((args.output / 'summary.json').read_text())
    assert summary['raw_sha256'] == sha(raw_path)
    # These fields are supplied by the unchanged transport wrapper, not the
    # native compiler result. Their original values remain in raw.jsonl.
    envelope = {'suite', 'variant', 'case_id', 'seed', 'request_wall_ns',
                'noncompile_nonparse_request_ns', 'output_sha256'}
    comparisons = []
    for comparison in summary['comparisons']:
        suite, case_id = comparison['suite'], comparison['case_id']
        old, new = lookup[suite, case_id, 'old'], lookup[suite, case_id, 'new']
        for row in (old, new):
            if row.get('status') == 'compiled':
                assert hashlib.sha256(row['out_qasm'].encode()).hexdigest() == row['output_sha256']
        parity = compare_results({k: v for k, v in old.items() if k not in envelope},
                                 {k: v for k, v in new.items() if k not in envelope})
        costs_equal = ('metrics' in comparison and all(value['old'] == value['new']
                       for value in comparison['metrics'].values()))
        comparisons.append({'suite': suite, 'case_id': case_id, 'result_parity': parity,
                            'all_structural_costs_unchanged': costs_equal,
                            'both_verified': comparison['semantically_eligible']})
    passed = all(row['result_parity']['passed'] and row['all_structural_costs_unchanged']
                 and row['both_verified'] for row in comparisons)
    receipt = {'passed': passed, 'scope': __doc__, 'cases': len(comparisons),
               'native_result_excluded_fields': list(EXCLUDED_FIELDS),
               'transport_envelope_fields_separated': sorted(envelope),
               'raw_sha256': sha(raw_path), 'original_summary_sha256': sha(args.output/'summary.json'),
               'driver_sha256': sha(__file__),
               'parity_helper_sha256': sha(Path(__file__).parent/'verification/result_parity.py'),
               'comparisons': comparisons}
    with (args.output / 'strict_parity.json').open('x') as stream:
        json.dump(receipt, stream, indent=2, sort_keys=True, allow_nan=False); stream.write('\n')
    source = args.output / 'strict_validation_source'
    source.mkdir()
    for path in (Path(__file__), Path(__file__).parent/'verification/result_parity.py'):
        with (source/path.name).open('xb') as stream:
            stream.write(path.read_bytes())
    print(json.dumps({'strict_parity_passed': passed, 'cases': len(comparisons)}), flush=True)
    if not passed:
        raise SystemExit(1)


if __name__ == '__main__':
    main()
