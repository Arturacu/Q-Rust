"""Exact native compiler-result parity, apart from three diagnostic fields."""
import json

EXCLUDED_FIELDS = ('compile_ns', 'parse_ns', 'pass_diagnostics')


def compare_results(previous, candidate):
    """Do not drop unknown/new metadata fields or normalize numerical values."""
    failures = []
    for label, value in [('previous', previous), ('candidate', candidate)]:
        if not isinstance(value, dict):
            return {'passed': False, 'failures': [label + ' result is not an object'],
                    'changed_fields': [], 'excluded_fields': list(EXCLUDED_FIELDS)}
        if value.get('status') != 'compiled':
            failures.append(label + ' result is not compiled')
        for key in EXCLUDED_FIELDS:
            if key not in value:
                failures.append(label + ' missing diagnostic field ' + key)
        if type(value.get('compile_ns')) is not int or value.get('compile_ns', 0) <= 0:
            failures.append(label + ' invalid compile time')
        if type(value.get('parse_ns')) is not int or value.get('parse_ns', -1) < 0:
            failures.append(label + ' invalid parse time')
        if not isinstance(value.get('pass_diagnostics'), list):
            failures.append(label + ' invalid pass diagnostics')
    left = {k: v for k, v in previous.items() if k not in EXCLUDED_FIELDS}
    right = {k: v for k, v in candidate.items() if k not in EXCLUDED_FIELDS}
    def canonical(value):
        return json.dumps(value, sort_keys=True, separators=(',', ':'), allow_nan=False)
    changed = sorted(key for key in set(left) | set(right)
                     if key not in left or key not in right or canonical(left[key]) != canonical(right[key]))
    return {'passed': not failures and not changed, 'failures': failures,
            'changed_fields': changed, 'excluded_fields': list(EXCLUDED_FIELDS)}
