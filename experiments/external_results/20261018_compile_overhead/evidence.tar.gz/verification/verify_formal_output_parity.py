#!/usr/bin/env python3
"""Check every formal old/new native response after all timing has finished."""
import argparse
import hashlib
import json
from pathlib import Path

from result_parity import compare_results

# These fields are added by the existing scheduler and transport wrapper,
# outside the native compiler response. The native response comparison itself
# excludes exactly compile_ns, parse_ns and pass_diagnostics.
ENVELOPE_FIELDS = {
    'case_id', 'tool', 'trial', 'seed', 'session', 'phase', 'schedule_index',
    'request_wall_ns', 'noncompile_nonparse_request_ns', 'output_sha256',
    'sampled_worker_rss_bytes', 'sampled_all_worker_rss_bytes',
}


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def unique_object(pairs):
    result = {}
    for key, value in pairs:
        if key in result:
            raise ValueError('Duplicate JSON object key: ' + key)
        result[key] = value
    return result


def read_json(path):
    return json.loads(path.read_text(), object_pairs_hook=unique_object)


def read_rows(path):
    return [json.loads(line, object_pairs_hook=unique_object)
            for line in path.read_text().splitlines() if line]


def key_for(row, default_phase):
    if type(row['trial']) is not int or type(row['seed']) is not int:
        raise ValueError('Q-Rust trial and seed must be integer schedule identities')
    return (row['case_id'], row['trial'], row['seed'],
            row.get('phase', default_phase))


def index_rows(rows_with_phases, *, session=None, expected_slots=None, matched=False):
    indexed = {}
    for row, default_phase in rows_with_phases:
        if row['tool'] != 'qrust':
            continue
        key = key_for(row, default_phase)
        if session is not None and (type(row.get('session')) is not int or row['session'] != session):
            raise ValueError('Q-Rust row session differs from enclosing session')
        if expected_slots is not None:
            if key not in expected_slots:
                raise ValueError('Q-Rust row identity differs from scheduled slots')
            if matched:
                if (type(row.get('schedule_index')) is not int or
                        row['schedule_index'] != expected_slots[key]):
                    raise ValueError('Matched Q-Rust schedule_index differs from planned slot')
            elif 'schedule_index' in row:
                raise ValueError('Unexpected external schedule_index field')
        if key in indexed:
            raise ValueError('Duplicate Q-Rust result identity: ' + repr(key))
        indexed[key] = row
    return indexed


def compare_native_rows(previous, candidate):
    failures = []
    for variant, row in [('previous', previous), ('candidate', candidate)]:
        if row.get('status') == 'compiled':
            actual = hashlib.sha256(row['out_qasm'].encode()).hexdigest()
            if row.get('output_sha256') != actual:
                failures.append(variant + ' output QASM hash mismatch')
    a = {k: v for k, v in previous.items() if k not in ENVELOPE_FIELDS}
    b = {k: v for k, v in candidate.items() if k not in ENVELOPE_FIELDS}
    check = compare_results(a, b)
    check['failures'] = failures + check['failures']
    check['passed'] = check['passed'] and not failures
    return check


def verify_campaign(campaign, completion_path=None, allow_relocated=False):
    campaign = campaign.resolve()
    completion_path = completion_path or campaign.parent / 'timing_completion.json'
    completion = read_json(completion_path)
    protocol_path = campaign / 'paired_protocol.json'
    if (not completion['all_four_sessions_completed'] or
            (not allow_relocated and completion['campaign'] != str(campaign)) or
            completion['paired_protocol_sha256'] != sha(protocol_path) or
            (campaign / 'active.lock').exists()):
        raise ValueError('All four matching timing sessions must be closed')
    protocol = read_json(protocol_path)
    files = {}
    records = []
    failures = []
    for suite in ['external', 'matched']:
        for session in [1, 2]:
            folder = campaign / suite
            expected_slots = {}
            for planned in protocol['schedules'][suite][str(session)]:
                if planned['tool'] != 'qrust':
                    continue
                key = (planned['case_id'], planned['trial'], planned['seed'],
                       'warmup' if planned['trial'] == -1 else 'timed')
                slot = planned['primary_schedule_index']
                if key in expected_slots and expected_slots[key] != slot:
                    raise ValueError('Protocol assigns inconsistent primary slots')
                expected_slots[key] = slot
            if suite == 'external':
                paths = {'previous': [(folder / f'control_session_{session}' / (phase + '.jsonl'), phase)
                                      for phase in ['warmup', 'timed']],
                         'candidate': [(folder / f'session_{session:02d}' / (phase + '.jsonl'), phase)
                                       for phase in ['warmup', 'timed']]}
            else:
                paths = {'previous': [(folder / f'control_session_{session}' / 'rows.jsonl', None)],
                         'candidate': [(folder / f'session_{session}.jsonl', None)]}
            indexed = {}
            for variant, items in paths.items():
                rows = []
                for path, phase in items:
                    files[str(path.relative_to(campaign))] = sha(path)
                    rows.extend((row, phase) for row in read_rows(path))
                indexed[variant] = index_rows(rows, session=session,
                    expected_slots=expected_slots, matched=suite == 'matched')
            planned = set(expected_slots)
            if set(indexed['previous']) != set(indexed['candidate']):
                failures.append({'suite': suite, 'session': session,
                                 'reason': 'Old/new result identities differ'})
            for variant in indexed:
                missing = planned - set(indexed[variant])
                extra = set(indexed[variant]) - planned
                if missing or extra:
                    failures.append({'suite': suite, 'session': session,
                                     'variant': variant,
                                     'reason': 'Results differ from exact scheduled pair identities',
                                     'missing': sorted(missing), 'extra': sorted(extra)})
            for key in sorted(set(indexed['previous']) & set(indexed['candidate'])):
                a, b = indexed['previous'][key], indexed['candidate'][key]
                check = compare_native_rows(a, b)
                record = {'suite': suite, 'session': session, 'case_id': key[0],
                          'trial': key[1], 'seed': key[2], 'phase': key[3], **check}
                records.append(record)
                if not check['passed']:
                    failures.append(record)
    return {'schema': 1, 'passed': not failures, 'pairs': len(records),
            'passed_pairs': sum(r['passed'] for r in records),
            'timed_pairs': sum(r['phase'] == 'timed' for r in records),
            'warmup_pairs': sum(r['phase'] == 'warmup' for r in records),
            'native_excluded_fields': ['compile_ns', 'parse_ns', 'pass_diagnostics'],
            'transport_envelope_fields': sorted(ENVELOPE_FIELDS),
            'scope': 'Every scheduled Q-Rust warmup and timed response is compared exactly after removing documented scheduler/transport envelope fields. Only the three listed native diagnostic fields may differ. All stored QASM hashes are independently checked. Extra replacement requests fail closed and require explicit investigation.',
            'paired_protocol_sha256': sha(protocol_path),
            'timing_completion_sha256': sha(completion_path),
            'source_sha256': {Path(__file__).name: sha(Path(__file__)),
                              'result_parity.py': sha(Path(__file__).with_name('result_parity.py'))},
            'raw_files_sha256': files, 'failures': failures, 'records': records}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--campaign', type=Path, required=True)
    parser.add_argument('--completion', type=Path)
    parser.add_argument('--allow-relocated', action='store_true',
                        help='Permit an extracted campaign path; protocol checksum binding remains mandatory.')
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    report = verify_campaign(args.campaign, args.completion, args.allow_relocated)
    with args.output.open('x') as stream:
        json.dump(report, stream, indent=2, sort_keys=True)
        stream.write('\n')
    print(json.dumps({k: report[k] for k in ['passed', 'pairs', 'passed_pairs', 'timed_pairs', 'warmup_pairs']}))
    raise SystemExit(0 if report['passed'] else 1)


if __name__ == '__main__':
    main()
