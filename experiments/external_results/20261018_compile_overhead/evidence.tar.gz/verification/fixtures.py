"""Retained small-circuit full-isometry checks of baseline and new compilers.

This is correctness fuzzing, not a timing comparison. Each compiled QASM,
request, map and independent validation record is retained. The analytic
NumPy oracle imports no compiler SDK and checks every logical input column,
with one shared global phase and all physical spare-wire amplitudes included.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import math
from pathlib import Path
import random
import re
import selectors
import subprocess
import sys
import time


def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def unitary_qasm(text):
    """Ignore only identity barriers for the numerical oracle, preserving raw QASM."""
    return re.sub(r'(?m)^\s*barrier\s+[^;]*;', '', text)


def encoded(a, b):
    return [f'cx q[{a}],q[{b}];', f'h q[{a}];', f'h q[{b}];',
            f'cx q[{a}],q[{b}];', f'h q[{a}];', f'h q[{b}];',
            f'cx q[{a}],q[{b}];']


def fixtures():
    rng = random.Random(202610180731)
    for index in range(64):
        width = 2 + index % 4
        kind = ['clifford', 'mixed', 'encoded', 'near_clifford',
                'controlled_rotations', 'overlapping_permutations',
                'commuting_cross_block', 'noncommuting_cross_block'][index // 8]
        body = []
        if kind in ('clifford', 'mixed', 'controlled_rotations'):
            for step in range(36):
                a, b = rng.sample(range(width), 2)
                choice = rng.randrange(8)
                if choice < 3:
                    body.append(f'{rng.choice(["cx", "cy", "cz"])} q[{a}],q[{b}];')
                elif kind == 'mixed' and choice == 3:
                    params = ','.join(repr(rng.uniform(-math.pi, math.pi)) for _ in range(3))
                    body.append(f'u({params}) q[{a}];')
                elif kind == 'controlled_rotations' and choice == 3:
                    body.append(f'{rng.choice(["cu1", "crz", "cry", "rzz"])}({rng.uniform(-1.3, 1.3)!r}) q[{a}],q[{b}];')
                else:
                    body.append(f'{rng.choice(["h", "s", "sdg", "x", "y", "z", "sx"])} q[{a}];')
                if step in (11, 25):
                    body.append('barrier ' + ','.join(f'q[{q}]' for q in range(width)) + ';')
        elif kind == 'near_clifford':
            # Repetition makes erasing each small deviation visibly wrong.
            for _ in range(32):
                part = encoded(0, width - 1)
                part[1] = f'u({math.pi / 2!r},9e-10,{math.pi!r}) q[0];'
                body.extend(part)
        elif kind in ('encoded', 'overlapping_permutations'):
            body.append('u(0.3,-0.2,0.7) q[0];')
            for step in range(5):
                a = step % width
                b = (a + 1) % width
                if kind == 'overlapping_permutations' and step % 2 == 0:
                    body.append(f'swap q[{a}],q[{b}];')
                else:
                    body.extend(encoded(a, b))
                body.append(f'u({0.1 + step * 0.07!r},-0.3,0.4) q[{a}];')
            body.append(f'cx q[{width - 1}],q[0];')
        else:
            for _ in range(8):
                a, b = rng.sample(range(width), 2)
                other = next((q for q in range(width) if q not in (a, b)), None)
                body.append(f'cx q[{a}],q[{b}];')
                body.append(f'{rng.choice(["s", "sdg", "x", "y"])} q[{a if kind == "commuting_cross_block" else b}];')
                if other is not None:
                    control = a if kind == 'commuting_cross_block' else b
                    body.append(f'cx q[{control}],q[{other}];')
                body.append(f'cx q[{a}],q[{b}];')
        yield {'case_id': f'{index:03d}_{kind}', 'kind': kind, 'width': width,
               'physical_width': width + (index % 3 == 0),
               'qasm': f'OPENQASM 2.0; include "qelib1.inc"; qreg q[{width}];\n' + '\n'.join(body) + '\n'}


class Worker:
    def __init__(self, binary, stderr):
        self.process = subprocess.Popen([str(binary)], stdin=subprocess.PIPE,
                                        stdout=subprocess.PIPE, stderr=stderr, text=True)
        assert self.read().get('ready') is True

    def read(self):
        with selectors.DefaultSelector() as selector:
            selector.register(self.process.stdout, selectors.EVENT_READ)
            if not selector.select(30):
                raise TimeoutError('compiler response exceeded 30 seconds')
        line = self.process.stdout.readline()
        if not line:
            raise RuntimeError('compiler exited without a response')
        return json.loads(line)

    def compile(self, request):
        self.process.stdin.write(json.dumps(request) + '\n')
        self.process.stdin.flush()
        return self.read()

    def close(self):
        self.process.stdin.close()
        try:
            self.process.wait(timeout=5)
        except subprocess.TimeoutExpired:
            self.process.terminate()
            self.process.wait(timeout=5)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--repo', type=Path, required=True)
    parser.add_argument('--runner', type=Path, required=True)
    parser.add_argument('--baseline', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    parser.add_argument('--replay-records', type=Path)
    args = parser.parse_args()
    args.output.mkdir(parents=True, exist_ok=False)
    sys.path.insert(0, str(args.repo.resolve() / 'experiments'))
    import comparison_validation as oracle
    started = time.time()
    provenance = {'schema': 1, 'seed': 202610180731,
                  'purpose': 'full-isometry correctness fuzz; compile_ns are diagnostic only',
                  'oracle_normalization': 'remove identity barrier statements only; restrict hardware edges to declared output wire range',
                  'script_sha256': digest(__file__), 'oracle_sha256': digest(oracle.__file__),
                  'runners': {name: {'path': str(path.resolve()), 'sha256': digest(path)}
                              for name, path in [('baseline', args.baseline), ('current', args.runner)]},
                  'source_hashes': {name: digest(args.repo / name) for name in [
                      'src/transpiler/encoded_swaps.rs', 'src/transpiler/clifford_simplification.rs',
                      'src/transpiler/optimization.rs', 'src/transpiler/mod.rs']}}
    replay = None
    if args.replay_records:
        provenance['replay_records_sha256'] = digest(args.replay_records)
        replay_rows = [json.loads(line) for line in args.replay_records.read_text().splitlines()]
        replay = {(row['case_id'], row['topology'], row['compiler']): row for row in replay_rows}
        assert len(replay) == len(replay_rows) == 256
    (args.output / 'provenance.json').write_text(json.dumps(provenance, indent=2) + '\n')
    rows = []
    failures = []
    workers = {}
    logs = {}
    try:
        if replay is None:
            for name, path in [('baseline', args.baseline), ('current', args.runner)]:
                logs[name] = (args.output / f'{name}.stderr.log').open('x')
                workers[name] = Worker(path.resolve(), logs[name])
        with (args.output / 'records.jsonl').open('x') as records:
            for fixture in fixtures():
                for topology in ('all_to_all', 'linear'):
                    width = fixture['physical_width']
                    edges = ([(q, q + 1) for q in range(width - 1)] if topology == 'linear'
                             else [(a, b) for a in range(width) for b in range(a + 1, width)])
                    request = {'qasm': fixture['qasm'], 'n_logical': fixture['width'],
                               'physical_width': width, 'topology': topology, 'edges': edges,
                               'encoded_swap_recognition': True, 'clifford_simplification': True}
                    allowed = edges + [(b, a) for a, b in edges]
                    for compiler in ('baseline', 'current'):
                        if replay is not None:
                            old = replay[fixture['case_id'], topology, compiler]
                            assert old['request'] == json.loads(json.dumps(request)), 'Replay request changed'
                            result = old['result']
                        else:
                            result = workers[compiler].compile(request)
                        row = {'case_id': fixture['case_id'], 'kind': fixture['kind'],
                               'topology': topology, 'compiler': compiler,
                               'request': request, 'result': result}
                        if result.get('status') != 'compiled':
                            row['validation'] = {'passed': False, 'error': 'compilation failed'}
                        else:
                            assert fixture['width'] <= result['output_qubits'] <= width
                            output_edges = [(a, b) for a, b in allowed if max(a, b) < result['output_qubits']]
                            kwargs = dict(n_logical=fixture['width'], physical_width=result['output_qubits'],
                                          edges=output_edges, initial_layout=result['initial_layout'],
                                          final_layout=result['final_layout'])
                            row['validation'] = oracle.validate_output(unitary_qasm(fixture['qasm']), unitary_qasm(result['out_qasm']), **kwargs)
                            # The full-isometry check must reject an extra output
                            # relative phase, even if zero-input probabilities agree.
                            if compiler == 'current':
                                altered = result['out_qasm'] + f'\nu(0,0,pi) q[{result["final_layout"][0]}];\n'
                                negative = oracle.validate_output(unitary_qasm(fixture['qasm']), unitary_qasm(altered), **kwargs)
                                row['relative_phase_negative'] = negative
                                if not (negative.get('passed') is False
                                        and negative.get('evidence_class') == 'full_isometry'
                                        and negative.get('basis_legal') is True
                                        and negative.get('coupling_legal') is True
                                        and negative.get('max_input_residual', 0) > 1.0):
                                    failures.append([fixture['case_id'], topology, compiler, 'negative control accepted'])
                        if row['validation'].get('passed') is not True:
                            failures.append([fixture['case_id'], topology, compiler, 'positive check failed'])
                        records.write(json.dumps(row, sort_keys=True) + '\n')
                        records.flush()
                        rows.append(row)
    finally:
        for worker in workers.values():
            worker.close()
        for log in logs.values():
            log.close()
    assert len(rows) == 256
    for name, path in [('baseline', args.baseline), ('current', args.runner)]:
        assert digest(path) == provenance['runners'][name]['sha256'], 'Runner changed during fuzzing'
    assert digest(oracle.__file__) == provenance['oracle_sha256'], 'Oracle changed during fuzzing'
    summary = {'schema': 1, 'passed': not failures, 'fixtures': 64, 'topologies': 2,
               'compiled_outputs': len(rows), 'complete_isometry_checks': sum(r['validation'].get('evidence_class') == 'full_isometry' for r in rows),
               'relative_phase_negative_controls': sum('relative_phase_negative' in r for r in rows),
               'maximum_input_residual': max(r['validation'].get('max_input_residual', 0) for r in rows),
               'maximum_ancilla_leakage_probability': max(r['validation'].get('max_ancilla_leakage_probability', 0) for r in rows),
               'failures': failures, 'elapsed_seconds': time.time() - started,
               'records_sha256': digest(args.output / 'records.jsonl'),
               'provenance_sha256': digest(args.output / 'provenance.json')}
    (args.output / 'summary.json').write_text(json.dumps(summary, indent=2) + '\n')
    print(json.dumps(summary, indent=2))
    if failures:
        raise SystemExit(1)


if __name__ == '__main__':
    main()
