"""Untimed independent isometry and final-cost checks of retained candidates.

Each of the preserved 64 generated fixtures is compiled on two graph families
by the previous frozen compiler and the candidate with cross-Clifford enabled
and disabled. Only the candidate's two branches form the nonregression test.
All requests, outputs, maps, validation receipts and source versions are kept.
"""
from __future__ import annotations

import argparse
import hashlib
import importlib.util
import json
from pathlib import Path
import re
import sys


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def dump(path, value):
    with path.open('x') as stream:
        json.dump(value, stream, indent=2, sort_keys=True, allow_nan=False)
        stream.write('\n')


def structural_cost(text, width, oracle, normalize):
    """Keep barrier scheduling even though the isometry oracle ignores identity fences."""
    declared, parsed = oracle.parse_qasm(normalize(text))
    assert declared == width
    gates = iter(parsed)
    total, two = [0] * width, [0] * width
    count = consumed = 0
    for statement in re.sub(r'//[^\n]*', '', text).split(';'):
        statement = statement.strip()
        if not statement or re.match(r'^(OPENQASM|include|qreg|creg)\b', statement):
            continue
        if statement.startswith('barrier '):
            args = statement.removeprefix('barrier ').split(',')
            wires = []
            for arg in args:
                arg = arg.strip()
                if arg == 'q':
                    wires.extend(range(width))
                else:
                    match = re.fullmatch(r'q\[(\d+)\]', arg)
                    assert match, 'Unsupported output barrier operand'
                    wires.append(int(match[1]))
            assert len(set(wires)) == len(wires) and all(q < width for q in wires)
            for frontier in (total, two):
                layer = max((frontier[q] for q in wires), default=0)
                for q in wires:
                    frontier[q] = layer
        else:
            gate = next(gates)
            consumed += 1
            layer = 1 + max(total[q] for q in gate.qubits)
            for q in gate.qubits:
                total[q] = layer
            if len(gate.qubits) == 2:
                count += 1
                layer = 1 + max(two[q] for q in gate.qubits)
                for q in gate.qubits:
                    two[q] = layer
    assert consumed == len(parsed)
    return [count, max(total), max(two)]


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    for key in ('repo', 'fixtures', 'previous', 'candidate', 'output'):
        parser.add_argument('--' + key, type=Path, required=True)
    a = parser.parse_args()
    a.output.mkdir(parents=True, exist_ok=False)
    versions = a.output / 'source_version'
    versions.mkdir()
    sys.path.insert(0, str(a.repo.resolve() / 'experiments'))
    import comparison_validation as oracle
    spec = importlib.util.spec_from_file_location('retained_fuzz_fixture_generator', a.fixtures)
    generator = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(generator)
    paths = {'driver.py': Path(__file__), 'fixtures.py': a.fixtures,
             'comparison_validation.py': Path(oracle.__file__)}
    paths.update({name: a.repo / 'src/transpiler' / name for name in
                  ['mod.rs', 'clifford_simplification.rs', 'encoded_swaps.rs',
                   'candidate_selection.rs', 'numerical_policy.rs',
                   'block_synthesis.rs', 'report.rs']})
    paths['comparison_runner.rs'] = a.repo / 'experiments/src/bin/comparison_runner.rs'
    for name, path in paths.items():
        with (versions / name).open('xb') as stream:
            stream.write(path.read_bytes())
    provenance = {'schema': 1, 'scope': __doc__, 'sources': {n: sha(p) for n, p in paths.items()},
                  'binaries': {n: {'path': str(p.resolve()), 'sha256': sha(p)}
                               for n, p in [('previous', a.previous), ('candidate', a.candidate)]},
                  'oracle_normalization': 'Remove identity barriers only; retain original requests/QASM and bound all maps to actual output width.'}
    dump(a.output / 'provenance.json', provenance)
    failures, rows, comparisons = [], [], []
    logs, workers = {}, {}
    try:
        for name, path in [('previous', a.previous), ('candidate', a.candidate)]:
            logs[name] = (a.output / f'{name}.stderr.log').open('x')
            workers[name] = generator.Worker(path.resolve(), logs[name])
        with (a.output / 'records.jsonl').open('x') as stream:
            for fixture in generator.fixtures():
                for topology in ('all_to_all', 'line'):
                    width = fixture['physical_width']
                    edges = ([(q, q + 1) for q in range(width - 1)] if topology == 'line'
                             else [(q, r) for q in range(width) for r in range(q + 1, width)])
                    request = dict(qasm=fixture['qasm'], n_logical=fixture['width'],
                                   physical_width=width, topology=topology, edges=edges,
                                   encoded_swap_recognition=True, clifford_simplification=True)
                    case = {}
                    for role in ('previous', 'candidate_cross_off', 'candidate'):
                        current = dict(request, clifford_simplification=role != 'candidate_cross_off')
                        result = workers['previous' if role == 'previous' else 'candidate'].compile(current)
                        assert result['status'] == 'compiled', result
                        actual_width = result['output_qubits']
                        assert fixture['width'] <= actual_width <= width
                        for layout in (result['initial_layout'], result['final_layout']):
                            assert len(layout) == fixture['width'] and len(set(layout)) == len(layout)
                            assert all(type(q) is int and 0 <= q < actual_width for q in layout)
                        allowed = [(x, y) for q, r in edges for x, y in [(q, r), (r, q)]
                                   if max(x, y) < actual_width]
                        options = dict(n_logical=fixture['width'], physical_width=actual_width,
                                       edges=allowed, initial_layout=result['initial_layout'],
                                       final_layout=result['final_layout'])
                        original = generator.unitary_qasm(fixture['qasm'])
                        validation = oracle.validate_output(original, generator.unitary_qasm(result['out_qasm']), **options)
                        row = dict(case_id=fixture['case_id'], topology=topology, role=role,
                                   request=current, result=result, validation=validation,
                                   structural_cost=structural_cost(result['out_qasm'], actual_width,
                                                                   oracle, generator.unitary_qasm))
                        if not (validation['passed'] and validation.get('evidence_class') == 'full_isometry'):
                            failures.append([fixture['case_id'], topology, role, 'positive equivalence'])
                        if role == 'candidate':
                            mutated = result['out_qasm'] + f'\nu(0,0,pi) q[{result["final_layout"][0]}];\n'
                            negative = oracle.validate_output(original, generator.unitary_qasm(mutated), **options)
                            row['relative_phase_negative'] = negative
                            if not (negative.get('passed') is False and negative.get('evidence_class') == 'full_isometry'
                                    and negative.get('basis_legal') and negative.get('coupling_legal')
                                    and negative.get('max_input_residual', 0) > 1.0):
                                failures.append([fixture['case_id'], topology, role, 'negative control'])
                        stream.write(json.dumps(row, sort_keys=True, allow_nan=False) + '\n')
                        stream.flush()
                        rows.append(row)
                        case[role] = row
                    costs = {role: case[role]['structural_cost']
                             for role in ('candidate', 'candidate_cross_off')}
                    guard = case['candidate']['result'].get('clifford_retention_stats')
                    selected_stats = case['candidate']['result'].get('clifford_simplification_stats') or {}
                    if selected_stats.get('rewrites', 0) > 0 and guard is None:
                        failures.append([fixture['case_id'], topology, 'selected rewrite has no retention comparison'])
                    comparison = dict(case_id=fixture['case_id'], topology=topology,
                                      costs=costs, retention=guard)
                    if guard is not None:
                        if guard['retained_compilation_failed']:
                            failures.append([fixture['case_id'], topology, 'retained compilation failed'])
                        if guard['selected_output_cost'] != costs['candidate'] or guard['retained_output_cost'] != costs['candidate_cross_off']:
                            failures.append([fixture['case_id'], topology, 'reported final cost mismatch'])
                        if not all(x <= y for x, y in zip(costs['candidate'], costs['candidate_cross_off'])):
                            failures.append([fixture['case_id'], topology, 'final Pareto regression'])
                        if guard['selected_retained_input']:
                            equal = {key: case['candidate']['result'][key] == case['candidate_cross_off']['result'][key]
                                     for key in ['out_qasm', 'initial_layout', 'final_layout', 'numerical_budget',
                                                 'two_qubit_block_stats', 'post_block_fusion_stats']}
                            comparison['selected_branch_equal'] = equal
                            if not all(equal.values()):
                                failures.append([fixture['case_id'], topology, 'selected branch metadata mismatch'])
                    comparisons.append(comparison)
    finally:
        for worker in workers.values():
            worker.close()
        for stream in logs.values():
            stream.close()
    assert len(rows) == 384 and len(comparisons) == 128
    for name, path in [('previous', a.previous), ('candidate', a.candidate)]:
        assert sha(path) == provenance['binaries'][name]['sha256']
    assert sha(oracle.__file__) == provenance['sources']['comparison_validation.py']
    dump(a.output / 'comparisons.json', comparisons)
    summary = {'schema': 1, 'passed': not failures, 'fixtures': 64, 'topologies': 2,
               'compiled_outputs': len(rows), 'full_isometry_checks': len(rows),
               'relative_phase_negative_controls': 128,
               'retention_comparisons': sum(r['retention'] is not None for r in comparisons),
               'selected_retained_inputs': sum(bool(r['retention'] and r['retention']['selected_retained_input']) for r in comparisons),
               'maximum_input_residual': max(r['validation'].get('max_input_residual', 0) for r in rows),
               'failures': failures, 'records_sha256': sha(a.output / 'records.jsonl'),
               'comparisons_sha256': sha(a.output / 'comparisons.json'),
               'provenance_sha256': sha(a.output / 'provenance.json')}
    dump(a.output / 'summary.json', summary)
    print(json.dumps(summary, indent=2))
    if failures:
        raise SystemExit(1)


if __name__ == '__main__':
    main()
