import copy
import unittest
from result_parity import compare_results


class ResultParityTests(unittest.TestCase):
    def result(self):
        return {'status': 'compiled', 'compile_ns': 10, 'parse_ns': 1, 'pass_diagnostics': [],
                'out_qasm': 'cx q[0],q[1];', 'initial_layout': [0, 1], 'final_layout': [1, 0],
                'numerical_budget': {'residual_sum': 1e-14},
                'clifford_retention_stats': {'selected_retained_input': True}}

    def test_only_three_diagnostic_values_may_change(self):
        a = self.result(); b = copy.deepcopy(a)
        b.update(compile_ns=500, parse_ns=7, pass_diagnostics=[{'elapsed_ns': 9}])
        self.assertTrue(compare_results(a, b)['passed'])

    def test_maps_qasm_ledger_and_selected_stats_are_exact(self):
        for key, value in [('out_qasm', 'cx q[1],q[0];'), ('final_layout', [0, 1]),
                           ('numerical_budget', {'residual_sum': 1.1e-14}),
                           ('clifford_retention_stats', {'selected_retained_input': False})]:
            with self.subTest(key=key):
                a = self.result(); b = {**a, key: value}
                verdict = compare_results(a, b)
                self.assertFalse(verdict['passed']); self.assertEqual(verdict['changed_fields'], [key])

    def test_new_metadata_and_missing_metadata_fail(self):
        a = self.result(); b = {**a, 'new_stats': 1}
        self.assertFalse(compare_results(a, b)['passed'])
        del b['new_stats']; del b['numerical_budget']
        self.assertFalse(compare_results(a, b)['passed'])

    def test_diagnostic_field_presence_and_types_remain_required(self):
        for key, value in [('compile_ns', 0), ('parse_ns', -1), ('pass_diagnostics', None)]:
            with self.subTest(key=key):
                a = self.result(); b = {**a, key: value}
                self.assertFalse(compare_results(a, b)['passed'])
                del b[key]
                self.assertFalse(compare_results(a, b)['passed'])

    def test_noncompiled_or_nonobject_fails(self):
        self.assertFalse(compare_results(self.result(), {'status': 'error'})['passed'])
        self.assertFalse(compare_results(self.result(), None)['passed'])


if __name__ == '__main__':
    unittest.main()
