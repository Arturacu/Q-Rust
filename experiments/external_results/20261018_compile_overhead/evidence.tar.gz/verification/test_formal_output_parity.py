import hashlib
import json
import unittest

from result_parity import compare_results
from verify_formal_output_parity import compare_native_rows, index_rows, unique_object


class FormalOutputParityTests(unittest.TestCase):
    def row(self):
        qasm = 'cx q[0],q[1];'
        return {'case_id': 'a', 'tool': 'qrust', 'trial': 0, 'seed': 7,
                'session': 1, 'status': 'compiled', 'compile_ns': 10,
                'parse_ns': 1, 'pass_diagnostics': [], 'out_qasm': qasm,
                'output_sha256': hashlib.sha256(qasm.encode()).hexdigest(),
                'final_layout': [0, 1], 'request_wall_ns': 20}

    def test_transport_measurements_are_not_native_result_fields(self):
        a = self.row()
        b = dict(a, request_wall_ns=500, sampled_worker_rss_bytes=1000,
                 compile_ns=100, parse_ns=2, pass_diagnostics=[{'ns': 5}])
        self.assertTrue(compare_native_rows(a, b)['passed'])

    def test_qasm_hash_mismatch_is_detected(self):
        a = self.row()
        b = dict(a, output_sha256='0' * 64)
        self.assertFalse(compare_native_rows(a, b)['passed'])

    def test_native_fields_cannot_be_hidden_by_envelope(self):
        a = self.row()
        for b in [dict(a, final_layout=[1, 0]), dict(a, new_field=True)]:
            self.assertFalse(compare_native_rows(a, b)['passed'])

    def test_schedule_identity_distinguishes_seeds_and_phases(self):
        a = self.row()
        b = dict(a, seed=8)
        c = dict(a, phase='replacement_warmup')
        self.assertEqual(len(index_rows([(a, 'timed'), (b, 'timed'), (c, 'timed')])), 3)
        with self.assertRaises(ValueError):
            index_rows([(a, 'timed'), (dict(a), 'timed')])

    def test_duplicate_json_keys_are_rejected(self):
        with self.assertRaises(ValueError):
            json.loads('{"compile_ns":1,"compile_ns":2}', object_pairs_hook=unique_object)

    def test_enclosing_session_is_bound(self):
        a = self.row()
        slots = {('a', 0, 7, 'timed'): 4}
        for session in [2, True, None]:
            with self.subTest(session=session), self.assertRaises(ValueError):
                index_rows([(dict(a, session=session), 'timed')], session=1,
                           expected_slots=slots)
        self.assertEqual(len(index_rows([(a, 'timed')], session=1,
                                        expected_slots=slots)), 1)

    def test_matched_primary_slot_is_bound(self):
        a = dict(self.row(), phase='timed', schedule_index=4)
        slots = {('a', 0, 7, 'timed'): 4}
        self.assertEqual(len(index_rows([(a, None)], session=1,
                                        expected_slots=slots, matched=True)), 1)
        for slot in [3, None, True]:
            with self.subTest(slot=slot), self.assertRaises(ValueError):
                index_rows([(dict(a, schedule_index=slot), None)], session=1,
                           expected_slots=slots, matched=True)
        with self.assertRaises(ValueError):
            index_rows([(a, 'timed')], session=1, expected_slots=slots)

    def test_boolean_seed_or_trial_cannot_alias_integer_identity(self):
        for key in ['seed', 'trial']:
            with self.subTest(key=key), self.assertRaises(ValueError):
                index_rows([(dict(self.row(), **{key: True}), 'timed')])


if __name__ == '__main__':
    unittest.main()
