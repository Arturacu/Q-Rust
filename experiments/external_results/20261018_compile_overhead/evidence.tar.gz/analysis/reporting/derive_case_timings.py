#!/usr/bin/env python3
"""Retain every eligible per-case old/new timing ratio, including slowdowns."""
import argparse
import hashlib
import json
from pathlib import Path


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def derive(analysis):
    path = analysis / 'summary.json'
    summary = json.loads(path.read_text())
    output = {
        'schema': 1, 'analysis_summary_sha256': sha(path),
        'source_sha256': sha(Path(__file__)),
        'method': 'Each session is reported separately. Ratios are candidate / previous per-case medians. Each suite uses exactly the old/new Q-Rust cases eligible in both sessions, requiring all warmups and trials to pass. Ratios >1 are retained as observed slowdowns without an added significance claim. Compiler time and complete request wall time are separate metrics. All cell metric summaries are retained; no pooled session samples or selective successful trials. The sum-of-medians calculation describes one occurrence of each eligible case; it is not a measured batch wall time and does not include startup, scheduling or inter-request overhead. It weights cases by absolute duration, unlike a geometric mean of relative per-case changes.',
        'suites': {},
    }
    for suite, suite_summary in summary['suites'].items():
        sessions = {s: {(c['variant'], c['case_id'], c['tool']): c
                        for c in suite_summary['sessions'][s]['cells']}
                    for s in ['1', '2']}
        case_ids = sorted({c['case_id'] for c in suite_summary['sessions']['1']['cells']
                           if c['tool'] == 'qrust'})
        cohort = [case for case in case_ids if all(
            sessions[s][variant, case, 'qrust']['eligible']
            for s in sessions for variant in ['control', 'primary'])]
        result = {'stable_old_new_cohort': cohort, 'excluded_cases': sorted(set(case_ids) - set(cohort)),
                  'sessions': {}}
        for session, indexed in sessions.items():
            cases = []
            counts = {name: {'candidate_faster': 0, 'equal': 0, 'candidate_slower': 0}
                      for name in ['compile_ns', 'request_wall_ns']}
            for case_id in cohort:
                a = indexed['control', case_id, 'qrust']
                b = indexed['primary', case_id, 'qrust']
                ratios = {}
                for name in ['compile_ns', 'parse_ns', 'request_wall_ns']:
                    old, new = a['metrics'][name]['median'], b['metrics'][name]['median']
                    ratios[name] = new / old if old else None
                    if name in counts:
                        key = 'candidate_faster' if new < old else 'candidate_slower' if new > old else 'equal'
                        counts[name][key] += 1
                cases.append({'case_id': case_id, 'candidate_over_previous': ratios,
                              'previous_metrics': a['metrics'], 'candidate_metrics': b['metrics']})
            totals = {}
            for name in ['compile_ns', 'parse_ns', 'request_wall_ns']:
                old = sum(c['previous_metrics'][name]['median'] for c in cases)
                new = sum(c['candidate_metrics'][name]['median'] for c in cases)
                totals[name] = {'previous_sum_ns': old, 'candidate_sum_ns': new,
                                'candidate_over_previous': new / old if old else None}
            result['sessions'][session] = {'observed_median_comparisons': counts,
                'one_per_case_sums_of_medians_not_measured_batch': totals, 'cases': cases}
        output['suites'][suite] = result
    return output


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--analysis', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    report = derive(args.analysis)
    with args.output.open('x') as stream:
        json.dump(report, stream, indent=2, sort_keys=True)
        stream.write('\n')
    print(json.dumps({suite: result['sessions'] and len(result['stable_old_new_cohort'])
                      for suite, result in report['suites'].items()}))


if __name__ == '__main__':
    main()
