#!/usr/bin/env python3
"""Render the measured tables and their fixed interpretation for review."""
import argparse
import json
from pathlib import Path

p=argparse.ArgumentParser();p.add_argument('--evidence-root',type=Path,required=True);p.add_argument('--output',type=Path,required=True);a=p.parse_args()
b=a.evidence_root;m=json.loads((b/'analysis/reporting/report_metrics.json').read_text());c=json.loads((b/'analysis/reporting/case_timings.json').read_text())
parts=[]
def add(s):parts.append(s.strip())
def table(headers,rows):
 add('| '+' | '.join(headers)+' |\n|'+'|'.join(['---']*len(headers))+'|\n'+'\n'.join('| '+' | '.join(map(str,row))+' |' for row in rows))
add('''# Reducing compilation overhead while retaining circuit outputs

The compiler removes repeated routing searches for identical prepared inputs and avoids repeated work in the Clifford pass. All 1,664 formal old/new Q-Rust response pairs have identical native results apart from compiler time, parser time and pass diagnostics: emitted QASM, maps, numerical ledgers, selected statistics and retention results are unchanged. This preserves the circuit improvements in [the preceding quality followup](CLIFFORD_QUALITY_RETENTION.md).

Across the 100 external cases, the geometric mean of per-case compile-time ratios is 0.9394 / 0.9372 in sessions 1 / 2, or 6.1% / 6.3% lower. Across the eight matched cases it is 0.7338 / 0.7373, or 26.6% / 26.3% lower. These are equal-weight relative changes per circuit, not a claim of that much less total time for a batch. The two dense 20-qubit cases dominate absolute matched compilation time and barely improve. Summing one compile median per case gives only 1.5% / 0.8% less matched time. These sums are descriptive calculations, not measured batch wall times.

Speed ratios compare the configured compiler pipelines on this arm64 macOS host. They do not causally measure Rust versus Python or establish universal compiler rankings.

## Paired results and unchanged circuit costs

Ratios below are candidate / previous. Each session uses the same stable old/new verified cohort; every timed result and warmup must pass. Sessions are not pooled.''')
rows=[]
for suite,label in [('external','External, 100 cases'),('matched','Matched, 8 cases')]:
 for s in ['1','2']:
  x=m['suites'][suite]['sessions'][s]['old_new_qrust']['metrics'];z=c['suites'][suite]['sessions'][s];t=z['one_per_case_sums_of_medians_not_measured_batch']
  rows.append([label,s,f"{x['compile_ns']['geomean']:.4f}",f"{x['request_wall_ns']['geomean']:.4f}",f"{t['compile_ns']['previous_sum_ns']/1e6:.3f} → {t['compile_ns']['candidate_sum_ns']/1e6:.3f}",f"{t['compile_ns']['candidate_over_previous']:.4f}"])
table(['Cohort','Session','Compile geometric ratio','Request-wall geometric ratio','Sum of compile medians, ms','Ratio of those sums'],rows)
add('''A geometric mean gives each relative case change equal weight. A ratio of sums weights long cases by their absolute durations. Neither includes cold startup or measures the wall time of compiling a batch. The immediate previous repository baseline verifies all eight matched cases; the six-case old/new cohort in the earlier report used a different baseline and must not be combined with these ratios.

Every CX count, total gate count, total depth and two-qubit depth is unchanged in the old/new formal comparisons. The retained anchors are:''')
table(['Circuit / target','CX','Total depth','Two-qubit depth','Total gates'],[
 ['EC-5 / complete',9,11,6,26],['EC-5 / line',17,19,12,39],['QEC encoder-5 / complete',8,10,8,14],['QEC encoder-5 / line',20,21,16,32]])
add('''The earlier QEC encoder trade-off remains: its line output has 21 total-depth layers and 16 two-qubit-depth layers. This runtime change does not alter that choice or remove its previously documented extra total-depth layer.

The following per-case medians retain small changes and slowdowns. Complete request wall time includes parsing, serialization, diagnostics and IPC as well as compilation. It is measured using the existing warm workers, not a cold command invocation.''')
selected=[('external','qasmbench__error_correctiond3_n5__all_to_all','EC-5 complete'),('external','qasmbench__error_correctiond3_n5__linear','EC-5 line'),('external','qasmbench__qec_en_n5__all_to_all','QEC encoder-5 complete'),('external','qasmbench__qec_en_n5__linear','QEC encoder-5 line'),('external','mqtbench__ae_n10__linear','AE-10 line'),('external','mqtbench__qpeexact_n10__linear','QPE-10 line'),('external','mqtbench__qpeexact_n5__all_to_all','QPE-5 complete'),('external','qasmbench__basis_trotter_n4__linear','Trotter-4 line')]
selected += [('matched',case,case.replace('_',' ')) for case in c['suites']['matched']['stable_old_new_cohort']]
rows=[]
for suite,case,label in selected:
 vals=[next(v for v in c['suites'][suite]['sessions'][s]['cases'] if v['case_id']==case) for s in ['1','2']]
 rows.append([label,*[f"{v['previous_metrics']['compile_ns']['median']/1e6:.3f} → {v['candidate_metrics']['compile_ns']['median']/1e6:.3f}" for v in vals], ' / '.join(f"{v['candidate_over_previous']['compile_ns']:.4f}" for v in vals),' / '.join(f"{v['candidate_over_previous']['request_wall_ns']:.4f}" for v in vals)])
table(['Case','Compile ms, S1 previous → candidate','Compile ms, S2 previous → candidate','Compile ratio, S1 / S2','Request-wall ratio, S1 / S2'],rows)
add('''External compile medians are higher on 54/100 cases in session 1 and 46/100 in session 2; complete request-wall medians are higher on 52 and 43 cases, with two ties in session 2. The largest external observed compile increases are 7.0% and 7.5% on different small cases. Matched compile/request-wall medians are higher on one case in each session: cat22 heavy-hex in session 1 and dense Clifford20 heavy-hex in session 2. These counts retain measurement variability and do not assert statistical significance for small per-case shifts. Every case, including slowdowns, is retained in `analysis/reporting/case_timings.json`.

## Why work was removed, and what still costs time

The previous quality-preserving pipeline compiled retained alternatives independently, sometimes repeating layout and routing on exactly the same prepared circuit. The new reuse key compares complete prepared circuit data and the routing context, including exact parameter representations. A compilation keeps at most four routing checkpoints. A reused checkpoint supplies routed output, maps and routing alternatives, while the new branch retains its own prefix metadata, logical permutation and numerical ledger. Each distinct lowering still runs and validates independently. Immutable checkpoint outputs are cloned into branch-owned state; this removes repeated searches, not all allocations. The new routing store exists only within one compilation. Existing Clifford lookup caches already persist in a warm worker and are present in both versions.

The Clifford pass reuses scratch storage for transported signed-Pauli data across endpoint searches, scores the same cost while projecting extracted wire permutations directly, and folds the edited operation stream without an intermediate deep clone. The transport data are cleared and recomputed; sharing that information across cuts was already present in the previous compiler. Final immutable candidate cost is computed lazily once and reused without changing selection ordering. Search bounds, candidate order, fences and acceptance semantics remain unchanged. Regression comparisons exercise the old and new scoring/folding implementations, including cuts, metadata and unsupported-operation fences.

The bounded diagnostic study uses 14 cases, three repetitions per profile mode and one warmup per mode: 112 requests each for the previous compiler, a pass-only variant and the final compiler. These runs occur separately from formal timing. All final diagnostic outputs verify, and all 112 native responses match the previous responses under the same three diagnostic exclusions. The traces show layout/routing call counts changing from 2 to 1 for AE-10 line, cat/GHZ square and both BV100 targets; from 4 to 2 for Trotter-4 line; and from 4 to 3 for EC complete. Explicit `ReuseRoutingCheckpoint` records replace the removed searches. EC line and both QEC cases retain two genuinely distinct routing calls, so they retain substantial route/lowering cost. The dense-20 cases were not included in this targeted profile study; their formal runtimes remain the dominant matched cost.

Summed diagnostic Clifford-pass medians fall from 9.10 to 3.55 ms on BV100 square, 21.69 to 7.70 ms on BV100 heavy-hex, and 6.85 to 2.58 ms on Trotter-4 line. Profile sums include retained and alternate paths and do not partition total compilation time. The separate diagnostic ablation timings are not controlled end-to-end causal estimates; the formal adjacent old/new requests above measure the combined change.

## Contemporaneous SDK comparisons

The unchanged external primary and light comparison cohorts each contain all 100 cases. Compiler/request speed ratios below are SDK / Q-Rust; output-cost ratios are Q-Rust / SDK. Values are geometric means of per-case medians. Both sessions have identical displayed quality ratios.''')
rows=[]
for profile,tool,label in [('primary','qiskit','Qiskit'),('primary','cirq','Cirq'),('primary','tket','TKET'),('light','cirq_one_pass','Cirq, one pass'),('light','tket_light','TKET, light')]:
 vals=[m['suites']['external']['sessions'][s]['sdk_common_cohort'][profile]['comparisons'][tool] for s in ['1','2']]
 rows.append([label,*[' / '.join(f"{v['speedup_baseline_over_qrust'][k]['geomean']:.3f}" for v in vals) for k in ['compile_ns','request_wall_ns']],*[f"{vals[0]['output_cost_qrust_over_baseline'][k]['geomean']:.4f}" for k in ['cx_count','depth','two_q_depth']]])
table(['Recipe','Compile ratio, S1 / S2','Request-wall ratio, S1 / S2','CX ratio','Depth ratio','Two-qubit-depth ratio'],rows)
add('''Two zero-CX/two-qubit-depth cases are excluded from the corresponding external geometric ratios and counted explicitly; no pseudocounts are used. All 100 cases remain in timing and total-depth ratios. Aggregate cost ratios do not imply Q-Rust wins every circuit: for example, Qiskit has fewer CX on seven external cases and TKET on six. The unchanged 2,000-draw external bootstrap analysis and its session-agreement results are retained in full.

The stable four-tool matched cohort still contains only the four cat/GHZ cases. It must not be reported as a verified four-tool comparison of all eight cases.''')
rows=[]
for tool,label in [('qiskit','Qiskit'),('cirq','Cirq'),('tket','TKET')]:
 vals=[m['suites']['matched']['sessions'][s]['sdk_common_cohort']['primary']['comparisons'][tool] for s in ['1','2']]
 rows.append([label,*[' / '.join(f"{v['speedup_baseline_over_qrust'][k]['geomean']:.3f}" for v in vals) for k in ['compile_ns','request_wall_ns']],*[f"{vals[0]['output_cost_qrust_over_baseline'][k]['geomean']:.4f}" for k in ['cx_count','depth','two_q_depth']]])
table(['SDK, four cat/GHZ cases','Compile ratio, S1 / S2','Request-wall ratio, S1 / S2','CX ratio','Depth ratio','Two-qubit-depth ratio'],rows)
add('''Q-Rust uses more CX on all four matched common-cohort cases. Its external aggregate quality advantage does not extend to this cohort. On EC complete it retains 9 CX / 11 depth / 6 two-qubit depth, versus TKET's 9 / 13 / 7; on EC line it retains 17 / 19 / 12, versus TKET's 20 / 25 / 19. Complete per-SDK EC/QEC tables, including compilation time and all gate counts, are retained in `report_metrics.json`.

## Frozen protocol, correctness and limits

The 100-case QASMBench/MQT Bench suite retains six recipes, two sessions, seven timed trials and one initial warmup per cell. The matched extension retains eight circuits/targets, four tools, two sessions, three timed trials and one initial warmup. A previous Q-Rust request runs next to every candidate request; case/trial parity balances the order and session 2 reverses it. The frozen schedule contains 10,040 timed slots and 1,480 initial warmups. Six timed Cirq slots were blocked after failed warmups; scheduled slots are not all successful compilations. Sessions ran sequentially: external 1, external 2, matched 1, matched 2. No agent build, profiling, simulation, validation, compression or other benchmark session overlapped their timing.

The input, normalization, adapter, oracle, schedule, timeout and SDK recipe contracts are unchanged, including Qiskit 2.5.2, Cirq 1.7.0 and pytket 2.18.5. External requests have a 60-second timeout. Matched requests have a 30-second timeout and approximately 100 ms RSS observations enforcing 2 GiB per worker and 3 GiB across workers, including the previous Q-Rust worker. This is sampled limit enforcement, not exact peak memory, descendant accounting or evidence of a peak-memory improvement.

All 11,200 external records verify. In the matched extension, both Q-Rust binaries and TKET verify all eight cases. Qiskit has 32 unsupported-recognition records; Cirq has 24 unsupported-recognition records, two warmup timeouts and six blocked timed slots. These are retained, and unsupported recognition is not called incorrect. No definite semantic counterexample or structural violation was found. Every eligible cell requires all timed outputs and all initial/replacement warmups to pass.

The unchanged external oracle checks complete clean-ancilla isometries through six physical qubits, and eight independently selected inputs above that within its existing limit. Sampling does not prove arbitrary-input equivalence. The matched oracle checks map/ancilla-aware signed-Clifford Choi isometries after bounded numerical recognition of local Clifford matrices; unsupported recognition fails closed. Neither checker has been relaxed. Exact native-result parity is additional evidence: after checking output QASM hashes and binding row/session/schedule identities, all 1,448 timed and 216 warmup pairs match except `compile_ns`, `parse_ns` and `pass_diagnostics`. Scheduler/transport observations are retained separately and are not native compiler fields.

Before timing, the strict 100+8 preflight verifies both binaries and finds exact output parity and unchanged structural costs. Final independent fuzzing verifies 384 compiled outputs from 64 fixtures on two topologies, rejects 128 relative-phase negative controls, checks 91 retention decisions and confirms 128 additional old/new native result pairs. Final checks pass 494 Rust tests (four existing tests intentionally ignored), strict Clippy, formatting and all 249 Python tests with the frozen binary and no skips. Five strict-parity tests, eight formal-pair identity/parity tests, 14 canonical-replay fault-injection tests and nine packaging boundary tests pass.

## Provenance and evidence

The previous repository baseline is `ef9c3552752b819440fad54882f56a77582ba46a`; its timed compiler commit is `65e6c64a66d68da79799c9ea6a344553cb844cc4`, binary SHA-256 `3ae3dcdc258e8b96b41d552964c3863702e17e4112c6e864f13376d33efaf891`. The candidate compiler commit is `3306937c0ae71fb2eb78ad86141f2ccd1b636465`, binary SHA-256 `aa6513a05aa814b8b89cf373472cacaef4a0afa7c66a296d76a67ef4f4824e1e`. The frozen protocol binds 79 Rust/Cargo source files, all adapter/oracle hashes and both binaries. The preservation manifest binds 1,192 earlier files; earlier reports, raw records, protocols and archives remain byte-identical.

The archive retains the baseline/pass-only/final profiles, source/binary provenance, strict preflight, final fuzzing, formal responses, dispatch records and all diagnostics. The first baseline profile attempt omitted the wrapper's required QASM checksum and stopped in instrumentation after compilation; its records and log are preserved, and the corrected wrapper reran the entire study. That failed diagnostic attempt is not a compiler correctness failure or a formal timing result.

The result package is [external_results/20261018_compile_overhead](external_results/20261018_compile_overhead/), with [the evidence archive](external_results/20261018_compile_overhead/evidence.tar.gz) and [checksums](external_results/20261018_compile_overhead/checksums.json). The final campaign is `campaign_release/` locally and `campaign/` in the archive. Saved analysis and a fresh full-output replay agree after normalizing only newly measured `validation.validation_ns` values, preserving field presence and adjusting only their derived row hashes. Compiler/parser/request timings and all remaining evidence remain exact. Both reporting derivations reproduce byte-identical JSON; their receipts are in `analysis/reporting/`.

With the recorded Python dependencies, replay into new paths after extracting the archive:

```sh
python harness/experiments/paired_analysis.py --repo harness --campaign campaign --output replay_analysis
python scripts/canonical_replay.py --reference analysis --replay replay_analysis --output replay_receipt.json
python analysis/reporting/compute_metrics.py --analysis analysis --campaign campaign --output report_metrics_replay.json
python analysis/reporting/derive_case_timings.py --analysis analysis --output case_timings_replay.json
python verification/verify_formal_output_parity.py --campaign campaign --completion receipts/timing_completion.json --allow-relocated --output native_parity_replay.json
```

This reruns the existing matched Q-Rust extension. The earlier native Benchpress workout results remain unchanged; there is no native Q-Rust gym. The bounded Clifford workload, ideal targets and structural metrics do not establish noisy-device execution quality or general large non-Clifford correctness. The [Benchpress pilot](BENCHPRESS_PILOT.md) documents the separate native runs and their different correctness contract.''')
with a.output.open('x') as f:f.write('\n\n'.join(parts)+'\n')
