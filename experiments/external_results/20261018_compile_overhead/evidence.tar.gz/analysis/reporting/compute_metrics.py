#!/usr/bin/env python3
"""Derive per-session report tables from unchanged, checksum-bound analyses.

This reports descriptive paired ratios, not pooled session samples. External
SDK confidence intervals are retained from the original 2,000-draw analyzer.
Matched comparisons use the stable common verified cohort across both sessions.
"""
import argparse
from collections import Counter, defaultdict
import hashlib
import json
import math
from pathlib import Path
import statistics


QUALITY = ('cx_count', 'gate_count', 'depth', 'two_q_depth')
TIMING = ('compile_ns', 'parse_ns', 'request_wall_ns')


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def ratios(observations):
    positive, zeros = [], Counter(both_zero=0, numerator_zero=0, denominator_zero=0)
    for numerator, denominator in observations:
        if numerator == denominator == 0:
            zeros['both_zero'] += 1
        elif numerator == 0:
            zeros['numerator_zero'] += 1
        elif denominator == 0:
            zeros['denominator_zero'] += 1
        else:
            positive.append(numerator / denominator)
    return {'paired_cells': len(observations), 'positive_ratio_cells': len(positive), 'zero_cases': dict(zeros),
            'geomean': math.exp(statistics.mean(math.log(value) for value in positive)) if positive else None,
            'median_ratio': statistics.median(positive) if positive else None}


def compare_cells(left, right, names):
    # Left/right ratios with explicit definitions attached by the caller.
    result = {}
    for name in names:
        values = [(a['metrics'][name]['median'], b['metrics'][name]['median']) for a, b in zip(left, right)]
        result[name] = dict(ratios(values), lower_left=sum(a < b for a, b in values),
                            tie=sum(a == b for a, b in values), higher_left=sum(a > b for a, b in values))
    return result


def load_checked(analysis, suite, session, summary):
    path = analysis / f'{suite}_session_{session}.jsonl'
    if sha(path) != summary['suites'][suite]['sessions'][str(session)]['validated_rows_sha256']:
        raise ValueError('Analysis rows differ from summary')
    return [json.loads(line) for line in path.read_text().splitlines() if line.strip()]


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--analysis', type=Path, required=True)
    parser.add_argument('--campaign', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    args.analysis = args.analysis.resolve()
    campaign = args.campaign.resolve()
    summary_path = args.analysis / 'summary.json'
    summary = json.loads(summary_path.read_text())
    sdk_path = campaign / 'external/analysis/external_summary.json'
    sdk = json.loads(sdk_path.read_text())
    pair_path = campaign / 'paired_protocol.json'
    if summary['paired_protocol_sha256'] != sha(pair_path):
        raise ValueError('Paired summary does not bind protocol')
    result = {
        'schema': 1, 'source_sha256': sha(Path(__file__)),
        'analysis_summary_sha256': sha(summary_path), 'external_sdk_summary_sha256': sha(sdk_path),
        'paired_protocol_sha256': sha(pair_path),
        'method': 'Per-session medians only. Old/new comparisons use contemporaneous paired old-Q-Rust controls. Every eligible cell requires all timed trials and all warmups verified. Stable SDK cohorts intersect every compared recipe across both sessions. Geometric ratios exclude zero-valued numerator/denominator cells, counted explicitly; no pseudocounts. Sessions are not pooled. Descriptive ratios here have no added uncertainty claim; original external bootstrap output is retained separately.',
        'suites': {}, 'error_correction_tables': {}, 'qec_encoder_tables': {},
        'external_original_sdk_bootstrap': {'sessions': sdk['sessions'], 'session_agreement': sdk['session_agreement']},
    }
    for suite in ('external', 'matched'):
        protocol = json.loads((campaign / suite / 'protocol.json').read_text())
        if suite == 'external' and sdk['protocol_sha256'] != sha(campaign / suite / 'protocol.json'):
            raise ValueError('SDK analysis protocol mismatch')
        cohorts = {'primary': ['qrust', 'qiskit', 'cirq', 'tket']}
        if suite == 'external':
            cohorts['light'] = ['qrust', 'qiskit', 'cirq_one_pass', 'tket_light']
        indexed = {session: {(cell['variant'], cell['case_id'], cell['tool']): cell
                            for cell in summary['suites'][suite]['sessions'][str(session)]['cells']}
                   for session in (1, 2)}
        stable = {profile: sorted(case['id'] for case in protocol['cases']
                     if all(indexed[session]['primary', case['id'], tool]['eligible']
                            for session in (1, 2) for tool in tools))
                  for profile, tools in cohorts.items()}
        paired = sorted(case['id'] for case in protocol['cases'] if all(
            indexed[session][variant, case['id'], 'qrust']['eligible']
            for session in (1, 2) for variant in ('primary', 'control')))
        suite_result = {'counts': summary['suites'][suite]['counts'],
                        'evidence_classifications': summary['suites'][suite]['evidence_classifications'],
                        'stable_sdk_cohorts': stable, 'stable_old_new_qrust_cohort': paired,
                        'sessions': {}}
        for session in (1, 2):
            cells = indexed[session]
            checked = load_checked(args.analysis, suite, session, summary)
            session_result = {'old_new_qrust': {'cohort': paired, 'ratio_definition': 'new Q-Rust / old Q-Rust; >1 runtime means added cost, <1 output cost means improvement',
                'metrics': compare_cells([cells['primary', case, 'qrust'] for case in paired],
                                         [cells['control', case, 'qrust'] for case in paired], TIMING + QUALITY)},
                'sdk_common_cohort': {}, 'quality_differences': [],
                'nonpass_outcomes': dict(Counter(f"{row['variant']}:{row['tool']}:{row['observed_phase']}:{row['outcome']}"
                                                for row in checked if row['outcome'] != 'passed'))}
            for profile, tools in cohorts.items():
                ids = stable[profile]
                comparisons = {}
                for tool in tools[1:]:
                    qrust = [cells['primary', case, 'qrust'] for case in ids]
                    baseline = [cells['primary', case, tool] for case in ids]
                    comparisons[tool] = {'speedup_baseline_over_qrust': compare_cells(baseline, qrust, TIMING),
                                         'output_cost_qrust_over_baseline': compare_cells(qrust, baseline, QUALITY)}
                session_result['sdk_common_cohort'][profile] = {'cohort': ids, 'comparisons': comparisons}
            # Retain structural diagnostics even when the local-Clifford oracle
            # cannot recognize an output. These rows are explicitly ineligible
            # and never contribute to verified speed/quality aggregates above.
            raw_groups = defaultdict(list)
            for row in checked:
                if row['tool'] == 'qrust' and row['observed_phase'] == 'timed':
                    raw_groups[row['variant'], row['case_id']].append(row)
            for case in protocol['cases']:
                old, new = raw_groups['control', case['id']], raw_groups['primary', case['id']]
                if (len(old) != protocol['trials'] or len(new) != protocol['trials'] or
                        any('metrics' not in row.get('validation', {}) for row in old + new)):
                    continue
                values = {name: {'old': statistics.median(row['validation']['metrics'][name] for row in old),
                                 'new': statistics.median(row['validation']['metrics'][name] for row in new)} for name in QUALITY}
                for value in values.values():
                    value['delta'] = value['new'] - value['old']
                if any(value['delta'] for value in values.values()):
                    session_result['quality_differences'].append({'case_id': case['id'],
                        'eligible': cells['primary', case['id'], 'qrust']['eligible'] and cells['control', case['id'], 'qrust']['eligible'],
                        'classification_counts': dict(Counter(row['validation']['failure_classification'] for row in old + new)),
                        'metrics': values})
            suite_result['sessions'][str(session)] = session_result
            if suite == 'external':
                for table, family in [('error_correction_tables', 'error_correctiond3_n5'),
                                      ('qec_encoder_tables', 'qec_en_n5')]:
                    result[table][str(session)] = {}
                    for topology in ('all_to_all', 'linear'):
                        case_id = 'qasmbench__' + family + '__' + topology
                        rows = []
                        for variant, tool in [('control', 'qrust')] + [('primary', tool) for tool in protocol['tools']]:
                            cell = cells[variant, case_id, tool]
                            record = {'case_id': case_id, 'variant': variant, 'tool': tool, 'eligible': cell['eligible']}
                            if cell['eligible']:
                                record['median'] = {name: cell['metrics'][name]['median'] for name in TIMING + QUALITY}
                                record['compile_ms'] = cell['metrics']['compile_ns']['median'] / 1e6
                            rows.append(record)
                        result[table][str(session)][topology] = rows
        result['suites'][suite] = suite_result
    with args.output.open('x') as stream:
        json.dump(result, stream, indent=2, sort_keys=True, allow_nan=False)
        stream.write('\n')
    print(json.dumps({'report_metrics_sha256': sha(args.output),
        'common_cohort_sizes': {suite: {profile: len(ids) for profile, ids in data['stable_sdk_cohorts'].items()}
                                for suite, data in result['suites'].items()}}))


if __name__ == '__main__':
    main()
