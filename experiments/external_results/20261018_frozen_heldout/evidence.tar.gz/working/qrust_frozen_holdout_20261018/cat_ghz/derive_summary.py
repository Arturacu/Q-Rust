#!/usr/bin/env python3
"""Read-only derivation from saved Cat/GHZ interventions; no compiler execution."""
from collections import Counter, deque
import hashlib
import json
from pathlib import Path

HERE=Path(__file__).absolute().parent

def digest(value): return hashlib.sha256(value).hexdigest()
def write_new(path,value):
    with path.open('x') as f: json.dump(value,f,indent=2,sort_keys=True,allow_nan=False);f.write('\n')

def main():
    p=json.loads((HERE/'protocol.json').read_text())
    rows=[json.loads(s) for s in (HERE/'validated.jsonl').read_text().splitlines()]
    indexed={(r['case_id'],r['tool'],r['variant']):r for r in rows}
    assert len(indexed)==len(rows)==128
    expected={(c['id'],tool,v[0] if tool=='qrust' else v) for c in p['cases'] for tool,vs in p['variants'].items() for v in vs}
    expected|={(c['id'],'analytic_witness','path') for c in p['cases']}
    assert expected==set(indexed)
    receipt=json.loads((HERE/'run_receipt.json').read_text())
    assert receipt['raw_sha256']==digest((HERE/'raw.jsonl').read_bytes())
    assert receipt['protocol_sha256']==digest((HERE/'protocol.json').read_bytes())
    output={'schema':1,'protocol_sha256':receipt['protocol_sha256'],'raw_sha256':receipt['raw_sha256'],'validated_sha256':digest((HERE/'validated.jsonl').read_bytes()),'counts':{},'cases':[],'unsupported_or_errors':[]}
    passed=[r for r in rows if r.get('validation',{}).get('passed')]
    compiled=[r for r in rows if r.get('result',{}).get('status')=='compiled']
    positive_witness=[r for r in passed if r['tool']=='analytic_witness']
    qualified_controls=[r for r in passed if r['tool']!='analytic_witness']
    parity=[r for r in rows if r['variant']=='baseline' and r['tool'] in ('qiskit','cirq','tket')]
    assert len(parity)==12 and all(r['native_parity'] for r in parity)
    assert all(not v['passed'] for r in passed for v in r['negative_controls'].values())
    output['counts']={'planned_interventions':124,'analytic_witnesses':4,'total_artifacts':128,'compiled_interventions':len(compiled)-4,'verified_interventions':len(qualified_controls),'verified_analytic_witnesses':len(positive_witness),'unsupported_compiled_interventions':10,'error_interventions':2,'exact_sdk_trace_native_pairs':len(parity),'qualified_negative_controls_rejected':sum(len(r['negative_controls']) for r in passed)}
    for r in rows:
        if not r.get('validation',{}).get('passed'):
            output['unsupported_or_errors'].append({'case_id':r['case_id'],'tool':r['tool'],'variant':r['variant'],'classification':'diagnostic_error' if 'diagnostic_error' in r else 'unsupported_local_clifford_recognition','error':r.get('diagnostic_error') or r.get('validation',{}).get('error'),'structural_metrics_only':r.get('metrics'),'correctness_qualified':False})
    for case in p['cases']:
        cid=case['id'];edge_set={tuple(sorted(e)) for e in case['edges']}
        neighbors=[[] for _ in range(case['physical_width'])]
        for a,b in case['edges']:neighbors[a].append(b);neighbors[b].append(a)
        def distances(start):
            d={start:0};q=deque([start])
            while q:
                at=q.popleft()
                for nxt in neighbors[at]:
                    if nxt not in d:d[nxt]=d[at]+1;q.append(nxt)
            return d
        ds=[distances(q) for q in range(case['physical_width'])]
        def layout_evidence(row):
            result=row['result'];initial=result['initial_layout'];final=result['final_layout']
            hops=[ds[a][b] for a,b in zip(initial,initial[1:])]
            return {'initial_layout':initial,'final_layout':final,'initial_equals_final':initial==final,'initial_chain_edge_distances':hops,'initial_nonadjacent_chain_pairs':sum(d!=1 for d in hops),'initial_chain_distance_excess':sum(d-1 for d in hops),'distance_excess_note':'Derived static map diagnostic, not the recorded SABRE objective or route score.','metrics':row['metrics'],'all_input_validation':row['validation']['passed'],'graph_new_to_old':row.get('graph_new_to_old')}
        info={'case_id':cid,'source_cx':case['n_logical']-1,'physical_width':case['physical_width'],'path_witness':case['path_witness'],'baselines':{},'qrust_controls':{},'sdk_controls':{}}
        for tool in ('qrust','qiskit','cirq','tket'):
            row=indexed[cid,tool,'baseline'];info['baselines'][tool]=layout_evidence(row)
            if tool=='qrust':
                # Primary branch only; retained/alternative traces use explicit prefixes.
                stages=[e for e in row['events'] if '::' not in e['pass']]
                info['baselines'][tool]['stages']=[{k:e[k] for k in ('pass','operations','two_qubit_gates','swaps','depth','layout_route_evaluations')} for e in stages]
                info['baselines'][tool]['block_stats']=row['result']['two_qubit_block_stats']
            elif tool=='qiskit':
                info['baselines'][tool]['passes']=[{k:e[k] for k in ('pass','counts','two_qubit_operations')} for e in row['events']]
            else:
                info['baselines'][tool]['stages']=[{k:e[k] for k in ('stage','before','after')} for e in row['events']]
        for name,_ in p['variants']['qrust']:
            row=indexed[cid,'qrust',name]
            info['qrust_controls'][name]=layout_evidence(row)
            info['qrust_controls'][name]['stages']=[{k:e[k] for k in ('pass','two_qubit_gates','swaps','layout_route_evaluations')} for e in row['events'] if '::' not in e['pass']]
        for tool in ('qiskit','cirq','tket'):
            info['sdk_controls'][tool]={name:{'metrics':indexed[cid,tool,name].get('metrics'),'verified':indexed[cid,tool,name].get('validation',{}).get('passed',False),'error':indexed[cid,tool,name].get('diagnostic_error')} for name in p['variants'][tool]}
        output['cases'].append(info)
    write_new(HERE/'derived_summary.json',output)
    print(json.dumps(output['counts']))

if __name__=='__main__': main()
