#!/usr/bin/env python3
"""Frozen Cat/GHZ diagnostic interventions; never a benchmark timing recipe."""
from __future__ import annotations
import argparse
from collections import Counter
from contextlib import ExitStack
import hashlib
import importlib.metadata
import json
import math
import os
from pathlib import Path
import re
import subprocess
import sys
import time
from unittest.mock import patch

HERE = Path(__file__).absolute().parent
WORK = HERE.parent.parent
REPO = WORK / 'qrust_pr_publish'
EXP = REPO / 'experiments'
BINARY = WORK / 'qrust_compile_overhead_20261018/comparison_runner_final'
CASES_FILE = WORK / 'qrust_tket_benchpress_20261018/benchpress/frozen/cases.json'
sys.path.insert(0, str(EXP))
for name in ('OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS','NUMEXPR_NUM_THREADS','VECLIB_MAXIMUM_THREADS','RAYON_NUM_THREADS','QISKIT_NUM_PROCS'):
    os.environ[name] = '1'
os.environ['QISKIT_PARALLEL'] = 'FALSE'
os.environ.setdefault('PYTHONHASHSEED', '20261015')


def digest(value):
    return hashlib.sha256(value.encode() if isinstance(value, str) else value).hexdigest()


def write_new(path, value):
    with path.open('x') as stream:
        json.dump(value, stream, indent=2, sort_keys=True, allow_nan=False)
        stream.write('\n')


def simple_path(width, edges, length):
    """Lexically deterministic depth-first witness; no compiler results used."""
    adjacent = [set() for _ in range(width)]
    for a,b in edges:
        adjacent[a].add(b); adjacent[b].add(a)
    visits = 0
    def search(path, used):
        nonlocal visits
        visits += 1
        if visits > 1_000_000:
            raise RuntimeError('Prespecified witness-search limit reached')
        if len(path) == length:
            return path
        for nxt in sorted(adjacent[path[-1]], key=lambda x:(len(adjacent[x]),x)):
            if nxt not in used:
                answer = search(path+[nxt], used|{nxt})
                if answer is not None:
                    return answer
        return None
    for first in sorted(range(width), key=lambda x:(len(adjacent[x]),x)):
        result = search([first], {first})
        if result is not None:
            return result, visits
    raise ValueError('No path witness found')


def relabel_case(case, path):
    new_to_old = path + [q for q in range(case['physical_width']) if q not in path]
    old_to_new = {q:i for i,q in enumerate(new_to_old)}
    output = dict(case)
    output['edges'] = [[old_to_new[a],old_to_new[b]] for a,b in case['edges']]
    # Preserve original edge order and orientations under this exact permutation.
    assert sorted(tuple(sorted((new_to_old[a],new_to_old[b]))) for a,b in output['edges']) == sorted(tuple(sorted(e)) for e in case['edges'])
    return output, new_to_old


def restore_labels(result, mapping):
    result = dict(result)
    result['out_qasm'] = re.sub(r'q\[(\d+)\]', lambda m: m.group(0) if int(m[1]) == len(mapping) else f'q[{mapping[int(m[1])]}]', result['out_qasm'])
    result['initial_layout'] = [mapping[i] for i in result['initial_layout']]
    result['final_layout'] = [mapping[i] for i in result['final_layout']]
    return result


def request(case):
    return {**{k:case[k] for k in ('qasm','n_logical','physical_width','edges','topology')}, 'seed':20261018}


def metrics(result):
    from comparison_validation import parse_qasm, common_metrics
    return common_metrics(*parse_qasm(result['out_qasm']))


def validate(case, result):
    from scalable_clifford import validate_clifford
    return validate_clifford(case['qasm'],result['out_qasm'],case['n_logical'],case['physical_width'],result['initial_layout'],result['final_layout'],case['edges'])


def negatives(case, result):
    phased = dict(result, out_qasm=result['out_qasm']+f'u3(0,0,{math.pi:.17g}) q[{result["final_layout"][0]}];\n')
    wrong = list(result['final_layout']); wrong[0],wrong[1] = wrong[1],wrong[0]
    mislabelled = dict(result, final_layout=wrong)
    used = re.search(r'cx q\[(\d+)\],\s*q\[(\d+)\];', result['out_qasm'])
    if used is None:
        raise ValueError('Expected a CX for the edge negative control')
    forbidden = tuple(sorted((int(used[1]),int(used[2]))))
    wrong_target = dict(case, edges=[e for e in case['edges'] if tuple(sorted(e)) != forbidden])
    return {'relative_phase':validate(case,phased),'transposed_outputs':validate(case,mislabelled),'removed_used_edge':validate(wrong_target,result)}


def operation_summary(circuit, kind):
    if kind == 'qiskit':
        counts = dict(circuit.count_ops())
        return {'counts':{str(k):int(v) for k,v in counts.items()},'depth':circuit.depth(),'two_qubit_operations':sum(len(node.qargs)==2 for node in circuit.op_nodes())}
    if kind == 'cirq':
        operations = list(circuit.all_operations())
        return {'counts':dict(Counter(str(op.gate) for op in operations)), 'depth':len(circuit), 'two_qubit_operations':sum(len(op.qubits)==2 for op in operations)}
    operations = list(circuit.get_commands())
    return {'counts':dict(Counter(str(op.op.type) for op in operations)), 'depth':circuit.depth(), 'two_qubit_operations':sum(len(op.qubits)==2 for op in operations), 'implicit_permutation':{str(a):str(b) for a,b in circuit.implicit_qubit_permutation().items()}}


def sdk_control(tool, case, variant):
    """Instrument frozen adapter entry points; every monkeypatch is scoped."""
    from comparison_qiskit_tket import compile_one as qt_compile
    from comparison_cirq import compile_one as cirq_compile
    events = []
    kwargs = request(case)
    path = case['path_witness']
    with ExitStack() as stack:
        if tool == 'qiskit':
            import qiskit
            from qiskit.transpiler.preset_passmanagers import generate_preset_pass_manager
            original = qiskit.transpile
            def transpile(circuit, **options):
                def callback(**args):
                    events.append({'pass':args['pass_'].name(), 'elapsed_seconds':args['time'], 'pass_index':args['count'], **operation_summary(args['dag'],'qiskit')})
                if variant.startswith('fixed_witness'):
                    options['initial_layout'] = path
                if variant == 'sabre_layout':
                    options['layout_method'] = 'sabre'
                if variant == 'trivial_layout':
                    options['layout_method'] = 'trivial'
                if variant in {'omit_optimization','fixed_witness_omit_optimization'}:
                    num_processes = options.pop('num_processes')
                    manager = generate_preset_pass_manager(**options)
                    manager.optimization = None
                    return manager.run(circuit, callback=callback, num_processes=num_processes)
                options['callback'] = callback
                return original(circuit, **options)
            stack.enter_context(patch.object(qiskit,'transpile',transpile))
        elif tool == 'cirq':
            import cirq
            original_opt = cirq.optimize_for_target_gateset
            original_route = cirq.RouteCQC.route_circuit
            calls = 0
            def optimize(circuit, **options):
                nonlocal calls
                calls += 1
                stage = 'pre_synthesis' if calls == 1 else 'post_synthesis'
                before = operation_summary(circuit,'cirq')
                start = time.perf_counter_ns()
                omit = variant in {f'omit_{stage}','omit_both_syntheses'}
                output = circuit.copy() if omit else original_opt(circuit,**options)
                events.append({'stage':stage,'omitted':omit,'before':before,'after':operation_summary(output,'cirq'),'elapsed_ns':time.perf_counter_ns()-start})
                return output
            def route(router, circuit, **options):
                if variant == 'identity_mapper':
                    options['initial_mapper'] = cirq.HardCodedInitialMapper({cirq.LineQubit(i):cirq.LineQubit(i) for i in range(case['n_logical'])})
                if variant.startswith('fixed_witness'):
                    options['initial_mapper'] = cirq.HardCodedInitialMapper({cirq.LineQubit(i):cirq.LineQubit(p) for i,p in enumerate(path)})
                start = time.perf_counter_ns()
                output,initial,final = original_route(router,circuit,**options)
                events.append({'stage':'route','before':operation_summary(circuit,'cirq'),'after':operation_summary(output,'cirq'), 'initial_layout':{str(a):str(b) for a,b in initial.items()},'swap_permutation':{str(a):str(b) for a,b in final.items()},'elapsed_ns':time.perf_counter_ns()-start})
                return output,initial,final
            stack.enter_context(patch.object(cirq,'optimize_for_target_gateset',optimize))
            stack.enter_context(patch.object(cirq.RouteCQC,'route_circuit',route))
        elif tool == 'tket':
            import pytket.passes
            original_sequence = pytket.passes.SequencePass
            original_mapping = pytket.passes.DefaultMappingPass
            def mapping(architecture):
                if variant not in {'identity_mapping','fixed_witness'}:
                    return original_mapping(architecture)
                from pytket.circuit import Qubit, Node
                chosen = path if variant == 'fixed_witness' else list(range(case['n_logical']))
                rename = pytket.passes.RenameQubitsPass({Qubit('q',i):Node(p) for i,p in enumerate(chosen)})
                return original_sequence([rename,pytket.passes.RoutingPass(architecture)])
            stack.enter_context(patch.object(pytket.passes,'DefaultMappingPass',mapping))
            class TracedSequence:
                def __init__(self, passes):
                    self.passes = passes
                def apply(self, unit):
                    changed = False
                    labels = ['peephole','mapping','swap_decomposition','post_synthesis','rebase']
                    if len(self.passes) != len(labels):
                        raise ValueError('Frozen pass list changed')
                    for label, compiler_pass in zip(labels,self.passes):
                        before = operation_summary(unit.circuit,'tket')
                        omit = variant in {f'omit_{label}'} or variant == 'omit_pre_post' and label in {'peephole','post_synthesis'}
                        start = time.perf_counter_ns()
                        if not omit:
                            changed |= compiler_pass.apply(unit)
                        events.append({'stage':label,'omitted':omit,'pass_specification':compiler_pass.to_dict(), 'before':before,'after':operation_summary(unit.circuit,'tket'),'elapsed_ns':time.perf_counter_ns()-start})
                    return changed
            stack.enter_context(patch.object(pytket.passes,'SequencePass',TracedSequence))
        else:
            raise ValueError(tool)
        result = cirq_compile(**kwargs) if tool == 'cirq' else qt_compile(tool,**kwargs)
        result['status'] = 'compiled'
    return result, events


def prepare():
    cases = [c for c in json.loads(CASES_FILE.read_text()) if c['id'].startswith(('cat','ghz'))]
    assert len(cases)==4
    for case in cases:
        assert digest(case['qasm'])==case['qasm_sha256']
        path,visits = simple_path(case['physical_width'],case['edges'],case['n_logical'])
        case.update(path_witness=path,witness_search_nodes=visits)
    variants = {
        'qrust': [
            ['baseline',{}], ['omit_clifford',{'clifford_simplification':False}],
            ['omit_blocks',{'two_qubit_block_synthesis':False}],
            ['omit_clifford_blocks',{'clifford_simplification':False,'two_qubit_block_synthesis':False}],
            ['layout_trials_1',{'layout_trials':1}], ['layout_trials_40',{'layout_trials':40}],
            ['layout_iterations_1',{'layout_iterations':1}], ['layout_iterations_6',{'layout_iterations':6}],
            ['path_relabel',{}], ['path_relabel_omit_clifford_blocks',{'clifford_simplification':False,'two_qubit_block_synthesis':False}],
        ],
        'qiskit':['baseline','omit_optimization','fixed_witness','fixed_witness_omit_optimization','sabre_layout','trivial_layout','path_relabel'],
        'cirq':['baseline','omit_pre_synthesis','omit_post_synthesis','omit_both_syntheses','fixed_witness','identity_mapper','path_relabel'],
        'tket':['baseline','omit_peephole','omit_post_synthesis','omit_pre_post','identity_mapping','fixed_witness','path_relabel'],
    }
    protocol = {'schema':3,'prefreeze_revision':'Added explicit placement interventions from static SDK source inspection and per-output removed-used-edge negative controls before any diagnostic compilation. Earlier designs and scripts preserved.', 'cases':cases,'variants':variants,'seed':20261018,'repetitions':1,
        'contract':'Diagnostic interventions only, not comparative speed measurements. Frozen U/CX unitary compilation; free input/output maps; clean spare physical inputs.',
        'path_control':'Exact graph relabeling whose first n labels form a witnessed simple path, restored to original physical coordinates before validation. This changes label-sensitive heuristic starts and is not a forced-layout API for Q-Rust.',
        'lower_bound':'On product |0> input each chain generates GHZ on n logical outputs. At least n−1 two-qubit interactions are needed to connect n initially independent output components under this unitary 1q/CX contract. An edge-respecting realization of the complete chain unitary witnesses attainment for these four circuits only.',
        'validation':'Independent map-aware signed-Pauli Choi isometry, all logical inputs plus clean spare wires; bounded local Clifford recognition; structural basis/edge checks. Every compiled output gets relative-phase, transposed-output-map and removed-used-edge negative controls.',
        'trace_parity':'Instrumented baseline SDK adapter output QASM, maps and common metrics must exactly match uninstrumented frozen entrypoint output for same seed; diagnostic timing metadata excluded.',
        'binary_sha256':digest(BINARY.read_bytes()),'cases_sha256':digest(CASES_FILE.read_bytes()),
        'sources':{str(p):digest(p.read_bytes()) for p in [Path(__file__),HERE/'test_controls.py',EXP/'comparison_cirq.py',EXP/'comparison_qiskit_tket.py',EXP/'comparison_study.py',EXP/'scalable_clifford.py',EXP/'comparison_validation.py']},
        'versions':{k:importlib.metadata.version(k) for k in ('qiskit','cirq-core','pytket','numpy','scipy','networkx')},
        'compiler_commit':subprocess.check_output(['git','rev-parse','HEAD'],cwd=REPO,text=True).strip()}
    write_new(HERE/'protocol.json',protocol)
    print(json.dumps({'prepared':True,'cases':len(cases),'requests':4*sum(len(v) for v in variants.values()),'protocol_sha256':digest((HERE/'protocol.json').read_bytes())}),flush=True)


def run():
    from comparison_study import Worker
    from comparison_qiskit_tket import compile_one as qt_compile
    from comparison_cirq import compile_one as cirq_compile
    p = json.loads((HERE/'protocol.json').read_text())
    assert p['binary_sha256']==digest(BINARY.read_bytes())
    for file,sha in p['sources'].items():
        assert digest(Path(file).read_bytes())==sha, file
    rows_path = HERE/'raw.jsonl'
    worker = Worker('qrust',BINARY,HERE)
    records = []
    try:
        with rows_path.open('x') as stream:
            for case in p['cases']:
                # A direct edge-respecting witness uses exactly n−1 CX and realizes the full source unitary.
                path = case['path_witness']
                mapped = re.sub(r'q\[(\d+)\]',lambda m:m.group(0) if int(m[1])==case['n_logical'] else f'q[{path[int(m[1])]}]',case['qasm'])
                mapped = mapped.replace(f'qreg q[{case["n_logical"]}];',f'qreg q[{case["physical_width"]}];').replace('h q[',f'u3({math.pi/2:.17g},0,{math.pi:.17g}) q[')
                witness = {'status':'compiled','out_qasm':mapped,'initial_layout':path,'final_layout':path}
                row = {'case_id':case['id'],'tool':'analytic_witness','variant':'path','result':witness}
                stream.write(json.dumps(row)+'\n');stream.flush();records.append(row)
                for tool, variants in p['variants'].items():
                    baseline = None
                    if tool!='qrust':
                        native = cirq_compile(**request(case)) if tool=='cirq' else qt_compile(tool,**request(case))
                        baseline = {k:native[k] for k in ('out_qasm','initial_layout','final_layout')}
                        write_new(HERE/f'native_{case["id"]}_{tool}.json',native)
                    for variant in variants:
                        name,options = variant if tool=='qrust' else (variant,{})
                        actual,mapping = relabel_case(case,path) if name.startswith('path_relabel') else (case,None)
                        row = {'case_id':case['id'],'tool':tool,'variant':name,'options':options,'graph_new_to_old':mapping}
                        try:
                            if tool=='qrust':
                                result = worker.call({**request(actual),**options,'profile_passes':True},120)
                                events = result.get('pass_diagnostics',[])
                            else:
                                result,events = sdk_control(tool,actual,name)
                            if mapping and result.get('status')=='compiled':
                                result = restore_labels(result,mapping)
                            row.update(result=result,events=events)
                            if name=='baseline' and baseline is not None:
                                row['native_parity'] = baseline=={k:result[k] for k in baseline}
                                if not row['native_parity']:
                                    raise ValueError('Native / instrumented output mismatch')
                        except Exception as error:
                            row['diagnostic_error'] = f'{type(error).__name__}: {error}'
                        stream.write(json.dumps(row,allow_nan=False)+'\n');stream.flush();records.append(row)
                        print(json.dumps({'case_id':case['id'],'tool':tool,'variant':name,'status':row.get('result',{}).get('status'),'diagnostic_error':row.get('diagnostic_error')}),flush=True)
    finally:
        worker.close()
    write_new(HERE/'run_receipt.json',{'records':len(records),'raw_sha256':digest(rows_path.read_bytes()),'protocol_sha256':digest((HERE/'protocol.json').read_bytes())})


def check():
    p = json.loads((HERE/'protocol.json').read_text());cases = {c['id']:c for c in p['cases']}
    rows = [json.loads(s) for s in (HERE/'raw.jsonl').read_text().splitlines()]
    summaries = []
    with (HERE/'validated.jsonl').open('x') as stream:
        for row in rows:
            case = cases[row['case_id']];result=row.get('result',{})
            if result.get('status')=='compiled':
                row['metrics']=metrics(result);row['validation']=validate(case,result);row['negative_controls']=negatives(case,result)
            stream.write(json.dumps(row,allow_nan=False)+'\n');stream.flush()
            summaries.append({k:v for k,v in row.items() if k not in ('result','events')})
    totals = Counter('diagnostic_error' if 'diagnostic_error' in r else 'passed' if r.get('validation',{}).get('passed') and all(not c['passed'] for c in r['negative_controls'].values()) else 'failed_or_unsupported' for r in summaries)
    write_new(HERE/'summary.json',{'totals':dict(totals),'rows':summaries,'raw_sha256':digest((HERE/'raw.jsonl').read_bytes()),'validated_sha256':digest((HERE/'validated.jsonl').read_bytes())})
    print(json.dumps({'totals':dict(totals)}),flush=True)


if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('command',choices=['prepare','run','validate']);args=parser.parse_args()
    {'prepare':prepare,'run':run,'validate':check}[args.command]()
