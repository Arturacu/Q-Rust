import copy
import unittest
from controls import relabel_case, restore_labels, simple_path

class ControlTests(unittest.TestCase):
    def test_path_is_distinct_and_edge_respecting(self):
        edges=[[0,1],[1,2],[2,3],[1,4]]
        path,visits=simple_path(5,edges,4)
        self.assertEqual(len(path),4)
        self.assertEqual(len(set(path)),4)
        self.assertGreater(visits,0)
        self.assertTrue(all(tuple(sorted(e)) in {tuple(sorted(x)) for x in edges} for e in zip(path,path[1:])))
    def test_target_permutation_preserves_edges_and_order(self):
        original={'physical_width':5,'edges':[[0,3],[3,2],[2,1],[1,4]]}
        before=copy.deepcopy(original)
        changed,mapping=relabel_case(original,[4,1,2])
        self.assertEqual(original,before)
        self.assertEqual(mapping,[4,1,2,0,3])
        self.assertEqual([[mapping[a],mapping[b]] for a,b in changed['edges']],original['edges'])
    def test_output_relabel_preserves_declaration_and_maps_once(self):
        result={'out_qasm':'OPENQASM 2.0;\nqreg q[4];\ncx q[0],q[3];\n','initial_layout':[0,3],'final_layout':[3,1]}
        original=copy.deepcopy(result)
        restored=restore_labels(result,[2,0,3,1])
        self.assertEqual(result,original)
        self.assertIn('qreg q[4];',restored['out_qasm'])
        self.assertIn('cx q[2],q[1];',restored['out_qasm'])
        self.assertEqual(restored['initial_layout'],[2,1])
        self.assertEqual(restored['final_layout'],[1,0])
    def test_path_absence_is_explicit(self):
        with self.assertRaises(ValueError): simple_path(4,[[0,1],[2,3]],3)

if __name__=='__main__': unittest.main()
