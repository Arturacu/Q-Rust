#!/usr/bin/env python3
"""Replay held-out validation and analysis from a relocated evidence archive."""
import argparse
import copy
import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import sys


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def read(path):
    return json.loads(path.read_text())


def isolated_output(study, output):
    archive_root = study.resolve().parent.parent
    output = output.resolve()
    if output.is_relative_to(archive_root) or archive_root.is_relative_to(output):
        raise ValueError('Replay output must be outside the evidence archive tree')
    return output


def semantic_rows(path):
    rows = [json.loads(line) for line in path.read_text().splitlines()]
    for row in rows:
        if isinstance(row.get('validation'), dict):
            row['validation'].pop('validation_ns', None)
    return rows


def compare_summary(reference, replay, filename, derived_field, derived_filename):
    left, right = read(reference / filename), read(replay / filename)
    for value, base in ((left, reference), (right, replay)):
        for session in value['sessions']:
            folder = session['session']
            if isinstance(folder, int):
                folder = f'session_{folder:02d}'
            if session[derived_field] != sha(base / folder / derived_filename):
                raise ValueError('Unbound derived validation hash: ' + filename)
            session.pop(derived_field)
    if left != right:
        raise ValueError('Validation summary differs beyond its checked derived hashes: ' + filename)


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--study', required=True, type=Path)
    p.add_argument('--output', required=True, type=Path)
    args = p.parse_args()
    study = args.study.absolute()
    work = study.parent
    source = study / 'heldout/campaign'
    output = isolated_output(study, args.output)
    output.mkdir(parents=True, exist_ok=False)
    target = output / 'campaign'
    target.mkdir()
    protocol = read(source / 'protocol.json')
    for name in ('protocol.json', 'protocol.sha256', 'corpus_manifest.json'):
        shutil.copyfile(source / name, target / name)
    for session in range(1, protocol['sessions'] + 1):
        folder = f'session_{session:02d}'
        (target / folder).mkdir()
        for name in ('session.json', 'timed.jsonl', 'warmup.jsonl'):
            shutil.copyfile(source / folder / name, target / folder / name)
    common = ['--repo', str(work / 'qrust_pr_publish'), '--study', str(target),
              '--binary', str(work / 'qrust_compile_overhead_20261018/comparison_runner_final'),
              '--plan', str(study / 'heldout/protocol_plan.json'),
              '--compiler-freeze', str(study / 'compiler_freeze.json'),
              '--allow-relocated', '--generator-root',
              str(work / 'qrust_external_20261018/sources/mqtbench')]
    commands = []
    for phase in ('validate', 'analyze'):
        command = [str(Path(sys.executable).absolute()), str(study / 'heldout/heldout_study.py'), phase, *common]
        log = output / (phase + '.log')
        with log.open('x') as stream:
            completed = subprocess.run(command, stdout=stream, stderr=subprocess.STDOUT)
        commands.append({'phase': phase, 'command': command, 'exit_code': completed.returncode,
                         'log_sha256': sha(log)})
        if completed.returncode:
            raise RuntimeError('Fresh held-out replay failed: ' + str(log))
    records = []
    for session in range(1, protocol['sessions'] + 1):
        folder = f'session_{session:02d}'
        for name in ('validated.jsonl', 'warmup_validated.jsonl'):
            left, right = source / folder / name, target / folder / name
            if semantic_rows(left) != semantic_rows(right):
                raise ValueError('Saved output semantics changed: ' + folder + '/' + name)
            records.append({'file': folder + '/' + name, 'semantic_equality': True,
                            'reference_sha256': sha(left), 'replay_sha256': sha(right)})
        for name in ('cells.json', 'cells.csv'):
            if (source / folder / name).read_bytes() != (target / folder / name).read_bytes():
                raise ValueError('Cell analysis changed: ' + folder + '/' + name)
    compare_summary(source, target, 'validation_summary.json', 'validated_sha256', 'validated.jsonl')
    compare_summary(source, target, 'warmup_validation_summary.json', 'warmup_validated_sha256', 'warmup_validated.jsonl')
    if (source / 'analysis.json').read_bytes() != (target / 'analysis.json').read_bytes():
        raise ValueError('Aggregate/stratified analysis changed')
    result = {'schema': 1, 'passed': True, 'no_compiler_execution': True,
              'protocol_sha256': sha(source / 'protocol.json'), 'commands': commands,
              'validated_artifacts': records, 'cells_and_analysis_byte_identical': True,
              'excluded_field': 'Only validation.validation_ns; derived validation-file hashes are checked against both actual files before comparison.',
              'analysis_sha256': sha(source / 'analysis.json'), 'replay_helper_sha256': sha(Path(__file__))}
    with (output / 'replay_receipt.json').open('x') as stream:
        json.dump(result, stream, indent=2, sort_keys=True)
        stream.write('\n')
    print(json.dumps({'passed': True, 'analysis_byte_identical': True}))


if __name__ == '__main__':
    main()
