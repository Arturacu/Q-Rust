"""Lightweight archive boundary tests; no compiler or semantic workload runs."""
from pathlib import Path
import tempfile
from types import SimpleNamespace
import unittest

import archive_primitives as package


class PackagingTests(unittest.TestCase):
    def test_command_sanitization_omits_only_local_policy_pairs(self):
        original = {'command': ['python', 'package.py', '--report', 'report.md',
                               '--reject-text', 'local marker one', '--campaign', 'campaign',
                               '--reject-text', 'local marker two'], 'report_sha256': 'bound'}
        result = package.sanitize_packaging_command(original)
        self.assertEqual(result['command'], ['python', 'package.py', '--report', 'report.md', '--campaign', 'campaign'])
        self.assertEqual(result['report_sha256'], 'bound')
        self.assertEqual(result['omitted_local_text_policy_argument_pairs'], 2)
        self.assertEqual(original['command'][-2:], ['--reject-text', 'local marker two'])
        self.assertNotIn('local marker', str(result))

    def test_command_without_policy_is_unchanged(self):
        original = {'command': ['python', 'package.py', '--report', 'report.md']}
        result = package.sanitize_packaging_command(original)
        self.assertEqual(result['command'], original['command'])
        self.assertEqual(result['omitted_local_text_policy_argument_pairs'], 0)

    def test_malformed_policy_receipt_fails_closed(self):
        for value in ({}, {'command': 'text'}, {'command': ['python', '--reject-text']},
                      {'command': ['python', 42]}, {'command': ['python', '--reject-text', None]}):
            with self.subTest(value=value), self.assertRaises(ValueError):
                package.sanitize_packaging_command(value)

    def test_text_audit_covers_receipts_rows_logs_and_qasm(self):
        with tempfile.TemporaryDirectory() as folder:
            root = Path(folder)
            for suffix in ['.json', '.jsonl', '.log', '.qasm', '.py', '.md', '.txt', '.rst', '.sha256', '.rs', '.toml', '.yaml', '.ini', '.csv', '.diff', '']:
                path = root / ('record' + suffix)
                path.write_text('local audit marker')
                with self.subTest(suffix=suffix), self.assertRaisesRegex(ValueError, 'Rejected text'):
                    package.audit_prose(root, ['local audit marker'])
                path.unlink()

    def test_evidence_trees_explicit_and_nonoverlapping(self):
        args = SimpleNamespace(evidence_tree=['clifford_diagnostics', 'diagnostics', 'preflight_final', 'verification'])
        self.assertEqual(package.evidence_trees(args), ['campaign', 'analysis_replay', *args.evidence_tree])

    def test_reserved_and_overlapping_evidence_rejected(self):
        for values in (['campaign'], ['campaign/subset'], ['analysis/subset'], ['analysis_replay'],
                       ['diagnostics', 'diagnostics/subset'], ['diagnostics/subset', 'diagnostics'],
                       ['abandoned_configurations/campaign'],
                       ['../escape'], ['/absolute'], ['.'], ['a//b']):
            with self.subTest(values=values):
                with self.assertRaises(ValueError):
                    package.evidence_trees(SimpleNamespace(evidence_tree=values))

    def test_completion_cannot_select_an_abandoned_campaign(self):
        campaign = Path('/evidence/campaign_final')
        good = {'campaign': str(campaign), 'paired_protocol_sha256': 'a' * 64}
        package.check_completion_identity([good, good], campaign, 'a' * 64)
        for bad in ({**good, 'campaign': '/evidence/campaign'},
                    {**good, 'paired_protocol_sha256': 'b' * 64}, {}):
            with self.subTest(receipt=bad), self.assertRaisesRegex(ValueError, 'another campaign'):
                package.check_completion_identity([good, bad], campaign, 'a' * 64)

    def test_archive_roundtrip_binds_every_payload(self):
        with tempfile.TemporaryDirectory() as folder:
            root = Path(folder)
            stage = root / 'stage'
            stage.mkdir()
            (stage / 'receipt.json').write_text('{"passed": true}\n')
            (stage / 'binary').write_bytes(b'preserved binary')
            archive = root / 'evidence.tar.gz'
            package.manifest_and_archive(stage, archive)
            receipt = package.extract_and_audit(archive, root / 'extracted')
            self.assertTrue(receipt['all_payload_hashes_match'])
            self.assertEqual(receipt['payload_files'], 2)

    def test_copy_rejects_symlink_and_existing_destination(self):
        with tempfile.TemporaryDirectory() as folder:
            root = Path(folder)
            source = root / 'source'
            source.write_bytes(b'original')
            link = root / 'link'
            link.symlink_to(source)
            with self.assertRaisesRegex(ValueError, 'symlinked'):
                package.copy_file(link, root / 'new')
            with self.assertRaises(FileExistsError):
                package.copy_file(source, source)
            self.assertEqual(source.read_bytes(), b'original')


if __name__ == '__main__':
    unittest.main()
