import json
from pathlib import Path
import tempfile
import unittest

from package_study import check_completion, check_output_paths, frozen_sources
from archive_primitives import sha


class CompletionTests(unittest.TestCase):
    def setUp(self):
        self.temporary = tempfile.TemporaryDirectory()
        self.addCleanup(self.temporary.cleanup)
        self.root = Path(self.temporary.name)
        self.study = self.root / 'study'
        self.study.mkdir()
        (self.study / 'raw.json').write_text('{"result": 7}\n')
        self.receipt = {'all_work_completed': True,
                        'completed_artifacts': {'raw.json': sha(self.study / 'raw.json')}}
        self.write_receipt()

    def write_receipt(self):
        (self.study / 'completion.json').write_text(json.dumps(self.receipt))

    def test_changed_raw_result_is_rejected(self):
        check_completion(self.study)
        (self.study / 'raw.json').write_text('{"result": 8}\n')
        with self.assertRaisesRegex(ValueError, 'artifact changed'):
            check_completion(self.study)

    def test_active_timing_is_rejected(self):
        (self.study / 'nested').mkdir()
        (self.study / 'nested/active.lock').touch()
        with self.assertRaisesRegex(ValueError, 'still be active'):
            check_completion(self.study)

    def test_incomplete_or_unsafe_receipt_is_rejected(self):
        self.receipt['all_work_completed'] = False
        self.write_receipt()
        with self.assertRaises(ValueError):
            check_completion(self.study)
        self.receipt['all_work_completed'] = True
        self.receipt['completed_artifacts'] = {'../raw.json': 'x'}
        self.write_receipt()
        with self.assertRaisesRegex(ValueError, 'Unsafe'):
            check_completion(self.study)

    def test_changed_frozen_binary_is_rejected(self):
        binary = self.root / 'binary'
        binary.write_bytes(b'original')
        record = {'path': str(binary), 'bytes': 8, 'sha256': sha(binary)}
        (self.study / 'compiler_freeze.json').write_text(json.dumps({
            'compiler_and_recipe_files': [], 'generator_source_files': [], 'binary': record}))
        binary.write_bytes(b'modified')
        with self.assertRaisesRegex(ValueError, 'Frozen payload changed'):
            frozen_sources(self.study, self.root / 'stage')

    def test_packaging_outputs_must_be_disjoint_after_normalization(self):
        for destination, scratch in (
                (self.study / 'output', self.root / 'scratch'),
                (self.root / 'output', self.root / 'output/scratch'),
                (self.root / 'scratch/output', self.root / 'scratch'),
                (self.root / 'elsewhere/../study/output', self.root / 'scratch')):
            with self.assertRaisesRegex(ValueError, 'separate directory trees'):
                check_output_paths(self.study, destination, scratch)

    def test_packaging_symlink_alias_cannot_enter_study(self):
        (self.root / 'alias').symlink_to(self.study, target_is_directory=True)
        with self.assertRaisesRegex(ValueError, 'separate directory trees'):
            check_output_paths(self.study, self.root / 'alias/output', self.root / 'scratch')


if __name__ == '__main__':
    unittest.main()
