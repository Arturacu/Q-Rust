#!/usr/bin/env python3
"""Render a technical report only from complete, hash-bound frozen evidence."""
from __future__ import annotations
import argparse
from collections import Counter
import hashlib
import json
import math
from pathlib import Path
import statistics

STUDY = Path(__file__).absolute().parent.parent
TOOLS = ('qrust','qiskit','cirq','tket')
LABELS = {'qrust':'Q-Rust','qiskit':'Qiskit','cirq':'Cirq','tket':'TKET'}
METRICS = ('cx_count','depth','two_q_depth')
INPUTS = {}


def require(condition, message):
    if not condition: raise ValueError(message)


def sha(path):
    digest=hashlib.sha256()
    with path.open('rb') as stream:
        for block in iter(lambda:stream.read(1<<20),b''):digest.update(block)
    return digest.hexdigest()


def read(path):
    require(path.is_file(),'Missing final report input: '+str(path))
    INPUTS[str(path.relative_to(STUDY))]=sha(path)
    return json.loads(path.read_text())


def note(path):
    require(path.is_file(),'Missing final causal notes: '+str(path))
    INPUTS[str(path.relative_to(STUDY))]=sha(path)
    return path.read_text()


def write_new(path, text):
    path.parent.mkdir(parents=True,exist_ok=True)
    with path.open('x') as f:f.write(text)


def json_new(path, value): write_new(path,json.dumps(value,indent=2,sort_keys=True,allow_nan=False)+'\n')


def fmt(value, digits=3):
    if value is None:return '—'
    require(isinstance(value,(int,float)) and not isinstance(value,bool) and math.isfinite(value),'Invalid reported numeric value')
    return format(value,f'.{digits}g')


def ratio(stat, interval=True):
    if stat['geomean'] is None:return '—'
    require(stat['geomean']>0,'Nonpositive logarithmic ratio')
    result=fmt(stat['geomean'])+'×'
    if interval and stat['ci95'] is not None:
        lo,hi=stat['ci95'];require(0<lo<=hi,'Invalid interval')
        result+=f' [{fmt(lo)}, {fmt(hi)}]'
    return result


def compact_case(value): return value.removeprefix('mqt_holdout__').replace('__',' / ')


def table(headers,rows):
    def clean(v):return str(v).replace('|','\\|').replace('\n',' ')
    return ['| '+' | '.join(headers)+' |','|'+'|'.join('---' for _ in headers)+'|',*['| '+' | '.join(clean(v) for v in row)+' |' for row in rows],'']


def outcome_text(counts):return '; '.join(f'{k}: {v}' for k,v in sorted(counts.items())) or 'none'


def agreement_table(agreement, protocol):
    counts=agreement['counts'];per_tool=agreement['by_tool']
    require(set(per_tool)==set(TOOLS),'Cross-session tool coverage differs')
    expected=len(protocol['cases'])*protocol['trials']
    aggregate=Counter()
    rows=[]
    for tool in TOOLS:
        values=per_tool[tool]
        require(all(isinstance(v,int) and not isinstance(v,bool) and v>=0 for v in values.values()),'Invalid cross-session outcome count')
        require(sum(values.values())==expected,'Incomplete cross-session paired trial identities')
        aggregate.update(values)
        rows.append([LABELS[tool],expected,outcome_text(values)])
    require(dict(aggregate)==counts,'Cross-session aggregate/by-tool mismatch')
    rows.append(['All tools',expected*len(TOOLS),outcome_text(counts)])
    return expected*len(TOOLS),table(['Tool','Cross-session paired trial identities','Agreement categories'],rows)


def variability_notes(agreement,cells=None):
    paragraphs=['The frozen seed-policy text described the non-Qiskit recipes as deterministic. This was an expected recipe property, not an empirical result. Only Qiskit consumes the requested compiler trial seeds in these adapters; the absence of a consumed seed does not establish repeatable output.']
    stable_compiled=[]
    for tool in TOOLS:
        values=agreement['by_tool'][tool]
        compiled=sum(values.get(key,0) for key in ('identical_artifact','same_quality_different_artifact','quality_changed','validation_status_changed'))
        quality=values.get('quality_changed',0);artifact=values.get('same_quality_different_artifact',0)
        status=values.get('compile_status_changed',0)+values.get('validation_status_changed',0)
        if quality or artifact or status:
            pairing=('Qiskit consumes the requested seed, which is held fixed across corresponding trials.' if tool=='qiskit'
                     else 'This pairs requests, not a controlled internal RNG seed for that SDK.')
            paragraphs.append(f'Observed {LABELS[tool]} variability: **{quality} of {compiled} matched-request/corresponding-trial pairs with both outputs compiled changed structural quality**; {artifact} additional pairs changed artifact/map hashes with unchanged quality, and {status} pairs changed compilation or validation status. {pairing} These observations remain in the separate session tables; their internal cause is not identified by this agreement check.')
            if cells is not None:
                tables=[{c['case_id']:c for c in rows if c['tool']==tool and c['eligible']} for rows in cells]
                shared=sorted(tables[0].keys() & tables[1].keys())
                changed=sum(any(tables[0][case]['medians'][metric]!=tables[1][case]['medians'][metric]
                                for metric in (*METRICS,'gate_count')) for case in shared)
                paragraphs.append(f'For {LABELS[tool]}, {changed} of {len(shared)} cells qualified in both sessions changed their median structural metrics. Trial-level variability and stability of cell medians are separate observations.')
        elif compiled:
            stable_compiled.append(f'{LABELS[tool]} ({compiled} compiled pairs)')
    if stable_compiled:
        paragraphs.append('Every paired compiled artifact/map matches for '+', '.join(stable_compiled)+'. Matching non-success statuses are counted separately and do not count as successful compilation.')
    return [line for paragraph in paragraphs for line in (paragraph,'')]


def bind_dense(root,name,account_name):
    directory=root/name
    p=read(directory/'protocol.json');r=read(directory/'receipt.json');s=read(directory/'summary.json');a=read(root/account_name)
    require(r['completed'] is True,'Dense diagnostic incomplete: '+name)
    require(r['protocol_sha256']==s['protocol_sha256']==a['protocol_sha256']==sha(directory/'protocol.json'),'Dense protocol binding mismatch')
    require(r['raw_sha256']==s['raw_sha256']==sha(directory/'raw.jsonl'),'Dense raw binding mismatch')
    require(s['validated_sha256']==sha(directory/'validated.jsonl'),'Dense validation binding mismatch')
    require(a['summary_sha256']==sha(directory/'summary.json'),'Dense accounting binding mismatch')
    require(a['analysis_script_sha256']==sha(root/'analyze_dense.py'),'Dense accounting helper changed')
    require(sum(s['counts'].values())==len(p['schedule']),'Dense diagnostic coverage mismatch')
    return p,s,a


def med_metrics(case):
    require(case['all_verified'],'Cannot report unqualified dense output quality')
    requests=case['requests'];require(len(requests)==3,'Dense repetition coverage mismatch')
    require(all(isinstance(row['metrics'][key],(int,float)) and not isinstance(row['metrics'][key],bool)
                and math.isfinite(row['metrics'][key]) and row['metrics'][key]>=0
                for row in requests for key in (*METRICS,'gate_count')),'Invalid dense structural cost')
    return {k:statistics.median(row['metrics'][k] for row in requests) for k in (*METRICS,'gate_count')}


def render(args):
    global STUDY
    STUDY=args.study.absolute()
    INPUTS.clear()
    exports=args.exports.absolute()
    require(not exports.exists(),'Choose a fresh report exports directory')
    require(not args.output.exists(),'Refusing to overwrite a report')
    require(not (STUDY/'heldout/campaign/active.lock').exists(),'Held-out timing or validation still active')
    freeze=read(STUDY/'compiler_freeze.json')
    campaign=STUDY/'heldout/campaign'
    protocol=read(campaign/'protocol.json');analysis=read(campaign/'analysis.json')
    validation=read(campaign/'validation_summary.json');warm_validation=read(campaign/'warmup_validation_summary.json')
    corpus=read(STUDY/'heldout/corpus/manifest.json')
    protocol_sha=sha(campaign/'protocol.json')
    require(protocol_sha==(campaign/'protocol.sha256').read_text().strip(),'Held-out protocol checksum mismatch')
    require(protocol['compiler_freeze_sha256']==sha(STUDY/'compiler_freeze.json'),'Compiler freeze binding mismatch')
    require(protocol['corpus_manifest_sha256']==sha(campaign/'corpus_manifest.json'),'Campaign corpus changed')
    require(sha(campaign/'corpus_manifest.json')==sha(STUDY/'heldout/corpus/manifest.json'),'Source corpus differs from campaign')
    for obj in (analysis,validation,warm_validation):require(obj['protocol_sha256']==protocol_sha,'Unbound held-out analysis/validation')
    require(len(analysis['sessions'])==protocol['sessions']==2,'Expected two complete held-out sessions')
    require(protocol['tools']==list(TOOLS),'Unexpected primary recipes')
    require(all(freeze['versions'].get(name)==version for name,version in protocol['versions'].items()),'Campaign and freeze versions differ')
    expected_cells={(case['id'],tool) for case in protocol['cases'] for tool in TOOLS}
    all_cells=[];failure_ledger=[]
    for i in (1,2):
        directory=campaign/f'session_{i:02d}'
        r=read(directory/'session.json');cells=read(directory/'cells.json')
        require(r['completed'] is True and r['protocol_sha256']==protocol_sha,'Incomplete held-out session')
        for kind in ('timed','warmup'):require(r[kind+'_sha256']==sha(directory/(kind+'.jsonl')),'Changed held-out raw data')
        require(validation['sessions'][i-1]['validated_sha256']==sha(directory/'validated.jsonl'),'Changed held-out validation')
        require(warm_validation['sessions'][i-1]['warmup_validated_sha256']==sha(directory/'warmup_validated.jsonl'),'Changed warmup validation')
        require(len(cells)==len(protocol['cases'])*len(TOOLS),'Incomplete cell table')
        require({(c['case_id'],c['tool']) for c in cells}==expected_cells,'Missing or unexpected cell identity')
        require(analysis['sessions'][i-1]['session']==i,'Session analysis order differs')
        require([c for c in cells if not c['eligible']]==analysis['sessions'][i-1]['excluded_cells'],'Excluded cells differ from analysis')
        all_cells.append(cells)
        failure_ledger.extend({'session':i,**c} for c in cells if not c['eligible'])
    stable=set.intersection(*({(c['case_id'],c['tool']) for c in cells if c['eligible']} for cells in all_cells))
    for session in analysis['sessions']:
        for tool in TOOLS:
            require(session['stable_two_session_cells']['coverage'][tool]==sum(t==tool for _,t in stable),'Stable coverage mismatch')
    cat_root=STUDY/'cat_ghz';cat=read(cat_root/'derived_summary.json');cat_notes=note(cat_root/'FINDINGS.md')
    for field,filename in (('protocol_sha256','protocol.json'),('raw_sha256','raw.jsonl'),('validated_sha256','validated.jsonl')):
        require(cat[field]==sha(cat_root/filename),'Cat/GHZ evidence changed')
    dense=STUDY/'dense'
    baseline_p,baseline_s,baseline_a=bind_dense(dense,'baseline_trace','baseline_accounting.json')
    qr_p,qr_s,qr_a=bind_dense(dense,'qrust_ablation','qrust_ablation_accounting.json')
    sdk_p,sdk_s,sdk_a=bind_dense(dense,'sdk_ablation_v2','sdk_ablation_accounting.json')
    dense_notes=note(dense/'FINDINGS.md');dense_source_notes=note(dense/'SOURCE_NOTES.md');causal=read(dense/'causal_findings.json')
    require(causal['analysis_sha256']==sha(dense/'build_findings.py'),'Dense causal helper changed')
    require(causal['retention_helper_sha256']==sha(dense/'retention_evidence.py'),'Dense retention helper changed')
    for label,name,summary,account in (('baseline','baseline_trace',baseline_s,baseline_a),
            ('qrust_interventions','qrust_ablation',qr_s,qr_a),('sdk_interventions','sdk_ablation_v2',sdk_s,sdk_a)):
        require(causal['studies'][label]['directory']==name,'Dense causal track mismatch')
        for filename,digest in causal['input_bindings'][label].items():
            require(digest==sha(dense/name/filename),'Dense causal input changed: '+filename)
        require(causal['studies'][label]['accounting']==account['cases'],'Dense causal accounting differs')
        require(causal['studies'][label]['profile_parity']==summary['profile_parity'],'Dense causal parity differs')
    revision=read(dense/'sdk_protocol_revision.json')
    require(revision['active_protocol']=='sdk_ablation_v2/protocol.json','Unexpected SDK revision')
    require(revision['revised_protocol_sha256']==sha(dense/'sdk_ablation_v2/protocol.json'),'SDK revised protocol changed')
    require(revision['original_protocol_sha256']==sha(dense/'sdk_ablation/protocol.json'),'Superseded SDK protocol changed')
    dialect_notes=note(STUDY/'reporting/INPUT_DIALECT.md')
    tket_variability_notes=note(STUDY/'reporting/TKET_VARIABILITY.md')
    tket_variability=read(STUDY/'reporting/TKET_VARIABILITY.json')
    require(tket_variability['schema']=='qrust_tket_variability_note_v1','Unknown TKET variability schema')
    require(tket_variability['protocol']['sha256']==protocol_sha,'Unbound TKET variability protocol')
    require(tket_variability['agreement']==analysis['same_seed_session_agreement'],'TKET variability agreement differs')
    require(tket_variability['frozen_seed_policy']==protocol['seed_policy'],'TKET variability seed-policy provenance differs')
    for entry in tket_variability['evidence_files']:
        relative=Path(entry['relative_to_working']);require(not relative.is_absolute(),'Absolute variability evidence key')
        source=(STUDY.parent/relative).resolve()
        require(source.is_relative_to(STUDY.resolve()),'Variability evidence outside study')
        require(sha(source)==entry['sha256'],'Changed TKET variability evidence')
    frozen_sources={entry['path']:entry['sha256'] for group in ('compiler_and_recipe_files','installed_files') for entry in freeze[group]}
    for entry in tket_variability['source_only_hypothesis']['sources']:
        require(frozen_sources.get(entry['path'])==entry['sha256'],'TKET hypothesis source differs from compiler freeze')
    changed=tket_variability['changed_trials']
    require(len(changed)==analysis['same_seed_session_agreement']['by_tool']['tket'].get('quality_changed',0),'TKET changed-trial count differs')
    require(len({(row['case_id'],row['trial_zero_based']) for row in changed})==len(changed),'Duplicate TKET changed-trial evidence')
    for row in changed:
        first,second=row['session_01'],row['session_02']
        require(first['metrics']!=second['metrics'],'TKET changed-trial metrics are unchanged')
        for session,entry in enumerate((first,second),1):
            require(entry['session']==session and entry['tool']=='tket' and entry['case_id']==row['case_id'] and entry['trial']==row['trial_zero_based'],'TKET changed-trial identity differs')
            require(entry['status']=='compiled' and entry['validation_passed'] is True and entry['seed_used'] is False,'Unqualified TKET variability evidence')
    for tool in TOOLS:
        tables=[{c['case_id']:c for c in rows if c['tool']==tool and c['eligible']} for rows in all_cells]
        shared=tables[0].keys() & tables[1].keys()
        changed_medians=sum(any(tables[0][case]['medians'][metric]!=tables[1][case]['medians'][metric] for metric in (*METRICS,'gate_count')) for case in shared)
        require(tket_variability['all_tool_structural_median_agreement'][tool]=={'eligible_matched_cells':len(shared),'cells_with_changed_structural_medians':changed_medians},'TKET note median agreement differs')
    require('pending' not in dense_notes.lower(),'Dense final notes still describe pending work')
    require('pending' not in dense_source_notes.lower(),'Dense source notes still describe pending work')
    figure=read(STUDY/'figures/data.json')
    require(figure['session']==1 and figure['protocol_sha256']==protocol_sha,'Plot belongs to another session/protocol')
    require(figure['plot_script_sha256']==sha(STUDY/'reporting/plot_tradeoffs.py'),'Plot source changed')
    for filename,digest in figure['input_sha256'].items():
        source=(STUDY/filename).resolve()
        require(source.is_relative_to(STUDY.resolve()),'Plot input outside study')
        require(sha(source)==digest,'Plot input changed: '+filename)
    require(set(figure['rendering']['figure_sha256'])=={'tradeoffs.svg','tradeoffs.png'},'Missing plot formats')
    for filename,digest in figure['rendering']['figure_sha256'].items():
        require(sha(STUDY/'figures'/filename)==digest,'Plot image changed')
    for tool in TOOLS[1:]:
        require(figure['panels'][tool]['paired_cases']==analysis['sessions'][0]['stable_two_session_cells']['pairwise'][tool]['paired_cells'],'Plot paired cohort differs')
    require(figure['metrics'] in (['cx_count'],['cx_count','depth']),'Unexpected plot metric contract')
    evidence=args.evidence_relative.rstrip('/')
    count=len(protocol['cases']);fixtures=len({c['fixture'] for c in protocol['cases']});families=sorted({c['family'] for c in protocol['cases']});widths=sorted({c['n_logical'] for c in protocol['cases']})
    L=['# Frozen compiler study: held-out results and routing diagnostics','',
       f'This study freezes the existing four compiler recipes and evaluates **{fixtures} new MQT Bench instances across {count} circuit–target cases**, alongside controlled investigations of the existing Cat/GHZ and dense-Clifford gaps. No production compiler, dependency, recipe or correctness oracle was changed. The held-out results describe the pinned configurations and selected corpus.','',
       '## Frozen configuration and scope','',
       f'Q-Rust timed compiler source: `{freeze["timed_compiler_source_commit"]}`; repository snapshot: `{freeze["repository_commit"]}`. Native binary SHA-256: `{freeze["binary"]["sha256"]}`. The archive includes the frozen Python harness, package versions and installed-file hashes, generator sources, input hashes, schedules and results; installed package payloads remain environment dependencies.','']
    L+=table(['Tool','Pinned version / recipe'],[
        ['Q-Rust','Public O3 pipeline, U/CX basis, deterministic routing'],
        ['Qiskit',protocol['versions']['qiskit']+'; transpile optimization_level=3, exact synthesis, qubits_initially_zero=False'],
        ['Cirq',protocol['versions']['cirq-core']+'; CZ synthesis / RouteCQC / CZ synthesis / CX closure, at most two synthesis iterations per phase'],
        ['TKET',protocol['versions']['pytket']+'; FullPeepholeOptimise / DefaultMappingPass / connectivity-preserving cleanup / U3,CX']])
    L += [f'The held-out corpus contains {len(families)} fixed generator families at {", ".join(map(str,widths))} logical qubits, each on complete, linear and grid connectivity. Grid shapes are 2×3, 2×5 and 4×4; physical width equals logical width. All tools receive the same normalized unitary input and U3/CX target, with free initial/final layouts and ideal bidirectional edges. These are structural costs, not hardware fidelity or calibrated gate durations.','',
          f'All {corpus["counts"]["candidates"]} candidates were prescribed before compiler observations; {corpus["counts"]["selected"]} passed source eligibility and {corpus["counts"]["excluded"]} were excluded without replacement. The source ledger retains every exclusion. QUARK copula/cardinality and random-circuit generators form the unused-generator subset; QAOA, arithmetic and variational cases test new instances of familiar coarse families. Parameter seeds produce related instances. Lexical non-overlap is checked; semantic independence and representative sampling are not established.','',
          'The generators come from [MQT Bench at the pinned revision `2cd3f3b`](https://github.com/munich-quantum-toolkit/bench/tree/2cd3f3b08d5d8866595948fbce955e701e86a5df/src/mqt/bench/benchmarks). This is a custom held-out comparison using those generators and the frozen common recipes, not execution of the complete native Benchpress workout suite or its leaderboard. The existing Benchpress-derived Cat/GHZ and dense cases are separate development diagnostics.','',
          'MQT inputs are generated through pinned Qiskit circuit definitions. Exact definition expansion and the common source normalizer are checked against the independent analytic oracle. This compares the same lowered input across recipes; it does not evaluate each SDK’s best native high-level pipeline or establish full independence from the generating front end. The retained `sxdg` input-dialect boundary illustrates this distinction.','',
          f'Each of two sequential sessions uses one initial warmup and {protocol["trials"]} timed trials per case/tool: {count*len(TOOLS)*protocol["trials"]*2:,} prescribed timed slots and {count*len(TOOLS)*2:,} initial warmups, plus any recorded restart warmups. Fresh persistent workers are used per session. Qiskit receives the same five trial seeds in both sessions; Cirq, TKET and Q-Rust do not consume those seeds in these recipes. Parsing, compilation and complete request time are recorded separately. No diagnostic jobs or validators run concurrently with timing.','',
          'Every timed output and initial/replacement warmup is checked after both sessions. The unchanged analytic oracle uses full numerical unitary/isometry comparison at six qubits and eight fixed input states at ten/sixteen qubits, one shared global phase, a 1e-7 residual threshold and explicit basis/edge/layout checks. The larger general-circuit checks are sampled evidence, not proof. Eligibility requires every prescribed trial and warmup to pass; failures are never replaced with a successful subset.','',
          '## Coverage and retained failures','']
    coverage=[]
    for tool in TOOLS:
        outcomes=[]
        for session in analysis['sessions']:
            outcomes.append(outcome_text({key.split('/',1)[1]:n for key,n in session['timed_outcomes'].items() if key.startswith(tool+'/')}))
        coverage.append([LABELS[tool],analysis['sessions'][0]['per_session_complete_cells']['coverage'][tool],analysis['sessions'][1]['per_session_complete_cells']['coverage'][tool],sum(t==tool for _,t in stable),outcomes[0],outcomes[1]])
    L+=table(['Tool','Eligible S1','Eligible S2','Stable across both','Timed outcomes S1','Timed outcomes S2'],coverage)
    common=[s['stable_two_session_cells']['complete_case_quality']['complete_all_four_cells'] for s in analysis['sessions']]
    require(common[0]==common[1],'Stable four-tool cohort changed between sessions')
    L += [f'The stable four-tool common cohort contains **{common[0]}/{count} cases**. Pairwise comparisons below use their own stable paired cohorts. The [failure ledger]({evidence}/failure_ledger.json) retains every excluded case/tool/session, failure reason and warmup outcome. Source exclusions and all raw statuses remain in the archive.','']
    dialect_failures=[c for c in failure_ledger if c['tool']=='qrust' and 'unknown gate: sxdg' in json.dumps(c).lower()]
    if dialect_failures:
        dialect_cases=sorted({c['case_id'] for c in dialect_failures})
        L += [f'**Q-Rust rejects undeclared `sxdg` in {len(dialect_cases)} distinct circuit–target cases ({len(dialect_failures)} case/session cells).** The frozen normalizer retains primitives supported by its analytic oracle; this vocabulary is broader than the four front ends’ shared input dialect. Qiskit explicitly enables legacy builtin instructions, and the installed Cirq/TKET parsers also recognize `sxdg`; Q-Rust recognizes `sx` but requires a source declaration for the unknown `sxdg` spelling. This is a pipeline/input-dialect interoperability gap, not evidence of wrong quantum mathematics or an OpenQASM 2.0 standards violation. These rejected cells remain failures and contribute no Q-Rust speed or quality scores; all paired means are conditional on supported, verified cases. [Exact source provenance]({evidence}/input_dialect.md).','']
    L += [
          'Worker RSS is sampled approximately every 100 ms, with 2 GiB per worker and 3 GiB aggregate limits including idle workers. Sampling can overshoot, child processes are not included, and observer work is outside compilation timing. Operating-system load, CPU frequency and affinity are not controlled.','']
    paired_identities,agreement_rows=agreement_table(analysis['same_seed_session_agreement'],protocol)
    L += ['### Cross-session consistency','',
          f'The following compares **{paired_identities:,} cross-session paired trial identities** (case, tool, trial), each joining one output or failure from each session. This is not a count of individual outputs. It checks compilation status, validation status, structural metrics and then artifact/map hashes in that order; a matching category does not by itself establish validation eligibility. Any changed quality, status or artifact remains visible. Timing values are not part of this agreement check.','']
    L += agreement_rows
    L += variability_notes(analysis['same_seed_session_agreement'],all_cells)
    L += [f'The [TKET variability evidence and pinned-source inspection]({evidence}/tket_variability.md), with its [machine-readable companion]({evidence}/TKET_VARIABILITY.json), identify the changed requests and distinguish observed output differences from possible mechanisms. A wall-clock placement timeout is a hypothesis, not an isolated cause established by this study.','']
    L += [
          '## Held-out speed and output quality','',
          'Each cell uses the median of all five trials. The primary estimate is an equal-case geometric mean over positive paired ratios on cases eligible for both tools in both sessions. Speed is baseline/Q-Rust (>1 favors Q-Rust); quality is Q-Rust/baseline (<1 favors Q-Rust). Brackets give 95% percentile intervals from 2,000 fixture-cluster bootstrap draws, retaining each fixture’s targets together. These intervals describe this fixed corpus, not all quantum workloads.','']
    rows=[];zeros=[]
    for s in analysis['sessions']:
        for tool in TOOLS[1:]:
            pair=s['stable_two_session_cells']['pairwise'][tool]
            rows.append([s['session'],LABELS[tool],pair['paired_cells'],ratio(pair['compile_ns']),ratio(pair['cx_count']),ratio(pair['depth']),ratio(pair['two_q_depth'])])
            for metric in ('compile_ns',*METRICS):
                z=pair[metric]['zero_cases']
                if sum(z.values()):zeros.append({'session':s['session'],'baseline':tool,'metric':metric,'zero_cases':z,'positive_ratio_cells':pair[metric]['positive_ratio_cells']})
    L+=table(['Session','Baseline','Paired cases','Compile speed','CX ratio','Depth ratio','Two-qubit-depth ratio'],rows)
    L += ['### Timing boundary sensitivity','',
          'The following uses the frozen analysis’s two existing timing endpoints. Compile-only excludes parsing; parse-plus-compile takes each trial’s sum before the cell median. Both use baseline/Q-Rust ratios, the same stable pairing and the existing fixture-cluster intervals. Complete request-wall duration is retained in raw records but is not an aggregate endpoint in the frozen analysis.','']
    boundary_rows=[]
    for session in analysis['sessions']:
        for tool in TOOLS[1:]:
            pair=session['stable_two_session_cells']['pairwise'][tool]
            boundary_rows.append([session['session'],LABELS[tool],pair['paired_cells'],ratio(pair['compile_ns']),ratio(pair['parse_compile_ns'])])
    L += table(['Session','Baseline','Paired cases','Compile-only speed ratio','Parse-plus-compile speed ratio'],boundary_rows)
    qiskit_boundaries=[session['stable_two_session_cells']['pairwise']['qiskit'] for session in analysis['sessions']]
    if all(pair['compile_ns']['geomean'] is not None and pair['parse_compile_ns']['geomean'] is not None
           and pair['compile_ns']['geomean']<1<pair['parse_compile_ns']['geomean'] for pair in qiskit_boundaries):
        L += ['Against Qiskit, the small point-estimate difference changes direction with the timing boundary in both sessions: Q-Rust is slower for compile-only and faster for parse-plus-compile. This boundary sensitivity does not support a robust speed-advantage claim.','']
    if all(pair[metric]['ci95'] is not None and pair[metric]['ci95'][0]<=1<=pair[metric]['ci95'][1]
           for pair in qiskit_boundaries for metric in ('compile_ns','parse_compile_ns')):
        L += ['All four Qiskit timing-boundary confidence intervals include parity.','']
    L += [f'![Session 1 compilation speed and output-cost trade-offs on the stable paired cohorts]({evidence}/tradeoffs.png)','',
          f'The figure displays session 1 cell medians; the table above retains both sessions. Points use stable paired eligibility, and each panel states its full paired denominator and all zero-cost exclusions. Right of one means Q-Rust compiles faster; above one means it uses more CX or greater depth. Colors/shapes distinguish unused generator families from new instances of known families. C/S annotations use the frozen analysis’s largest-CX and lowest-speed tails. [Vector figure]({evidence}/tradeoffs.svg) · [Exact plot data]({evidence}/tradeoffs_data.json).','']
    L+=['Zero numerator/denominator pairs are excluded from logarithmic ratios and counted explicitly; no pseudocount is used. Win/tie/loss and all zero cases remain in the machine-readable report metrics. '+('There are no zero pairs in the aggregate metrics shown above.' if not zeros else f'{len(zeros)} session/baseline/metric entries have zero pairs; see report_metrics.json for their exact counts.'),'',
        'The secondary estimate balances represented generator families rather than individual cases. The family count is explicit because a family absent from an eligible positive-ratio cohort cannot contribute to its geometric mean.','']
    rows=[]
    for s in analysis['sessions']:
        for tool in TOOLS[1:]:
            pair=s['stable_two_session_cells']['pairwise'][tool]
            row=[s['session'],LABELS[tool]]
            for metric in ('compile_ns',*METRICS):
                family=pair[metric]['family_balanced'];row.append(ratio(family)+f' (families {family["families"]})')
            rows.append(row)
    L+=table(['Session','Baseline','Balanced speed','Balanced CX','Balanced depth','Balanced two-qubit depth'],rows)
    L+=['### Unused generators versus new instances of known families','',
        'These strata test two different kinds of transfer. Ratios below use the same stable qualification rule; they are not a new independent sample of compiler behavior. Entries show session 1 / session 2.','']
    groups=analysis['sessions'][0]['stable_two_session_cells']['by_holdout_class'];rows=[]
    for group in sorted(groups):
        for tool in TOOLS[1:]:
            pairs=[s['stable_two_session_cells']['by_holdout_class'][group][tool] for s in analysis['sessions']]
            require(pairs[0]['paired_cells']==pairs[1]['paired_cells'],'Stable stratum coverage changed')
            rows.append([group.replace('_',' '),LABELS[tool],pairs[0]['paired_cells'],*[' / '.join(ratio(p[m],False) for p in pairs) for m in ('compile_ns',*METRICS)]])
    L+=table(['Stratum','Baseline','Cases','Speed S1 / S2','CX S1 / S2','Depth S1 / S2','Two-qubit depth S1 / S2'],rows)
    L+=['### Important adverse tails','',
        'The following are the weakest Q-Rust speed/CX/depth comparisons selected mechanically from the stable cohort in session 1. A speed ratio above one can still be the weakest observed speed result; it is not labeled a loss. Full tails for both sessions and separate family/width/target summaries are retained in the analysis.','']
    rows=[];tail_records=[]
    for tool in TOOLS[1:]:
        tails=analysis['sessions'][0]['stable_two_session_cells']['worst_tails'][tool]
        for key,label in (('slowest_relative_cases','lowest speed ratio'),('worst_cx_count','largest CX ratio'),('worst_depth','largest depth ratio')):
            if not tails[key]:continue
            item=tails[key][0];tail_records.append({'tool':tool,'selection':label,**item})
            q,b=item['qrust'],item['baseline']
            rows.append([LABELS[tool],label,compact_case(item['case_id']),fmt(item['compile_speed_ratio'])+'×',f'{q["cx_count"]} / {b["cx_count"]}',f'{q["depth"]} / {b["depth"]}'])
    L+=table(['Baseline','Selection','Case','Speed ratio','CX Q-Rust / baseline','Depth Q-Rust / baseline'],rows)
    L+=['## Cat/GHZ: why the CX gap occurs','',
        'The four development inputs are H plus a CX chain. Each target contains a path that realizes the complete unitary with no routing SWAP. Qiskit’s default trace uses VF2Layout; Cirq’s LineInitialMapper and TKET’s GraphPlacement likewise find zero-SWAP paths. Q-Rust’s default initial layouts miss that opportunity.','']
    rows=[]
    for case in cat['cases']:
        q=case['baselines']['qrust'];stages={p['pass']:p for p in q['stages']}
        require(all(case['baselines'][tool]['all_input_validation'] for tool in TOOLS),'Unqualified Cat baseline')
        relabel=case['qrust_controls']['path_relabel'];require(relabel['all_input_validation'],'Unverified Cat path control')
        rows.append([case['case_id'],case['source_cx'],stages['BeamSabrePass']['swaps'],stages['TargetBasisPass']['two_qubit_gates'],q['metrics']['cx_count'],relabel['metrics']['cx_count'],' / '.join(str(case['baselines'][t]['metrics']['cx_count']) for t in TOOLS[1:])])
    L+=table(['Case','Input CX','Q-Rust SWAPs','CX after lowering','Final Q-Rust CX','Path-relabel CX','Qiskit / Cirq / TKET CX'],rows)
    L += ['Relabeling only the physical graph around a witnessed path lets the unchanged Q-Rust binary attain 21/22 CX. Outputs/maps are restored to original physical labels before all-input Clifford isometry checks. This demonstrates heuristic label sensitivity and attainable zero-SWAP placement, not a fixed-layout API. Disabling Clifford simplification, block synthesis, or both leaves the default final costs unchanged. Forty layout trials change only GHZ-heavy-hex, 52→50 CX; six layout iterations change none.','',
          'For these four cases, n−1 CX is a proven lower bound under the unitary one-qubit/CX contract: the product-zero input must become an n-output GHZ state, requiring a connected interaction component. The independently checked path witness also implements the full input unitary and attains that bound. This limited optimum claim does not extend to the remaining benchmarks.','',
          'Qiskit optimization-stage omission and TKET pre/post-cleanup omissions preserve their minimal counts. TKET identity placement introduces substantial verified routing overhead, while fixed path placement restores the minimum. Cirq’s default CZ synthesis round trip preserves optimal CX but produces depth 43/45; omitting both synthesis stages preserves correctness and yields depth 22/23. This is a cost of the chosen Cirq recipe, not its best possible configuration.','',
          f'Cat/GHZ evidence: {cat["counts"]["verified_interventions"]} verified compiler interventions plus {cat["counts"]["verified_analytic_witnesses"]} verified witnesses; {cat["counts"]["unsupported_compiled_interventions"]} unsupported compiled controls and {cat["counts"]["error_interventions"]} retained errors. {cat["counts"]["exact_sdk_trace_native_pairs"]} SDK trace/native pairs match exactly; {cat["counts"]["qualified_negative_controls_rejected"]} qualified phase/map/edge negative controls are rejected. Unsupported local decompositions are not labeled incorrect. [Full Cat/GHZ evidence and limitations]({evidence}/cat_ghz_findings.md).','',
          '## Dense Clifford20: where compilation time goes','',
          'These controlled tests use one existing 20-logical-qubit development circuit on two larger physical graphs. Their instrumented durations are diagnostic and separate from held-out speed measurements. Per-request stage groups are summed first, divided by that request’s total, and then summarized; separately computed stage medians are not added into a false total.','']
    baseline_index={(c['case_id'],c['recipe']):c for c in baseline_a['cases']};rows=[]
    for cid in sorted({c['case_id'] for c in baseline_a['cases']}):
        raw=baseline_index[cid,'qrust_default_unprofiled'];profile=baseline_index[cid,'qrust_default_profiled'];m=med_metrics(raw)
        require(med_metrics(profile)==m,'Profiled/unprofiled dense baseline quality differs')
        rows.append([cid,fmt(raw['compile_median_ns']/1e9)+' s',fmt(100*profile['median_per_request_share']['beam_routing'])+'%',fmt(100*profile['median_per_request_share']['layout_search'])+'%',f'{m["cx_count"]} / {m["depth"]} / {m["two_q_depth"]}'])
    L+=table(['Target','Unprofiled compile median','Beam-routing share','Layout-search share','CX / depth / two-qubit depth'],rows)
    L+=['The dominant work is beam routing. The frozen O3 routine repeatedly searches forward and backward with multiple active candidate states. The frozen pipeline routes two distinct prepared Clifford continuations before applying its final-output quality guard. Source inspection also identifies state copying, candidate scoring/ranking and retained alternatives; allocation-level contributions are not separately measured. Distances are precomputed per route, so repeated shortest-path search for every candidate is not the explanation.','',
        '### Controlled Q-Rust changes','',
        'Each row below is a verified diagnostic intervention, not a production update. Speed ratios compare its profiled median with the profiled default recorded in the same diagnostic campaign. Quality columns show intervention minus default; positive values are worse.','']
    index={(c['case_id'],c['recipe']):c for c in qr_a['cases']};rows=[];dense_unpaired=[]
    dense_unqualified=[{'track':track,'case_id':c['case_id'],'recipe':c['recipe'],'outcomes':c['outcomes_including_warmup']}
                       for track,account in (('baseline_trace',baseline_a),('qrust_ablation',qr_a),('sdk_ablation_v2',sdk_a))
                       for c in account['cases'] if not c['all_verified']]
    for case in qr_a['cases']:
        if case['recipe']=='qrust_default_profiled':continue
        default=index[case['case_id'],'qrust_default_profiled']
        if not (case['all_verified'] and default['all_verified']):
            if case['all_verified']:dense_unpaired.append({'case_id':case['case_id'],'recipe':case['recipe'],'reference':default['recipe']})
            continue
        m,b=med_metrics(case),med_metrics(default)
        rows.append([case['case_id'],case['recipe'],fmt(default['compile_median_ns']/case['compile_median_ns'])+'×',*[f'{m[k]-b[k]:+g}' for k in METRICS]])
    L+=table(['Target','Intervention','Diagnostic speed ratio','Δ CX','Δ depth','Δ two-qubit depth'],rows)
    if dense_unpaired:L += [f'{len(dense_unpaired)} verified intervention cells lack a verified default reference; no paired effect is reported. Their identities remain in the failure/reference ledger.','']
    L+=['### SDK controls on the same dense input','',
        'Only complete independently verified diagnostic cells are shown with quality and compilation medians. Native entries use the unchanged adapters; instrumented entries include callback/stage-probe work and are labeled separately. These durations are diagnostic, not native comparative speed estimates. Recipe omissions alter optimization effort; they are not equal-budget searches. Every unsupported output, timeout and error is retained below and in the full diagnostic notes. The SDK v2 protocol replaced a statically inapplicable native-CX arm with one-pass Cirq synthesis before any SDK execution; the original unexecuted protocol and revision rationale are preserved.','']
    rows=[]
    for case in sdk_a['cases']:
        if not case['all_verified']:
            continue
        m=med_metrics(case)
        timing='native' if case['recipe'] in ('qiskit_original','tket_original','cirq_frozen') else 'instrumented'
        rows.append([case['case_id'],case['recipe'],timing,fmt(case['compile_median_ns']/1e9)+' s',m['cx_count'],m['depth'],m['two_q_depth']])
    L+=table(['Target','Recipe','Timing kind','Diagnostic compile median','CX','Depth','Two-qubit depth'],rows)
    if dense_unqualified:L+=table(['Track','Target','Recipe','Unqualified outcomes'],[[r['track'],r['case_id'],r['recipe'],outcome_text(r['outcomes'])] for r in dense_unqualified])
    else:L+=['All prescribed dense diagnostic cells independently verified.','']
    L += [f'The [full dense investigation]({evidence}/dense_findings.md) and [pinned source details]({evidence}/dense_source_notes.md) retain pass specifications, per-request traces, alternate-candidate selection evidence and remaining causal limits. The causal records are bound in the archive; unsupported local-Clifford decompositions do not establish semantic failure.','',
          '## What this study establishes and what remains open','',
          'The Cat/GHZ controls isolate an available placement improvement and explain the competitors’ minimal CX. The dense controls locate the dominant runtime and test selected search/optimization trade-offs. The held-out run tests transfer to new inputs without changing the frozen compilers or selecting replacements from their outcomes.','',
          'This does not establish the best possible settings of each SDK, equal optimization effort, language-level causality, optimality outside the witnessed Cat/GHZ cases, calibrated hardware fidelity or comprehensive state-of-the-art coverage. Larger non-Clifford checks remain sampled, related generator instances are not independent families, and two sessions of warm-process timing on one host do not characterize all platforms. Diagnostics explain tested mechanisms; they do not attribute every remaining score to a unique internal cause.','',
          '## Reproducibility and preservation','',
          f'[Evidence archive]({evidence}/evidence.tar.gz), [checksums]({evidence}/checksums.json), [report metrics]({evidence}/report_metrics.json) and [failure ledger]({evidence}/failure_ledger.json). The archive retains frozen generator/recipe/source hashes, original inputs, schedules, raw outcomes, warmups, errors, validation, analysis and diagnostic interventions. Historical results remain unchanged in their earlier versioned directories and are checked against the preservation manifest.','',
          'After fresh extraction, use the supplied replay helpers to validate saved outputs and rederive summaries in the pinned environment. They do not rerun compilers. Every compiler/parse/request/pass measurement and verdict/map must remain identical; only an explicitly identified fresh verifier duration and its independently checked derived hash may differ. Exact installed-file hashes are more restrictive than version numbers, and the native binary remains specific to its original host architecture. Archive audit/replay completion is documented in the separate receipts, not inferred from the report generator.','']
    report='\n'.join(L)
    exports.mkdir(parents=True)
    write_new(exports/'cat_ghz_findings.md',cat_notes)
    write_new(exports/'dense_findings.md',dense_notes.rstrip()+'\n\n[Complete pinned source inspection and baseline accounting](./dense_source_notes.md).\n')
    write_new(exports/'dense_source_notes.md',dense_source_notes)
    write_new(exports/'input_dialect.md',dialect_notes)
    write_new(exports/'tket_variability.md',tket_variability_notes.rstrip()+'\n\n[Exact machine-readable companion](./TKET_VARIABILITY.json).\n')
    write_new(exports/'TKET_VARIABILITY.json',(STUDY/'reporting/TKET_VARIABILITY.json').read_text())
    for filename in ('tradeoffs.png','tradeoffs.svg'):
        with (exports/filename).open('xb') as stream:stream.write((STUDY/'figures'/filename).read_bytes())
    write_new(exports/'tradeoffs_data.json',(STUDY/'figures/data.json').read_text())
    json_new(exports/'failure_ledger.json',{'protocol_sha256':protocol_sha,'excluded_cells':failure_ledger,'source_exclusions':analysis['source_exclusions'],'cat_unsupported_or_errors':cat['unsupported_or_errors'],'dense_unqualified_cells':dense_unqualified,'dense_qualified_without_reference':dense_unpaired})
    write_new(args.output,report)
    metrics={'schema':1,'renderer_sha256':sha(Path(__file__)),'report_sha256':sha(args.output),'input_sha256':dict(sorted(INPUTS.items())),'heldout_protocol_sha256':protocol_sha,'counts':{'fixtures':fixtures,'cases':count,'families':len(families),'stable_four_tool_cases':common[0]},'sessions':[{k:s[k] for k in ('session','timed_outcomes','stable_two_session_cells')} for s in analysis['sessions']],'aggregate_zero_entries':zeros,'displayed_tails':tail_records,'cat_counts':cat['counts'],'dense_counts':{'baseline':baseline_s['counts'],'qrust_ablation':qr_s['counts'],'sdk_ablation_v2':sdk_s['counts']},'same_seed_session_agreement':analysis['same_seed_session_agreement']}
    json_new(exports/'report_metrics.json',metrics)
    print(json.dumps({'report':str(args.output),'report_sha256':sha(args.output),'exports':str(exports),'cases':count,'paired_stable':{t:analysis['sessions'][0]['stable_two_session_cells']['pairwise'][t]['paired_cells'] for t in TOOLS[1:]}}))


if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--study',type=Path,default=STUDY);p.add_argument('--output',type=Path,required=True);p.add_argument('--exports',type=Path,required=True);p.add_argument('--evidence-relative',default='./external_results/20261018_frozen_heldout')
    render(p.parse_args())
