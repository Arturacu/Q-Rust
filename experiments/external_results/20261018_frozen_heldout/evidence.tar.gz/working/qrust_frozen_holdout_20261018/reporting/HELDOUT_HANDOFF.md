# Frozen held-out comparison handoff

All scheduled work completed: two sequential timing sessions, validation after both sessions, then the unchanged analysis. Existing evidence and frozen compiler recipes are preserved. The CPU slot has been released.

The selection contains 30 fixtures and 90 target cases at 6, 10 and 16 qubits on complete, line and grid targets. All candidates were admitted. Fifteen fixtures use untouched generators; fifteen are new instances from previously studied families. The common qualified cohort contains 28 fixtures and 84 cases: 39/45 cases from untouched generators and 45/45 from known-family transfer.

All 3,540 compiled timed outputs and 708 compiled warmups passed independent checks. The 60 timed errors and 12 warmup errors are all Q-Rust rejecting `sxdg` in random-circuit inputs at widths 10 and 16 on the three targets. These are input-dialect interoperability failures; every failed slot is retained. There were no timeouts, memory-limit events or replacement warmups. Validation covered 536 unique timed artifacts: 169 full-isometry and 367 sampled-isometry; maximum residual 2.36345e-12.

Each cell uses five timed trials per session. The table gives equal-case geometric means on the stable 84-case cohort. Speed means baseline / Q-Rust; quality means Q-Rust / baseline. Intervals are 95% fixture-cluster bootstrap intervals over this fixed corpus.

| Baseline | Compile speed ratio, session 1 [95% CI] | Session 2 [95% CI] | CX ratio | Depth ratio | Two-qubit depth ratio |
|---|---:|---:|---:|---:|---:|
| qiskit | 0.9648 [0.7795, 1.177] | 0.9605 [0.7785, 1.205] | 0.9527 | 0.8998 | 0.9712 |
| cirq | 56.39 [49.08, 64.81] | 56.29 [48.78, 64.74] | 0.8114 | 0.5944 | 0.8012 |
| tket | 145.7 [121.9, 172.1] | 145.6 [123.6, 170.5] | 0.8418 | 0.8540 | 0.8341 |

Quality cell medians and their aggregate ratios agree across sessions. Warm compile time is about 3.6–4.1% slower than Qiskit in the point estimate; the intervals include parity. Parse-plus-compile ratios are 1.0276 and 1.0226 versus Qiskit, so the measured boundary changes the small point-estimate advantage. The much larger speed ratios against these Cirq and TKET recipes do not establish equal-effort or universal compiler superiority.

Family-balanced compile speed ratios, giving equal weight to the six fixed generators:

| Baseline | Session 1 [95% CI] | Session 2 [95% CI] |
|---|---:|---:|
| qiskit | 0.9505 [0.8003, 1.141] | 0.9421 [0.7954, 1.138] |
| cirq | 59.49 [55.18, 63.88] | 59.48 [55.36, 64] |
| tket | 147 [134.6, 159.5] | 147.2 [135.5, 159.9] |

The structured handoff preserves confidence intervals and family-balanced results for every metric and all prespecified strata: holdout class, coarse family, generator, width and topology. These intervals describe variation within a small fixed corpus, not a representative population of quantum workloads.

Q-Rust matches or improves the best observed baseline CX count in 72/84 cases (85.7%) and lies within 5% in 76/84 (90.5%). Depth has the same counts; two-qubit depth is best in 70/84, within 5% in 71/84 and within 10% in 73/84. The best observed baseline is not an optimum.

The tails remain material (session 1 cell medians):

- VQE-16 seed 11 on a line: Q-Rust 398.9 ms versus Qiskit 60.2 ms, with 1,010 versus 812 CX, although Q-Rust total depth is 277 versus 300.
- VQE-6 seed 11 on the grid: Q-Rust 83 CX versus Qiskit 65, Cirq 70 and TKET 77.
- Copula-16 seed 11 on a line: Q-Rust depth 289 versus Qiskit 222, despite 495 versus 500 CX.
- VQE-10 seed 11 on the grid: Q-Rust two-qubit depth 96 versus Qiskit 56.
- Draper adder-16 with complete connectivity: Q-Rust depth 137 versus TKET 118 at equal 176 CX.

TKET has seven changed trial outputs across three cells, although every cell structural median is unchanged. See `TKET_VARIABILITY.md` and its hash-bound JSON companion for exact pairs and the source-only timeout hypothesis. The frozen protocol’s non-Qiskit determinism expectation is contradicted by this observation.

Prerequisite checks: 19 protocol tests and all four frozen adapters on an unrelated explicit-grid smoke test passed before formal execution. The complete result, intervals, strata, worst two tails per metric and baseline, exclusions, execution receipt and frozen provenance are in `heldout_final_handoff.json`.

Limits: ideal synthetic targets and structural costs; numerical evidence rather than formal proof; sampled checks at 10/16 qubits; pinned configured recipes with unequal search effort; related seeds and only six generators. This study does not identify every cause of every score, demonstrate hardware fidelity, establish optimality, or isolate a Rust-language speed benefit.
