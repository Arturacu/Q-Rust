"""Pure formula/zero-policy checks; no rendering, packages or campaign execution."""
import math
import unittest
from plot_tradeoffs import axis_limits,ratio_value


class TradeoffFormulaTests(unittest.TestCase):
    def test_compile_and_quality_direction(self):
        # The compiler costs twice as much time but half the CX of its baseline.
        self.assertEqual(ratio_value(10,20),(0.5,None))
        self.assertEqual(ratio_value(3,6),(0.5,None))

    def test_each_zero_case_is_preserved_without_pseudocount(self):
        self.assertEqual(ratio_value(0,0),(None,'both_zero'))
        self.assertEqual(ratio_value(0,2),(None,'numerator_zero'))
        self.assertEqual(ratio_value(2,0),(None,'denominator_zero'))

    def test_invalid_costs_fail(self):
        for value in (-1,True,math.nan,math.inf):
            with self.assertRaises(ValueError):ratio_value(value,1)
        for numerator,denominator in ((1e300,1e-300),(1e-300,1e300)):
            with self.assertRaises(ValueError):ratio_value(numerator,denominator)

    def test_log_axes_include_reference_and_all_points(self):
        lower,upper=axis_limits([.02,200])
        self.assertTrue(0<lower<.02<1<200<upper)


if __name__=='__main__':unittest.main()
