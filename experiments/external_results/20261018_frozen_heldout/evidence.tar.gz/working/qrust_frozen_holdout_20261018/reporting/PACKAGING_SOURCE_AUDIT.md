# Packaging and held-out replay source audit

This review inspected the prepared `package_study.py`, `replay_heldout.py`, shared archive primitives, and the output-path boundary in `replay_controls.py` against the final frozen held-out harness. It used source reads only while the dense-control experiment held the CPU reservation. No tests, Python helpers, hashing of large inventories, numerical validation, compiler calls or replay were executed. No frozen study file or prepared helper was edited by this reviewer.

The findings below concern prepared packaging/replay guards. They are not defects in the completed held-out experiment or evidence that its outcomes changed.

## Output isolation findings

1. The inspected `package_study.py` checked path freshness and lexical containment under the study, but did not normalize paths or reject containment between destination and scratch. A destination such as `<scratch>/stage/export` would put the archive inside the staged tree being archived. Reject both ancestor directions between resolved destination and scratch, and reject either output under the resolved source study, before creating any directory. Resolve existing symlink parents and `..` components rather than relying on lexical `is_relative_to` comparisons.
2. The inspected `replay_heldout.py` required a new output directory, but permitted creating it inside the freshly extracted evidence tree. This would add replay products to the immutable extraction even without overwriting existing files. Require a resolved output outside the extracted archive root, with an explicit rule for identifying that root.
3. `replay_controls.py` had the same output-isolation gap in `Replay.__init__`: it resolved the study but created `output.absolute()` without rejecting a fresh nested output. Apply the same resolved archive-root isolation rule to both replay entry points.

These findings were sent to the parent agent before any edit. The parent added the guards to the prepared helpers, and a second source-only read confirmed their wiring before directory creation. `check_output_paths` resolves all three paths, checks output freshness, and rejects every pair's equality or ancestor relationship. Both replay helpers now use `isolated_output`, which resolves paths and rejects output inside or above the extracted archive root, defined by the documented `<archive>/working/<study>` layout.

The parent added two packaging tests for normalized nesting and symlink aliases, plus one isolation test for each replay helper covering nested, symlink and dot-component paths. These tests remain unexecuted at the time of this audit. The planned real output paths were already outside the source/archive trees. This note does not claim the tests or a fresh replay have passed; later receipts establish execution status.

## Held-out dependency and relocation assessment

No missing held-out replay input was identified in the inspected package layout:

- The complete study tree contains the four frozen held-out Python files, plan, selection ledger, prior-input inventory, original generated artifacts, source/normalized corpus, campaign manifest, frozen protocol, session receipts, raw timed/warmup outcomes, saved validation, cells and aggregate analysis.
- Frozen tracked Rust/Cargo and experiment Python files are copied with their recorded hashes. The additional `compiler_provenance.compiler_source_sha256` loop covers every Rust/Cargo file required by the inherited runtime inventory, including ignored diagnostic sources. Requirements files are copied separately because the frozen recipe contract includes `requirements-comparison.txt`.
- The frozen native binary and pinned MQT source mirror are included at the paths supplied to relocated validation. The additional benchmark mirrors and frozen Benchpress catalog support the diagnostic tracks. Installed distribution payloads remain environment dependencies; their versions and exact file hashes are recorded and rechecked. Installing the same version numbers alone is insufficient for strict replay.
- The replay creates a fresh campaign from protocol/checksum/corpus manifest plus each session's receipt and raw timed/warmup files. These are the inputs consumed by the unchanged validation and analysis paths. Existing validated files are comparison references, not substituted as fresh validation outputs.
- Relocation is restricted to `validate` and `analyze`. It changes source-directory prefixes and installed-environment prefix resolution while retaining the frozen file sizes, hashes, package/Python versions, plan equality, source inventory, binary hash, corpus reconstruction, schedules and raw-session hash checks. The replay launches fresh subprocesses through the caller's Python executable without resolving away a virtual-environment executable path.
- Archive extraction accepts only unique regular members with safe relative names, rejects links and traversal, and verifies the complete member inventory and each payload digest against the manifest. The outer checksums separately bind the manifest and archive.

The existing completion gate verifies every entry listed in `completion.json`; final integration must populate that ledger with the final held-out and diagnostic outputs before packaging. The guard is not a replacement for fresh-extraction replay.

## Replay comparison assessment

No overbroad semantic exclusion was found in `replay_heldout.py`:

- Row comparison removes only the explicitly located `validation.validation_ns` field. Compilation, parsing, request-wall timings, resource samples, statuses, layouts, output strings/hashes, oracle verdicts, residuals and structural metrics remain compared.
- Validation-summary row-file hashes are removed only after each original and recomputed hash has been checked against its actual file. All remaining summary fields are compared.
- Both `cells.json` and `cells.csv`, and the complete `analysis.json`, must be byte-identical. This preserves qualification, every prespecified aggregate/stratum, tails, confidence intervals, and trial-agreement counts.
- The diagnostic replay likewise limits duration exclusions to `validation.validation_ns` and named negative-control verifier durations. Its derived validation/summary hashes are checked before exclusion, and all compiler/pass timers remain part of equality. The brief diagnostic inspection was an output-boundary and exclusion check, not a second full audit of every diagnostic intervention.

Numerical replay may fail if the runtime or numerical execution environment differs; the correct response is to retain that failure and investigate it. Broadening field exclusions or accepting changed residuals to obtain a passing receipt would weaken the established contract. Successful fresh execution is still required after the CPU reservation ends.
