"""Small fail-closed reporting boundaries; no compiler or campaign execution."""
import json
from pathlib import Path
from tempfile import TemporaryDirectory
from types import SimpleNamespace
import unittest

import render_report as report


class ReportingBoundaryTests(unittest.TestCase):
    def setUp(self):
        self.temp=TemporaryDirectory()
        self.root=Path(self.temp.name)
        self.original_study=report.STUDY
        report.STUDY=self.root
        report.INPUTS.clear()

    def tearDown(self):
        report.STUDY=self.original_study
        report.INPUTS.clear()
        self.temp.cleanup()

    def put(self,path,value):
        path.parent.mkdir(parents=True,exist_ok=True)
        path.write_text(json.dumps(value))

    def dense_stub(self,completed,receipt_hash):
        directory=self.root/'dense'/'track'
        self.put(directory/'protocol.json',{'schedule':[]})
        digest=report.sha(directory/'protocol.json')
        self.put(directory/'receipt.json',{'completed':completed,'protocol_sha256':receipt_hash})
        self.put(directory/'summary.json',{'protocol_sha256':digest})
        self.put(self.root/'dense'/'accounting.json',{'protocol_sha256':digest})
        return self.root/'dense'

    def test_missing_final_evidence_fails_before_outputs(self):
        args=SimpleNamespace(study=self.root,exports=self.root/'exports',output=self.root/'report.md')
        with self.assertRaisesRegex(ValueError,'Missing final report input'):
            report.render(args)
        self.assertFalse(args.exports.exists())
        self.assertFalse(args.output.exists())

    def test_incomplete_dense_receipt_is_not_reportable(self):
        root=self.dense_stub(False,'irrelevant')
        with self.assertRaisesRegex(ValueError,'Dense diagnostic incomplete'):
            report.bind_dense(root,'track','accounting.json')

    def test_changed_dense_protocol_binding_fails(self):
        root=self.dense_stub(True,'bad protocol digest')
        with self.assertRaisesRegex(ValueError,'Dense protocol binding mismatch'):
            report.bind_dense(root,'track','accounting.json')

    def test_unqualified_dense_cost_cannot_be_displayed(self):
        with self.assertRaisesRegex(ValueError,'unqualified dense output quality'):
            report.med_metrics({'all_verified':False,'requests':[{'metrics':{'cx_count':1}}]})
        invalid={'cx_count':-1,'depth':1,'two_q_depth':1,'gate_count':1}
        with self.assertRaisesRegex(ValueError,'Invalid dense structural cost'):
            report.med_metrics({'all_verified':True,'requests':[{'metrics':invalid}]*3})

    def test_zero_logarithmic_ratio_is_not_formatted_as_score(self):
        self.assertEqual(report.ratio({'geomean':None,'ci95':None}),'—')
        for value in (0,-1):
            with self.assertRaisesRegex(ValueError,'Nonpositive logarithmic ratio'):
                report.ratio({'geomean':value,'ci95':None})

    def test_cross_session_categories_preserve_changes_and_pair_denominator(self):
        categories=('identical_artifact','quality_changed','compile_status_changed','same_nonsuccess_status')
        per_tool={tool:{category:2} for tool,category in zip(report.TOOLS,categories)}
        agreement={'counts':{category:2 for category in categories},'by_tool':per_tool}
        denominator,lines=report.agreement_table(agreement,{'cases':[{},{}],'trials':1})
        self.assertEqual(denominator,8)
        self.assertIn('quality_changed: 2','\n'.join(lines))
        self.assertIn('compile_status_changed: 2','\n'.join(lines))
        agreement['counts']['quality_changed']=3
        with self.assertRaisesRegex(ValueError,'aggregate/by-tool mismatch'):
            report.agreement_table(agreement,{'cases':[{},{}],'trials':1})

    def test_variability_disclosure_is_derived_not_hardcoded(self):
        agreement={'by_tool':{
            'qrust':{'identical_artifact':3,'same_nonsuccess_status':1},
            'qiskit':{'identical_artifact':4},'cirq':{'identical_artifact':4},
            'tket':{'identical_artifact':2,'quality_changed':2}}}
        text='\n'.join(report.variability_notes(agreement))
        self.assertIn('Observed TKET variability',text)
        self.assertIn('2 of 4 matched-request/corresponding-trial pairs',text)
        self.assertIn('Q-Rust (3 compiled pairs)',text)
        self.assertIn('not an empirical result',text)
        self.assertNotIn('7 of 450',text)
        left={'case_id':'fixture/linear','tool':'tket','eligible':True,
              'medians':{'cx_count':10,'gate_count':20,'depth':12,'two_q_depth':8}}
        right={**left,'medians':dict(left['medians'])}
        self.assertIn('0 of 1 cells qualified','\n'.join(report.variability_notes(agreement,[[left],[right]])))
        right['medians']['depth']=13
        self.assertIn('1 of 1 cells qualified','\n'.join(report.variability_notes(agreement,[[left],[right]])))


if __name__=='__main__':unittest.main()
