# Prepared reporting and replay helper source audit

This is a source-only audit conducted during the second formal timing session. It records no test, plot, validation or replay execution. The frozen held-out harness, compilers, recipes, inputs and prior results were not edited.

The report and plot follow the frozen `analyze_comparison_study.py` ratio direction: baseline/Q-Rust for compilation time and Q-Rust/baseline for structural costs. Stable eligibility intersects each case/tool across both sessions, then constructs baseline-specific pairs. The plot uses session-1 cell medians, checks all pair/positive/zero counts and geometric ratios against the saved analysis, and imports its existing tail selections rather than changing tie-breaking. Both report and plot now require the exact protocol-prescribed cell identities and ordered session records. Paired-trial agreement counts are 1,800 cross-session pairs for this protocol, not 3,600 individual outputs.

The audit made these changes only to prepared helpers and their tests:

- Corrected archive wording: installed distribution versions and file hashes are retained; package payloads remain environment dependencies.
- Preserved every unqualified dense cell, including default-reference failures; a verified intervention without a verified reference has no paired effect reported.
- Labeled native SDK timing separately from instrumented timing. Callback/stage-probe costs are diagnostic and are not promoted into native speed estimates.
- Required verified equal structural costs for the profiled/unprofiled dense baseline and qualified Cat/GHZ baselines before using them in causal tables.
- Added standalone plot checks for raw/validation receipts, exact cell identities, positive compilation ratios and numeric overflow/underflow. Zero costs retain separate numerator/baseline/both-zero counts and receive no pseudocount.
- Reset Matplotlib defaults before explicit styles; fixed SVG IDs, suppressed date metadata, and recorded rendering versions plus the resolved font-file digest. Byte reproducibility remains scoped to the same rendering dependencies and must be tested after timing.
- Extended diagnostic replay to check the shared freeze's complete installed-file inventory and Python/package versions, with only the environment prefix relocated. The original dense helper's fixed binary constant is checked as well as its protocol hash.
- Added replay boundary tests for path traversal and same-length installed-file mutation, and strengthened structural-cost/ratio boundary tests. No tests were run during timing.
- Added the pinned upstream MQT generator source link and an explicit distinction between this custom held-out comparison and a complete native Benchpress workout/leaderboard run.

The existing interpretation limits remain: `sxdg` is an input-dialect interoperability gap, not a demonstrated standard violation or wrong mathematical transformation; the same lowered input is generated through pinned Qiskit definitions; sampled 10/16-qubit checks are evidence rather than proof; timing is warm-process, single-host evidence. The Cat/GHZ path relabel is label-sensitivity evidence, not a forced-layout API. The n−1 CX optimum applies only to the four witnessed GHZ-producing circuits under the one-qubit/CX unitary contract, with full-unitary witnesses checked separately from the product-state lower-bound argument. Unsupported counterfactual decompositions remain unverified.

Remaining execution checks are deliberately deferred until the formal timing reservation ends: all helper tests, complete saved-artifact replay, plot rendering and visual inspection, repeat-render byte comparison, final report generation and fresh-archive replay. The report refuses absent final diagnostic notes or incomplete bound evidence.
