# Independent read-only audit

Scope: frozen held-out selection, timing, qualification and analysis source; inherited comparison adapters/oracle; new archive and diagnostic replay design. This audit was performed by source inspection while the held-out timing sessions were active. No compiler, selected fixture, frozen harness, recipe, timing process or prior result was changed, and no tests or numerical replay were executed during that reservation.

## Timing and correctness assessment

No defect requiring a timing restart was identified in the inspected code.

- Selection fixes all 30 candidates and retains source-eligibility failures without replacement. Source normalization is checked before final study freeze. The selection describes lexical non-overlap as a limited check, distinguishes new instances of known families from previously unused generator families, and keeps related QUARK families identifiable.
- The controller reuses the four production recipes, fixes the same five Qiskit trial seeds across sessions, and records deterministic-seed limitations for the other recipes. Randomized order is rebuilt and checked against the frozen schedule. Each session has fresh persistent workers, with startup/parse/request timing distinguished from compiler timing.
- Every prescribed timed identity and initial warmup is required. Restarts cause explicit replacement warmups; unsuccessful requests remain in the data. Eligibility requires all five timed trials plus all initial/replacement warmups to compile and independently validate. No successful-trial subset replaces a failed cell.
- Source and normalized QASM, full target edges, physical width, output QASM and both input/output maps are bound in artifact hashes. Validation uses the frozen map-aware oracle and checks retained outputs after both sessions; it does not substitute recompilations. The greater-than-six-qubit check remains sampled evidence and is correctly identified as such.
- Stable paired comparisons require both tools to qualify in both sessions. The four-tool common cohort is separate. Ratios use medians within cells, geometric means across positive paired ratios, explicit zero counts and win/tie/loss counts. Bootstrap clusters retain a fixture's target topologies together. The method explicitly limits interpretation to this fixed corpus and acknowledges related parameterized instances.
- All worker RSS is sampled by unique PID, including idle workers. The resource policy records its sampling/child-process limitations. Ordinary operating-system load and CPU frequency remain uncontrolled and are disclosed.

## Archive consistency hardening

The first package design copied the tracked compiler/recipe freeze, while held-out runtime verification independently enumerates all Rust/Cargo sources through `source_provenance()`. This creates a potential portability failure if an ignored diagnostic Rust file is part of the latter manifest. Current manifest inspection did not establish an actual missing file, so this was a consistency concern rather than evidence of invalid timing.

The root agent strengthened packaging to copy and hash-check every `compiler_provenance.compiler_source_sha256` entry in addition to the tracked freeze. This change concerns evidence packaging only; it does not change any timed compiler or harness source. A fresh extraction must still run the actual frozen runtime checks, validation and analysis to establish successful replay.

## Interpretation checks for the final report

1. Report the number of represented families for each qualified family-balanced aggregate. The inherited estimator balances families represented among positive eligible pairs; a completely unqualified family is absent from that estimate. Calling every result an equal-weight average over all six families would be wrong if any family disappears from a particular cohort. Coverage by family and tool must remain visible.
2. The generated holdout tests unseen instances and selected unused generator families. It does not establish independence across parameter seeds, a representative sample of all quantum programs, or state-of-the-art best settings for every SDK.
3. For Cat/GHZ controls, unsupported arbitrary-one-qubit decompositions are not correctness failures. Only independently qualified controls support quality comparisons. The graph relabeling intervention establishes label sensitivity and a reachable zero-SWAP placement; it is not a forced-layout API for Q-Rust.
4. Diagnostic pass timers are instrumented measurements on existing development circuits and must remain separate from formal held-out speed claims.
5. Reconstructing the exact frozen installed-file hashes can be more restrictive than installing the listed package versions, particularly across platforms or virtual-environment paths. The bundled native binary retains its original architecture. Replay should identify the actual environment used and report completion rather than imply universal portability.

## Required final verification

Run the prepared diagnostic replay boundary tests, package boundary tests, old-result preservation check, full frozen-environment check, then the fresh-extraction manifest audit and semantic replay after the timing reservation ends. Diagnostic replay must retain all compiler/parse/request/pass measurements and all verdicts/maps; only an explicitly located fresh verifier duration and its independently checked derived hash may differ. No successful replay is claimed by this read-only audit.
