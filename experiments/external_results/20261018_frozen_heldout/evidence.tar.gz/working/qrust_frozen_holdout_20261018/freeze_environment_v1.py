#!/usr/bin/env python3
"""Bind the existing compiler binary, source, recipes and installed distributions."""
import argparse
import hashlib
import importlib.metadata
import json
from pathlib import Path
import platform
import subprocess
import sys

BASE = Path(__file__).absolute().parent
REPO = BASE.parent / 'qrust_pr_publish'
BINARY = BASE.parent / 'qrust_compile_overhead_20261018/comparison_runner_final'
EXPECTED_HEAD = '3327d6cdcd937f3a3786c756a0279cf99e522239'
EXPECTED_BINARY = 'aa6513a05aa814b8b89cf373472cacaef4a0afa7c66a296d76a67ef4f4824e1e'
EXPECTED_VERSIONS = {'qiskit': '2.5.2', 'cirq-core': '1.7.0', 'pytket': '2.18.5', 'mqt.bench': '2.3.0'}

def sha(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()

def record(path):
    return {'path': str(path.absolute()), 'bytes': path.stat().st_size, 'sha256': sha(path)}

def verify(manifest):
    for entry in manifest['compiler_and_recipe_files'] + manifest['installed_files'] + [manifest['binary']]:
        path = Path(entry['path'])
        if not path.is_file() or path.stat().st_size != entry['bytes'] or sha(path) != entry['sha256']:
            raise ValueError('Frozen file changed: ' + entry['path'])
    for name, version in manifest['versions'].items():
        if importlib.metadata.version(name) != version:
            raise ValueError('Frozen distribution changed: ' + name)
    if str(Path(sys.executable).absolute()) != manifest['python_executable']:
        raise ValueError('Use the frozen Python environment')

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('action', choices=['freeze', 'check'])
    args = parser.parse_args()
    destination = BASE / 'compiler_freeze.json'
    if args.action == 'freeze':
        head = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=REPO, text=True).strip()
        if head != EXPECTED_HEAD or sha(BINARY) != EXPECTED_BINARY:
            raise ValueError('Unexpected baseline source or binary')
        for name, expected in EXPECTED_VERSIONS.items():
            if importlib.metadata.version(name) != expected:
                raise ValueError('Unexpected compiler/generator version: ' + name)
        tracked = subprocess.check_output(['git', 'ls-files', '-z'], cwd=REPO).decode().split('\0')
        paths = [REPO / name for name in tracked if name and (
            name.endswith('.rs') or name.endswith(('Cargo.toml', 'Cargo.lock')) or
            name.startswith('experiments/') and name.endswith('.py'))]
        versions, installed = {}, set()
        for distribution in importlib.metadata.distributions():
            name = distribution.metadata['Name']
            versions[name] = distribution.version
            for item in distribution.files or []:
                if '__pycache__' in item.parts or str(item).endswith(('.pyc', '.pyo')):
                    continue
                path = Path(distribution.locate_file(item)).absolute()
                if path.is_file():
                    installed.add(path)
        manifest = {
            'schema': 1, 'repository_commit': head,
            'timed_compiler_source_commit': '3306937c0ae71fb2eb78ad86141f2ccd1b636465',
            'python_executable': str(Path(sys.executable).absolute()),
            'python_version': sys.version, 'platform': platform.platform(),
            'machine': platform.machine(), 'versions': dict(sorted(versions.items())),
            'binary': record(BINARY),
            'compiler_and_recipe_files': [record(p) for p in sorted(paths)],
            'installed_files': [record(p) for p in sorted(installed)],
            'scope': 'Existing binary, tracked Rust/Cargo and experiment Python source, and installed distribution files excluding mutable Python bytecode. No compiler, dependency or primary recipe updates are permitted during the study.'}
        with destination.open('x') as stream:
            json.dump(manifest, stream, indent=2, sort_keys=True)
            stream.write('\n')
    else:
        manifest = json.loads(destination.read_text())
        verify(manifest)
    print(json.dumps({'action': args.action, 'compiler_freeze_sha256': sha(destination),
        'source_and_recipe_files': len(manifest['compiler_and_recipe_files']),
        'installed_files': len(manifest['installed_files']), 'distributions': len(manifest['versions'])}))

if __name__ == '__main__':
    main()
