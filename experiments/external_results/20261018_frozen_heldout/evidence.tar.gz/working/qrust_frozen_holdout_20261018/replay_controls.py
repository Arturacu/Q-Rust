#!/usr/bin/env python3
"""Fresh, relocated diagnostic validation from immutable archived artifacts.

No compiler execution. Original diagnostic helpers are imported byte-for-byte.
Only their file-location bindings are supplied externally after every frozen
source, fixture, binary, package and input receipt is verified. Result semantics,
including every compilation/pass timer, remain part of the equality check.
"""
from __future__ import annotations
import argparse
import copy
import hashlib
import importlib.metadata
import importlib.util
import json
from pathlib import Path
import shutil
import sys
from types import SimpleNamespace


def sha(path):
    digest=hashlib.sha256()
    with path.open('rb') as stream:
        for block in iter(lambda:stream.read(1<<20),b''):digest.update(block)
    return digest.hexdigest()
def read(path): return json.loads(path.read_text())
def lines(path): return [json.loads(s) for s in path.read_text().splitlines()]
def dump_new(path,value):
    with path.open('x') as stream: json.dump(value,stream,sort_keys=True,indent=2,allow_nan=False);stream.write('\n')


def require_equal(expected, actual, label):
    if expected != actual: raise ValueError('Replay mismatch: '+label)


def isolated_output(study,output):
    archive_root=study.resolve().parent.parent
    output=output.resolve()
    if output.is_relative_to(archive_root) or archive_root.is_relative_to(output):
        raise ValueError('Replay output must be outside the evidence archive tree')
    return output


def row_semantics(row):
    """Permit only an explicitly located fresh verifier clock, when present."""
    row=copy.deepcopy(row)
    validation=row.get('validation')
    if isinstance(validation,dict): validation.pop('validation_ns',None)
    for check in row.get('negative_controls',{}).values():
        if isinstance(check,dict): check.pop('validation_ns',None)
    return row


def summary_semantics(value):
    value=copy.deepcopy(value)
    value.pop('validated_sha256',None) # Independently bound to each actual file below.
    if 'rows' in value:value['rows']=[row_semantics(row) for row in value['rows']]
    return value


def load_module(name,path):
    spec=importlib.util.spec_from_file_location(name,path)
    if spec is None or spec.loader is None: raise ValueError('Cannot import archived helper')
    module=importlib.util.module_from_spec(spec)
    sys.modules[name]=module
    spec.loader.exec_module(module)
    require_equal(Path(module.__file__).resolve(),path.resolve(),'helper import origin')
    return module


class Replay:
    def __init__(self,study,output,required_dense):
        self.study=study.resolve();self.work=self.study.parent
        self.output=isolated_output(self.study,output);self.output.mkdir(parents=True,exist_ok=False)
        self.required_dense=required_dense
        p=read(self.study/'cat_ghz/protocol.json')
        suffix='/qrust_pr_publish/experiments/comparison_study.py'
        keys=[k for k in p['sources'] if k.endswith(suffix)]
        if len(keys)!=1:raise ValueError('Cannot determine unique original working root')
        self.original_work=Path(keys[0][:-len(suffix)])
        if not self.original_work.is_absolute():raise ValueError('Original source root must be absolute')
        self.records=[]

    def verify_environment(self):
        freeze_path=self.study/'compiler_freeze.json'
        freeze=read(freeze_path)
        campaign=read(self.study/'heldout/campaign/protocol.json')
        require_equal(campaign['compiler_freeze_sha256'],sha(freeze_path),'shared compiler/package freeze')
        require_equal(sys.version,freeze['python_version'],'frozen Python runtime version')
        old_env=Path(freeze['python_executable']).parent.parent
        new_env=Path(sys.executable).absolute().parent.parent
        for entry in freeze['installed_files']:
            path=new_env/Path(entry['path']).relative_to(old_env)
            if not path.is_file():raise ValueError('Missing frozen installed file: '+str(path))
            require_equal(entry['bytes'],path.stat().st_size,'frozen installed file size')
            require_equal(entry['sha256'],sha(path),'frozen installed file '+str(path))
        require_equal(freeze['versions'],{name:importlib.metadata.version(name) for name in freeze['versions']},'full frozen environment versions')
        self.environment_evidence={'freeze_sha256':sha(freeze_path),'installed_files_checked':len(freeze['installed_files']),
                                   'python_version_equal':True,'package_versions_equal':True}

    def relocate(self,original):
        path=Path(original)
        try:relative=path.relative_to(self.original_work)
        except ValueError as error:raise ValueError('Frozen source outside original working root: '+str(path)) from error
        if '..' in relative.parts:raise ValueError('Parent traversal in frozen source path')
        result=(self.work/relative).resolve()
        if not result.is_relative_to(self.work):raise ValueError('Archived source escapes working root')
        if not result.is_file():raise ValueError('Missing archived source: '+str(result))
        return result

    def verify_protocol(self,p,helper=None):
        bindings=p.get('sources',p.get('source_sha256'))
        if not isinstance(bindings,dict) or not bindings:raise ValueError('No frozen source bindings')
        for original,expected in bindings.items():require_equal(expected,sha(self.relocate(original)),'frozen source '+original)
        if helper is not None:require_equal(p['script_sha256'],sha(helper),'diagnostic helper')
        require_equal(p['binary_sha256'],sha(self.work/'qrust_compile_overhead_20261018/comparison_runner_final'),'compiler binary')
        cases_path=self.work/'qrust_tket_benchpress_20261018/benchpress/frozen/cases.json'
        require_equal(p['cases_sha256'],sha(cases_path),'fixture catalog')
        originals={case['id']:case for case in read(cases_path)}
        for case in p['cases']:
            original=originals[case['id']]
            require_equal(original,{k:case[k] for k in original},'frozen case '+case['id'])
            require_equal(case['qasm_sha256'],hashlib.sha256(case['qasm'].encode()).hexdigest(),'embedded case QASM')
        require_equal(p['versions'],{name:importlib.metadata.version(name) for name in p['versions']},'installed package versions')

    def verify_origins(self):
        experiment_root=(self.work/'qrust_pr_publish/experiments').resolve()
        for name in ('comparison_study','comparison_validation','scalable_clifford','paired_analysis'):
            if name in sys.modules:
                actual=Path(sys.modules[name].__file__).resolve()
                require_equal(actual,experiment_root/(name+'.py'),'frozen imported module '+name)

    def fresh(self,source,label,receipt_name):
        target=self.output/label;target.mkdir(parents=True)
        for filename in ('protocol.json','raw.jsonl',receipt_name):shutil.copyfile(source/filename,target/filename)
        receipt=read(target/receipt_name)
        require_equal(receipt['protocol_sha256'],sha(target/'protocol.json'),'protocol receipt '+label)
        require_equal(receipt['raw_sha256'],sha(target/'raw.jsonl'),'raw receipt '+label)
        if receipt_name=='receipt.json':require_equal(receipt['completed'],True,'completion receipt '+label)
        return target

    def compare_validation(self,source,target,label):
        old,new=lines(source/'validated.jsonl'),lines(target/'validated.jsonl')
        require_equal([row_semantics(r) for r in old],[row_semantics(r) for r in new],label+' validated rows')
        left,right=read(source/'summary.json'),read(target/'summary.json')
        require_equal(left['validated_sha256'],sha(source/'validated.jsonl'),label+' original validated hash')
        require_equal(right['validated_sha256'],sha(target/'validated.jsonl'),label+' replay validated hash')
        require_equal(summary_semantics(left),summary_semantics(right),label+' summary')
        self.records.append({'track':label,'rows':len(new),'semantic_equality':True,'original_validated_sha256':sha(source/'validated.jsonl'),'replay_validated_sha256':sha(target/'validated.jsonl'),'byte_identical_validated':(source/'validated.jsonl').read_bytes()==(target/'validated.jsonl').read_bytes()})

    def cat(self):
        source=self.study/'cat_ghz';p=read(source/'protocol.json');self.verify_protocol(p)
        module=load_module('archived_cat_controls',source/'controls.py')
        target=self.fresh(source,'cat_ghz','run_receipt.json')
        # Retain original source file and set only its runtime output/read directory.
        module.HERE=target
        module.check()
        self.verify_origins();self.compare_validation(source,target,'cat_ghz')
        # Independently recompute the saved native / reconstructed artifact pairing.
        rows=lines(target/'validated.jsonl');pairs=0
        for row in rows:
            if row['variant']=='baseline' and row['tool'] in ('qiskit','cirq','tket'):
                native=read(source/f'native_{row["case_id"]}_{row["tool"]}.json')
                for field in ('out_qasm','initial_layout','final_layout'):
                    require_equal(native[field],row['result'][field],'cat SDK baseline '+row['case_id']+' '+row['tool']+' '+field)
                require_equal(row['native_parity'],True,'cat SDK recorded parity verdict');pairs+=1
        require_equal(pairs,12,'cat SDK parity coverage')
        derive=load_module('archived_cat_derive',source/'derive_summary.py');derive.HERE=target;derive.main()
        left,right=read(source/'derived_summary.json'),read(target/'derived_summary.json')
        require_equal(left['validated_sha256'],sha(source/'validated.jsonl'),'cat derived original input')
        require_equal(right['validated_sha256'],sha(target/'validated.jsonl'),'cat derived fresh input')
        require_equal(summary_semantics(left),summary_semantics(right),'cat derived summary')
        self.records[-1].update(native_sdk_pairs=pairs,derived_summary_equal=True,derivation_source_sha256=sha(source/'derive_summary.py'))

    def dense(self,name):
        root=self.study/'dense';source=root/name
        if not (source/'receipt.json').exists():raise ValueError('Required dense track incomplete: '+name)
        helper=root/('dense_sdk_controls.py' if name=='sdk_ablation_v2' else 'dense_controls.py')
        p=read(source/'protocol.json');self.verify_protocol(p,helper)
        module=load_module('archived_dense_'+name,helper)
        require_equal(module.EXPECTED,p['binary_sha256'],'original dense helper binary constant')
        target=self.fresh(source,'dense/'+name,'receipt.json')
        def relocated_protocol(output):
            actual=read(output/'protocol.json')
            require_equal(actual,p,'immutable relocated dense protocol')
            self.verify_protocol(actual,helper)
            return actual
        # The original reader cannot resolve the author's absolute path keys.
        # This replacement runs every original binding check with strict relocation,
        # and additionally checks the fixture catalog / embedded cases.
        module.protocol=relocated_protocol
        module.validate(SimpleNamespace(output=target))
        self.verify_origins();self.compare_validation(source,target,'dense/'+name)
        analysis=load_module('archived_dense_analysis_'+name,root/'analyze_dense.py')
        result=analysis.analyze(target)
        dump_new(target/'accounting.json',result)
        expected=root/({'baseline_trace':'baseline_accounting.json','qrust_ablation':'qrust_ablation_accounting.json','sdk_ablation_v2':'sdk_ablation_accounting.json'}[name])
        # Match the saved accounting file by its protocol binding if a different
        # explicit filename was used; ambiguity or missing analysis fails closed.
        if not expected.exists():
            matches=[path for path in root.glob('*.json') if isinstance((v:=read(path)),dict) and v.get('protocol_sha256')==sha(source/'protocol.json') and 'analysis_script_sha256' in v]
            if len(matches)!=1:raise ValueError('Missing/ambiguous saved dense accounting: '+name)
            expected=matches[0]
        original=read(expected)
        require_equal(original['summary_sha256'],sha(source/'summary.json'),'dense original accounting input')
        require_equal(result['summary_sha256'],sha(target/'summary.json'),'dense replay accounting input')
        original=copy.deepcopy(original);result=copy.deepcopy(result)
        original.pop('summary_sha256');result.pop('summary_sha256')
        require_equal(original,result,'dense accounting '+name)
        self.records[-1].update(accounting_equal=True,accounting_source_sha256=sha(root/'analyze_dense.py'))

    def run(self):
        self.verify_environment()
        self.cat()
        for name in self.required_dense:self.dense(name)
        dump_new(self.output/'replay_receipt.json',{'schema':1,'all_passed':True,'no_compiler_execution':True,'replay_helper_sha256':sha(Path(__file__)),'environment_evidence':self.environment_evidence,'excluded_semantic_fields':['validation.validation_ns when present','negative_controls.<name>.validation_ns when present'],'derived_hash_policy':'validated_sha256 / summary_sha256 are checked against each original and fresh file before comparison of all remaining semantic fields. Every compiler, parser, transport and pass timing remains compared.','tracks':self.records})
        print(json.dumps({'all_passed':True,'tracks':[r['track'] for r in self.records]}))


if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--study',type=Path,default=Path(__file__).absolute().parent);p.add_argument('--output',required=True,type=Path)
    p.add_argument('--dense',nargs='+',choices=['baseline_trace','qrust_ablation','sdk_ablation_v2'],default=['baseline_trace','qrust_ablation','sdk_ablation_v2'])
    args=p.parse_args();Replay(args.study,args.output,args.dense).run()
