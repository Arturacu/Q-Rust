#!/usr/bin/env python3
"""Derive dense causal tables from completed saved diagnostics, without compilers."""
from collections import Counter, defaultdict
import hashlib
import json
from pathlib import Path
import statistics
import sys

import analyze_dense
from retention_evidence import interpret

def sha(path): return hashlib.sha256(path.read_bytes()).hexdigest()
def fingerprint(result):
    return json.dumps({k:result[k] for k in ('out_qasm','output_qubits','initial_layout','final_layout')},sort_keys=True)

DESCRIPTIONS={
    'qrust_default_unprofiled':'Frozen O3 recipe with pass clocks disabled.',
    'qrust_default_profiled':'Frozen O3 recipe with pass clocks enabled.',
    'qrust_no_clifford':'Disable cross-block Clifford rewriting and its retained-input continuation guard.',
    'qrust_no_blocks':'Disable two-qubit block synthesis and its dependent post-block fusion.',
    'qrust_layout_1x1':'Use one layout trial and one forward/backward refinement; O3 beam budget unchanged.',
    'qrust_lookahead_5':'Reduce routing/layout extended lookahead from 20 to 5; scoring and search outcomes may change.',
    'qrust_no_rank_progress':'Disable free-progress ranking/deduplication policy; this changes search semantics as well as bookkeeping.',
    'qiskit_original':'Frozen Qiskit recipe.',
    'qiskit_profiled':'Identical Qiskit recipe plus pass callbacks; outer timing includes callback work.',
    'tket_original':'Frozen TKET recipe.',
    'tket_profiled':'Apply identical TKET passes individually with stage clocks and same CompilationUnit.',
    'tket_light':'Replace FullPeepholeOptimise with SynthesiseTket before unchanged routing/rebase stages.',
    'cirq_frozen':'Frozen Cirq recipe.',
    'cirq_original':'Reconstruct identical Cirq recipe with stage clocks.',
    'cirq_one_pass':'Reduce target-gateset optimization passes from two to one at each synthesis stage.',
    'cirq_native_cx':'Diagnostic restricted 1q/CX/SWAP representation path; unsupported on CY/CZ dense fixture.',
}

def derive(base, sdk_name):
    outputs={}
    bindings={}
    for label,name in [('baseline','baseline_trace'),('qrust_interventions','qrust_ablation'),('sdk_interventions',sdk_name)]:
        directory=base/name
        accounting=analyze_dense.analyze(directory)
        summary=json.loads((directory/'summary.json').read_text())
        rows=[json.loads(line) for line in (directory/'validated.jsonl').read_text().splitlines()]
        groups=defaultdict(list)
        for row in rows:groups[row['case_id'],row['recipe']].append(row)
        compact=[]
        indexed={(c['case_id'],c['recipe']):c for c in summary['cases']}
        for key,values in sorted(groups.items()):
            case,recipe=key
            reference=('qrust_default_profiled' if recipe.startswith('qrust_') else
                       'qiskit_original' if recipe.startswith('qiskit_') else
                       'tket_original' if recipe.startswith('tket_') else 'cirq_frozen')
            cell=indexed[key]
            reference_cell=indexed.get((case,reference))
            compiled=[r for r in values if r['result']['status']=='compiled']
            measured=[r for r in compiled if r['phase']=='diagnostic' and not r['result']['cold_after_failure']]
            metric_rows=[r['validation']['metrics'] for r in measured if r['validation'] and r['validation'].get('metrics')]
            metrics={name:statistics.median(m[name] for m in metric_rows) if metric_rows else None
                     for name in ('cx_count','depth','two_q_depth','gate_count')}
            retention=[]
            for row in measured:
                if row['outcome']=='passed' and row['result'].get('clifford_retention_stats'):
                    retention.append(interpret(row['result']['clifford_retention_stats'],row['validation']['metrics']))
            eligible=cell['eligible_for_diagnostic_timing']
            reference_eligible=reference_cell is not None and reference_cell['eligible_for_diagnostic_timing']
            artifacts={fingerprint(r['result']) for r in compiled}
            reference_rows=groups.get((case,reference),[])
            reference_artifacts={fingerprint(r['result']) for r in reference_rows if r['result']['status']=='compiled'}
            comparable=eligible and reference_eligible
            stage_keys={name for row in measured for name in row['result'].get('stages_ns',{})}
            stage_shares={name:statistics.median(row['result'].get('stages_ns',{}).get(name,0)/row['result']['compile_ns']
                                                for row in measured) for name in sorted(stage_keys)}
            snapshots=[]
            for row in measured:
                trace=[{k:event.get(k) for k in ('pass','operations','two_qubit_gates','swaps','depth')}
                       for event in row['result'].get('pass_diagnostics',[]) if event['pass'].endswith('BeamSabrePass')]
                if trace and trace not in snapshots:snapshots.append(trace)
            compact.append({'case_id':case,'recipe':recipe,'intervention':DESCRIPTIONS[recipe],
                'outcomes_including_warmup':dict(Counter(r['outcome'] for r in values)),
                'classifications':cell['classifications'],'all_outputs_verified':eligible,
                'compile_median_ns':cell['compile_ns_median'],'observed_structural_metric_medians':metrics,
                'qualified_structural_metric_medians':metrics if eligible else None,
                'reference_recipe':reference,'verified_comparison_to_reference_available':comparable,
                'diagnostic_compile_ratio_to_reference':cell['compile_ns_median']/reference_cell['compile_ns_median'] if comparable else None,
                'structural_delta_to_reference':{name:metrics[name]-statistics.median(m[name] for m in reference_cell['metrics']) for name in metrics} if comparable else None,
                'all_compiled_artifacts_repeat_identically':len(artifacts)==1,
                'exact_artifact_map_parity_to_reference':bool(artifacts and artifacts==reference_artifacts) if comparable else None,
                'distinct_measured_routing_snapshots':snapshots,
                'median_per_request_stage_share_of_compile':stage_shares,
                'pass_or_stage_medians_ns':cell['pass_medians_ns'],'retention':retention,
                'interpretation_limit':'Exploratory fixed-seed diagnostics. A toggle changes its complete resulting pipeline, including downstream decisions. Unsupported output is unverified rather than incorrect.'})
        outputs[label]={'directory':name,'cells':compact,'accounting':accounting['cases'],'profile_parity':summary['profile_parity']}
        bindings[label]={name:sha(directory/name) for name in ('protocol.json','receipt.json','raw.jsonl','validated.jsonl','summary.json')}
    return {'schema':1,'scope':'Dense 20 diagnostic controls on two graphs; frozen production compilers unchanged.',
            'studies':outputs,'input_bindings':bindings,'analysis_sha256':sha(Path(__file__)),
            'retention_helper_sha256':sha(Path(__file__).with_name('retention_evidence.py'))}

if __name__=='__main__':
    base=Path(sys.argv[1]);sdk_name=sys.argv[2];output=Path(sys.argv[3])
    value=derive(base,sdk_name)
    with output.open('x') as stream:json.dump(value,stream,sort_keys=True,indent=2);stream.write('\n')
