"""Interpret saved retention metadata against independently measured output costs."""
LABELS = ('cx_count', 'depth', 'two_q_depth')

def _cost(value):
    if not (isinstance(value,list) and len(value)==3 and
            all(isinstance(x,int) and not isinstance(x,bool) and x>=0 for x in value)):
        raise ValueError('Malformed retained-output cost')
    return value

def interpret(stats, metrics):
    if stats is None: return None
    if not isinstance(stats['retained_compilation_failed'],bool) or not isinstance(stats['selected_retained_input'],bool):
        raise ValueError('Malformed retained-output decision flags')
    selected = _cost(stats['selected_output_cost'])
    if selected != [metrics[name] for name in LABELS]:
        raise ValueError('Reported selected cost differs from independently measured output')
    rewritten = _cost(stats['rewritten_output_cost'])
    if stats['retained_compilation_failed']:
        if stats['selected_retained_input']:
            raise ValueError('Failed retained compilation cannot be selected')
        return {'selected_output_cost':selected,'retained_reference_available':False,
                'selected_retained_input':stats['selected_retained_input']}
    retained = _cost(stats['retained_output_cost'])
    if any(a>b for a,b in zip(selected,retained)):
        raise ValueError('Selected cost regresses retained reference')
    if stats['selected_retained_input'] and selected != retained:
        raise ValueError('Retained-input selection disagrees with selected cost')
    delta = {name:a-b for name,a,b in zip(LABELS,rewritten,retained)}
    return {'selected_output_cost':selected,'retained_reference_available':True,
            'selected_retained_input':stats['selected_retained_input'],
            'reported_rewritten_cost_matches_selected':selected==rewritten,
            'rewritten_minus_retained':delta,
            'reported_rewritten_exceeds_reference_on':[name for name,d in delta.items() if d>0],
            'reported_rewritten_no_worse_on_all_costs':all(d<=0 for d in delta.values()),
            'selection_limit':'This checks recorded selection and its fixed reference; it does not reconstruct discarded candidates or infer their runtime.'}
