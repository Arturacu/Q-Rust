#!/usr/bin/env python3
"""Deterministically derive per-request pass accounting from saved diagnostics."""
from collections import Counter, defaultdict
import hashlib
import json
from pathlib import Path
import statistics
import sys

def sha(path): return hashlib.sha256(path.read_bytes()).hexdigest()
def median(values): return statistics.median(values) if values else None

def analyze(directory):
    protocol = json.loads((directory/'protocol.json').read_text())
    receipt = json.loads((directory/'receipt.json').read_text())
    summary = json.loads((directory/'summary.json').read_text())
    assert receipt['completed']
    assert receipt['protocol_sha256'] == summary['protocol_sha256'] == sha(directory/'protocol.json')
    assert receipt['raw_sha256'] == summary['raw_sha256'] == sha(directory/'raw.jsonl')
    assert summary['validated_sha256'] == sha(directory/'validated.jsonl')
    rows = [json.loads(line) for line in (directory/'validated.jsonl').read_text().splitlines()]
    assert len(rows) == len(protocol['schedule'])
    groups = defaultdict(list)
    for index,row in enumerate(rows):
        assert row['schedule_index'] == index
        assert all(row[k] == v for k,v in protocol['schedule'][index].items())
        groups[row['case_id'],row['recipe']].append(row)
    derived = []
    for (case,recipe), group in sorted(groups.items()):
        measured = [r for r in group if r['phase']=='diagnostic' and r['result']['status']=='compiled'
                    and not r['result']['cold_after_failure']]
        sampled = []
        for row in measured:
            result = row['result']
            events = result.get('pass_diagnostics',[])
            stages = result.get('stages_ns',{})
            partition = defaultdict(int)
            for event in events:
                name = event['pass']
                category = ('beam_routing' if name.endswith('BeamSabrePass') else
                            'layout_search' if name.endswith('SabreLayoutPass') else
                            'clifford_simplification' if name.endswith('CliffordSimplificationPass') else
                            'two_qubit_block_synthesis' if name.endswith('TwoQubitBlockSynthesisPass') else
                            'other_profiled_passes')
                partition[category] += event['elapsed_ns']
            # Categories are a disjoint partition of individual saved Q-Rust events.
            assert sum(partition.values()) == sum(e['elapsed_ns'] for e in events)
            sampled.append({'repeat':row['repeat'],'compile_ns':result['compile_ns'],
                            'groups_ns':dict(partition),'groups_share_of_compile':{
                                k:v/result['compile_ns'] for k,v in partition.items()},
                            'profiled_events_share_of_compile':sum(partition.values())/result['compile_ns'],
                            'routing_pass_calls':sum(e['pass'].endswith('BeamSabrePass') for e in events),
                            'stage_clock_ns':stages,
                            'metrics':(row['validation'] or {}).get('metrics'),
                            'validation':(row['validation'] or {}).get('failure_classification')})
        keys = {key for row in sampled for key in row['groups_ns']}
        derived.append({'case_id':case,'recipe':recipe,
                        'outcomes_including_warmup':dict(Counter(row['outcome'] for row in group)),
                        'all_verified':len(measured)==3 and all(row['outcome']=='passed' for row in group),
                        'compile_median_ns':median([row['compile_ns'] for row in sampled]),
                        'group_median_ns':{k:median([row['groups_ns'].get(k,0) for row in sampled]) for k in sorted(keys)},
                        'median_per_request_share':{k:median([row['groups_share_of_compile'].get(k,0) for row in sampled]) for k in sorted(keys)},
                        'requests':sampled})
    return {'scope':'Exploratory diagnostics only; each request partitions actual saved pass events. Medians of shares are computed after per-request summation, not sums of separately computed pass medians.',
            'protocol_sha256':sha(directory/'protocol.json'),'summary_sha256':sha(directory/'summary.json'),
            'analysis_script_sha256':sha(Path(__file__)),'cases':derived}

if __name__ == '__main__':
    output=Path(sys.argv[2])
    result=analyze(Path(sys.argv[1]))
    with output.open('x') as stream: json.dump(result,stream,sort_keys=True,indent=2);stream.write('\n')
