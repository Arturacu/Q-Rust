"""Fault injection tests for dense diagnostic evidence; no compiler invocation."""
import copy
import hashlib
import json
from pathlib import Path
import tempfile
from types import SimpleNamespace
import unittest
from unittest.mock import patch

import analyze_dense
import dense_controls
from retention_evidence import interpret

QASM = 'OPENQASM 2.0; include "qelib1.inc"; qreg q[2]; u3(1.5707963267948966,0,3.141592653589793) q[0]; cx q[0],q[1];\n'

def write(path, data):
    path.write_text(json.dumps(data,sort_keys=True)+'\n')

def sha(path): return hashlib.sha256(path.read_bytes()).hexdigest()

def native_rows():
    case={'id':'fixture','qasm':QASM,'n_logical':2,'physical_width':2,'edges':[[0,1]],'topology':'linear'}
    rows=[]
    for repeat in range(-1,3):
        for recipe in ('qrust_default_profiled','qrust_default_unprofiled'):
            slot={'case_id':'fixture','recipe':recipe,'repeat':repeat,
                  'phase':'warmup' if repeat==-1 else 'diagnostic','request':{}}
            result={'status':'compiled','compile_ns':100,'parse_ns':10,'pass_diagnostics':[],
                    'request_wall_ns':120,'cold_after_failure':False,'out_qasm':QASM,
                    'output_qubits':2,'initial_layout':[0,1],'final_layout':[0,1],
                    'output_sha256':hashlib.sha256(QASM.encode()).hexdigest(),
                    'numerical_budget':{'accepted':0,'rejected':0,'charged_error':0.0},
                    'clifford_retention_stats':{'selected_output_cost':[1,2,1]}}
            rows.append(dict(slot,schedule_index=len(rows),result=result))
    return case,rows

def install_native(directory,rows,case):
    protocol={'cases':[case],'schedule':[{k:v for k,v in r.items() if k not in ('schedule_index','result')} for r in rows]}
    write(directory/'protocol.json',protocol)
    (directory/'raw.jsonl').write_text(''.join(json.dumps(r,sort_keys=True)+'\n' for r in rows))
    write(directory/'receipt.json',{'completed':True,'protocol_sha256':sha(directory/'protocol.json'),
                                   'raw_sha256':sha(directory/'raw.jsonl')})
    return protocol

def validate_native(directory,protocol):
    # Protocol/source/binary integrity is separately tested by actual replay; this
    # isolated fixture exercises the frozen validator's native parity/eligibility.
    with patch.object(dense_controls,'protocol',return_value=protocol):
        dense_controls.validate(SimpleNamespace(output=directory))
    return json.loads((directory/'summary.json').read_text())

class NativeParityTests(unittest.TestCase):
    def test_profile_clock_changes_preserve_native_parity(self):
        case,rows=native_rows()
        rows[-1]['result'].update(compile_ns=999,parse_ns=999,pass_diagnostics=[{'pass':'probe','elapsed_ns':9}])
        with tempfile.TemporaryDirectory() as d:
            p=Path(d);summary=validate_native(p,install_native(p,rows,case))
        self.assertTrue(summary['profile_parity'][0]['exact_native_parity'])
        self.assertTrue(all(c['eligible_for_diagnostic_timing'] for c in summary['cases']))

    def test_semantically_equivalent_output_edit_is_not_exact_native_parity(self):
        case,rows=native_rows()
        # Two appended CXs cancel, so equivalence alone cannot catch this edit.
        changed=QASM+'cx q[0],q[1]; cx q[0],q[1];\n'
        rows[-1]['result'].update(out_qasm=changed,output_sha256=hashlib.sha256(changed.encode()).hexdigest())
        with tempfile.TemporaryDirectory() as d:
            p=Path(d)
            with self.assertRaisesRegex(AssertionError,'Profiling changed native result'):
                validate_native(p,install_native(p,rows,case))

    def test_map_and_reported_cost_mutations_fail_closed(self):
        for field,value in [('initial_layout',[1,0]),('final_layout',[1,0]),
                            ('clifford_retention_stats',{'selected_output_cost':[2,2,1]}),
                            ('numerical_budget',{'accepted':1,'rejected':0,'charged_error':0.0}),
                            ('unexpected_new_counter',1)]:
            with self.subTest(field=field):
                case,rows=native_rows();rows[-1]['result'][field]=value
                with tempfile.TemporaryDirectory() as d:
                    p=Path(d)
                    with self.assertRaisesRegex(AssertionError,'Profiling changed native result'):
                        validate_native(p,install_native(p,rows,case))

    def test_cold_restart_excluded_from_timing_eligibility(self):
        case,rows=native_rows();rows[-1]['result']['cold_after_failure']=True
        with tempfile.TemporaryDirectory() as d:
            p=Path(d);summary=validate_native(p,install_native(p,rows,case))
        cells={c['recipe']:c for c in summary['cases']}
        self.assertFalse(cells['qrust_default_unprofiled']['eligible_for_diagnostic_timing'])
        self.assertTrue(cells['qrust_default_profiled']['eligible_for_diagnostic_timing'])

class AccountingTests(unittest.TestCase):
    def run_accounting(self,rows):
        with tempfile.TemporaryDirectory() as d:
            p=Path(d)
            protocol={'schedule':[{k:v for k,v in r.items() if k not in
                                  ('schedule_index','result','outcome','validation','validation_cache_key')} for r in rows]}
            write(p/'protocol.json',protocol)
            (p/'raw.jsonl').write_text(''.join(json.dumps({k:v for k,v in r.items() if k not in
                    ('outcome','validation','validation_cache_key')},sort_keys=True)+'\n' for r in rows))
            (p/'validated.jsonl').write_text(''.join(json.dumps(r,sort_keys=True)+'\n' for r in rows))
            common={'protocol_sha256':sha(p/'protocol.json'),'raw_sha256':sha(p/'raw.jsonl')}
            write(p/'receipt.json',dict(common,completed=True))
            write(p/'summary.json',dict(common,validated_sha256=sha(p/'validated.jsonl')))
            return analyze_dense.analyze(p)

    def rows(self):
        _,all_rows=native_rows();rows=[r for r in all_rows if r['recipe']=='qrust_default_profiled']
        for i,row in enumerate(rows):
            row['schedule_index']=i;row.update(outcome='passed',validation={'passed':True,'failure_classification':'verified',
                       'metrics':{'cx_count':1,'depth':2,'two_q_depth':1,'gate_count':2}},validation_cache_key='fixture')
            row['result']['compile_ns']=200
            row['result']['pass_diagnostics']=[{'pass':'BeamSabrePass','elapsed_ns':80},
                  {'pass':'pre-clifford-input::BeamSabrePass','elapsed_ns':60},
                  {'pass':'SabreLayoutPass','elapsed_ns':20},
                  {'pass':'CliffordSimplificationPass','elapsed_ns':10},
                  {'pass':'GateFusionPass','elapsed_ns':10}]
            row['result']['stages_ns']={'overlapping_outer_stage':200}
        return rows

    def test_exclusive_prefix_aware_grouping_does_not_double_count_outer_stage(self):
        cell=self.run_accounting(self.rows())['cases'][0]
        self.assertEqual(cell['group_median_ns']['beam_routing'],140)
        self.assertEqual(cell['median_per_request_share']['beam_routing'],0.7)
        self.assertEqual(sum(cell['group_median_ns'].values()),180)
        self.assertTrue(all(r['routing_pass_calls']==2 for r in cell['requests']))
        self.assertTrue(all(r['profiled_events_share_of_compile']==0.9 for r in cell['requests']))

    def test_fraction_is_computed_per_request_before_median(self):
        rows=self.rows()
        for row,compile_ns,beam_ns in zip(rows[1:],[100,1000,1000],[90,200,300]):
            row['result']['compile_ns']=compile_ns
            row['result']['pass_diagnostics']=[{'pass':'BeamSabrePass','elapsed_ns':beam_ns}]
        cell=self.run_accounting(rows)['cases'][0]
        self.assertEqual(cell['median_per_request_share']['beam_routing'],0.3)
        self.assertNotEqual(cell['median_per_request_share']['beam_routing'],
                            cell['group_median_ns']['beam_routing']/cell['compile_median_ns'])

    def test_missing_repeat_cold_restart_and_unsupported_are_ineligible(self):
        for change in ('missing','cold','unsupported','unsupported_warmup'):
            with self.subTest(change=change):
                rows=self.rows()
                if change=='missing':rows.pop()
                if change=='cold':rows[-1]['result']['cold_after_failure']=True
                if change in ('unsupported','unsupported_warmup'):
                    row=rows[0 if change.endswith('warmup') else -1]
                    row['outcome']='unverified_output';row['validation'].update(passed=False,failure_classification='unsupported_recognition')
                self.assertFalse(self.run_accounting(rows)['cases'][0]['all_verified'])

    def test_protocol_receipt_tampering_rejected(self):
        # The replay path requires protocol receipt binding before accounting.
        with tempfile.TemporaryDirectory() as d:
            p=Path(d);write(p/'protocol.json',{});write(p/'receipt.json',{'completed':True,'protocol_sha256':'changed'})
            write(p/'summary.json',{'protocol_sha256':sha(p/'protocol.json')})
            with self.assertRaises(AssertionError):analyze_dense.analyze(p)

class RetentionTests(unittest.TestCase):
    def stats(self):
        return {'selected_output_cost':[7898,3612,3138], 'rewritten_output_cost':[8050,3600,3134],
                'retained_output_cost':[7898,3612,3138], 'retained_compilation_failed':False,
                'selected_retained_input':True}
    def metrics(self):return {'cx_count':7898,'depth':3612,'two_q_depth':3138}

    def test_lower_depth_alone_does_not_imply_rewritten_is_eligible(self):
        result=interpret(self.stats(),self.metrics())
        self.assertEqual(result['reported_rewritten_exceeds_reference_on'],['cx_count'])
        self.assertEqual(result['rewritten_minus_retained'],{'cx_count':152,'depth':-12,'two_q_depth':-4})
        self.assertFalse(result['reported_rewritten_no_worse_on_all_costs'])
        self.assertTrue(result['selected_retained_input'])

    def test_dominating_rewrite_and_selected_metrics(self):
        stats={'selected_output_cost':[4416,2464,2017],'rewritten_output_cost':[4416,2464,2017],
               'retained_output_cost':[4491,2795,2223],'retained_compilation_failed':False,'selected_retained_input':False}
        result=interpret(stats,{'cx_count':4416,'depth':2464,'two_q_depth':2017})
        self.assertTrue(result['reported_rewritten_no_worse_on_all_costs'])
        self.assertTrue(result['reported_rewritten_cost_matches_selected'])

    def test_mismatched_actual_cost_and_selection_flag_fail_closed(self):
        with self.assertRaisesRegex(ValueError,'independently measured'):
            interpret(self.stats(),dict(self.metrics(),cx_count=7899))
        stats=self.stats();stats['selected_output_cost']=[7897,3612,3138]
        with self.assertRaisesRegex(ValueError,'selection disagrees'):
            interpret(stats,dict(self.metrics(),cx_count=7897))

    def test_failed_retained_reference_has_no_dominance_claim(self):
        stats=self.stats();stats.update(retained_compilation_failed=True,retained_output_cost=None,selected_retained_input=False)
        result=interpret(stats,self.metrics())
        self.assertFalse(result['retained_reference_available'])
        self.assertNotIn('reported_rewritten_no_worse_on_all_costs',result)

    def test_malformed_or_impossible_decision_flags_are_rejected(self):
        stats=self.stats();stats['selected_retained_input']='false'
        with self.assertRaisesRegex(ValueError,'Malformed'):
            interpret(stats,self.metrics())
        stats=self.stats();stats['retained_compilation_failed']=True
        with self.assertRaisesRegex(ValueError,'cannot be selected'):
            interpret(stats,self.metrics())

if __name__=='__main__':unittest.main()
