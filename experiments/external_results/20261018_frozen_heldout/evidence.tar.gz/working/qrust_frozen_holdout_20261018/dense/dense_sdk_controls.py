#!/usr/bin/env python3
"""Frozen dense-Clifford exploratory controls, never formal benchmark recipes."""
from collections import Counter, defaultdict
import argparse
import hashlib
import importlib.metadata
import json
import os
from pathlib import Path
import select
import statistics
import subprocess
import sys
import time

HERE = Path(__file__).absolute().parent
WORK = HERE.parent.parent
REPO = WORK / 'qrust_pr_publish'
BINARY = WORK / 'qrust_compile_overhead_20261018/comparison_runner_final'
EXPECTED = 'aa6513a05aa814b8b89cf373472cacaef4a0afa7c66a296d76a67ef4f4824e1e'
CASES = WORK / 'qrust_tket_benchpress_20261018/benchpress/frozen/cases.json'
sys.path.insert(0, str(REPO / 'experiments'))
from comparison_study import THREAD_ENV
os.environ.update(THREAD_ENV)

def sha(value):
    if isinstance(value, Path): value = value.read_bytes()
    if isinstance(value, str): value = value.encode()
    return hashlib.sha256(value).hexdigest()

def canonical(value):
    return json.dumps(value, sort_keys=True, separators=(',', ':'), allow_nan=False)

def write_new(path, value):
    with path.open('x') as stream:
        json.dump(value, stream, sort_keys=True, indent=2, allow_nan=False)
        stream.write('\n')

def cases():
    selected = [c for c in json.loads(CASES.read_text()) if c['id'].startswith('clifford20_')]
    assert len(selected) == 2
    assert all(sha(c['qasm']) == c['qasm_sha256'] for c in selected)
    return selected

RECIPES = {
    'qrust_default_unprofiled': {},
    'qrust_default_profiled': {'profile_passes': True},
    'qrust_no_clifford': {'profile_passes': True, 'clifford_simplification': False},
    'qrust_no_blocks': {'profile_passes': True, 'two_qubit_block_synthesis': False},
    'qrust_layout_1x1': {'profile_passes': True, 'layout_trials': 1, 'layout_iterations': 1},
    'qrust_lookahead_5': {'profile_passes': True, 'lookahead_size': 5},
    'qrust_no_rank_progress': {'profile_passes': True, 'rank_progress': False},
    'qiskit_original': {}, 'qiskit_profiled': {},
    'cirq_frozen': {}, 'cirq_original': {}, 'cirq_one_pass': {}, 'cirq_native_cx': {},
    'tket_original': {}, 'tket_profiled': {}, 'tket_two_qubit': {}, 'tket_light': {},
}

def prepare(args):
    assert sha(BINARY) == EXPECTED
    assert not args.output.exists()
    args.output.mkdir(parents=True)
    selected = cases()
    schedule = []
    for case_index, case in enumerate(selected):
        for repeat in range(-1, 3):
            recipes = list(args.recipes)
            # Alternating order balances warm cache/order effects but is not a formal speed claim.
            if (case_index + repeat) % 2: recipes.reverse()
            for recipe in recipes:
                assert recipe in RECIPES
                request = {k: case[k] for k in ('qasm', 'n_logical', 'physical_width', 'edges', 'topology')}
                request.update(seed=20261018, **RECIPES[recipe])
                schedule.append({'case_id': case['id'], 'recipe': recipe, 'repeat': repeat,
                                 'phase': 'warmup' if repeat == -1 else 'diagnostic', 'request': request})
    sources = [REPO / 'experiments' / name for name in (
        'comparison_study.py', 'comparison_qiskit_tket.py', 'comparison_cirq.py',
        'diagnose_compiler_tradeoffs.py', 'comparison_validation.py', 'scalable_clifford.py', 'paired_analysis.py')]
    write_new(args.output / 'protocol.json', {
        'study': __doc__, 'binary_sha256': EXPECTED,
        'repository_head': subprocess.check_output(['git','rev-parse','HEAD'], cwd=REPO, text=True).strip(),
        'script_sha256': sha(Path(__file__)), 'source_sha256': {str(p): sha(p) for p in sources},
        'versions': {n: importlib.metadata.version(n) for n in ('qiskit','cirq-core','pytket','numpy','scipy')},
        'cases_sha256': sha(CASES), 'cases': selected, 'recipes': args.recipes,
        'schedule': schedule, 'thread_environment': THREAD_ENV,
        'request_timeout_seconds': 30, 'repetitions': 3, 'warmups_per_case_recipe': 1,
        'timing_limits': 'Post-hoc diagnostic only. Stage clocks/callback metric collection add overhead; profiles do not establish production speed. Same fixed seed for every repeat/control. Parsing, serialization and validation outside native compile clocks.',
        'scope': 'One existing dense Clifford20 logical circuit on two target graphs. Pass removals or search reductions are interventions, not improved production recipes. Holdout and production compilers remain untouched.',
        'validation': 'Every compiled output, including warmups, checked after all requests by frozen map-aware Clifford Choi-isometry oracle and U/CX/edge checks. Unsupported local non-Clifford representations stay unverified, not incorrect. No checker change.',
        'failure_policy': 'Every schedule slot retained. Request failures close worker; a later request restarts worker but is flagged cold-after-failure and excluded from timing summaries. No silent retries.',
    })

def worker(recipe):
    # SDK imports complete before the ready line; compile helpers are unchanged production/diagnostic functions.
    if recipe.startswith('qiskit_'):
        import qiskit
        from comparison_qiskit_tket import compile_one
    elif recipe.startswith('tket_'):
        import pytket
        from diagnose_compiler_tradeoffs import tket_trial
        from comparison_qiskit_tket import compile_one
    else:
        import cirq
        from diagnose_compiler_tradeoffs import cirq_trial
        from comparison_cirq import compile_one as cirq_compile_one
    print(canonical({'ready': True}), flush=True)
    for line in sys.stdin:
        request = json.loads(line)
        try:
            if recipe.startswith('qiskit_'):
                original = qiskit.transpile
                trace = []
                def callback(**kwargs):
                    dag, compiler_pass = kwargs['dag'], kwargs['pass_']
                    trace.append({'pass': compiler_pass.name(), 'elapsed_ns': round(kwargs['time'] * 1e9),
                                  'operations': dict(dag.count_ops()), 'depth': dag.depth()})
                def instrumented(*positional, **keywords):
                    return original(*positional, callback=callback, **keywords)
                if recipe == 'qiskit_profiled': qiskit.transpile = instrumented
                try: result = compile_one('qiskit', **request)
                finally: qiskit.transpile = original
                result['pass_diagnostics'] = trace
            elif recipe == 'tket_original':
                result = compile_one('tket', **request)
            elif recipe.startswith('tket_'):
                result = tket_trial(request, 'tket_original' if recipe == 'tket_profiled' else recipe,
                                    stage_probe=True)
            elif recipe == 'cirq_frozen':
                result = cirq_compile_one(**request)
            else:
                result = cirq_trial(request, recipe)
            result['status'] = 'compiled'
        except Exception as error:
            result = {'status': 'error', 'error': f'{type(error).__name__}: {error}'}
        print(canonical(result), flush=True)

class Worker:
    def __init__(self, recipe, output):
        self.recipe, self.output, self.process = recipe, output, None
        self.failed = False
        self.start()
    def start(self):
        command = [str(BINARY)] if self.recipe.startswith('qrust_') else [sys.executable, str(Path(__file__).absolute()), 'worker', self.recipe]
        self.log = (self.output / ('worker_' + self.recipe + '.log')).open('a')
        self.process = subprocess.Popen(command, stdin=subprocess.PIPE, stdout=subprocess.PIPE,
                                        stderr=self.log, text=True, bufsize=1, env=dict(os.environ, **THREAD_ENV))
        assert self.receive(120).get('ready')
    def receive(self, timeout):
        if not select.select([self.process.stdout], [], [], timeout)[0]: raise TimeoutError('Diagnostic request exceeded bounded timeout')
        line = self.process.stdout.readline()
        if not line: raise RuntimeError(f'Worker exited: {self.process.poll()}')
        return json.loads(line)
    def call(self, request, timeout):
        cold = self.process is None
        if cold: self.start()
        started = time.perf_counter_ns()
        try:
            self.process.stdin.write(canonical(request) + '\n'); self.process.stdin.flush()
            result = self.receive(timeout)
        except Exception as error:
            result = {'status': 'timeout' if isinstance(error, TimeoutError) else 'error',
                      'error': f'{type(error).__name__}: {error}'}
            self.close()
        result['request_wall_ns'] = time.perf_counter_ns() - started
        result['cold_after_failure'] = cold
        if 'out_qasm' in result: result['output_sha256'] = sha(result['out_qasm'])
        return result
    def close(self):
        if self.process:
            self.process.terminate()
            try: self.process.wait(timeout=3)
            except subprocess.TimeoutExpired:
                self.process.kill(); self.process.wait()
            self.process = None
            self.log.close()

def protocol(output):
    p = json.loads((output / 'protocol.json').read_text())
    assert sha(BINARY) == p['binary_sha256'] == EXPECTED
    assert sha(Path(__file__)) == p['script_sha256']
    for name, expected in p['source_sha256'].items(): assert sha(Path(name)) == expected
    assert p['versions'] == {n: importlib.metadata.version(n) for n in p['versions']}
    return p

def run(args):
    p = protocol(args.output)
    workers, started = {}, time.monotonic()
    try:
        for recipe in p['recipes']: workers[recipe] = Worker(recipe, args.output)
        with (args.output / 'raw.jsonl').open('x') as stream:
            for index, slot in enumerate(p['schedule']):
                result = workers[slot['recipe']].call(slot['request'], p['request_timeout_seconds'])
                stream.write(canonical(dict(slot, result=result, schedule_index=index)) + '\n'); stream.flush()
                print(canonical({'done': index + 1, 'total': len(p['schedule']), 'case': slot['case_id'],
                                 'recipe': slot['recipe'], 'status': result['status'],
                                 'compile_ms': result.get('compile_ns', 0)/1e6,
                                 'wall_seconds': round(time.monotonic() - started, 3)}), flush=True)
    finally:
        for worker in workers.values(): worker.close()
    write_new(args.output / 'receipt.json', {'completed': True, 'wall_seconds': time.monotonic() - started,
              'protocol_sha256': sha(args.output / 'protocol.json'), 'raw_sha256': sha(args.output / 'raw.jsonl')})

def validate(args):
    from paired_analysis import checked_artifact
    from comparison_validation import validate_output, parse_qasm, common_metrics
    from scalable_clifford import validate_clifford
    p = protocol(args.output)
    receipt = json.loads((args.output / 'receipt.json').read_text())
    assert receipt['completed'] and sha(args.output / 'raw.jsonl') == receipt['raw_sha256']
    rows = [json.loads(line) for line in (args.output / 'raw.jsonl').read_text().splitlines()]
    assert len(rows) == len(p['schedule'])
    cache, counts = {}, Counter()
    by_case = {c['id']: c for c in p['cases']}
    with (args.output / 'validated.jsonl').open('x') as stream:
        for index, (row, slot) in enumerate(zip(rows, p['schedule'])):
            assert row['schedule_index'] == index and all(row[k] == v for k,v in slot.items())
            outcome, key, validation = checked_artifact(by_case[row['case_id']], row['result'], 'matched', cache,
                                                       validate_output, validate_clifford, parse_qasm, common_metrics)
            row.update(outcome=outcome, validation=validation, validation_cache_key=key)
            stream.write(canonical(row) + '\n')
            counts[outcome] += 1
    grouped = defaultdict(list)
    for row in rows: grouped[row['case_id'], row['recipe']].append(row)
    summaries = []
    for (case, recipe), values in grouped.items():
        measured = [r for r in values if r['phase'] == 'diagnostic' and r['result']['status'] == 'compiled'
                    and not r['result']['cold_after_failure']]
        pass_values = defaultdict(list)
        for row in measured:
            accumulated = defaultdict(int)
            for event in row['result'].get('pass_diagnostics', []): accumulated[event['pass']] += event['elapsed_ns']
            for name, elapsed in row['result'].get('stages_ns', {}).items(): accumulated[name] += elapsed
            for name, elapsed in accumulated.items(): pass_values[name].append(elapsed)
        fields = ('out_qasm','output_qubits','initial_layout','final_layout')
        fingerprints = {canonical({k:r['result'][k] for k in fields}) for r in values if r['result']['status'] == 'compiled'}
        summary = {'case_id': case, 'recipe': recipe, 'outcomes': dict(Counter(r['outcome'] for r in values)),
                   'all_artifacts_identical_across_repeats': len(fingerprints) == 1,
                   'eligible_for_diagnostic_timing': len(measured) == 3 and all(r['outcome'] == 'passed' for r in values),
                   'compile_ns_median': statistics.median(r['result']['compile_ns'] for r in measured) if measured else None,
                   'request_wall_ns_median': statistics.median(r['result']['request_wall_ns'] for r in measured) if measured else None,
                   'pass_medians_ns': {name:statistics.median(v) for name,v in pass_values.items()},
                   'metrics': [r['validation'].get('metrics') for r in measured if r['validation']],
                   'classifications': dict(Counter((r['validation'] or {}).get('failure_classification','not_compiled') for r in values)),
                   'sample_diagnostics': {k: measured[0]['result'].get(k) for k in ('clifford_retention_stats','clifford_simplification_stats','two_qubit_block_stats')} if measured else {}}
        summaries.append(summary)
    parity = []
    for case in by_case:
        controls = [r for r in rows if r['case_id'] == case and r['recipe'] in
                    ('qrust_default_unprofiled','qrust_default_profiled')]
        if controls:
            excluded = {'compile_ns','parse_ns','pass_diagnostics','request_wall_ns','cold_after_failure'}
            fingerprints = {canonical({k:v for k,v in r['result'].items() if k not in excluded}) for r in controls}
            parity.append({'case_id': case, 'requests': len(controls), 'exact_native_parity': len(fingerprints) == 1,
                           'excluded_native_fields': ['compile_ns','parse_ns','pass_diagnostics'],
                           'excluded_wrapper_fields': ['request_wall_ns','cold_after_failure']})
            assert len(fingerprints) == 1, 'Profiling changed native result beyond allowed fields'
    for case in by_case:
        for original, instrumented in [('qiskit_original','qiskit_profiled'),('tket_original','tket_profiled'),('cirq_frozen','cirq_original')]:
            paired = []
            for repeat in range(-1,3):
                pair = [r for r in rows if r['case_id']==case and r['repeat']==repeat and r['recipe'] in (original,instrumented)]
                if len(pair) == 2 and all(r['result']['status']=='compiled' for r in pair):
                    fingerprints = {canonical({k:r['result'][k] for k in ('out_qasm','output_qubits','initial_layout','final_layout')}) for r in pair}
                    assert len(fingerprints) == 1, 'Instrumented SDK baseline changed artifact or maps: ' + original
                    paired.append(repeat)
            if original in p['recipes'] and instrumented in p['recipes']:
                parity.append({'case_id':case,'original':original,'instrumented':instrumented,'matching_compiled_pairs':paired,
                               'expected_pairs':4,'all_pairs_available':len(paired)==4,'exact_artifact_and_map_parity':True if paired else None})
    write_new(args.output / 'summary.json', {'counts': dict(counts), 'cases': summaries, 'profile_parity': parity,
              'protocol_sha256': sha(args.output / 'protocol.json'), 'raw_sha256': sha(args.output / 'raw.jsonl'),
              'validated_sha256': sha(args.output / 'validated.jsonl'), 'unique_artifacts': len(cache)})
    print(canonical({'validated': dict(counts), 'unique_artifacts':len(cache)}))

def main():
    p = argparse.ArgumentParser(description=__doc__)
    sub = p.add_subparsers(dest='command', required=True)
    prep = sub.add_parser('prepare'); prep.add_argument('output', type=Path); prep.add_argument('recipes', nargs='+')
    for name in ('run','validate'):
        child=sub.add_parser(name); child.add_argument('output', type=Path)
    child=sub.add_parser('worker'); child.add_argument('recipe')
    args = p.parse_args()
    if args.command == 'worker': worker(args.recipe)
    else: globals()[args.command](args)

if __name__ == '__main__': main()
