#!/usr/bin/env python3
"""Plot stable session-one cell medians; never execute compilers or fit statistics."""
from __future__ import annotations
import argparse
from collections import Counter
import hashlib
import json
import math
from pathlib import Path
import statistics
import textwrap

STUDY=Path(__file__).absolute().parent.parent
TOOLS=('qrust','qiskit','cirq','tket')
LABELS={'qiskit':'Qiskit','cirq':'Cirq','tket':'TKET'}
STRATA={'untouched_generator_family':('Unused generator family','#0072B2','o'),
        'new_instance_known_family':('New instance of known family','#D55E00','^')}
ZERO_KEYS=('both_zero','numerator_zero','denominator_zero')


def require(condition,message):
    if not condition:raise ValueError(message)


def sha(path):
    digest=hashlib.sha256()
    with path.open('rb') as stream:
        for block in iter(lambda:stream.read(1<<20),b''):digest.update(block)
    return digest.hexdigest()


def ratio_value(numerator,denominator):
    require(all(isinstance(x,(float,int)) and not isinstance(x,bool) and math.isfinite(x) and x>=0
                for x in (numerator,denominator)),'Invalid cost/timing value')
    kind=('both_zero' if numerator==denominator==0 else 'numerator_zero' if numerator==0
          else 'denominator_zero' if denominator==0 else None)
    if kind:return None,kind
    value=numerator/denominator
    require(math.isfinite(value) and value>0,'Positive ratio is outside finite plotting range')
    return value,None


def compact(value):
    return value.removeprefix('mqt_holdout__').replace('__',' / ')


def derive(study,metrics):
    campaign=study/'heldout/campaign';bindings={}
    def read(path):
        require(path.is_file(),'Missing completed evidence: '+str(path))
        bindings[str(path.relative_to(study))]=sha(path)
        return json.loads(path.read_text())
    require(not (campaign/'active.lock').exists(),'Formal campaign remains active')
    protocol=read(campaign/'protocol.json');analysis=read(campaign/'analysis.json')
    validation=read(campaign/'validation_summary.json');warm_validation=read(campaign/'warmup_validation_summary.json')
    digest=sha(campaign/'protocol.json')
    require(digest==(campaign/'protocol.sha256').read_text().strip(),'Protocol checksum mismatch')
    for value in (analysis,validation,warm_validation):require(value['protocol_sha256']==digest,'Unbound analysis/validation')
    require(protocol['sessions']==2 and protocol['tools']==list(TOOLS),'Unexpected campaign design')
    require(len(analysis['sessions'])==2,'Incomplete session analysis')
    expected_cells={(case['id'],tool) for case in protocol['cases'] for tool in TOOLS}
    tables=[]
    for number in (1,2):
        directory=campaign/f'session_{number:02d}'
        receipt=read(directory/'session.json');cells=read(directory/'cells.json')
        require(receipt['completed'] is True and receipt['protocol_sha256']==digest,'Incomplete session')
        for kind in ('timed','warmup'):
            require(receipt[kind+'_sha256']==sha(directory/(kind+'.jsonl')),'Changed raw session evidence')
        require(validation['sessions'][number-1]['validated_sha256']==sha(directory/'validated.jsonl'),'Changed saved validation')
        require(warm_validation['sessions'][number-1]['warmup_validated_sha256']==sha(directory/'warmup_validated.jsonl'),'Changed saved warmup validation')
        require(analysis['sessions'][number-1]['session']==number,'Session analysis order differs')
        require(len(cells)==len(protocol['cases'])*len(TOOLS),'Incomplete cell table')
        indexed={(c['case_id'],c['tool']):c for c in cells}
        require(len(indexed)==len(cells),'Duplicate cell identity')
        require(set(indexed)==expected_cells,'Missing or unexpected cell identity')
        require([c for c in cells if not c['eligible']]==analysis['sessions'][number-1]['excluded_cells'],'Excluded-cell evidence differs')
        tables.append(indexed)
    stable={key for key,c in tables[0].items() if c['eligible'] and tables[1][key]['eligible']}
    reference=analysis['sessions'][0]['stable_two_session_cells']
    for tool in TOOLS:require(sum(t==tool for _,t in stable)==reference['coverage'][tool],'Stable coverage differs')
    panels={}
    for tool in TOOLS[1:]:
        ids=sorted(case for case,t in stable if t=='qrust' and (case,tool) in stable)
        summary=reference['pairwise'][tool]
        require(len(ids)==summary['paired_cells'],'Paired denominator differs')
        require(summary['compile_ns']['positive_ratio_cells']==len(ids) and not any(summary['compile_ns']['zero_cases'].values()),'Frozen speed eligibility is not strictly positive')
        rows=[]
        for case in ids:
            q,b=tables[0][case,'qrust'],tables[0][case,tool]
            require(q['holdout_class'] in STRATA,'Unknown hold-out class')
            require(all(q[k]==b[k] for k in ('fixture','family','topology','holdout_class')),'Pair metadata differs')
            speed,speed_zero=ratio_value(b['medians']['compile_ns'],q['medians']['compile_ns'])
            require(speed_zero is None,'Eligible compilation duration must be positive')
            values={};zero={}
            for metric in metrics:values[metric],zero[metric]=ratio_value(q['medians'][metric],b['medians'][metric])
            rows.append({'case_id':case,'fixture':q['fixture'],'family':q['family'],'topology':q['topology'],
                         'holdout_class':q['holdout_class'],'qrust':q['medians'],'baseline':b['medians'],
                         'compile_speed_ratio':speed,'quality_ratios':values,'zero_exclusions':zero})
        zero_counts={}
        for metric in metrics:
            zeros=Counter({key:0 for key in ZERO_KEYS})
            zeros.update(row['zero_exclusions'][metric] for row in rows if row['zero_exclusions'][metric])
            positives=[row['quality_ratios'][metric] for row in rows if row['quality_ratios'][metric] is not None]
            require(dict(zeros)==summary[metric]['zero_cases'],'Zero exclusion policy differs from frozen analysis')
            require(len(positives)==summary[metric]['positive_ratio_cells'],'Positive-ratio denominator differs')
            if positives:
                require(math.isclose(math.exp(statistics.mean(map(math.log,positives))),summary[metric]['geomean'],rel_tol=1e-12),'Cell ratios differ from frozen analysis')
            else:require(summary[metric]['geomean'] is None,'Unexpected frozen quality mean')
            zero_counts[metric]=dict(zeros)
        if rows:
            speed_mean=math.exp(statistics.mean(math.log(r['compile_speed_ratio']) for r in rows))
            require(math.isclose(speed_mean,summary['compile_ns']['geomean'],rel_tol=1e-12),'Speed formula differs from frozen analysis')
        # Use the frozen analysis's selected tails rather than introducing a new tie-break policy.
        tails=reference['worst_tails'][tool]
        selected={letter:values[0]['case_id'] for letter,values in
                  (('C',tails['worst_cx_count']),('S',tails['slowest_relative_cases'])) if values}
        require(all(case in ids for case in selected.values()),'Tail outside the stable cohort')
        panels[tool]={'paired_cases':len(rows),'total_cases':len(protocol['cases']),'rows':rows,
                      'zero_counts':zero_counts,'annotations':selected}
    return {'schema':1,'session':1,'eligibility':'Both tools eligible across both sessions; displayed cell medians from session 1 only.',
            'metrics':metrics,'speed_formula':'baseline compile_ns / Q-Rust compile_ns; >1 means Q-Rust faster',
            'quality_formula':'Q-Rust metric / baseline metric; >1 means Q-Rust more CX or deeper',
            'zero_policy':'No pseudocount or clipping. Zero numerator/denominator omitted from log axes and retained in data/counts.',
            'annotation_policy':'C is the first frozen worst_cx_count entry; S is the first frozen slowest_relative_cases entry. Nonpositive-axis annotations are retained in the caption/data but cannot be plotted.',
            'aggregate_policy':'No new inferential statistics; plotted ratios and counts cross-checked against frozen session-1 analysis. Refer to the report for both sessions and confidence intervals.',
            'input_sha256':bindings,'protocol_sha256':digest,'plot_script_sha256':sha(Path(__file__)),
            'panels':panels}


def axis_limits(values):
    logs=[0.0,*[math.log10(value) for value in values]]
    low,high=min(logs),max(logs)
    padding=max((high-low)*0.09,0.08)
    return 10**(low-padding),10**(high+padding)


def render(data,output):
    require(not output.exists(),'Choose a fresh figure directory')
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    from matplotlib.lines import Line2D
    from matplotlib import font_manager
    import importlib.metadata
    plt.rcdefaults()
    matplotlib.rcParams.update({'font.family':'DejaVu Sans','font.size':9,'axes.titlesize':12,
        'axes.labelsize':10,'svg.hashsalt':'qrust-frozen-tradeoffs-20261018','savefig.facecolor':'white'})
    metrics=data['metrics'];count=len(metrics)
    fig,axes=plt.subplots(count,3,figsize=(15,4.1*count+1.6),squeeze=False)
    fig.subplots_adjust(left=.075,right=.985,top=.85,bottom=.20,hspace=.38,wspace=.25)
    xvalues=[row['compile_speed_ratio'] for panel in data['panels'].values() for row in panel['rows']]
    xlim=axis_limits(xvalues)
    for rownum,metric in enumerate(metrics):
        yvalues=[r['quality_ratios'][metric] for p in data['panels'].values() for r in p['rows'] if r['quality_ratios'][metric] is not None]
        ylim=axis_limits(yvalues)
        for col,tool in enumerate(TOOLS[1:]):
            ax=axes[rownum,col];panel=data['panels'][tool];rows=panel['rows']
            ax.set_xscale('log');ax.set_yscale('log');ax.set_xlim(xlim);ax.set_ylim(ylim)
            ax.axvline(1,color='#555555',linestyle='--',linewidth=.9,zorder=1)
            ax.axhline(1,color='#555555',linestyle='--',linewidth=.9,zorder=1)
            ax.grid(True,which='major',color='#dddddd',linewidth=.5,zorder=0)
            for group,(label,color,marker) in STRATA.items():
                chosen=[r for r in rows if r['holdout_class']==group and r['quality_ratios'][metric] is not None]
                ax.scatter([r['compile_speed_ratio'] for r in chosen],[r['quality_ratios'][metric] for r in chosen],
                           s=28,c=color,marker=marker,alpha=.75,edgecolors='white',linewidths=.3,zorder=3)
            zero=panel['zero_counts'][metric];plotted=len(rows)-sum(zero.values())
            if rownum==0:ax.set_title(LABELS[tool],pad=35,weight='bold')
            ax.text(.5,1.015,f'Stable pairs {len(rows)}/{panel["total_cases"]}; plotted {plotted}; zeros {sum(zero.values())}\n'
                    f'Q-Rust zero only {zero["numerator_zero"]}; baseline zero only {zero["denominator_zero"]}; both zero {zero["both_zero"]}',
                    ha='center',va='bottom',fontsize=7.8,transform=ax.transAxes)
            ylabel='CX ratio' if metric=='cx_count' else 'Depth ratio'
            ax.set_ylabel(ylabel+'  (Q-Rust / baseline)\n>1: Q-Rust more CX / deeper' if col==0 else ylabel)
            ax.set_xlabel('Compile-time ratio (baseline / Q-Rust)\n>1: Q-Rust faster')
            annotations={}
            for letter,case in panel['annotations'].items():annotations.setdefault(case,[]).append(letter)
            index={r['case_id']:r for r in rows}
            for case,letters in annotations.items():
                r=index[case];y=r['quality_ratios'][metric]
                if y is None:continue
                x=r['compile_speed_ratio'];label='/'.join(letters)
                offset=(7,11) if 'C' in letters else (7,-16)
                ax.annotate(label,(x,y),xytext=offset,textcoords='offset points',fontsize=8,weight='bold',
                            bbox={'boxstyle':'round,pad=.15','fc':'white','ec':'#444444','lw':.5},
                            arrowprops={'arrowstyle':'-','color':'#444444','lw':.6},zorder=5)
    fig.suptitle('Frozen held-out comparison — session 1 cell medians',y=.975,fontsize=15,weight='bold')
    fig.text(.5,.937,'Stable qualification uses both sessions. Ratios describe the pinned recipes; session 1 and 2 aggregate results appear in the report.',ha='center',fontsize=10)
    handles=[Line2D([],[],color=color,marker=marker,linestyle='None',label=label,markersize=7)
             for label,color,marker in STRATA.values()]
    fig.legend(handles=handles,loc='upper center',bbox_to_anchor=(.5,.925),ncol=2,frameon=False)
    for col,tool in enumerate(TOOLS[1:]):
        selected=data['panels'][tool]['annotations']
        text=LABELS[tool]+': C = largest CX ratio; S = lowest speed ratio\n'
        text+='\n'.join(textwrap.fill(letter+': '+compact(case),width=50) for letter,case in selected.items())
        fig.text(.075+col*.305,.137,text,ha='left',va='top',fontsize=8)
    fig.text(.075,.025,'Zero costs are omitted from logarithmic axes and counted explicitly. C/S denotes the same selected case; labels follow frozen-analysis tails. No hardware-fidelity claim.',fontsize=8)
    output.mkdir(parents=True)
    fig.savefig(output/'tradeoffs.svg',metadata={'Date':None,'Creator':'Q-Rust frozen study plot'})
    fig.savefig(output/'tradeoffs.png',dpi=180,metadata={'Software':'Q-Rust frozen study plot'})
    plt.close(fig)
    font_path=Path(font_manager.findfont(font_manager.FontProperties(family='DejaVu Sans'),fallback_to_default=False))
    data['rendering']={'matplotlib':matplotlib.__version__,'font':'DejaVu Sans','font_file_sha256':sha(font_path),'dpi':180,
                       'dependency_versions':{name:importlib.metadata.version(name) for name in ('matplotlib','numpy','pillow')},
                       'figure_sha256':{name:sha(output/name) for name in ('tradeoffs.svg','tradeoffs.png')},
                       'determinism':'Stable ordering, fixed styles/hash salt, no time metadata; byte identity is scoped to the same rendering dependencies.'}
    with (output/'data.json').open('x') as stream:json.dump(data,stream,indent=2,sort_keys=True,allow_nan=False);stream.write('\n')
    print(json.dumps({'output':str(output),'paired_cases':{t:p['paired_cases'] for t,p in data['panels'].items()},'session':1}))


if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--study',type=Path,default=STUDY);parser.add_argument('--output',type=Path)
    parser.add_argument('--cx-only',action='store_true')
    args=parser.parse_args();args.study=args.study.absolute()
    data=derive(args.study,['cx_count'] if args.cx_only else ['cx_count','depth'])
    render(data,args.output or args.study/'figures')
