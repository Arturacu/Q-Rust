#!/usr/bin/env python3
"""Package a completed frozen study without changing historical evidence."""
import argparse
import json
from pathlib import Path
import subprocess
import sys

from archive_primitives import (audit_prose, copy_file, copy_tree, dump_new,
    extract_and_audit, manifest_and_archive, relative_name, require, sha)


def check_output_paths(study, destination, scratch):
    study, destination, scratch = (path.resolve() for path in (study, destination, scratch))
    require(not destination.exists() and not scratch.exists(),
            'Choose fresh destination and scratch paths')
    paths = (study, destination, scratch)
    for index, left in enumerate(paths):
        for right in paths[index + 1:]:
            require(not left.is_relative_to(right) and not right.is_relative_to(left),
                    'Study, destination and scratch must be separate directory trees')
    return study, destination, scratch


def frozen_sources(study, stage):
    freeze = json.loads((study / 'compiler_freeze.json').read_text())
    working = study.parent
    records = freeze['compiler_and_recipe_files'] + freeze['generator_source_files'] + [freeze['binary']]
    for record in records:
        source = Path(record['path'])
        require(source.is_relative_to(working), 'Frozen payload outside study workspace')
        require(source.stat().st_size == record['bytes'] and sha(source) == record['sha256'],
                'Frozen payload changed: ' + str(source))
        target = stage / 'working' / source.relative_to(working)
        if not target.exists():
            copy_file(source, target)
        else:
            require(sha(target) == record['sha256'], 'Conflicting archive payload')
    return freeze


def check_completion(study):
    completion = json.loads((study / 'completion.json').read_text())
    require(completion['all_work_completed'] is True, 'Study is not complete')
    for name, expected in completion['completed_artifacts'].items():
        source = study / relative_name(name)
        require(source.is_file() and sha(source) == expected, 'Completed artifact changed: ' + name)
    require(not list(study.rglob('active.lock')), 'A benchmark process may still be active')
    return completion


def main():
    p = argparse.ArgumentParser(description=__doc__)
    for name in ('study', 'repo', 'destination', 'scratch', 'report', 'text-policy-file'):
        p.add_argument('--' + name, type=Path, required=True)
    args = p.parse_args()
    args.study, args.destination, args.scratch = check_output_paths(
        args.study, args.destination, args.scratch)
    completion = check_completion(args.study)
    preservation = json.loads((args.study / 'original_preservation.json').read_text())
    for item in preservation['files']:
        source = args.study.parent / relative_name(item['path'])
        require(source.is_file() and source.stat().st_size == item['bytes'] and sha(source) == item['sha256'],
                'Previous evidence changed: ' + item['path'])
    args.scratch.mkdir(parents=True)
    stage = args.scratch / 'stage'
    stage.mkdir()
    working = stage / 'working'
    copy_tree(args.study, working / args.study.name)
    frozen = frozen_sources(args.study, stage)
    protocol = json.loads((args.study / 'heldout/campaign/protocol.json').read_text())
    # The primary harness also binds ignored diagnostic Rust sources. Keep the
    # complete build-input inventory it recorded, not only Git-tracked files.
    for name, expected in protocol['compiler_provenance']['compiler_source_sha256'].items():
        name = relative_name(name)
        source = args.repo / name
        require(sha(source) == expected, 'Protocol-bound compiler source changed: ' + name)
        target = working / 'qrust_pr_publish' / name
        if target.exists():
            require(sha(target) == expected, 'Conflicting protocol-bound source')
        else:
            copy_file(source, target)
    # Frozen sources already copied above. Preserve source provenance metadata,
    # licenses and the small original benchmark mirrors alongside them.
    source_root = args.study.parent / 'qrust_external_20261018/sources'
    source_target = working / 'qrust_external_20261018/sources'
    for name in ('mqtbench_commit.json', 'mqtbench_tree.json', 'qasmbench_commit.json',
                 'qasmbench_tree.json', 'benchpress_commit.json', 'benchpress_tree.json'):
        copy_file(source_root / name, source_target / name)
    for name in ('qasmbench', 'benchpress'):
        copy_tree(source_root / name, source_target / name)
    copy_tree(args.study.parent / 'qrust_tket_benchpress_20261018/benchpress/frozen',
              working / 'qrust_tket_benchpress_20261018/benchpress/frozen')
    copy_file(args.study.parent / 'qrust_tket_benchpress_20261018/benchpress/benchpress-b695f30e83a32bac05b9b4d8e98d37ba9aae5236/LICENSE.txt',
              stage / 'upstream_legal/benchpress/LICENSE.txt')
    for path in args.repo.iterdir():
        if path.is_file() and path.name.lower().startswith(('license', 'copying', 'notice')):
            copy_file(path, working / 'qrust_pr_publish' / path.name)
    for path in (args.repo / 'experiments').glob('requirements*.txt'):
        copy_file(path, working / 'qrust_pr_publish/experiments' / path.name)
    copy_file(args.report, stage / 'report' / args.report.name)
    dump_new(stage / 'evidence_index.json', {
        'schema': 1, 'study_path': 'working/' + args.study.name,
        'compiler_source_and_harness': 'working/qrust_pr_publish',
        'frozen_repository_commit': frozen['repository_commit'],
        'timed_compiler_source_commit': frozen['timed_compiler_source_commit'],
        'binary_sha256': frozen['binary']['sha256'],
        'scope': 'Complete new-study inputs, recipes, schedules, raw outcomes, diagnostic attempts, validation, analysis, scripts and receipts. Original absolute paths are provenance. Installed distributions are recorded by file hash. requirements-comparison.txt supplies version pins, but strict replay additionally requires byte-identical installed files; version equality alone is insufficient. The native binary is for its original host architecture.',
        'previous_evidence': 'Every historical checksum is retained and checked before packaging; prior archive payloads remain in their original versioned result directories rather than being duplicated here.',
        'completion_sha256': sha(args.study / 'completion.json'),
        'preserved_previous_files': len(preservation['files'])})
    audit_prose(stage, json.loads(args.text_policy_file.read_text()))
    args.destination.mkdir(parents=True)
    archive = args.destination / 'evidence.tar.gz'
    manifest_and_archive(stage, archive)
    audit = extract_and_audit(archive, args.scratch / 'extracted')
    copy_file(stage / 'sha256_manifest.json', args.destination / 'evidence_manifest.json')
    dump_new(args.destination / 'checksums.json', {
        'schema': 1, 'archive_sha256': sha(archive), 'archive_bytes': archive.stat().st_size,
        'manifest_sha256': sha(args.destination / 'evidence_manifest.json'),
        'compiler_freeze_sha256': sha(args.study / 'compiler_freeze.json'),
        'preservation_manifest_sha256': sha(args.study / 'original_preservation.json'),
        'archive_audit': audit})
    print(json.dumps({'archive': str(archive), 'extracted': str(args.scratch / 'extracted'), **audit}))


if __name__ == '__main__':
    main()
