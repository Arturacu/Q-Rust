#!/usr/bin/env python3
"""Fail-closed protocol checks; no held-out compiler inputs are executed."""
import argparse
import copy
import json
import sys
import tempfile
from pathlib import Path
from types import SimpleNamespace
import unittest

import heldout_corpus as corpus
import heldout_study as study


class SelectionTests(unittest.TestCase):
    def test_candidate_count_and_no_fixed_constructor_padding(self):
        rows = corpus.candidates()
        self.assertEqual(len(rows), 30)
        self.assertEqual(len({row['id'] for row in rows}), 30)
        self.assertEqual(sum(row['holdout_class'] == 'untouched_generator_family' for row in rows), 15)
        for family in ('randomcircuit', 'draper_qft_adder'):
            selected = [row for row in rows if row['family'] == family]
            self.assertEqual(len(selected), 3)
            self.assertTrue(all(row['parameter_seed'] is None for row in selected))

    def test_grid_edges_are_explicit_connected_and_bounded(self):
        for width, count in ((6, 7), (10, 13), (16, 24)):
            edges = corpus.target_edges(width, 'grid')
            self.assertEqual(len(edges), count)
            self.assertEqual(len(set(map(tuple, edges))), count)
            reached = {0}
            while True:
                extra = {b for a, b in edges if a in reached} | {a for a, b in edges if b in reached}
                if extra <= reached:
                    break
                reached |= extra
            self.assertEqual(reached, set(range(width)))
            self.assertTrue(all(0 <= a < b < width for a, b in edges))

    def test_unknown_target_and_width_fail(self):
        with self.assertRaises(ValueError):
            corpus.target_edges(6, 'not_a_target')
        with self.assertRaises(KeyError):
            corpus.target_edges(14, 'grid')

    def test_lexical_digest_strips_only_comments_and_whitespace(self):
        a = 'OPENQASM 2.0; qreg q[6]; cx q[0],q[5];'
        b = '// example\nOPENQASM 2.0;\nqreg q[6];\ncx q[0], q[5]; // tail'
        self.assertEqual(corpus.lexical_digest(a), corpus.lexical_digest(b))
        self.assertNotEqual(corpus.lexical_digest(a), corpus.lexical_digest(a.replace('q[5]', 'q[4]')))

    def test_prior_inventory_reads_embedded_inputs_not_only_files(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            qasm = 'OPENQASM 2.0; qreg q[6]; h q[0];'
            (root / 'protocol.json').write_text(json.dumps({'cases': [{'qasm': qasm}]}))
            rows = corpus.prior_inventory(root, root / 'new_study')
            self.assertEqual(len(rows), 1)
            self.assertEqual(rows[0]['kind'], 'json_input_payload')
            self.assertEqual(rows[0]['sha256'], corpus.digest(qasm))


class ProtocolTests(unittest.TestCase):
    @staticmethod
    def fixture():
        text = 'OPENQASM 2.0; include "qelib1.inc"; qreg q[6]; h q[0];'
        return {'id': 'test_input', 'family': 'generic', 'n_logical': 6,
            'source_qasm': text, 'qasm': text, 'source_sha256': study.sha(text), 'normalized_sha256': study.sha(text),
            'normalization_evidence': {'passed': True, 'mode': 'full_unitary_numerical',
                'input_count': 64, 'tolerance': 1e-7, 'residuals': {'source': 0, 'normalized': 0}}}

    def test_case_grid_has_identical_input_and_explicit_edges(self):
        fixture = self.fixture()
        rows = study.build_cases({'cases': [fixture]})
        self.assertEqual(len(rows), 3)
        self.assertTrue(all(row['qasm'] == fixture['qasm'] for row in rows))
        self.assertEqual(next(row for row in rows if row['topology'] == 'grid')['edges'], corpus.target_edges(6, 'grid'))

    def test_bad_hash_or_duplicate_fixture_rejected(self):
        fixture = self.fixture()
        fixture['normalized_sha256'] = '0' * 64
        with self.assertRaises(ValueError):
            study.build_cases({'cases': [fixture]})
        with self.assertRaises(ValueError):
            study.build_cases({'cases': [self.fixture(), self.fixture()]})

    def test_unsupported_width_and_invalid_evidence_rejected(self):
        for field, value in [('n_logical', 17), ('n_logical', 14), ('n_logical', True)]:
            fixture = self.fixture()
            fixture[field] = value
            with self.assertRaises(ValueError):
                study.build_cases({'cases': [fixture]})
        for field, value in [('passed', False), ('input_count', 8), ('tolerance', 1e-6), ('mode', 'sampled_8_inputs_numerical')]:
            fixture = self.fixture()
            fixture['normalization_evidence'][field] = value
            with self.assertRaises(ValueError):
                study.build_cases({'cases': [fixture]})

    def test_idle_worker_rss_and_aggregate_limit(self):
        study.check_rss({101: study.PER_WORKER_RSS, 102: 1})
        with self.assertRaises(MemoryError):
            study.check_rss({101: 1, 102: study.PER_WORKER_RSS + 1})
        with self.assertRaises(MemoryError):
            study.check_rss({101: study.PER_WORKER_RSS, 102: study.PER_WORKER_RSS})

    def test_maximum_slot_count(self):
        plan = study.plan()
        self.assertEqual(plan['maximum_candidate_cases'], 90)
        self.assertEqual(plan['maximum_timed_slots'], 3600)
        self.assertEqual(plan['maximum_initial_warmup_slots'], 720)

    def test_changed_frozen_source_fails(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            files = [root / 'a.rs', root / 'b.rs', root / 'binary']
            for path in files:
                path.write_text('original')
            rows = [{'path': str(path), 'bytes': path.stat().st_size, 'sha256': study.sha(path)} for path in files]
            freeze = {'compiler_and_recipe_files': rows[:2], 'generator_source_files': [],
                'installed_files': [], 'binary': rows[2], 'versions': {},
                'python_executable': str(Path(sys.executable).absolute())}
            study.verify_freeze(freeze, SimpleNamespace(allow_relocated=False))
            files[0].write_text('tampered')
            with self.assertRaises(ValueError):
                study.verify_freeze(freeze, SimpleNamespace(allow_relocated=False))

    def test_relocated_source_requires_identical_bytes(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            old, new = root / 'old', root / 'new'
            old.mkdir(); new.mkdir()
            entries = []
            for name in ('a.rs', 'b.rs'):
                (old / name).write_text('frozen')
                (new / name).write_text('frozen')
                entries.append({'path': str(old / name), 'bytes': 6, 'sha256': study.sha(old / name)})
            binary = new / 'binary'
            binary.write_text('binary')
            freeze = {'compiler_and_recipe_files': entries, 'generator_source_files': [], 'installed_files': [],
                'binary': {'path': str(old / 'binary'), 'bytes': 6, 'sha256': study.sha(binary)},
                'versions': {}, 'python_executable': str(Path(sys.executable).absolute())}
            args = SimpleNamespace(allow_relocated=True, repo=new, binary=binary, generator_root=None)
            study.verify_freeze(freeze, args)
            (new / 'a.rs').write_text('edited')
            with self.assertRaises(ValueError):
                study.verify_freeze(freeze, args)


class ExistingContractTests(unittest.TestCase):
    def setUp(self):
        self.external = study.configure(REPO)
        self.protocol = {'cases': study.build_cases({'cases': [ProtocolTests.fixture()]}),
            'sessions': 2, 'trials': study.TRIALS, 'master_seed': study.MASTER_SEED}
        self.protocol['schedules'] = {str(session): self.external.schedule(
            self.protocol['cases'], study.TRIALS, study.MASTER_SEED, session) for session in (1, 2)}

    def timed_rows(self):
        return [{**entry, 'session': 1, 'status': 'error',
            'id': f"{entry['case_id']}__{entry['tool']}__{entry['trial']}"}
            for entry in self.protocol['schedules']['1'] if entry['trial'] >= 0]

    def warmups(self):
        return [{**entry, 'session': 1, 'status': 'error'}
                for entry in self.protocol['schedules']['1'] if entry['trial'] == -1]

    def test_missing_timed_slot_rejected(self):
        rows = self.timed_rows()
        self.external.check_rows(self.protocol, 1, rows)
        with self.assertRaises(ValueError):
            self.external.check_rows(self.protocol, 1, rows[:-1])

    def test_missing_duplicate_or_unscheduled_warmup_rejected(self):
        rows = self.warmups()
        study.check_warmups(self.protocol, 1, rows, self.external)
        for invalid in (rows[:-1], rows + rows[:1], [{**rows[0], 'seed': 9}, *rows[1:]]):
            with self.assertRaises(ValueError):
                study.check_warmups(self.protocol, 1, invalid, self.external)

    def test_duplicate_restart_warmup_rejected(self):
        entry = next(row for row in self.protocol['schedules']['1'] if row['trial'] == 0)
        replacement = {**entry, 'session': 1, 'status': 'error', 'reason': 'worker_restart'}
        study.check_warmups(self.protocol, 1, self.warmups() + [replacement], self.external)
        with self.assertRaises(ValueError):
            study.check_warmups(self.protocol, 1, self.warmups() + [replacement, replacement], self.external)

    def test_failure_taxonomy_is_not_validation_success(self):
        from paired_analysis import classify_evidence
        self.assertEqual(classify_evidence({'passed': False, 'evidence_class': 'sampled_isometry'}, 'external'), 'semantic_counterexample')
        self.assertEqual(classify_evidence({'passed': False, 'evidence_class': 'unchecked_width'}, 'external'), 'unsupported_width')
        self.assertEqual(classify_evidence({'passed': False, 'evidence_class': 'invalid'}, 'external'), 'structural_contract_failure')

    def test_zero_ratio_is_excluded_and_counted(self):
        from analyze_comparison_study import geometric_ratio_summary
        result = geometric_ratio_summary([
            {'fixture': 'a', 'numerator': 0, 'denominator': 3},
            {'fixture': 'b', 'numerator': 4, 'denominator': 0},
            {'fixture': 'c', 'numerator': 2, 'denominator': 2}], label='zero-policy', draws=20)
        self.assertEqual(result['geomean'], 1.0)
        self.assertEqual(result['positive_ratio_cells'], 1)
        self.assertEqual(result['zero_cases'], {'both_zero': 0, 'numerator_zero': 1, 'denominator_zero': 1})

    def test_timeout_and_memory_status_remain_distinct(self):
        from comparison_study import Worker
        class Broken(Worker):
            def __init__(self, error):
                self.error, self.process = error, None
            def start(self):
                raise self.error
            def close(self):
                self.process = None
        timeout = Broken(TimeoutError('limit')).call({}, 1)
        memory = Broken(MemoryError('limit')).call({}, 1)
        self.assertEqual(timeout['status'], 'timeout')
        self.assertEqual(memory['status'], 'error')
        self.assertTrue(memory['error'].startswith('MemoryError:'))

    def test_failed_initial_and_restart_warmups_exclude_cells(self):
        class FakeBase:
            @staticmethod
            def build_cells(*args, **kwargs):
                return [{'case_id': 'test', 'tool': 'qrust', 'eligible': True,
                    'exclusion_reasons': [], 'medians': {'compile_ns': 1}, 'ranges': {}}]
        protocol = {'cases': [{'id': 'test', 'holdout_class': 'new_instance_known_family', 'coarse_family': 'generic'}]}
        good = {'case_id': 'test', 'tool': 'qrust', 'status': 'compiled', 'validation': {'passed': True}}
        for rows in ([{**good, 'status': 'timeout', 'validation': {}}],
                     [good, {**good, 'reason': 'worker_restart', 'status': 'memory_limit', 'validation': {}}],
                     [good, {**good, 'reason': 'worker_restart', 'validation': {'passed': False}}]):
            cell = study.qualify_cells(protocol, [], [], rows, FakeBase)[0]
            self.assertFalse(cell['eligible'])
            self.assertIsNone(cell['medians'])


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--repo', type=Path, required=True)
    args, remainder = parser.parse_known_args()
    REPO = args.repo
    unittest.main(argv=[sys.argv[0], *remainder])
