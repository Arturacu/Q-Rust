#!/usr/bin/env python3
"""Exercise explicit grid routing on an unrelated generic six-qubit input."""
import argparse
import json
from pathlib import Path
import sys

from heldout_corpus import target_edges
from heldout_study import TOOLS, dump_new, sha


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--repo', type=Path, required=True)
    parser.add_argument('--binary', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    sys.path.insert(0, str(args.repo / 'experiments'))
    from comparison_study import Worker
    qasm = '\n'.join(['OPENQASM 2.0;', 'include "qelib1.inc";', 'qreg q[6];',
        'h q[0];', 'ry(0.314159) q[2];', 'cx q[0],q[5];', 'cx q[0],q[4];',
        'cx q[0],q[3];', 'cx q[0],q[2];', 'cx q[0],q[1];', 'rz(0.271828) q[5];',
        'cx q[5],q[1];', 'ry(-0.8317) q[3];', 'cx q[3],q[5];']) + '\n'
    edges = target_edges(6, 'grid')
    request = {'qasm': qasm, 'n_logical': 6, 'physical_width': 6,
               'edges': edges, 'topology': 'grid', 'seed': 20261020}
    args.output.mkdir(parents=True, exist_ok=False)
    raw = {}
    for tool in TOOLS:
        worker = Worker(tool, args.binary, args.output)
        try:
            raw[tool] = worker.call(request, 60)
            raw[tool].setdefault('status', 'compiled')
        finally:
            worker.close()
    from comparison_validation import validate_output
    checked = {}
    for tool, row in raw.items():
        if row['status'] != 'compiled':
            checked[tool] = {'passed': False, 'compile_status': row['status']}
        else:
            checked[tool] = validate_output(qasm, row['out_qasm'], 6, 6,
                [pair for a, b in edges for pair in ((a, b), (b, a))], row['initial_layout'], row['final_layout'])
    result = {'scope': 'Generic protocol smoke test, disjoint from held-out fixtures; not benchmark evidence.',
              'binary_sha256': sha(args.binary), 'request': request, 'outputs': raw,
              'validation': checked, 'passed': all(row['passed'] is True for row in checked.values())}
    dump_new(args.output / 'result.json', result)
    print(json.dumps({'passed': result['passed'], 'by_tool': {tool: row['passed'] for tool, row in checked.items()}}))
    if not result['passed']:
        raise SystemExit(1)


if __name__ == '__main__':
    main()
