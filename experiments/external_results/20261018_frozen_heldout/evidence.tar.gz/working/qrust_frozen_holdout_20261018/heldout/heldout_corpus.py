#!/usr/bin/env python3
"""Prespecified pinned-generator holdout; never calls compiler optimization."""
from __future__ import annotations

import argparse
from collections import Counter
import hashlib
import json
import os
from pathlib import Path
import re
import sys

WIDTHS = (6, 10, 16)
PARAMETER_SEEDS = (11, 29)
FAMILIES = ('bmw_quark_copula', 'bmw_quark_cardinality', 'qaoa', 'vqe_two_local',
            'draper_qft_adder', 'randomcircuit')
PARAMETERIZED = frozenset(FAMILIES[:4])
UNTOUCHED = frozenset(('bmw_quark_copula', 'bmw_quark_cardinality', 'randomcircuit'))
SKIP_DIRS = frozenset(('.git', 'target', '__pycache__', 'node_modules', '.venv', 'venv',
                       'qrust_comparison_env', 'package_audit', 'archive_replay'))


def digest(data):
    return hashlib.sha256(data.encode() if isinstance(data, str) else data).hexdigest()


def dump_new(path, value):
    with path.open('x') as out:
        json.dump(value, out, indent=2, sort_keys=True, allow_nan=False)
        out.write('\n')


def lexical_digest(qasm):
    """Catch repeated exact QASM modulo comments and whitespace; not semantic proof."""
    qasm = re.sub(r'//[^\n]*', '', qasm)
    return digest(re.sub(r'\s+', '', qasm))


def candidates():
    result = []
    for family in FAMILIES:
        for width in WIDTHS:
            for seed in PARAMETER_SEEDS if family in PARAMETERIZED else (None,):
                name = f'mqt_holdout__{family}_n{width}' + (f'_s{seed}' if seed is not None else '')
                result.append({'id': name, 'family': family, 'width': width,
                    'parameter_seed': seed, 'generator_options': {'seed': seed} if family == 'qaoa' else {},
                    'generator_random_seed': 10 if family == 'randomcircuit' else (seed if family == 'qaoa' else None),
                    'holdout_class': 'untouched_generator_family' if family in UNTOUCHED else 'new_instance_known_family',
                    'coarse_family': ('generative_modeling' if family.startswith('bmw_') else
                                      'general_random' if family == 'randomcircuit' else
                                      'arithmetic' if family == 'draper_qft_adder' else
                                      'variational' if family == 'vqe_two_local' else 'qaoa')})
    return result


def target_edges(width, topology):
    if topology == 'all_to_all':
        return [[a, b] for a in range(width) for b in range(a + 1, width)]
    if topology == 'linear':
        return [[a, a + 1] for a in range(width - 1)]
    if topology != 'grid':
        raise ValueError('Unknown target')
    rows, columns = {6: (2, 3), 10: (2, 5), 16: (4, 4)}[width]
    edges = []
    for row in range(rows):
        for col in range(columns):
            q = row * columns + col
            if col + 1 < columns:
                edges.append([q, q + 1])
            if row + 1 < rows:
                edges.append([q, q + columns])
    return sorted(edges)


def prior_inventory(working, exclude):
    paths = []

    def embedded(value, pointer=''):
        if isinstance(value, dict):
            for key, item in value.items():
                if key in ('qasm', 'source_qasm') and isinstance(item, str) and 'OPENQASM' in item:
                    yield pointer + '/' + key, item
                elif isinstance(item, (dict, list)):
                    yield from embedded(item, pointer + '/' + key)
        elif isinstance(value, list):
            for index, item in enumerate(value):
                yield from embedded(item, pointer + '/' + str(index))

    for directory, dirs, files in os.walk(working):
        dirs[:] = sorted(name for name in dirs if name not in SKIP_DIRS
                         and not (Path(directory) / name).resolve().is_relative_to(exclude.resolve()))
        for name in sorted(files):
            if not name.endswith(('.qasm', '.json')):
                continue
            path = Path(directory) / name
            text = path.read_text()
            if name.endswith('.qasm'):
                paths.append({'path': str(path.relative_to(working)), 'kind': 'qasm_file',
                              'sha256': digest(text), 'lexical_sha256': lexical_digest(text)})
            elif 'OPENQASM' in text:
                for pointer, qasm in embedded(json.loads(text)):
                    paths.append({'path': str(path.relative_to(working)) + '#' + pointer,
                        'kind': 'json_input_payload', 'container_sha256': digest(text),
                        'sha256': digest(qasm), 'lexical_sha256': lexical_digest(qasm)})
    return paths


def prescribe(args):
    args.output.mkdir(parents=True, exist_ok=True)
    old = prior_inventory(args.working, args.output.parent)
    dump_new(args.output / 'prior_qasm_inventory.json', old)
    selection = {'schema': 1, 'candidates': candidates(), 'topologies': ['all_to_all', 'linear', 'grid'],
        'widths': list(WIDTHS), 'maximum_expanded_source_gates': 5000,
        'maximum_raw_export_bytes': 250000,
        'selection_rule': 'All listed candidates, before compiler observations; generation, static-unitary eligibility, exact normalization, declared width and gate/byte limits only. Retain every exclusion without replacement. Compiler failures never change candidate membership.',
        'normalization': 'Pinned MQT algorithm level; no transpile, mapped level, mirror or optimization. Bind symbolic parameters with NumPy default_rng(seed) uniform[0,2pi) in circuit.parameters order; keep fixed constructors once. Strip only terminal global measurements/barriers, exact definition expansion and shared CRZ/RZZ normalization.',
        'holdout_scope': 'Untouched generator-family means not present in the recorded development corpus; QUARK copula/cardinality share one coarse generative-modeling family. General random circuits and these generators are held out. QAOA, arithmetic and variational examples are new instances of known coarse families. Lexical non-overlap is checked; it does not establish universal semantic independence or representative coverage.',
        'prior_qasm_inventory_sha256': digest((args.output / 'prior_qasm_inventory.json').read_bytes()),
        'generator_revision': '2cd3f3b08d5d8866595948fbce955e701e86a5df',
        'generator_release': '2.3.0', 'output_independence': 'No compiled output observed during selection or normalization.',
        'source_sha256': digest(Path(__file__).read_bytes())}
    dump_new(args.output / 'selection.json', selection)
    (args.output / 'selection.sha256').write_text(digest((args.output / 'selection.json').read_bytes()) + '\n')
    print(json.dumps({'candidates': len(selection['candidates']), 'prior_qasm_files': len(old),
                      'selection_sha256': digest((args.output / 'selection.json').read_bytes())}))


def build(args):
    sys.path.insert(0, str(args.repo / 'experiments'))
    import external_corpus as original
    from bench_baselines import normalize_qasm
    from qiskit import qasm2, qpy
    import numpy as np
    selection_bytes = (args.selection / 'selection.json').read_bytes()
    if digest(selection_bytes) != (args.selection / 'selection.sha256').read_text().strip():
        raise ValueError('Selection checksum mismatch')
    selection = json.loads(selection_bytes)
    if selection['candidates'] != candidates() or selection['source_sha256'] != digest(Path(__file__).read_bytes()):
        raise ValueError('Selection generator changed')
    prior_bytes = (args.selection / 'prior_qasm_inventory.json').read_bytes()
    if digest(prior_bytes) != selection['prior_qasm_inventory_sha256']:
        raise ValueError('Prior inventory changed')
    prior = json.loads(prior_bytes)
    old_hashes = {row['sha256'] for row in prior}
    old_lexical = {row['lexical_sha256'] for row in prior}
    integrity = original.verify_source_mirror(args.sources)
    sys.path.insert(0, str(args.sources / 'mqtbench/src'))
    from mqt.bench import get_benchmark_alg
    args.output.mkdir(parents=True, exist_ok=False)
    raw_dir = args.output / 'generated_raw'
    raw_dir.mkdir()
    ledger, cases, new_hashes = [], [], set()
    for candidate in selection['candidates']:
        row = dict(candidate)
        family, width, name = row['family'], row['width'], row['id']
        source_path = f'src/mqt/bench/benchmarks/{family}.py'
        row.update(community_source='MQT Bench', source_revision=original.MQTBENCH_REVISION,
            source_path=source_path, generator_source_sha256=digest((args.sources / 'mqtbench' / source_path).read_bytes()),
            source_url=f'https://github.com/munich-quantum-toolkit/bench/blob/{original.MQTBENCH_REVISION}/{source_path}',
            license='Pinned upstream MIT license and embedded QUARK/IBM Apache notices retained',
            directory_width=width, generator={'api': 'get_benchmark_alg', 'level': 'ALG',
                'random_parameters': False, 'parameter_binding_seed': row['parameter_seed'],
                'options': row['generator_options'], 'no_transpile_or_mirror': True})
        try:
            circuit = get_benchmark_alg(family, width, random_parameters=False, **row['generator_options'])
            if circuit.num_qubits != width:
                raise ValueError('actual_width_disagrees_with_declared_width')
            parameters = list(circuit.parameters)
            if bool(parameters) != (family in PARAMETERIZED):
                raise ValueError('Unexpected parameterization of frozen generator')
            rng = np.random.default_rng(row['parameter_seed']) if parameters else None
            bound = {parameter: float(rng.uniform(0, 2 * np.pi)) for parameter in parameters}
            if bound:
                circuit = circuit.assign_parameters(bound)
            row['parameter_bindings'] = [{'parameter': str(p), 'value': bound[p]} for p in parameters]
            qpy_path = raw_dir / (name + '.qpy')
            with qpy_path.open('xb') as stream:
                qpy.dump(circuit, stream)
            raw_qasm = qasm2.dumps(circuit)
            (raw_dir / (name + '.qasm')).write_text(raw_qasm)
            row.update(raw_source_format='Qiskit QPY and raw QASM from original generated circuit',
                raw_artifact=str(qpy_path.relative_to(args.output)), raw_source_sha256=digest(qpy_path.read_bytes()),
                raw_qasm_sha256=digest(raw_qasm), raw_qasm_bytes=len(raw_qasm.encode()))
            if row['raw_qasm_bytes'] > selection['maximum_raw_export_bytes']:
                raise ValueError('raw_source_above_250000_bytes')
            prefix, removals = original.unitary_prefix(circuit)
            source, expansion = original.canonical_source(prefix, selection['maximum_expanded_source_gates'])
            normalized = normalize_qasm(source)
            if digest(normalized) in old_hashes or lexical_digest(normalized) in old_lexical:
                raise RuntimeError('heldout_input_matches_prior_development_QASM')
            if lexical_digest(normalized) in new_hashes:
                raise RuntimeError('duplicate_new_normalized_input')
            evidence = original.normalization_evidence(prefix, source, normalized)
            if evidence['passed'] is not True:
                raise RuntimeError('normalization_equivalence_failed')
            new_hashes.add(lexical_digest(normalized))
            (args.output / (name + '.source.qasm')).write_text(source)
            (args.output / (name + '.normalized.qasm')).write_text(normalized)
            row.update(fixture=name, n_logical=width, source_qasm=source, qasm=normalized,
                source_sha256=digest(source), normalized_sha256=digest(normalized),
                source_artifact=name + '.source.qasm', normalized_artifact=name + '.normalized.qasm',
                normalization_evidence=evidence, normalization={'removed': removals, **expansion,
                    'shared_gate_expansion': 'unchanged exact CRZ/RZZ expansion', 'optimization': 'none'},
                selection_status='selected', exclusion_reason=None)
            cases.append(row)
        except Exception as error:
            row.update(selection_status='excluded', exclusion_reason=f'{type(error).__name__}: {error}')
        ledger.append(row)
        print(json.dumps({'candidate': name, 'status': row['selection_status'], 'reason': row['exclusion_reason']}), flush=True)
    compact = [{key: value for key, value in row.items() if key not in ('qasm', 'source_qasm')} for row in ledger]
    manifest = {'schema': 1, 'cases': sorted(cases, key=lambda row: row['id']),
        'candidate_ledger': compact, 'exclusions': [r for r in compact if r['selection_status'] == 'excluded'],
        'selection_sha256': digest(selection_bytes), 'provenance': {'source_integrity': integrity,
            'generator_revision': original.MQTBENCH_REVISION, 'selection': selection,
            'normalizer_sha256': digest((args.repo / 'experiments/external_corpus.py').read_bytes()),
            'oracle_sha256': digest((args.repo / 'experiments/comparison_validation.py').read_bytes()),
            'prior_qasm_inventory_sha256': selection['prior_qasm_inventory_sha256'],
            'lexical_nonoverlap_checked': True, 'prior_qasm_files_checked': len(prior)},
        'counts': {'selected': len(cases), 'excluded': len(ledger) - len(cases), 'candidates': len(ledger),
            'by_family': dict(Counter(row['family'] for row in cases)),
            'by_holdout_class': dict(Counter(row['holdout_class'] for row in cases))}}
    dump_new(args.output / 'manifest.json', manifest)
    print(json.dumps(manifest['counts']))


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest='command', required=True)
    p = sub.add_parser('prescribe')
    p.add_argument('--working', type=Path, required=True)
    p.add_argument('--output', type=Path, required=True)
    b = sub.add_parser('build')
    for flag in ('repo', 'sources', 'selection', 'output'):
        b.add_argument('--' + flag, type=Path, required=True)
    args = parser.parse_args()
    {'prescribe': prescribe, 'build': build}[args.command](args)


if __name__ == '__main__':
    main()
