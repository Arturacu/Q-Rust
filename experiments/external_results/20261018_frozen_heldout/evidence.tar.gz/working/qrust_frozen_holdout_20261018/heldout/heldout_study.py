#!/usr/bin/env python3
"""Bounded held-out study using unchanged production adapters and oracle."""
from __future__ import annotations

import argparse
from collections import Counter, defaultdict
import hashlib
import importlib.metadata
import json
import os
from pathlib import Path
import select
import sys
import time
from types import SimpleNamespace

from heldout_corpus import WIDTHS, candidates, target_edges

TOOLS = ('qrust', 'qiskit', 'cirq', 'tket')
TRIALS, SESSIONS, TIMEOUT = 5, 2, 60.0
MASTER_SEED = 20261019
PER_WORKER_RSS = 2 * 1024 ** 3
ALL_WORKER_RSS = 3 * 1024 ** 3


def sha(data):
    if isinstance(data, Path):
        data = data.read_bytes()
    return hashlib.sha256(data.encode() if isinstance(data, str) else data).hexdigest()


def dump_new(path, data):
    with path.open('x') as out:
        json.dump(data, out, indent=2, sort_keys=True, allow_nan=False)
        out.write('\n')


def plan():
    return {'schema': 1, 'candidate_fixtures': candidates(), 'widths': list(WIDTHS),
        'targets': {str(width): {topology: target_edges(width, topology)
                    for topology in ('all_to_all', 'linear', 'grid')} for width in WIDTHS},
        'tools': list(TOOLS), 'trials': TRIALS, 'sessions': SESSIONS, 'master_seed': MASTER_SEED,
        'warmups_per_cell_tool': 1, 'timeout_seconds': TIMEOUT, 'startup_timeout_seconds': 120,
        'maximum_candidate_cases': len(candidates()) * 3,
        'maximum_timed_slots': len(candidates()) * 3 * len(TOOLS) * TRIALS * SESSIONS,
        'maximum_initial_warmup_slots': len(candidates()) * 3 * len(TOOLS) * SESSIONS,
        'per_worker_rss_limit_bytes': PER_WORKER_RSS, 'all_worker_rss_limit_bytes': ALL_WORKER_RSS,
        'timing': 'Unchanged warm in-process compile_ns, parse_ns and full request-wall time separately. Fresh persistent workers each session. Sequential requests; randomized tools/cases/trials, same five Qiskit trial seeds across sessions. All primary recipes unchanged; no profiles or controlled-pass variants in this study.',
        'resource_policy': 'Sample every known live worker process RSS approximately every 100 ms; limit 2 GiB per worker and 3 GiB aggregate, including idle workers and counting distinct process IDs once. Child processes are not included; sampling is not exact peak memory and can overshoot. Watcher cost is outside compile_ns. Preserve every timeout/error and scheduled slot. The unchanged external restart warmup policy applies; all warmups must pass for eligibility.',
        'normalization': 'Upstream generation/definition expansion and independent normalization checks before freeze; no compiler sees any selected input until final protocol and compiler freeze are bound. Failed source eligibility retained without replacement.',
        'validation': 'Unchanged comparison_validation.py NumPy analytic oracle, after BOTH sessions. Full isometry at six qubits; eight fixed inputs at 10/16 qubits, one shared global phase, full physical amplitude residual 1e-7, explicit basis/edge/layout checks. Check all warmups and timed outputs. Sampled results are evidence, not proof.',
        'qualification': 'Each case/tool/session needs all five timed trials and every initial/replacement warmup compiled and independently passed. A failure excludes the whole cell; never select successful trials. Main comparisons use pairwise cells eligible in both sessions; the four-tool common cohort is reported separately. Status/verification coverage for ALL selected cases, including unqualified cells, remains visible.',
        'analysis': {'per_session': True, 'cell_estimator': 'median of five prescribed trials',
            'metrics': ['compile_ns', 'parse_compile_ns', 'cx_count', 'gate_count', 'depth', 'two_q_depth'],
            'timing_ratio': 'baseline / Q-Rust', 'quality_ratio': 'Q-Rust / baseline',
            'primary_aggregate': 'equal-case-weight geometric mean of positive paired ratios on the stable paired cohort',
            'secondary_aggregate': 'family-balanced geometric mean; equal weight across six fixed generator families',
            'zero_policy': 'Zero numerator/denominator excluded from logarithmic ratios and counted; all pairs retained in win/tie/loss counts; no pseudocount.',
            'bootstrap': '2,000 draws, seed 20261015, fixture clusters keeping all topologies, 95% percentile. Describes fixed-corpus variation, not representative sampling; parameter seeds produce related instances and are not independent families.',
            'strata': ['holdout_class', 'coarse_family', 'family', 'n_logical', 'topology'],
            'scope': 'Pinned configured pipelines, unequal search effort and ideal synthetic connectivity. No claim of best settings, optimality, language causality or hardware fidelity. Report all results without tuning or replacement.'}}


def build_cases(manifest):
    fixtures = manifest['cases']
    if not fixtures or len({c['id'] for c in fixtures}) != len(fixtures):
        raise ValueError('Nonempty unique fixtures required')
    rows = []
    for fixture in fixtures:
        width = fixture['n_logical']
        if type(width) is not int or width not in WIDTHS:
            raise ValueError('Unexpected held-out width')
        for text, checksum in [('source_qasm', 'source_sha256'), ('qasm', 'normalized_sha256')]:
            if sha(fixture[text]) != fixture[checksum]:
                raise ValueError('Input checksum mismatch')
        evidence = fixture.get('normalization_evidence', {})
        if (evidence.get('passed') is not True or evidence.get('tolerance') != 1e-7
                or evidence.get('mode') != ('full_unitary_numerical' if width <= 6 else 'sampled_8_inputs_numerical')
                or evidence.get('input_count') != (2 ** width if width <= 6 else 8)
                or any(type(evidence.get('residuals', {}).get(key)) not in (int, float)
                       or not 0 <= evidence['residuals'][key] <= 1e-7 for key in ('source', 'normalized'))):
            raise ValueError('Invalid normalization evidence')
        for topology in ('all_to_all', 'linear', 'grid'):
            rows.append({**fixture, 'id': f"{fixture['id']}__{topology}",
                'fixture': fixture['id'], 'physical_width': width, 'topology': topology,
                'edges': target_edges(width, topology)})
    return sorted(rows, key=lambda row: row['id'])


def configure(repo):
    sys.path.insert(0, str(repo / 'experiments'))
    import external_comparison as external
    external.TOOLS = TOOLS
    external.PACKAGES = (*external.PACKAGES, 'psutil') if 'psutil' not in external.PACKAGES else external.PACKAGES
    external.PROFILES = {'primary': list(TOOLS)}
    external.build_cases = build_cases
    return external


def sources():
    return {str(path): sha(path) for path in sorted(Path(__file__).parent.glob('*.py'))}


def prepare(args):
    external = configure(args.repo)
    frozen_plan = json.loads(args.plan.read_text())
    if frozen_plan != plan():
        raise ValueError('Frozen plan differs from implementation')
    freeze = json.loads(args.compiler_freeze.read_text())
    verify_freeze(freeze, args)
    external.prepare(SimpleNamespace(corpus=args.corpus, output=args.study, binary=args.binary,
        compiler_commit=args.compiler_commit, trials=TRIALS, sessions=SESSIONS, timeout=TIMEOUT,
        seed=MASTER_SEED, machine_note='Single host; no other CPU-heavy jobs during timing; no CPU frequency or affinity control.'))
    path = args.study / 'protocol.json'
    protocol = json.loads(path.read_text())
    protocol.update(study='prespecified pinned-generator held-out comparison',
        heldout_plan=frozen_plan, heldout_plan_sha256=sha(args.plan),
        compiler_freeze=freeze, compiler_freeze_sha256=sha(args.compiler_freeze),
        harness_source_sha256=sources(), selection_sha256=json.loads(args.corpus.read_text())['selection_sha256'],
        recipe_profiles={'primary': list(TOOLS)}, recipes={key: value for key, value in protocol['recipes'].items() if key in TOOLS},
        profile_caveat='Four unchanged primary adapter recipes; optimization effort is unequal; these are not universal best SDK settings.',
        seed_policy='Five trial seeds master_seed+trial, reused across sessions; Qiskit consumes the seed, other recipes are deterministic. Parameter seeds 11/29 construct circuits and are distinct from compiler trial seeds.',
        target='U3/CX, bidirectional ideal complete/line/grid, equal physical/logical width, free initial/final maps. Grid dimensions: six qubits 2x3, ten qubits 2x5, sixteen qubits 4x4.',
        validation=frozen_plan['validation'], analysis=frozen_plan['analysis'],
        qualification=frozen_plan['qualification'], resource_policy=frozen_plan['resource_policy'])
    external.dump(path, protocol)
    (args.study / 'protocol.sha256').write_text(sha(path) + '\n')
    print(json.dumps({'frozen_protocol_sha256': sha(path), 'cases': len(protocol['cases']),
                      'timed_slots': len(protocol['cases']) * len(TOOLS) * TRIALS * SESSIONS}))


def verify(args):
    external = configure(args.repo)
    protocol, checksum = external.load_protocol(args.study)
    expected_scripts = protocol['harness_source_sha256']
    actual_scripts = sources()
    relocated = getattr(args, 'allow_relocated', False)
    if relocated:
        if args.command not in ('validate', 'analyze'):
            raise ValueError('Relocation is restricted to validation and analysis')
        expected_scripts = {Path(path).name: value for path, value in expected_scripts.items()}
        actual_scripts = {Path(path).name: value for path, value in actual_scripts.items()}
    if protocol['heldout_plan'] != plan() or expected_scripts != actual_scripts:
        raise ValueError('Held-out harness or frozen plan changed')
    if protocol['heldout_plan_sha256'] != sha(args.plan):
        raise ValueError('Plan file changed')
    if protocol['compiler_freeze_sha256'] != sha(args.compiler_freeze):
        raise ValueError('Compiler freeze changed')
    verify_freeze(json.loads(args.compiler_freeze.read_text()), args)
    external.check_runtime(protocol, args.binary)
    return external, protocol, checksum


def verify_freeze(freeze, args):
    """Relocation changes path prefixes only, never the required file digests."""
    relocated = getattr(args, 'allow_relocated', False)
    old_repo = Path(os.path.commonpath([row['path'] for row in freeze['compiler_and_recipe_files']]))
    old_env = Path(freeze['python_executable']).parent.parent
    new_env = Path(sys.executable).absolute().parent.parent
    for group in ('compiler_and_recipe_files', 'generator_source_files', 'installed_files', 'binary'):
        entries = [freeze[group]] if group == 'binary' else freeze[group]
        for entry in entries:
            original = Path(entry['path'])
            path = original
            if relocated:
                if group == 'binary':
                    path = args.binary
                elif group == 'compiler_and_recipe_files':
                    path = args.repo / original.relative_to(old_repo)
                elif group == 'generator_source_files':
                    if args.generator_root is None:
                        raise ValueError('Relocated replay needs the archived pinned generator root')
                    marker = '/sources/mqtbench/'
                    if marker not in str(original):
                        raise ValueError('Unknown original generator root')
                    path = args.generator_root / str(original).split(marker, 1)[1]
                elif group == 'installed_files':
                    path = new_env / original.relative_to(old_env)
            if not path.is_file() or path.stat().st_size != entry['bytes'] or sha(path) != entry['sha256']:
                raise ValueError('Frozen file changed or missing: ' + str(path))
    for name, version in freeze['versions'].items():
        if importlib.metadata.version(name) != version:
            raise ValueError('Frozen distribution version changed: ' + name)
    if not relocated and str(Path(sys.executable).absolute()) != freeze['python_executable']:
        raise ValueError('Use the frozen Python environment')


def time_session(args):
    external, protocol, _ = verify(args)
    import psutil
    registry = []
    Base = external.ProfileWorker

    class ObservedWorker(Base):
        def __init__(self, tool, binary, outdir):
            self.peak_rss = self.peak_all_rss = 0
            registry.append(self)
            super().__init__(tool, binary, outdir)

        def receive(self, timeout):
            deadline = time.monotonic() + timeout
            while True:
                values = {}
                for item in registry:
                    process = getattr(item, 'process', None)
                    if process is None:
                        continue
                    try:
                        values[process.pid] = psutil.Process(process.pid).memory_info().rss
                    except psutil.NoSuchProcess:
                        values[process.pid] = 0
                own, total = values.get(self.process.pid, 0), sum(values.values())
                self.peak_rss = max(self.peak_rss, own)
                self.peak_all_rss = max(self.peak_all_rss, total)
                check_rss(values)
                remaining = deadline - time.monotonic()
                if remaining <= 0:
                    raise TimeoutError(f'{self.tool} exceeded {timeout} seconds')
                if select.select([self.process.stdout], [], [], min(0.1, remaining))[0]:
                    line = self.process.stdout.readline()
                    if not line:
                        raise RuntimeError(f'Worker exited: {self.process.poll()}')
                    return json.loads(line)

        def call(self, request, timeout):
            self.peak_rss = self.peak_all_rss = 0
            result = super().call(request, timeout)
            if result.get('error', '').startswith('MemoryError:'):
                result['status'] = 'memory_limit'
            result.update(sampled_worker_rss_bytes=self.peak_rss,
                          sampled_all_worker_rss_bytes=self.peak_all_rss)
            return result

    external.ProfileWorker = ObservedWorker
    external.timing(args)


def check_rss(values):
    """Dictionary keys are distinct process IDs, including idle workers."""
    if any(value > PER_WORKER_RSS for value in values.values()) or sum(values.values()) > ALL_WORKER_RSS:
        raise MemoryError('Sampled worker RSS limit exceeded')


def check_warmups(protocol, session, rows, external):
    expected = {(row['case_id'], row['tool']): row for row in protocol['schedules'][str(session)] if row['trial'] == -1}
    timed = {(row['case_id'], row['tool'], row['trial']): row for row in protocol['schedules'][str(session)] if row['trial'] >= 0}
    cases = {case['id']: case for case in protocol['cases']}
    seen, replacement = set(), set()
    for row in rows:
        cell = row['case_id'], row['tool']
        if row.get('session') != session:
            raise ValueError('Wrong warmup session')
        if row.get('reason') == 'worker_restart':
            identity = (*cell, row['trial'])
            if identity not in timed or identity in replacement:
                raise ValueError('Unexpected or duplicate replacement warmup')
            required = timed[identity]
            replacement.add(identity)
        else:
            if cell not in expected or cell in seen or row['trial'] != -1:
                raise ValueError('Unexpected or duplicate initial warmup')
            required = expected[cell]
            seen.add(cell)
        if any(row.get(key) != value for key, value in required.items()):
            raise ValueError('Warmup differs from prescribed schedule')
        if row.get('status') == 'compiled':
            # Legacy replacementwarmups lack the transport artifact envelope.
            if 'output_sha256' in row and sha(row['out_qasm']) != row['output_sha256']:
                raise ValueError('Warmup output hash mismatch')
            if 'artifact_sha256' in row and external.artifact_hash(cases[row['case_id']], row) != row['artifact_sha256']:
                raise ValueError('Warmup artifact mismatch')
    if seen != set(expected):
        raise ValueError('Missing initial warmups')


def validate(args):
    external, protocol, checksum = verify(args)
    # Unchanged timing validator requires every prescribed session completed.
    external.validate(args)
    from comparison_validation import validate_output
    from paired_analysis import classify_evidence
    cache, cases, receipt = {}, {case['id']: case for case in protocol['cases']}, []
    for session in range(1, SESSIONS + 1):
        directory = args.study / f'session_{session:02d}'
        for row in external.read_rows(directory / 'validated.jsonl'):
            if row['status'] == 'compiled':
                cache[row['artifact_sha256']] = row['validation']
        warmups = external.read_rows(directory / 'warmup.jsonl')
        check_warmups(protocol, session, warmups, external)
        counts = Counter()
        with (directory / 'warmup_validated.jsonl').open('x') as stream:
            for original in warmups:
                row = dict(original)
                if row['status'] == 'compiled':
                    case = cases[row['case_id']]
                    row['output_sha256'] = sha(row['out_qasm'])
                    key = external.artifact_hash(case, row)
                    if key not in cache:
                        edges = None if case['topology'] == 'all_to_all' else [pair for a, b in case['edges'] for pair in ((a, b), (b, a))]
                        cache[key] = validate_output(case['source_qasm'], row['out_qasm'], case['n_logical'],
                            case['physical_width'], edges, row['initial_layout'], row['final_layout'])
                    row['validation'] = cache[key]
                    row['artifact_sha256'] = key
                    outcome = classify_evidence(row['validation'], 'external')
                else:
                    outcome = row['status']
                counts[row['tool'] + '/' + outcome] += 1
                stream.write(external.canonical(row) + '\n')
        receipt.append({'session': session, 'counts': dict(counts),
                        'warmup_validated_sha256': sha(directory / 'warmup_validated.jsonl')})
    dump_new(args.study / 'warmup_validation_summary.json', {'protocol_sha256': checksum, 'sessions': receipt})


def qualify_cells(protocol, timed, validated, warmups, base):
    cells = base.build_cells(protocol, timed, validated, expected_trials=TRIALS)
    grouped = defaultdict(list)
    case_meta = {row['id']: row for row in protocol['cases']}
    for row in warmups:
        grouped[row['case_id'], row['tool']].append(row)
    for cell in cells:
        rows = grouped[cell['case_id'], cell['tool']]
        good = bool(rows) and all(row.get('status') == 'compiled' and row.get('validation', {}).get('passed') is True for row in rows)
        cell['warmup_outcomes'] = dict(Counter('verified' if row.get('validation', {}).get('passed') is True else row['status'] for row in rows))
        if not good:
            cell['eligible'] = False
            cell['exclusion_reasons'].append('Initial or replacement warmup failed compilation/independent validation')
            cell['medians'], cell['ranges'] = None, None
        for field in ('holdout_class', 'coarse_family'):
            cell[field] = case_meta[cell['case_id']][field]
    return cells


def summarize(cells, base, label):
    result = {'coverage': {tool: sum(c['tool'] == tool and c['eligible'] for c in cells) for tool in TOOLS},
              'pairwise': {tool: base.summarize_pairs(cells, tool, label=label, draws=2000) for tool in TOOLS[1:]},
              'complete_case_quality': base.complete_case_quality(cells), 'worst_tails': base.worst_tails(cells)}
    for field in ('holdout_class', 'coarse_family', 'family', 'n_logical', 'topology'):
        result['by_' + field] = {str(group): {tool: base.summarize_pairs(
            [cell for cell in cells if cell[field] == group], tool,
            label=f'{label}/{field}/{group}', draws=2000) for tool in TOOLS[1:]}
            for group in sorted({cell[field] for cell in cells})}
    return result


def analyze(args):
    external, protocol, checksum = verify(args)
    import analyze_comparison_study as base
    from paired_analysis import classify_evidence
    validation = json.loads((args.study / 'validation_summary.json').read_text())
    warm_receipt = json.loads((args.study / 'warmup_validation_summary.json').read_text())
    if validation['protocol_sha256'] != checksum or warm_receipt['protocol_sha256'] != checksum:
        raise ValueError('Unbound validation receipt')
    all_cells, sessions, checked_sessions = [], [], []
    for session in range(1, SESSIONS + 1):
        directory = args.study / f'session_{session:02d}'
        info = json.loads((directory / 'session.json').read_text())
        if info['completed'] is not True or info['protocol_sha256'] != checksum:
            raise ValueError('Incomplete session')
        for kind in ('timed', 'warmup'):
            if sha(directory / f'{kind}.jsonl') != info[f'{kind}_sha256']:
                raise ValueError('Changed raw session file')
        if sha(directory / 'validated.jsonl') != validation['sessions'][session - 1]['validated_sha256']:
            raise ValueError('Changed validation file')
        if sha(directory / 'warmup_validated.jsonl') != warm_receipt['sessions'][session - 1]['warmup_validated_sha256']:
            raise ValueError('Changed warmup validation file')
        timed, checked, warmed = (external.read_rows(directory / name) for name in
                                  ('timed.jsonl', 'validated.jsonl', 'warmup_validated.jsonl'))
        external.check_rows(protocol, session, timed)
        check_warmups(protocol, session, warmed, external)
        cells = qualify_cells(protocol, timed, checked, warmed, base)
        checked_sessions.append(checked)
        all_cells.append(cells)
        outcomes = Counter(row['tool'] + '/' + (classify_evidence(row['validation'], 'external')
                          if row['status'] == 'compiled' else row['status']) for row in checked)
        sessions.append({'session': session, 'timed_outcomes': dict(outcomes),
            'per_session_complete_cells': summarize(cells, base, f'session{session}/complete'),
            'excluded_cells': [c for c in cells if not c['eligible']]})
        dump_new(directory / 'cells.json', cells)
        base.write_csv(directory / 'cells.csv', cells)
    stable = set.intersection(*({(cell['case_id'], cell['tool']) for cell in cells if cell['eligible']} for cells in all_cells))
    for session, cells in enumerate(all_cells, 1):
        stable_cells = [{**c, 'eligible': c['eligible'] and (c['case_id'], c['tool']) in stable} for c in cells]
        sessions[session - 1]['stable_two_session_cells'] = summarize(stable_cells, base, f'session{session}/stable')
    agreement = Counter()
    per_tool_agreement = {tool: Counter() for tool in TOOLS}
    indexed = [{(row['case_id'], row['tool'], row['trial']): row for row in rows} for rows in checked_sessions]
    if indexed[0].keys() != indexed[1].keys():
        raise ValueError('Session trial identities differ')
    for key, left in indexed[0].items():
        right = indexed[1][key]
        if left['status'] != right['status']:
            state = 'compile_status_changed'
        elif left['status'] != 'compiled':
            state = 'same_nonsuccess_status'
        elif left['validation']['passed'] != right['validation']['passed']:
            state = 'validation_status_changed'
        elif left['validation'].get('metrics') != right['validation'].get('metrics'):
            state = 'quality_changed'
        elif left['artifact_sha256'] != right['artifact_sha256']:
            state = 'same_quality_different_artifact'
        else:
            state = 'identical_artifact'
        agreement[state] += 1
        per_tool_agreement[key[1]][state] += 1
    dump_new(args.study / 'analysis.json', {'schema': 1, 'protocol_sha256': checksum,
        'method': protocol['heldout_plan']['analysis'], 'sessions': sessions,
        'same_seed_session_agreement': {'counts': dict(agreement),
            'by_tool': {tool: dict(counts) for tool, counts in per_tool_agreement.items()}},
        'scope': protocol['qualification'], 'source_exclusions': protocol['corpus_exclusions']})


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('command', choices=('plan', 'prepare', 'time', 'validate', 'analyze'))
    parser.add_argument('--repo', type=Path)
    parser.add_argument('--study', type=Path)
    parser.add_argument('--binary', type=Path)
    parser.add_argument('--plan', type=Path)
    parser.add_argument('--compiler-freeze', type=Path)
    parser.add_argument('--corpus', type=Path)
    parser.add_argument('--compiler-commit')
    parser.add_argument('--session', type=int)
    parser.add_argument('--allow-relocated', action='store_true')
    parser.add_argument('--generator-root', type=Path)
    args = parser.parse_args()
    if args.command == 'plan':
        dump_new(args.plan, plan())
    else:
        {'prepare': prepare, 'time': time_session, 'validate': validate, 'analyze': analyze}[args.command](args)


if __name__ == '__main__':
    main()
