import json
from pathlib import Path
import sys
from tempfile import TemporaryDirectory
import unittest
from unittest.mock import patch
import replay_controls
from replay_controls import Replay,require_equal,row_semantics,summary_semantics
class ReplayBoundaryTests(unittest.TestCase):
    def test_replay_output_is_outside_archived_tree(self):
        with TemporaryDirectory() as directory:
            root=Path(directory);study=root/'extracted/working/study';study.mkdir(parents=True)
            (root/'alias').symlink_to(root/'extracted',target_is_directory=True)
            for output in (study/'replay',root/'extracted/replay',root/'alias/replay',root/'other/../extracted/replay'):
                with self.assertRaisesRegex(ValueError,'outside the evidence archive'):
                    replay_controls.isolated_output(study,output)
            self.assertEqual(replay_controls.isolated_output(study,root/'replay'),(root/'replay').resolve())

    def test_only_verifier_clock_is_ignored(self):
        left={'result':{'compile_ns':7,'parse_ns':3,'pass_diagnostics':[{'elapsed_ns':4}]},'validation':{'passed':True,'validation_ns':1}}
        right={'result':{'compile_ns':7,'parse_ns':3,'pass_diagnostics':[{'elapsed_ns':4}]},'validation':{'passed':True,'validation_ns':5}}
        require_equal(row_semantics(left),row_semantics(right),'clock')
        right['result']['compile_ns']=8
        with self.assertRaises(ValueError):require_equal(row_semantics(left),row_semantics(right),'compiler clock')
    def test_changed_verdict_is_not_ignored(self):
        with self.assertRaises(ValueError): require_equal(row_semantics({'validation':{'passed':True}}),row_semantics({'validation':{'passed':False}}),'verdict')
    def test_unrelated_validation_ns_is_not_ignored(self):
        with self.assertRaises(ValueError):require_equal(row_semantics({'result':{'validation_ns':1}}),row_semantics({'result':{'validation_ns':2}}),'native unexpected clock')
    def test_summary_keeps_compilation_measurements(self):
        a={'validated_sha256':'one','compile_ns_median':3};b={'validated_sha256':'two','compile_ns_median':4}
        with self.assertRaises(ValueError):require_equal(summary_semantics(a),summary_semantics(b),'summary compiler clock')
    def test_phase_negative_verdict_is_not_ignored(self):
        a={'negative_controls':{'relative_phase':{'passed':False,'validation_ns':1}}};b={'negative_controls':{'relative_phase':{'passed':True,'validation_ns':2}}}
        with self.assertRaises(ValueError):require_equal(row_semantics(a),row_semantics(b),'negative verdict')
    def test_relocation_rejects_outside_and_parent_paths(self):
        with TemporaryDirectory() as directory:
            replay=Replay.__new__(Replay);replay.work=Path(directory).resolve();replay.original_work=Path('/original/working')
            with self.assertRaises(ValueError):replay.relocate('/outside/source.py')
            with self.assertRaises(ValueError):replay.relocate('/original/working/../source.py')
    def test_installed_file_digest_is_checked(self):
        with TemporaryDirectory() as directory:
            root=Path(directory);study=root/'study';env=root/'env'
            (study/'heldout/campaign').mkdir(parents=True);(env/'lib').mkdir(parents=True)
            installed=env/'lib/frozen.txt';installed.write_text('one')
            freeze={'python_executable':'/original/env/bin/python','python_version':sys.version,'versions':{},
                    'installed_files':[{'path':'/original/env/lib/frozen.txt','bytes':3,'sha256':replay_controls.sha(installed)}]}
            (study/'compiler_freeze.json').write_text(json.dumps(freeze))
            (study/'heldout/campaign/protocol.json').write_text(json.dumps({'compiler_freeze_sha256':replay_controls.sha(study/'compiler_freeze.json')}))
            replay=Replay.__new__(Replay);replay.study=study
            with patch.object(replay_controls.sys,'executable',str(env/'bin/python')):
                replay.verify_environment()
                self.assertEqual(replay.environment_evidence['installed_files_checked'],1)
                installed.write_text('two')
                with self.assertRaisesRegex(ValueError,'frozen installed file'):
                    replay.verify_environment()
if __name__=='__main__':unittest.main()
