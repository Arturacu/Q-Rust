import json
from pathlib import Path
import tempfile
import unittest

from replay_heldout import compare_summary, isolated_output, semantic_rows, sha


class ReplayTests(unittest.TestCase):
    def test_replay_cannot_mutate_extracted_evidence_tree(self):
        with tempfile.TemporaryDirectory() as name:
            root = Path(name)
            study = root / 'extracted/working/study'
            study.mkdir(parents=True)
            (root / 'alias').symlink_to(root / 'extracted', target_is_directory=True)
            for output in (study / 'replay', root / 'extracted/replay',
                           root / 'alias/replay', root / 'outside/../extracted/replay'):
                with self.assertRaisesRegex(ValueError, 'outside the evidence archive'):
                    isolated_output(study, output)
            self.assertEqual(isolated_output(study, root / 'replay'), (root / 'replay').resolve())

    def test_only_verifier_clock_is_excluded(self):
        with tempfile.TemporaryDirectory() as name:
            path = Path(name) / 'rows.jsonl'
            row = {'compile_ns': 10, 'parse_ns': 3, 'request_wall_ns': 18,
                   'validation': {'passed': True, 'validation_ns': 20,
                                  'metrics': {'cx_count': 4}}, 'final_layout': [1, 0]}
            path.write_text(json.dumps(row) + '\n')
            baseline = semantic_rows(path)
            row['validation']['validation_ns'] = 999
            path.write_text(json.dumps(row) + '\n')
            self.assertEqual(baseline, semantic_rows(path))
            for field, value in [('compile_ns', 11), ('parse_ns', 4), ('request_wall_ns', 19),
                                 ('final_layout', [0, 1])]:
                changed = {**row, field: value}
                path.write_text(json.dumps(changed) + '\n')
                self.assertNotEqual(baseline, semantic_rows(path))

    def test_validation_verdict_and_metrics_remain_bound(self):
        with tempfile.TemporaryDirectory() as name:
            path = Path(name) / 'rows.jsonl'
            row = {'validation': {'passed': True, 'metrics': {'depth': 3}}}
            path.write_text(json.dumps(row) + '\n')
            baseline = semantic_rows(path)
            for validation in ({'passed': False, 'metrics': {'depth': 3}},
                               {'passed': True, 'metrics': {'depth': 4}}):
                path.write_text(json.dumps({'validation': validation}) + '\n')
                self.assertNotEqual(baseline, semantic_rows(path))

    def test_summary_hash_exclusion_requires_actual_binding(self):
        with tempfile.TemporaryDirectory() as name:
            root = Path(name)
            for folder in ('old', 'new'):
                directory = root / folder
                (directory / 'session_01').mkdir(parents=True)
                rows = directory / 'session_01/validated.jsonl'
                rows.write_text(folder)
                value = {'sessions': [{'session': 'session_01', 'counts': {'passed': 1},
                                       'validated_sha256': sha(rows)}]}
                (directory / 'summary.json').write_text(json.dumps(value))
            compare_summary(root / 'old', root / 'new', 'summary.json', 'validated_sha256', 'validated.jsonl')
            (root / 'new/session_01/validated.jsonl').write_text('tampered')
            with self.assertRaisesRegex(ValueError, 'Unbound'):
                compare_summary(root / 'old', root / 'new', 'summary.json', 'validated_sha256', 'validated.jsonl')


if __name__ == '__main__':
    unittest.main()
