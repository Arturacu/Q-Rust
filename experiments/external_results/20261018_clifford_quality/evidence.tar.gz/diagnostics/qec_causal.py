"""Untimed QEC routing controls with retained full-isometry validation."""
import argparse
import hashlib
import itertools
import json
from pathlib import Path
import subprocess
import sys


def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def main():
    p = argparse.ArgumentParser(description=__doc__)
    for name in ('repo', 'baseline', 'current', 'source', 'output'):
        p.add_argument('--' + name, type=Path, required=True)
    a = p.parse_args()
    a.output.mkdir(parents=True, exist_ok=False)
    sys.path.insert(0, str(a.repo.resolve() / 'experiments'))
    import comparison_validation as oracle
    source = a.source.read_text()
    width, _ = oracle.parse_qasm(source)
    results = []
    for compiler, binary in [('baseline', a.baseline), ('current', a.current)]:
        pending = []
        for topology in ('all_to_all', 'line'):
            edges = (list(itertools.combinations(range(width), 2)) if topology == 'all_to_all'
                     else [(q, q + 1) for q in range(width - 1)])
            flags = itertools.product((False, True), repeat=2) if compiler == 'current' else [(False, False)]
            for encoded, clifford in flags:
                request = dict(qasm=source, n_logical=width, physical_width=width,
                               topology=topology, edges=edges, profile_passes=True,
                               encoded_swap_recognition=encoded, clifford_simplification=clifford)
                pending.append(dict(name=f'{compiler}_{topology}_encoded{int(encoded)}_clifford{int(clifford)}',
                                    compiler=compiler, request=request))
        proc = subprocess.run([str(binary.resolve())], capture_output=True, text=True,
                              input=''.join(json.dumps(r['request']) + '\n' for r in pending),
                              check=True, timeout=60)
        responses = [json.loads(line) for line in proc.stdout.splitlines()]
        assert responses.pop(0)['ready']
        (a.output / f'{compiler}.stderr.log').write_text(proc.stderr)
        for row, response in zip(pending, responses, strict=True):
            assert response['status'] == 'compiled', response
            edges = [(x, y) for u, v in row['request']['edges'] for x, y in [(u, v), (v, u)]]
            validation = oracle.validate_output(source, response['out_qasm'], width,
                                                response['output_qubits'], edges,
                                                response['initial_layout'], response['final_layout'])
            row.update(response=response, validation=validation)
            results.append(row)
            (a.output / f"{row['name']}.qasm").write_text(response['out_qasm'])
            print(json.dumps({'name': row['name'], 'passed': validation['passed'],
                              'metrics': validation.get('metrics'),
                              'maps': [response['initial_layout'], response['final_layout']],
                              'encoded': response.get('encoded_swap_stats'),
                              'clifford': response.get('clifford_simplification_stats')}), flush=True)
    receipt = dict(purpose='Untimed causal controls; elapsed values are diagnostic only',
                   source_sha256=digest(a.source), script_sha256=digest(__file__),
                   oracle_sha256=digest(oracle.__file__),
                   binary_sha256={n: digest(b) for n, b in [('baseline', a.baseline), ('current', a.current)]},
                   source=source, rows=results)
    (a.output / 'results.json').write_text(json.dumps(receipt, indent=2) + '\n')
    assert all(row['validation']['passed'] for row in results)


if __name__ == '__main__':
    main()
