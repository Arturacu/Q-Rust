OPENQASM 2.0; include "qelib1.inc"; qreg q[2];
cx q[0],q[1]; cx q[1],q[0]; h q[1]; s q[0]; cx q[1],q[0]; sdg q[0]; s q[1];
