"""Untimed routing interventions; all outputs checked against the original unitary."""
import hashlib
import json
from pathlib import Path
import subprocess
import sys

ROOT = Path(__file__).resolve().parents[2]
TASK = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / 'qrust_pr_publish/experiments'))
from comparison_validation import validate_output

binary = ROOT / 'qrust_clifford_followup_20261018/comparison_runner_fixed'
original = (ROOT / 'qrust_external_20261018/corpus/qasmbench__error_correctiond3_n5.normalized.qasm').read_text()
trace = json.loads((TASK / 'clifford_diagnostics/rejected_candidates.json').read_text())
final = (TASK / 'clifford_diagnostics/intervention_meet_literal.qasm').read_text()
cases = [('final_default', final, {})]
for i, row in enumerate(trace['meet_literal']['rows']):
    if row['accepted']:
        qasm = 'OPENQASM 2.0;\ninclude "qelib1.inc";\nqreg q[5];\n' + ''.join(
            name + ' ' + ','.join(f'q[{q}]' for q in wires) + ';\n' for name, wires in row['candidate'])
        cases.append((f'accepted_intermediate_{i}', qasm, {'clifford_simplification': False}))
for lookahead in [0, 5, 10, 40, 60]:
    cases.append((f'lookahead_{lookahead}', final, {'lookahead_size': lookahead}))
for trials in [1, 5, 20, 50]:
    cases.append((f'trials_{trials}', final, {'layout_trials': trials}))
for iterations in [1, 2, 5, 10]:
    cases.append((f'iterations_{iterations}', final, {'layout_iterations': iterations}))
cases += [('no_progress', final, {'rank_progress': False}),
          ('no_orientation', final, {'orient_swaps': False}),
          ('no_elision', final, {'elide_output_permutations': False})]
rows = []
edges = [[q, q+1] for q in range(4)]
with (TASK / 'diagnostics/ec_line_search.stderr.log').open('x') as err:
    proc = subprocess.Popen([str(binary)], stdin=subprocess.PIPE, stdout=subprocess.PIPE,
                            stderr=err, text=True)
    try:
        for label, qasm, overrides in cases:
            request = {'qasm': qasm, 'topology': 'linear', 'physical_width': 5,
                       'n_logical': 5, 'edges': edges, 'profile_passes': True, **overrides}
            proc.stdin.write(json.dumps(request) + '\n')
            proc.stdin.flush()
            response = json.loads(proc.stdout.readline())
            checked = validate_output(original, response['out_qasm'], 5, 5,
                                      edges + [e[::-1] for e in edges],
                                      response['initial_layout'], response['final_layout'])
            rows.append({'label': label, 'request': request, 'response': response, 'validation': checked})
            print(label, checked['passed'], checked.get('metrics'), flush=True)
    finally:
        proc.stdin.close()
        proc.wait(timeout=15)
with (TASK / 'diagnostics/ec_line_search.json').open('x') as stream:
    json.dump({'purpose': __doc__, 'binary_sha256': hashlib.sha256(binary.read_bytes()).hexdigest(),
               'script_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest(), 'rows': rows},
              stream, indent=2)
    stream.write('\n')
assert all(row['validation']['passed'] for row in rows)
