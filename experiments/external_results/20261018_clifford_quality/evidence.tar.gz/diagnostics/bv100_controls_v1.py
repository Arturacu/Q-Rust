"""Untimed BV100 cleanup controls using the unchanged frozen Clifford checker."""
import argparse
import hashlib
import itertools
import json
from pathlib import Path
import subprocess
import sys


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def main():
    p = argparse.ArgumentParser(description=__doc__)
    for name in ('repo', 'binary', 'preflight', 'output'):
        p.add_argument('--' + name, type=Path, required=True)
    a = p.parse_args()
    a.output.mkdir(parents=True, exist_ok=False)
    protocol = json.loads((a.preflight / 'protocol.json').read_text())
    case = next(c for c in protocol['cases']['matched'] if c['id'] == 'bv100_square')
    sys.path.insert(0, str(a.repo.resolve() / 'experiments'))
    import scalable_clifford as checker
    rows = []
    for block, fusion in itertools.product((False, True), repeat=2):
        request = {k: case[k] for k in ('qasm', 'n_logical', 'physical_width', 'edges', 'topology')}
        request.update(two_qubit_block_synthesis=block, post_block_fusion=fusion, profile_passes=True)
        rows.append({'name': f'block{int(block)}_fusion{int(fusion)}', 'request': request})
    run = subprocess.run([str(a.binary.resolve())], input=''.join(json.dumps(r['request']) + '\n' for r in rows),
                         capture_output=True, text=True, check=True, timeout=60)
    values = [json.loads(line) for line in run.stdout.splitlines()]
    assert values.pop(0)['ready']
    for row, result in zip(rows, values, strict=True):
        assert result['status'] == 'compiled'
        validation = checker.validate_clifford(case['qasm'], result['out_qasm'], case['n_logical'],
                                               result['output_qubits'], case['edges'],
                                               result['initial_layout'], result['final_layout'])
        row.update(result=result, validation=validation)
        (a.output / (row['name'] + '.qasm')).write_text(result['out_qasm'])
        print(json.dumps({'name': row['name'], 'passed': validation['passed'],
                          'error': validation.get('error'), 'metrics': validation.get('metrics'),
                          'blocks': result['two_qubit_block_stats'], 'fusion': result['post_block_fusion_stats']}), flush=True)
    with (a.output / 'results.json').open('x') as stream:
        json.dump({'scope': __doc__, 'binary_sha256': sha(a.binary),
                   'checker_sha256': sha(checker.__file__), 'protocol_sha256': sha(a.preflight / 'protocol.json'),
                   'script_sha256': sha(__file__), 'rows': rows}, stream, indent=2)
        stream.write('\n')


if __name__ == '__main__':
    main()
