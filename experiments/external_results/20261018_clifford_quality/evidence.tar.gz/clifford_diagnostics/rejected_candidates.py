"""Untimed exact-algebra diagnostic, separate from production and old results.

Replay the previously independently checked source SWAP substitutions, absorb
their permutation, then mirror the bounded controlled-Pauli rewrite. This is a
controlled source intervention, not an assertion that the intermediate circuit
is byte-identical to every production optimization stage.
"""
from pathlib import Path
from collections import deque
from functools import lru_cache
import hashlib, json, sys, math

BASE=Path(__file__).resolve().parents[2]
sys.path.insert(0,str(BASE/'qrust_pr_publish/experiments'))
from comparison_validation import parse_qasm, validate_output
OUT=Path(__file__).resolve().parent
ID=((1,0,0),(0,1,0),(2,0,0),(0,2,0))
def pauli(x,z):return (x,z,(x&z).bit_count()%4)
def mul(a,b):return (a[0]^b[0],a[1]^b[1],(a[2]+b[2]+2*(a[1]&b[0]).bit_count())%4)
def neg(a):return (*a[:2],(a[2]+2)%4)
def anti(a,b):return ((a[0]&b[1]).bit_count()+(a[1]&b[0]).bit_count())%2
def apply(t,p):
 out=(0,0,p[2])
 for q in range(2):
  if p[0]&(1<<q):out=mul(out,t[2*q])
 for q in range(2):
  if p[1]&(1<<q):out=mul(out,t[2*q+1])
 return out
def compose(a,b):return tuple(apply(a,p) for p in b)
def inverse(t):
 out=[]
 for target in ID:
  for x in range(4):
   for z in range(4):
    p=pauli(x,z);r=apply(t,p)
    if r[:2]==target[:2]:out.append(p if r[2]==target[2] else neg(p))
 return tuple(out)
def controlled(p,q):
 out=[]
 for r in ID:
  a,b=anti(r,p),anti(r,q);v=r
  if b:v=mul(v,p)
  if a:v=mul(v,q)
  if a and b:v=neg(v)
  out.append(v)
 return tuple(out)
@lru_cache(None)
def table(g):
 name,qs=g
 if name=='cx':return controlled(pauli(0,1<<qs[0]),pauli(1<<qs[1],0))
 if name=='swap':return (ID[2],ID[3],ID[0],ID[1])
 q=qs[0];x,z=pauli(1<<q,0),pauli(0,1<<q);y=pauli(1<<q,1<<q)
 axes={'h':(z,x),'s':(y,z),'sdg':(neg(y),z),'x':(x,neg(z)),
       'y':(neg(x),neg(z)),'z':(neg(x),z),'sx':(x,neg(y)),'id':(x,z)}[name]
 out=list(ID);out[2*q:2*q+2]=axes;return tuple(out)
GENERATORS=('h','s','sdg','x','y','z','sx')
WORDS={ID:()};queue=deque([(ID,())]);ORDER=[]
while queue:
 t,w=queue.popleft();ORDER.append((t,w))
 for name in GENERATORS:
  g=(name,(0,));n=compose(table(g),t)
  if n not in WORDS:WORDS[n]=w+(g,);queue.append((n,WORDS[n]))
def relocate(w,q):return tuple((name,(q,)) for name,_ in w)
PAIRS=[]
for a,wa in ORDER:
 for _,wb in ORDER:
  wb=relocate(wb,1);t=a
  for g in wb:t=compose(table(g),t)
  PAIRS.append((inverse(t),wa+wb))
def localword(t):
 out=()
 for q in range(2):
  local=list(ID)
  for k in range(2):
   x,z,p=t[2*q+k]
   if (x|z)&~(1<<q):return None
   local[k]=(x>>q,z>>q,p)
  out+=relocate(WORDS[tuple(local)],q)
 return out
def depth(ops,n=5):
 d=[0]*n
 for name,qs in ops:
  level=max(d[q] for q in qs)+1
  for q in qs:d[q]=level
 return max(d,default=0)
@lru_cache(None)
def synth(t):
 w=localword(t)
 if w is not None:return w
 best=None
 for ri,rw in PAIRS:
  for d in range(2):
   cx=('cx',(d,1-d));left=localword(compose(compose(t,ri),table(cx)))
   if left is None:continue
   candidate=rw+(cx,)+left
   if best is None or (depth(candidate,2),len(candidate))<(depth(best,2),len(best)):best=candidate
 return best
def fold(ops):
 pending=[ID]*5;out=[]
 def flush(q):
  out.extend(relocate(WORDS[pending[q]],q));pending[q]=ID
 for name,qs in ops:
  if name=='id':continue
  if len(qs)==1 and name in GENERATORS:
   pending[qs[0]]=compose(table((name,(0,))),pending[qs[0]]);continue
  for q in qs:flush(q)
  out.append((name,qs))
 for q in range(5):flush(q)
 return out
def extract(ops):
 perm=list(range(5));out=[]
 for name,qs in ops:
  if name=='swap':perm[qs[0]],perm[qs[1]]=perm[qs[1]],perm[qs[0]]
  else:out.append((name,tuple(perm[q] for q in qs)))
 # logical output map, inverse of the relabelling above
 return out,[perm.index(q) for q in range(5)]
def cost(ops,fused=False):
 ops,_=extract(ops)
 if fused:
  folded=fold(ops);pending=[False]*5;compressed=[]
  for name,qs in folded:
   if len(qs)==1:pending[qs[0]]=True;continue
   for q in qs:
    if pending[q]:compressed.append(('local',(q,)));pending[q]=False
   compressed.append((name,qs))
  for q in range(5):
   if pending[q]:compressed.append(('local',(q,)))
 else:compressed=ops
 count=0;layers=[0]*5
 for name,qs in ops:
  weight={'cx':1,'cy':1,'cz':1,'swap':3}.get(name,0);count+=weight
  d=max(layers[q] for q in qs)+weight
  for q in qs:layers[q]=d
 return (count,depth(compressed),max(layers))
def commutes(axis,wire,name,qs,pair):
 if pair[wire] not in qs:return True
 pos=qs.index(pair[wire]);a=(axis[0]>>wire,axis[1]>>wire,axis[2])
 b=pauli(0,1) if pos==0 or name=='cz' else pauli(1,1 if name=='cy' else 0)
 return not anti(a,b)
def run(ops,fused):
 ops=list(ops);quality=cost(ops,fused);rows=[]
 for sweep in range(2):
  changed=False;start=0
  while start<len(ops):
   name,pair=ops[start]
   if name!='cx':start+=1;continue
   p,q=pauli(0,1),pauli(2,0)
   for end in range(start+1,min(len(ops),start+97)):
    name,qs=ops[end]
    if len(qs)==1:
     if qs[0] in pair:
      t=table((name,(pair.index(qs[0]),)));p,q=apply(t,p),apply(t,q)
     continue
    if name not in ('cx','cy','cz'):break
    if name=='cx' and set(qs)==set(pair):
     d=int(qs[0]!=pair[0]);prod=compose(table(('cx',(d,1-d))),controlled(p,q))
     for swap in (False,True):
      w=synth(compose(prod,table(('swap',(0,1))))) if swap else synth(prod)
      if w is None:continue
      if swap:w=(('swap',(0,1)),)+w
      candidate=fold(ops[:start]+ops[start+1:end]+[(n,tuple(pair[q] for q in qs)) for n,qs in w]+ops[end+1:])
      nxt=cost(candidate,fused);accept=nxt[0]<quality[0] and nxt[1]<=quality[1] and nxt[2]<=quality[2]
      rows.append({'sweep':sweep,'start':start,'end':end,'pair':pair,'swap':swap,'input_cost':quality,'candidate_cost':nxt,'literal_before':cost(ops),'literal_after':cost(candidate),'fused_before':cost(ops,True),'fused_after':cost(candidate,True),'accepted':accept,'input':ops,'candidate':candidate})
      if accept:ops=candidate;quality=nxt;changed=True;break
     break
    if not commutes(p,0,name,qs,pair) or not commutes(q,1,name,qs,pair):break
   start+=1
  if not changed:break
 return ops,rows
def adjoint(ops):
 out=[]
 for name,qs in reversed(ops):
  if len(qs)==1:out.extend(relocate(WORDS[inverse(table((name,(0,))))],qs[0]))
  else:out.append((name,qs))
 return out
def cross_axes(p,q,g,pair,back=False):
 name,qs=g
 if len(qs)==1:
  if qs[0] in pair:
   t=table((name,(pair.index(qs[0]),)))
   if back:t=inverse(t)
   p,q=apply(t,p),apply(t,q)
  return p,q
 if name in ('cx','cy','cz') and commutes(p,0,name,qs,pair) and commutes(q,1,name,qs,pair):return p,q
 return None
def meet(ops,fused):
 ops=list(ops);quality=cost(ops,fused);rows=[]
 for sweep in range(2):
  changed=False;start=0
  while start<len(ops):
   name,pair=ops[start]
   if name!='cx':start+=1;continue
   end=next((i for i in range(start+1,min(len(ops),start+97)) if ops[i][0]=='cx' and set(ops[i][1])==set(pair)),None)
   if end is None:start+=1;continue
   left=(pauli(0,1),pauli(2,0));lefts={start+1:left};cut=start+1
   while cut<end:
    moved=cross_axes(*left,ops[cut],pair)
    if moved is None:break
    left=moved;cut+=1;lefts[cut]=left
   right=(pauli(0,1),pauli(2,0)) if ops[end][1]==pair else (pauli(1,0),pauli(0,2))
   accepted=False
   for cut in reversed(range(start+1,end+1)):
    if cut<end:
     right=cross_axes(*right,ops[cut],pair,back=True)
     if right is None:break
    if cut not in lefts:continue
    product=compose(controlled(*right),controlled(*lefts[cut]))
    for swap in (False,True):
     w=synth(compose(product,table(('swap',(0,1))))) if swap else synth(product)
     if w is None:continue
     if swap:w=(('swap',(0,1)),)+w
     candidate=fold(ops[:start]+ops[start+1:cut]+[(n,tuple(pair[q] for q in qs)) for n,qs in w]+ops[cut:end]+ops[end+1:])
     nxt=cost(candidate,fused);accept=nxt[0]<quality[0] and nxt[1]<=quality[1] and nxt[2]<=quality[2]
     rows.append({'sweep':sweep,'start':start,'end':end,'cut':cut,'pair':pair,'swap':swap,'input_cost':quality,'candidate_cost':nxt,'literal_before':cost(ops),'literal_after':cost(candidate),'fused_before':cost(ops,True),'fused_after':cost(candidate,True),'accepted':accept,'input':ops,'candidate':candidate})
     if accept:ops=candidate;quality=nxt;changed=True;accepted=True;break
    if accepted:break
   start+=1
  if not changed:break
 return ops,rows
def qasm(ops):return 'OPENQASM 2.0;\ninclude "qelib1.inc";\nqreg q[5];\n'+''.join(n+' '+','.join(f'q[{q}]' for q in qs)+';\n' for n,qs in ops)
def lower_for_oracle(text):
 params={'h':(math.pi/2,0,math.pi),'s':(0,0,math.pi/2),'sdg':(0,0,-math.pi/2),'x':(math.pi,0,math.pi),'y':(math.pi,math.pi/2,math.pi/2),'z':(0,0,math.pi),'sx':(math.pi/2,-math.pi/2,math.pi/2)}
 return '\n'.join('u('+','.join(map(str,params[line.split()[0]]))+') '+line.split(maxsplit=1)[1] if line.split() and line.split()[0] in params else line for line in text.splitlines())+'\n'
source=(BASE/'qrust_external_20261018/corpus/qasmbench__error_correctiond3_n5.normalized.qasm').read_text()
_,parsed=parse_qasm(source);ops=[(g.name,g.qubits) for g in parsed]
windows=json.loads((BASE/'qrust_clifford_followup_20261018/clifford_diagnostics/swap_windows.json').read_text())
removed=set()
for row in windows['rows']:
 indices=row['source_gate_indices'];anchor=next(i for i in indices if len(ops[i][1])==2)
 removed.update(i for i in indices if i!=anchor);ops[anchor]=('swap',tuple(row['pair']))
intervention,original_map=extract([g for i,g in enumerate(ops) if i not in removed]);intervention=fold(intervention)
result={'purpose':__doc__,'source_sha256':hashlib.sha256(source.encode()).hexdigest(),'original_map':original_map,'input':intervention,'input_cost':cost(intervention),'input_fused_cost':cost(intervention,True),'modes':{}}
for fused in (False,True):
 output,rows=run(intervention,fused);output,final_map=extract(output);composed=[final_map[q] for q in original_map]
 text=qasm(output);validation=validate_output(source,lower_for_oracle(text),5,5,None,list(range(5)),composed)
 result['modes']['fused' if fused else 'literal']={'rows':rows,'cost':cost(output),'fused_cost':cost(output,True),'final_layout':composed,'validation':validation}
 (OUT/('intervention_fused.qasm' if fused else 'intervention_literal.qasm')).write_text(text)
 print('fused',fused,'output',cost(output),cost(output,True),'validated',validation['passed'])
 for row in rows:print({k:v for k,v in row.items() if k not in ('input','candidate')})
 assert validation['passed']
 if fused:
  backward,back_rows=run(adjoint(output),True)
  forward=adjoint(backward);forward,back_map=extract(forward)
  backward_validation=validate_output(source,lower_for_oracle(qasm(forward)),5,5,None,list(range(5)),[back_map[q] for q in composed])
  result['bidirectional']={'rows':back_rows,'cost':cost(forward),'fused_cost':cost(forward,True),'validation':backward_validation,'output':forward}
  (OUT/'intervention_bidirectional.qasm').write_text(qasm(forward))
  print('bidirectional',cost(forward),cost(forward,True),backward_validation['passed'])
  for row in back_rows:print({k:v for k,v in row.items() if k not in ('input','candidate')})
  assert backward_validation['passed']
  forward2,forward2_rows=run(forward,True);forward2,forward2_map=extract(forward2)
  forward2_validation=validate_output(source,lower_for_oracle(qasm(forward2)),5,5,None,list(range(5)),[forward2_map[back_map[q]] for q in composed])
  result['bidirectional_then_forward']={'rows':forward2_rows,'cost':cost(forward2),'fused_cost':cost(forward2,True),'validation':forward2_validation,'output':forward2}
  (OUT/'intervention_bidirectional_then_forward.qasm').write_text(qasm(forward2))
  print('bidirectional then forward',cost(forward2),cost(forward2,True),forward2_validation['passed'])
  for row in forward2_rows:print({k:v for k,v in row.items() if k not in ('input','candidate')})
  assert forward2_validation['passed']
for fused in (False,True):
 output,rows=meet(intervention,fused);output,final_map=extract(output);composed=[final_map[q] for q in original_map]
 validation=validate_output(source,lower_for_oracle(qasm(output)),5,5,None,list(range(5)),composed)
 result['meet_fused' if fused else 'meet_literal']={'rows':rows,'cost':cost(output),'fused_cost':cost(output,True),'final_layout':composed,'validation':validation,'output':output}
 (OUT/('intervention_meet_fused.qasm' if fused else 'intervention_meet_literal.qasm')).write_text(qasm(output))
 print('meet fused',fused,cost(output),cost(output,True),validation['passed'])
 for row in rows:print({k:v for k,v in row.items() if k not in ('input','candidate')})
 assert validation['passed']
(OUT/'rejected_candidates.json').write_text(json.dumps(result,indent=2)+'\n')
