"""Independent named-Pauli replay and full-unitary audit of one physical route."""
from pathlib import Path
import json,hashlib,sys

ROOT=Path(__file__).resolve().parent
BASE=ROOT.parents[2]
helper=ROOT.parent/'rejected_candidates.py'
# Load definitions only. Disable SWAP synthesis exactly as the production
# post-routing invocation does; no test input or historical result is changed.
definitions=helper.read_text().split('source=(BASE/')[0]
definitions=definitions.replace('for swap in (False,True):','for swap in (False,):')
ns={'__file__':str(helper)}
exec(definitions,ns)
parse=ns['parse_qasm'];validate=ns['validate_output']
stage=ROOT/'public_forward_full'
source=(BASE/'qrust_external_20261018/corpus/qasmbench__error_correctiond3_n5.normalized.qasm').read_text()
initial=[2,3,1,4,0];final=[1,2,3,4,0]
edges=[(i,j) for i in range(5) for j in range(5) if abs(i-j)==1]
_,gates=parse((stage/'02_expanded.qasm').read_text())
ops=[(g.name,g.qubits) for g in gates]
assert all(not g.params for g in gates)
output,rows=ns['meet'](ops,False)
_,native=parse((stage/'03_clifford.qasm').read_text())
assert output==[(g.name,g.qubits) for g in native], 'independent exact trace must reproduce every native operation'
accepted=[]
for row in rows:
 if not row['accepted']:continue
 row['validation']=validate(source,ns['lower_for_oracle'](ns['qasm'](row['candidate'])),5,5,edges,initial,final)
 assert row['validation']['passed']
 pair=row['pair'];start,end,cut=(row[k] for k in ('start','end','cut'));left=(ns['pauli'](0,1),ns['pauli'](2,0))
 right=left if row['input'][end][1]==pair else (ns['pauli'](1,0),ns['pauli'](0,2))
 for i in range(start+1,cut):left=ns['cross_axes'](*left,row['input'][i],pair)
 for i in reversed(range(cut,end)):right=ns['cross_axes'](*right,row['input'][i],pair,back=True)
 row['left_axes']=left;row['right_axes']=right
 accepted.append(row)
 print({k:v for k,v in row.items() if k not in ('input','candidate','validation')})
validations={}
for name in ('02_expanded','03_clifford','04_final'):
 text=(stage/f'{name}.qasm').read_text()
 if name!='04_final':text=ns['lower_for_oracle'](text)
 validations[name]=validate(source,text,5,5,edges,initial,final)
 assert validations[name]['passed']
native_evidence=json.loads((BASE/'qrust_clifford_quality_20261018/expanded_postrouting_v1/ec_controls/results.json').read_text())
reference=next(row for row in native_evidence['rows'] if row.get('name')=='current_line_encoded1_clifford1')['response']
final_native=(stage/'04_final.qasm').read_text()
exact_final=(final_native==reference['out_qasm'])
assert exact_final, 'public fixed-route reconstruction must exactly match selected production QASM'
result={'purpose':__doc__,'source_sha256':hashlib.sha256(source.encode()).hexdigest(),
 'trace_helper_sha256':hashlib.sha256(helper.read_bytes()).hexdigest(),
 'script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
 'original_initial_layout':initial,'original_final_layout':final,
 'fixed_route_matches_selected_output_exactly':exact_final,
 'post_pass_matches_independent_trace_exactly':True,'accepted_rewrites':accepted,
 'all_candidate_cuts':rows,'stage_validations':validations}
(ROOT/'routed_exact_trace.json').write_text(json.dumps(result,indent=2)+'\n')
print('exact final QASM match',exact_final)
print({name:row['metrics'] for name,row in validations.items()})
