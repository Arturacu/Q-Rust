//! Untimed public-pass reconstruction of one explicitly fixed forward route.
//! This is a diagnostic copy; no private candidate type or production edit.
use q_rust::{backend::Backend, ir::Circuit, parser::parse_qasm};
use q_rust::transpiler::{optimization::*, phase_gadgets::RecoverPhaseGadgetsPass,
    encoded_swaps::EncodedSwapRecognitionPass,
    clifford_simplification::{CliffordSimplificationPass,CliffordSimplificationStats},
    decomposition::*, target_basis::TargetBasisPass,
    routing::BeamSabrePass, pass::Pass, property_set::PropertySet};
use std::{fs, path::Path};

fn save(root: &Path, name: &str, c: &Circuit, p: &PropertySet) {
    fs::write(root.join(format!("{name}.qasm")),c.to_qasm(None)).unwrap();
    println!("{}",serde_json::json!({"stage":name,"depth":c.depth(),"operations":c.operations.len(),
        "initial_layout":p.get::<Vec<usize>>("initial_layout"),
        "final_layout":p.get::<Vec<usize>>("final_layout"),
        "clifford_stats":p.get::<CliffordSimplificationStats>("clifford_simplification_stats").map(|s|
            serde_json::json!({"rewrites":s.rewrites,"cx_removed":s.cx_removed,"interior_rewrites":s.interior_rewrites,"candidate_evaluations":s.candidate_evaluations}))}));
}
fn main() {
    let args:Vec<String>=std::env::args().collect();
    let source=fs::read_to_string(&args[1]).unwrap();let root=Path::new(&args[2]);fs::create_dir(root).unwrap();
    let mut c=parse_qasm(&source).unwrap();let mut p=PropertySet::new();
    let prefix:Vec<Box<dyn Pass>>=vec![Box::new(RecoverPhaseGadgetsPass),Box::new(GateCrystallizationPass::default()),
        Box::new(ParameterSimplificationPass::default()),Box::new(RotationMergePass),Box::new(CrossConjugationPass),
        Box::new(InverseCancellationPass),Box::new(CommutationCancellationPass),Box::new(ParameterSimplificationPass::default()),
        Box::new(EncodedSwapRecognitionPass),Box::new(ExtractOutputPermutationPass),
        Box::new(CliffordSimplificationPass{allow_swap_replacements:true}),Box::new(ComposeOutputPermutationPass),
        Box::new(HighArityDecompositionPass)];
    for pass in prefix {c=pass.try_run(&c,&mut p).unwrap();}
    save(root,"00_logical",&c,&p);
    let backend=Backend::linear(c.num_qubits);
    p.insert("sabre_initial_layout",vec![2_usize,3,1,4,0]);
    p.insert("routing_lookahead_size",20_usize);p.insert("routing_rank_progress",true);
    p.insert("routing_commute_diagonal",true);p.insert("retain_routing_candidates",false);
    c=BeamSabrePass{backend,beam_width:8,branch_factor:5,bidir_iterations:1,lookahead_strategy:Default::default()}.try_run(&c,&mut p).unwrap();
    save(root,"01_routed",&c,&p);
    c=TrailingSwapElisionPass.run(&c,&mut p);c=ApplyOutputPermutationPass.run(&c,&mut p);
    c=OrientSwapDecompositionPass.run(&c,&mut p);
    c=TargetBasisPass::new(["u".to_string(),"cx".to_string()].into()).unwrap().run(&c,&mut p);
    save(root,"02_expanded",&c,&p);
    c=CliffordSimplificationPass{allow_swap_replacements:false}.run(&c,&mut p);
    save(root,"03_clifford",&c,&p);
}
