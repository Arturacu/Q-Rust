"""Preserved, untimed feature ablations with complete small-circuit validation."""
import argparse, hashlib, itertools, json, subprocess, sys
from pathlib import Path
p=argparse.ArgumentParser(); p.add_argument('--repo',type=Path,required=True); p.add_argument('--binary',type=Path,required=True); p.add_argument('--source',type=Path,required=True); p.add_argument('--out',type=Path,required=True)
a=p.parse_args(); a.out.mkdir(parents=True,exist_ok=False)
sys.path.insert(0,str(a.repo/'experiments'))
from comparison_validation import parse_qasm,validate_output
source=a.source.read_text(); width,_=parse_qasm(source)
rows=[]
for topology in ('all_to_all','line'):
 edges=list(itertools.combinations(range(width),2)) if topology=='all_to_all' else [(i,i+1) for i in range(width-1)]
 for encoded,clifford in itertools.product((False,True),repeat=2):
  request={'qasm':source,'topology':topology,'n_logical':width,'physical_width':width,'edges':edges,'encoded_swap_recognition':encoded,'clifford_simplification':clifford,'profile_passes':True}
  rows.append({'name':f'{topology}_encoded{int(encoded)}_clifford{int(clifford)}','request':request})
run=subprocess.run([str(a.binary.resolve())],input=''.join(json.dumps(r['request'])+'\n' for r in rows),capture_output=True,text=True,check=True)
responses=[json.loads(line) for line in run.stdout.splitlines()]; assert responses.pop(0)['ready']
for row,response in zip(rows,responses,strict=True):
 assert response['status']=='compiled',response
 request=row['request']; edges=[edge for a,b in request['edges'] for edge in ((a,b),(b,a))]
 evidence=validate_output(source,response['out_qasm'],width,width,edges,response['initial_layout'],response['final_layout'])
 row.update(response=response,validation=evidence)
 (a.out/(row['name']+'.qasm')).write_text(response['out_qasm'])
 print(row['name'],json.dumps({'passed':evidence['passed'],'metrics':evidence.get('metrics'),'swap':response.get('encoded_swap_stats'),'clifford':response.get('clifford_simplification_stats'),'map':response['final_layout']}),flush=True)
assert all(r['validation']['passed'] for r in rows)
receipt={'purpose':'profiled causal diagnostics, not benchmark timing','source_sha256':hashlib.sha256(source.encode()).hexdigest(),'binary_sha256':hashlib.sha256(a.binary.read_bytes()).hexdigest(),'rows':rows}
(a.out/'ablations.json').write_text(json.dumps(receipt,indent=2)+'\n')
