from pathlib import Path
import hashlib, json, sys
BASE = Path(__file__).resolve().parents[2]
REPO = BASE / "qrust_pr_publish"
sys.path.insert(0, str(REPO / "experiments"))
import scalable_clifford as sc
from comparison_validation import parse_qasm, _one_matrix
import numpy as np
control_path = BASE / "qrust_clifford_quality_20261018/expanded_postrouting_v1/ec_controls/results.json"
control = json.loads(control_path.read_text())
rows = []
for row in control["rows"]:
    if not row["name"].endswith("encoded1_clifford1"):
        continue
    request, response = row["request"], row["response"]
    output = response["out_qasm"]
    check = sc.validate_clifford(control["source"], output, 5, 5,
        response["initial_layout"], response["final_layout"], request["edges"],
        output_basis=("u", "u3", "cx"))
    noncliff = []
    for index, gate in enumerate(parse_qasm(output)[1]):
        if len(gate.qubits) != 1:
            continue
        matrix = np.asarray(_one_matrix(gate.name, gate.params), dtype=complex).reshape(2,2)
        residual, word = min((sc.phase_residual(matrix, target), word) for target, word in sc.representatives())
        if residual > sc.LOCAL_TOLERANCE:
            noncliff.append({"index": index, "name": gate.name, "qubits": gate.qubits,
                "params": gate.params, "nearest_clifford_residual": residual, "nearest_word": word})
    rows.append({"name": row["name"], "metrics": row["validation"]["metrics"],
        "full_unitary_validation": row["validation"], "gatewise_clifford_validation": check,
        "nonclifford_local_gates": noncliff})
result = {"purpose": "Diagnostic representation audit; original results unchanged",
    "script_sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
    "control_sha256": hashlib.sha256(control_path.read_bytes()).hexdigest(),
    "checker_sha256": hashlib.sha256(Path(sc.__file__).read_bytes()).hexdigest(), "rows": rows}
out = Path(__file__).with_suffix(".json")
assert not out.exists()
out.write_text(json.dumps(result, indent=2)+"\n")
for row in rows:
    print(row["name"], row["metrics"], row["gatewise_clifford_validation"], row["nonclifford_local_gates"])
