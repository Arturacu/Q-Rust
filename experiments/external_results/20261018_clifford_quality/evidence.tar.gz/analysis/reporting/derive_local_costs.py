#!/usr/bin/env python3
"""Derive local paired timing ratios from the checksum-bound report tables."""
import argparse
import hashlib
import json
from pathlib import Path

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--input', type=Path, required=True)
parser.add_argument('--output', type=Path, required=True)
args = parser.parse_args()
raw = args.input.read_bytes()
metrics = json.loads(raw)
result = {'report_metrics_sha256': hashlib.sha256(raw).hexdigest(),
          'source_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
          'method': 'Candidate median compile_ns divided by adjacent previous-baseline median compile_ns, separately for each session and topology; added percent is 100*(ratio-1). No pooling.',
          'tables': {}}
for name in ('error_correction_tables', 'qec_encoder_tables'):
    result['tables'][name] = {}
    for session, topologies in metrics[name].items():
        result['tables'][name][session] = {}
        for topology, rows in topologies.items():
            old = next(row for row in rows if row['variant'] == 'control' and row['tool'] == 'qrust')
            new = next(row for row in rows if row['variant'] == 'primary' and row['tool'] == 'qrust')
            if not old['eligible'] or not new['eligible']:
                raise ValueError('Local cost cell is not eligible')
            ratio = new['median']['compile_ns'] / old['median']['compile_ns']
            result['tables'][name][session][topology] = {
                'old_compile_ms': old['compile_ms'], 'new_compile_ms': new['compile_ms'],
                'new_over_old': ratio, 'added_percent': 100 * (ratio - 1)}
with args.output.open('x') as stream:
    json.dump(result, stream, indent=2, sort_keys=True, allow_nan=False)
    stream.write('\n')
