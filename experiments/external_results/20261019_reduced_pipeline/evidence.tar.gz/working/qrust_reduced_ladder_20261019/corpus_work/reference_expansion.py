#!/usr/bin/env python3
"""Source-only exact SDK-definition expansion, separate from QASM normalization."""
from __future__ import annotations
from collections import Counter
import json
from pathlib import Path
import sys


def expand_reference(circuit, maximum_gates=5000, maximum_depth=100):
    from qiskit import QuantumCircuit
    out = QuantumCircuit(circuit.num_qubits)
    out.global_phase = circuit.global_phase
    expanded = Counter()
    phases = []

    def emit(operation, wires, depth):
        if depth > maximum_depth:
            raise ValueError('Reference definition recursion limit')
        if operation.num_clbits or operation.name in ('measure', 'reset', 'barrier'):
            raise ValueError('Reference must be a static unitary circuit')
        if len(wires) <= 2:
            if len(out.data) >= maximum_gates:
                raise ValueError('Reference expanded gate limit')
            out.append(operation, wires)
            return
        definition = operation.definition
        if definition is None:
            raise ValueError('Wide operation lacks an exact SDK definition: ' + operation.name)
        expanded[operation.name] += 1
        phase = float(definition.global_phase)
        out.global_phase = out.global_phase + phase
        phases.append({'operation': operation.name, 'phase': phase, 'depth': depth})
        for item in definition.data:
            mapped = [wires[definition.find_bit(q).index] for q in item.qubits]
            emit(item.operation, mapped, depth + 1)

    for item in circuit.data:
        emit(item.operation, [circuit.find_bit(q).index for q in item.qubits], 0)
    return out, {'method': 'Independent recursive Qiskit operation.definition expansion of gates wider than two qubits',
        'definition_expansions': dict(sorted(expanded.items())), 'nested_global_phases': phases,
        'outer_global_phase': float(circuit.global_phase), 'expanded_global_phase': float(out.global_phase),
        'expanded_gate_count': len(out.data), 'maximum_leaf_width': max((len(i.qubits) for i in out.data), default=0),
        'optimization': 'none', 'reference_is_common_normalizer_output': False}


def worker(request_path):
    request = json.loads(Path(request_path).read_text())
    sys.path.insert(0, str(Path(request['repo']) / 'experiments'))
    import external_corpus
    from qiskit import qpy
    with Path(request['raw_qpy']).open('rb') as stream:
        original = qpy.load(stream)[0]
    prefix, _ = external_corpus.unitary_prefix(original)
    reference, receipt = expand_reference(prefix)
    evidence = external_corpus.normalization_evidence(reference, request['source_qasm'], request['qasm'])
    print(json.dumps({'normalization_evidence': evidence, 'reference_expansion': receipt}, allow_nan=False), flush=True)


if __name__ == '__main__':
    worker(sys.argv[1])
