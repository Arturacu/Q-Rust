"""Synthetic regressions; never loads a selected circuit or launches a compiler."""
import copy
import importlib
import json
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch

import ladder_corpus as corpus
import ladder_study as study

REPO = Path(__file__).resolve().parents[2] / 'qrust_pr_publish'
legacy = study.load_legacy(study.DEFAULT_LEGACY)
external = study.configure(REPO)
base = importlib.import_module('analyze_comparison_study')
base.TOOLS = study.TOOLS


def cell(case, tool, eligible=True, value=10):
    return {'case_id': case, 'fixture': case.split('__')[0], 'tool': tool,
        'family': corpus.FAMILIES[0], 'coarse_family': 'generative_modeling',
        'holdout_class': 'new_instance_known_generator', 'topology': 'linear',
        'n_logical': 6, 'physical_width': 6, 'eligible': eligible,
        'medians': {metric: value for metric in ('compile_ns', 'parse_compile_ns', *base.METRICS)}}


class CorpusTests(unittest.TestCase):
    def test_selection_hash(self):
        self.assertEqual(len(corpus.candidates()), 18)
        with tempfile.TemporaryDirectory() as tmp:
            p = Path(tmp)
            (p / 'selection.json').write_text('{}')
            (p / 'selection.sha256').write_text(corpus.SELECTION_SHA256)
            with self.assertRaisesRegex(ValueError, 'checksum'):
                corpus.read_selection(p)

    def test_graphs(self):
        for width, count in [(6, 7), (10, 13), (14, 19)]:
            edges = corpus.target_edges(width, 'grid')
            self.assertEqual(len(edges), count)
            self.assertEqual(len(edges), len({tuple(e) for e in edges}))
            self.assertTrue(all(0 <= a < b < width for a, b in edges))
        with self.assertRaises(ValueError):
            corpus.target_edges(6, 'unsupported')
        with self.assertRaises(KeyError):
            corpus.target_edges(16, 'grid')

    def test_json_and_jsonl_only_inputs(self):
        qasm = 'OPENQASM 2.0; qreg q[1]; h q[0];'
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            (root / 'old.jsonl').write_text(json.dumps({'request': {'qasm': qasm}, 'out_qasm': qasm + 'x q[0];'}) + '\n')
            (root / 'old.json').write_text(json.dumps({'case': {'source_qasm': qasm}}))
            rows = corpus.prior_inventory(root, root / 'exclude')
            self.assertEqual(len(rows), 2)
            self.assertEqual({r['kind'] for r in rows}, {'json_input_payload', 'jsonl_input_payload'})
            self.assertTrue(all(r['sha256'] == corpus.digest(qasm) for r in rows))
            self.assertTrue(all('container_sha256' in r for r in rows))

    def test_overlap_checks_all_forms_and_comments(self):
        qasm = 'OPENQASM 2.0; qreg q[1]; h q[0];'
        prior = [{'sha256': corpus.digest(qasm), 'lexical_sha256': corpus.lexical_digest(qasm)}]
        for name in ('raw', 'source', 'normalized'):
            with self.assertRaisesRegex(RuntimeError, 'prior_recorded'):
                corpus.audit_overlap({name: '// comment\n' + qasm.replace(';', ';\n')}, prior, set())
        with self.assertRaisesRegex(RuntimeError, 'duplicate_new'):
            corpus.audit_overlap({'source': qasm}, [], {corpus.lexical_digest(qasm)})


class ScheduleTests(unittest.TestCase):
    def test_balanced_all_ten_positions(self):
        cases = [{'id': 'synthetic_a'}, {'id': 'synthetic_b'}]
        rows = [r for s in (1, 2) for r in study.schedule(cases, 5, study.MASTER_SEED, s)]
        for case in cases:
            for tool in study.TOOLS:
                measured = [r for r in rows if r['case_id'] == case['id'] and r['tool'] == tool and r['trial'] >= 0]
                self.assertEqual(sorted(r['tool_order'] for r in measured), list(range(10)))
                self.assertEqual(sorted(r['rotation'] for r in measured), list(range(10)))
        self.assertEqual(len(rows), 2 * 2 * 10 * 6)
        self.assertEqual(study.schedule(cases, 5, study.MASTER_SEED, 1), study.schedule(cases, 5, study.MASTER_SEED, 1))
        with self.assertRaises(ValueError):
            study.schedule(cases, 7, study.MASTER_SEED, 1)


class AnalysisTests(unittest.TestCase):
    def test_primary_identical_across_sessions_and_all_arms(self):
        first = [cell(case, tool) for case in ('a', 'b') for tool in study.TOOLS]
        second = copy.deepcopy(first)
        next(c for c in second if c['case_id'] == 'b' and c['tool'] == 'R3')['eligible'] = False
        self.assertEqual(study.stable_cohort([first, second], study.ARMS), {'a'})
        self.assertEqual(study.stable_cohort([first, second], ('R0', 'R1')), {'a', 'b'})
        result = study.analysis_summaries([first, second], base, draws=0)
        self.assertEqual(result['primary_all_seven_case_ids'], ['a'])
        for session in result['sessions']:
            self.assertEqual(session['primary']['versus_R0']['R6']['paired_cells'], 1)
            self.assertEqual(session['secondary_adjacent_stable']['R1_vs_R0']['paired_cells'], 2)

    def test_retention_zero_and_joint(self):
        cells = [cell('a', arm, value=0) for arm in study.ARMS]
        next(c for c in cells if c['tool'] == 'R0')['medians']['depth'] = 1
        result = study.retention(cells, {'a'})
        for threshold in ('0', '0.05', '0.1'):
            self.assertEqual(result['R0'][threshold]['counts']['cx_count'], 1)
            self.assertEqual(result['R0'][threshold]['counts']['depth'], 0)
            self.assertEqual(result['R0'][threshold]['counts']['joint_all_three'], 0)
            self.assertEqual(result['R6'][threshold]['counts']['joint_all_three'], 1)
            self.assertEqual(result['R6'][threshold]['zero_reference_counts']['depth'], 1)

    def test_ratio_zeros_are_not_epsilon(self):
        cells = [cell('a', 'R0', value=0), cell('a', 'R1', value=0)]
        result = study.pair_summary(cells, 'R1', 'R0', {'a'}, base, 'synthetic', draws=0)
        self.assertEqual(result['cx_count']['positive_ratio_cells'], 0)
        self.assertIsNone(result['cx_count']['geomean'])
        self.assertEqual(result['cx_count']['zero_cases']['both_zero'], 1)
        self.assertEqual(result['cx_count']['candidate_win_tie_loss']['tie'], 1)

    def test_missing_trials_and_failed_warmup(self):
        protocol = {'cases': [{'id': 'a', 'fixture': 'a', 'family': corpus.FAMILIES[0],
            'topology': 'linear', 'n_logical': 6, 'physical_width': 6,
            'coarse_family': 'generative_modeling', 'holdout_class': 'new_instance_known_generator'}]}
        rows = [{'id': 'a__R0__' + str(i), 'case_id': 'a', 'tool': 'R0', 'trial': i,
            'status': 'compiled', 'compile_ns': 100, 'parse_ns': 10,
            'validation': {'passed': True, 'metrics': {key: 1 for key in base.METRICS}}} for i in range(5)]
        bad_warmup = [{'case_id': 'a', 'tool': 'R0', 'status': 'error'}]
        qualified = legacy.qualify_cells(protocol, rows, rows, bad_warmup, base)
        c = next(c for c in qualified if c['tool'] == 'R0')
        self.assertFalse(c['eligible'])
        self.assertIsNone(c['medians'])
        good_warmup = [{'case_id': 'a', 'tool': 'R0', 'status': 'compiled', 'validation': {'passed': True}}]
        qualified = legacy.qualify_cells(protocol, rows[:4], rows[:4], good_warmup, base)
        self.assertFalse(next(c for c in qualified if c['tool'] == 'R0')['eligible'])

    def test_memory_limits_include_idle_and_distinct_pids(self):
        legacy.check_rss({1: 10, 2: 20})
        with self.assertRaises(MemoryError):
            legacy.check_rss({1: 1, 2: legacy.PER_WORKER_RSS + 1})
        with self.assertRaises(MemoryError):
            legacy.check_rss({1: legacy.PER_WORKER_RSS, 2: legacy.PER_WORKER_RSS})


if __name__ == '__main__':
    unittest.main()
