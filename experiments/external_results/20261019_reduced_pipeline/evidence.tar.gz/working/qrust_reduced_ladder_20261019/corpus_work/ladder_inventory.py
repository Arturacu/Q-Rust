#!/usr/bin/env python3
"""Classify prior QASM conservatively and preserve the first admission attempt."""
from __future__ import annotations
import argparse
from collections import Counter
import json
import os
from pathlib import Path
import shutil

import ladder_corpus as corpus

OUTPUT_CONTEXTS = frozenset(('output', 'outputs', 'out', 'result', 'results', 'response', 'responses',
    'compiled', 'compiled_circuit', 'stages', 'stage_outputs', 'pass_trace', 'pass_traces', 'trace', 'traces'))
INPUT_CONTEXTS = frozenset(('request', 'requests', 'case', 'cases', 'candidate', 'candidates', 'corpus', 'fixtures', 'inputs', 'input'))
QASM_FIELDS = frozenset(('qasm', 'source_qasm', 'input_qasm', 'normalized_qasm', 'raw_qasm',
    'out_qasm', 'output_qasm', 'compiled_qasm'))


def embedded(value, pointer='', contexts=()):
    if isinstance(value, dict):
        for key, item in value.items():
            child = pointer + '/' + str(key).replace('~', '~0').replace('/', '~1')
            if key in QASM_FIELDS and isinstance(item, str) and 'OPENQASM' in item:
                if key in ('out_qasm', 'output_qasm', 'compiled_qasm'):
                    classification = 'explicit_output'
                elif key in ('source_qasm', 'input_qasm', 'raw_qasm'):
                    classification = 'explicit_input'
                else:
                    # The closest explicit context wins; outer result containers can hold requests.
                    nearest = next((v for v in reversed(contexts) if v in INPUT_CONTEXTS or v in OUTPUT_CONTEXTS), None)
                    if nearest in INPUT_CONTEXTS:
                        classification = 'explicit_input'
                    elif nearest in OUTPUT_CONTEXTS and nearest not in ('result', 'results'):
                        classification = 'explicit_output'
                    elif 'fixture' in value or 'source_qasm' in value or 'source_sha256' in value:
                        classification = 'explicit_input'
                    else:
                        classification = 'unclassified_qasm'
                yield child, item, classification
            elif isinstance(item, (dict, list)):
                yield from embedded(item, child, (*contexts, str(key).lower()))
    elif isinstance(value, list):
        for i, item in enumerate(value):
            yield from embedded(item, pointer + '/' + str(i), contexts)


def file_classification(path):
    parts, name = set(path.parts), path.name.lower()
    if name.endswith(('.source.qasm', '.normalized.qasm')):
        return 'explicit_input'
    if parts & {'outputs', 'compiled', 'compiled_outputs'} or name.startswith(('output_', 'compiled_', 'out_')) or name.endswith(('.out.qasm', '.output.qasm')):
        return 'explicit_output'
    if parts & {'corpus', 'corpus_v2', 'fixtures', 'generated_raw', 'qasmbench'} or name.endswith(('.source.qasm', '.normalized.qasm')):
        return 'explicit_input'
    return 'unclassified_qasm'


def inventory(working, exclude):
    rows = []
    for directory, dirs, files in os.walk(working):
        dirs[:] = sorted(name for name in dirs if name not in corpus.SKIP_DIRS
            and not (Path(directory) / name).resolve().is_relative_to(exclude.resolve()))
        for name in sorted(files):
            if not name.endswith(('.qasm', '.json', '.jsonl')):
                continue
            path = Path(directory) / name
            raw = path.read_bytes()
            text, relative = raw.decode(), str(path.relative_to(working))
            if name.endswith('.qasm'):
                rows.append({'path': relative, 'kind': 'standalone_qasm', 'classification': file_classification(Path(relative)),
                    'sha256': corpus.digest(raw), 'lexical_sha256': corpus.lexical_digest(text)})
            elif 'OPENQASM' in text:
                container_hash = corpus.digest(raw)
                documents = [(i, json.loads(line)) for i,line in enumerate(text.splitlines(),1) if line.strip()] if name.endswith('.jsonl') else [(None,json.loads(text))]
                for line, document in documents:
                    for pointer, qasm, classification in embedded(document):
                        rows.append({'path': relative, 'kind': 'jsonl_qasm_payload' if line else 'json_qasm_payload',
                            'line': line, 'pointer': pointer, 'classification': classification,
                            'container_sha256': container_hash, 'sha256': corpus.digest(qasm), 'lexical_sha256': corpus.lexical_digest(qasm)})
    return rows


def audit(args):
    # The initial generation, numerical checks and inventory stay byte-identical.
    raw = (args.first / 'manifest.json').read_bytes()
    first = json.loads(raw)
    if first['selection_sha256'] != corpus.SELECTION_SHA256:
        raise ValueError('Unexpected original selection')
    prior = inventory(args.working, args.output.parent.parent)
    admitted_prior = [r for r in prior if r['classification'] != 'explicit_output']
    prior_path = args.selection / 'prior_qasm_inventory_v2.json'
    corpus.dump_new(prior_path, prior)
    new_hashes, cases, ledger = set(), [], []
    by_id = {row['id']: row for row in first['cases']}
    for entry in first['candidate_ledger']:
        row = dict(entry)
        if entry['selection_status'] == 'selected':
            case = dict(by_id[entry['id']])
            forms = {'raw': (args.first / 'generated_raw' / (entry['id'] + '.qasm')).read_text(),
                     'source': case['source_qasm'], 'normalized': case['qasm']}
            if corpus.digest(forms['source']) != case['source_sha256'] or corpus.digest(forms['normalized']) != case['normalized_sha256'] or corpus.digest(forms['raw']) != case['raw_qasm_sha256']:
                raise ValueError('Original source artifact hash changed')
            for kind, text in [('source_artifact', forms['source']), ('normalized_artifact', forms['normalized'])]:
                if (args.first / case[kind]).read_text() != text:
                    raise ValueError('Original source file differs from manifest')
            try:
                hashes = corpus.audit_overlap(forms, admitted_prior, new_hashes)
                new_hashes.update(corpus.lexical_digest(qasm) for qasm in forms.values())
                case['nonoverlap_hashes'] = hashes
                cases.append(case)
            except RuntimeError as error:
                row.update(selection_status='excluded', exclusion_reason=str(error))
        ledger.append(row)
    shutil.copytree(args.first, args.output)
    # Write new admission evidence at a new path, preserving the copied first receipt.
    (args.output / 'manifest.json').rename(args.output / 'initial_manifest.json')
    manifest = {**first, 'cases': cases, 'candidate_ledger': ledger,
        'exclusions': [r for r in ledger if r['selection_status'] == 'excluded'],
        'provenance': {**first['provenance'], 'prior_qasm_inventory_sha256': corpus.digest(prior_path.read_bytes()),
            'prior_qasm_files_checked': len(admitted_prior),
            'prior_inventory_classification_counts': dict(Counter(r['classification'] for r in prior)),
            'nonoverlap_policy': 'Explicit input payloads and conservative unclassified QASM are compared. Explicit compiler outputs are separately identified and excluded from the prior-input comparison. Counts are records, not unique circuits. Lexical checks do not prove semantic independence.',
            'admission_audit': {'initial_manifest_sha256': corpus.digest(raw), 'source_sha256': corpus.digest(Path(__file__).read_bytes()),
                'changes': 'Inventory classification and fail-closed source hash audit only. Same selection, generated circuits and exact numerical normalization evidence; no compiler observations and no rerun of normalization.'}},
        'counts': {'selected': len(cases), 'excluded': len(ledger)-len(cases), 'candidates': len(ledger),
            'by_family': dict(Counter(r['family'] for r in cases)),
            'by_holdout_class': dict(Counter(r['holdout_class'] for r in cases))}}
    corpus.dump_new(args.output / 'manifest.json', manifest)
    print(json.dumps({'counts': manifest['counts'], 'inventory': manifest['provenance']['prior_inventory_classification_counts'],
        'inventory_v2_sha256': corpus.digest(prior_path.read_bytes()), 'manifest_sha256': corpus.digest((args.output / 'manifest.json').read_bytes())}))


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    for flag in ('working', 'selection', 'first', 'output'):
        parser.add_argument('--' + flag, type=Path, required=True)
    audit(parser.parse_args())
