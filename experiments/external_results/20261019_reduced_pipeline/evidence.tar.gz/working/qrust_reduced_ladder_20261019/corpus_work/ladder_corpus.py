#!/usr/bin/env python3
"""Prespecified pinned-generator holdout; never calls compiler optimization."""
from __future__ import annotations

import argparse
from collections import Counter
import hashlib
import json
import os
from pathlib import Path
import re
import sys

WIDTHS = (6, 10, 14)
SELECTION_SHA256 = 'a5caec1fc15c4ef2072a469140d84f6262174fc5856b74016d95501fda60dffb'
FAMILIES = ('bmw_quark_copula', 'bmw_quark_cardinality', 'qaoa', 'vqe_two_local', 'graphstate', 'qftentangled')
PARAMETERIZED = frozenset(FAMILIES[:4])
SKIP_DIRS = frozenset(('.git', 'target', '__pycache__', 'node_modules', '.venv', 'venv',
                       'qrust_comparison_env', 'package_audit', 'archive_replay'))


def digest(data):
    return hashlib.sha256(data.encode() if isinstance(data, str) else data).hexdigest()


def dump_new(path, value):
    with path.open('x') as out:
        json.dump(value, out, indent=2, sort_keys=True, allow_nan=False)
        out.write('\n')


def lexical_digest(qasm):
    """Catch repeated exact QASM modulo comments and whitespace; not semantic proof."""
    qasm = re.sub(r'//[^\n]*', '', qasm)
    return digest(re.sub(r'\s+', '', qasm))


def read_selection(directory=None):
    directory = directory or Path(__file__).parent / 'selection'
    raw = (directory / 'selection.json').read_bytes()
    if digest(raw) != SELECTION_SHA256 or (directory / 'selection.sha256').read_text().strip() != SELECTION_SHA256:
        raise ValueError('Prespecified selection checksum mismatch')
    return json.loads(raw)


def candidates():
    return read_selection()['candidates']


def target_edges(width, topology):
    if topology == 'all_to_all':
        return [[a, b] for a in range(width) for b in range(a + 1, width)]
    if topology == 'linear':
        return [[a, a + 1] for a in range(width - 1)]
    if topology != 'grid':
        raise ValueError('Unknown target')
    rows, columns = {6: (2, 3), 10: (2, 5), 14: (2, 7)}[width]
    edges = []
    for row in range(rows):
        for col in range(columns):
            q = row * columns + col
            if col + 1 < columns:
                edges.append([q, q + 1])
            if row + 1 < rows:
                edges.append([q, q + columns])
    return sorted(edges)


def embedded_inputs(value, pointer=''):
    """Only explicit input fields; output-QASM fields are never selected inputs."""
    if isinstance(value, dict):
        for key, item in value.items():
            escaped = str(key).replace('~', '~0').replace('/', '~1')
            child = pointer + '/' + escaped
            if key in ('qasm', 'source_qasm', 'input_qasm', 'normalized_qasm', 'raw_qasm') and isinstance(item, str) and 'OPENQASM' in item:
                yield child, item
            elif isinstance(item, (dict, list)):
                yield from embedded_inputs(item, child)
    elif isinstance(value, list):
        for index, item in enumerate(value):
            yield from embedded_inputs(item, pointer + '/' + str(index))


def prior_inventory(working, exclude):
    paths = []
    for directory, dirs, files in os.walk(working):
        dirs[:] = sorted(name for name in dirs if name not in SKIP_DIRS
                         and not (Path(directory) / name).resolve().is_relative_to(exclude.resolve()))
        for name in sorted(files):
            if not name.endswith(('.qasm', '.json', '.jsonl')):
                continue
            path = Path(directory) / name
            text = path.read_text()
            relative = str(path.relative_to(working))
            if name.endswith('.qasm'):
                paths.append({'path': relative, 'kind': 'qasm_file',
                              'sha256': digest(text), 'lexical_sha256': lexical_digest(text)})
            elif 'OPENQASM' in text:
                documents = [(str(index), json.loads(line)) for index, line in enumerate(text.splitlines(), 1) if line.strip()] if name.endswith('.jsonl') else [('', json.loads(text))]
                for line, document in documents:
                    for pointer, qasm in embedded_inputs(document):
                        paths.append({'path': relative, 'pointer': pointer, 'line': line or None,
                            'kind': 'jsonl_input_payload' if line else 'json_input_payload',
                            'container_sha256': digest(text), 'sha256': digest(qasm),
                            'lexical_sha256': lexical_digest(qasm)})
    return paths


def audit_overlap(forms, prior, new_hashes):
    old_hashes = {row['sha256'] for row in prior}
    old_lexical = {row['lexical_sha256'] for row in prior}
    for name, qasm in forms.items():
        if digest(qasm) in old_hashes or lexical_digest(qasm) in old_lexical:
            raise RuntimeError('fresh_input_matches_prior_recorded_QASM:' + name)
    if any(lexical_digest(qasm) in new_hashes for qasm in forms.values()):
        raise RuntimeError('duplicate_new_input')
    return {name: {'sha256': digest(qasm), 'lexical_sha256': lexical_digest(qasm)} for name, qasm in forms.items()}


def build(args):
    sys.path.insert(0, str(args.repo / 'experiments'))
    import external_corpus as original
    from bench_baselines import normalize_qasm
    from qiskit import qasm2, qpy
    import numpy as np
    selection = read_selection(args.selection)
    selection_bytes = (args.selection / 'selection.json').read_bytes()
    prior = prior_inventory(args.working, args.output.parent.parent)
    inventory_path = args.selection / 'prior_qasm_inventory.json'
    dump_new(inventory_path, prior)
    prior_sha = digest(inventory_path.read_bytes())
    integrity = original.verify_source_mirror(args.sources)
    sys.path.insert(0, str(args.sources / 'mqtbench/src'))
    from mqt.bench import get_benchmark_alg
    args.output.mkdir(parents=True, exist_ok=False)
    raw_dir = args.output / 'generated_raw'
    raw_dir.mkdir()
    ledger, cases, new_hashes = [], [], set()
    for candidate in selection['candidates']:
        row = dict(candidate)
        family, width, name = row['family'], row['width'], row['id']
        source_path = f'src/mqt/bench/benchmarks/{family}.py'
        row.update(community_source='MQT Bench', source_revision=original.MQTBENCH_REVISION,
            source_path=source_path, generator_source_sha256=digest((args.sources / 'mqtbench' / source_path).read_bytes()),
            source_url=f'https://github.com/munich-quantum-toolkit/bench/blob/{original.MQTBENCH_REVISION}/{source_path}',
            license='Pinned upstream MIT license and embedded QUARK/IBM Apache notices retained',
            directory_width=width, generator={'api': 'get_benchmark_alg', 'level': 'ALG',
                'random_parameters': False, 'parameter_binding_seed': row['parameter_binding_seed'],
                'options': row['generator_options'], 'no_transpile_or_mirror': True})
        try:
            circuit = get_benchmark_alg(family, width, random_parameters=False, generate_mirror_circuit=False, **row['generator_options'])
            if circuit.num_qubits != width:
                raise ValueError('actual_width_disagrees_with_declared_width')
            parameters = list(circuit.parameters)
            if bool(parameters) != (family in PARAMETERIZED):
                raise ValueError('Unexpected parameterization of frozen generator')
            rng = np.random.default_rng(row['parameter_binding_seed']) if parameters else None
            bound = {parameter: float(rng.uniform(0, 2 * np.pi)) for parameter in parameters}
            if bound:
                circuit = circuit.assign_parameters(bound)
            row['parameter_bindings'] = [{'parameter': str(p), 'value': bound[p]} for p in parameters]
            qpy_path = raw_dir / (name + '.qpy')
            with qpy_path.open('xb') as stream:
                qpy.dump(circuit, stream)
            raw_qasm = qasm2.dumps(circuit)
            (raw_dir / (name + '.qasm')).write_text(raw_qasm)
            row.update(raw_source_format='Qiskit QPY and raw QASM from original generated circuit',
                raw_artifact=str(qpy_path.relative_to(args.output)), raw_source_sha256=digest(qpy_path.read_bytes()),
                raw_qasm_sha256=digest(raw_qasm), raw_qasm_bytes=len(raw_qasm.encode()))
            if row['raw_qasm_bytes'] > selection['eligibility']['maximum_raw_export_bytes']:
                raise ValueError('raw_source_above_250000_bytes')
            prefix, removals = original.unitary_prefix(circuit)
            source, expansion = original.canonical_source(prefix, selection['eligibility']['maximum_expanded_source_gates'])
            normalized = normalize_qasm(source)
            forms = {'raw': raw_qasm, 'source': source, 'normalized': normalized}
            row['nonoverlap_hashes'] = audit_overlap(forms, prior, new_hashes)
            evidence = original.normalization_evidence(prefix, source, normalized)
            if evidence['passed'] is not True:
                raise RuntimeError('normalization_equivalence_failed')
            new_hashes.update(lexical_digest(qasm) for qasm in forms.values())
            (args.output / (name + '.source.qasm')).write_text(source)
            (args.output / (name + '.normalized.qasm')).write_text(normalized)
            row.update(fixture=name, n_logical=width, source_qasm=source, qasm=normalized,
                source_sha256=digest(source), normalized_sha256=digest(normalized),
                source_artifact=name + '.source.qasm', normalized_artifact=name + '.normalized.qasm',
                normalization_evidence=evidence, normalization={'removed': removals, **expansion,
                    'shared_gate_expansion': 'unchanged exact CRZ/RZZ expansion', 'optimization': 'none'},
                selection_status='selected', exclusion_reason=None)
            cases.append(row)
        except Exception as error:
            row.update(selection_status='excluded', exclusion_reason=f'{type(error).__name__}: {error}')
        ledger.append(row)
        print(json.dumps({'candidate': name, 'status': row['selection_status'], 'reason': row['exclusion_reason']}), flush=True)
    compact = [{key: value for key, value in row.items() if key not in ('qasm', 'source_qasm')} for row in ledger]
    manifest = {'schema': 1, 'cases': sorted(cases, key=lambda row: row['id']),
        'candidate_ledger': compact, 'exclusions': [r for r in compact if r['selection_status'] == 'excluded'],
        'selection_sha256': digest(selection_bytes), 'provenance': {'source_integrity': integrity,
            'generator_revision': original.MQTBENCH_REVISION, 'selection': selection,
            'normalizer_sha256': digest((args.repo / 'experiments/external_corpus.py').read_bytes()),
            'oracle_sha256': digest((args.repo / 'experiments/comparison_validation.py').read_bytes()),
            'prior_qasm_inventory_sha256': prior_sha,
            'lexical_nonoverlap_checked': True, 'prior_qasm_files_checked': len(prior), 'corpus_builder_sha256': digest(Path(__file__).read_bytes())},
        'counts': {'selected': len(cases), 'excluded': len(ledger) - len(cases), 'candidates': len(ledger),
            'by_family': dict(Counter(row['family'] for row in cases)),
            'by_holdout_class': dict(Counter(row['holdout_class'] for row in cases))}}
    dump_new(args.output / 'manifest.json', manifest)
    print(json.dumps(manifest['counts']))


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('command', choices=('build',))
    for flag in ('repo', 'sources', 'selection', 'output', 'working'):
        parser.add_argument('--' + flag, type=Path, required=True)
    args = parser.parse_args()
    build(args)


if __name__ == '__main__':
    main()
