#!/usr/bin/env python3
"""Frozen cumulative Q-Rust ladder with unchanged contextual SDK recipes."""
from __future__ import annotations

import argparse
from collections import Counter
import hashlib
import importlib.util
import json
from pathlib import Path
import random
import sys
from types import SimpleNamespace

import ladder_corpus as corpus

ARMS = tuple('R' + str(i) for i in range(7))
SDKS = ('qiskit', 'cirq', 'tket')
TOOLS = (*ARMS, *SDKS)
TRIALS, SESSIONS, TIMEOUT, MASTER_SEED = 5, 2, 60.0, 20261020
DEFAULT_LEGACY = Path(__file__).resolve().parents[2] / 'qrust_frozen_holdout_20261018/heldout'
LEGACY = None
EXPECTED_RECIPES = None


def sha(value):
    if isinstance(value, Path):
        value = value.read_bytes()
    return hashlib.sha256(value.encode() if isinstance(value, str) else value).hexdigest()


def dump_new(path, value):
    with path.open('x') as stream:
        json.dump(value, stream, indent=2, sort_keys=True, allow_nan=False)
        stream.write('\n')


def load_legacy(directory):
    global LEGACY
    if LEGACY is not None:
        if Path(LEGACY.__file__).parent.resolve() != directory.resolve():
            raise ValueError('Conflicting legacy helper root')
        return LEGACY
    sys.path.insert(0, str(directory))
    import heldout_study
    LEGACY = heldout_study
    LEGACY.TOOLS = TOOLS
    LEGACY.TRIALS, LEGACY.SESSIONS = TRIALS, SESSIONS
    LEGACY.WIDTHS = corpus.WIDTHS
    LEGACY.target_edges = corpus.target_edges
    LEGACY.configure, LEGACY.verify = configure, verify
    return LEGACY


def schedule(cases, trials, master_seed, session):
    """Each recipe occupies each of ten timed positions once per case over two sessions."""
    if trials != 5 or session not in (1, 2):
        raise ValueError('This balanced design requires two sessions of five trials')
    rng = random.Random(master_seed + 1_000_003 * session)
    ordered = list(cases)
    rng.shuffle(ordered)
    result = []
    for case_order, case in enumerate(ordered):
        seed = int.from_bytes(hashlib.sha256((str(master_seed) + '/' + case['id']).encode()).digest()[:8], 'big')
        recipes = list(TOOLS)
        random.Random(seed).shuffle(recipes)
        trial_order = list(range(trials))
        rng.shuffle(trial_order)
        warmup_order = list(recipes)
        rng.shuffle(warmup_order)
        for trial in [-1, *trial_order]:
            rotation = 5 * (session - 1) + trial if trial >= 0 else None
            ordered_tools = warmup_order if trial == -1 else recipes[rotation:] + recipes[:rotation]
            for tool_order, tool in enumerate(ordered_tools):
                result.append({'case_id': case['id'], 'tool': tool, 'trial': trial,
                    'seed': master_seed + max(trial, 0), 'case_order': case_order,
                    'tool_order': tool_order, 'rotation': rotation})
    return result


def plan():
    return {'schema': 'qrust_reduced_ladder_plan_v1', 'selection_sha256': corpus.SELECTION_SHA256,
        'source_preparation_protocol_v2_sha256': '12c6e8ec1c55cfeb8a90f9876cf83730b39523c808962787323cfba3a048f984',
        'candidate_fixtures': corpus.candidates(), 'widths': list(corpus.WIDTHS),
        'targets': {str(w): {t: corpus.target_edges(w, t) for t in ('all_to_all', 'linear', 'grid')} for w in corpus.WIDTHS},
        'tools': list(TOOLS), 'qrust_arms': list(ARMS), 'trials': TRIALS, 'sessions': SESSIONS,
        'master_seed': MASTER_SEED, 'warmups_per_cell_tool': 1,
        'timeout_seconds': TIMEOUT, 'startup_timeout_seconds': 120,
        'maximum_candidate_cases': 54, 'maximum_timed_slots': 5400, 'maximum_initial_warmup_slots': 1080,
        'timing': 'Unchanged warm in-process compile_ns; parse_ns separately, parse_compile_ns is the median of trial sums. Request-wall time is retained raw. Fresh persistent workers each session; sequential requests and no concurrent CPU-heavy work. No profiling during the primary campaign.',
        'schedule': 'Seeded per-case permutation of ten recipes; rotate by trial + 5*(session-1). Across both sessions each recipe occupies each timed position exactly once per case. Case order, trial block order and initial warmup order are independently seeded and shuffled. This balances position, not every possible predecessor effect.',
        'resource_policy': 'Unchanged bounded watcher: 60 seconds per request, 120 seconds startup, 2 GiB per worker and 3 GiB combined sampled RSS. Include idle workers and count distinct PIDs; sample about every 100 ms. Child memory is not included and this is not peak RSS. Preserve all errors, timeouts, warmups and replacement warmups; do not remove slow cases.',
        'normalization': 'Immutable selection before generation. Unchanged exact source normalization; versioned independent source-reference clarification expands wide SDK gate definitions with exact phase/wire preservation before unchanged normalization_evidence. Actual compiler inputs are unchanged; original attempt and controls are retained. No selected compiler sees inputs until protocol, environment, experimental clone and recipe contracts are frozen. No outcome-based tuning or replacement.',
        'validation': 'Unchanged independent analytic NumPy oracle after BOTH sessions. Full numerical isometry at six qubits, eight fixed inputs at ten/fourteen with one shared phase and residual tolerance 1e-7. Validate basis, edges and maps for every warmup and timed output. Cache only identical source/output/physical target/layout artifacts; retain every request. Sampled checks are evidence, not proof.',
        'qualification': 'Every five-trial cell requires all timed and initial/replacement warmup requests to compile and pass independent validation. Primary cumulative and adjacent comparisons use the identical all-seven-arm cohort qualified in BOTH sessions. Secondary adjacent-pair stable cohorts disclose their different coverage. SDK context uses R6/SDK stable pairs and the all-ten-recipe common cohort. Never select successful trials from an incomplete cell.',
        'analysis': {'per_session': True, 'cell_estimator': 'median of five prescribed trials',
            'metrics': ['compile_ns', 'parse_compile_ns', 'cx_count', 'gate_count', 'depth', 'two_q_depth'],
            'ratios': 'For candidate versus reference: timing reference/candidate; quality candidate/reference. All metrics also retain win/tie/loss counts.',
            'primary_cohort': 'Intersection of eligible case IDs for all R0..R6 arms in both sessions',
            'primary_comparisons': 'Every arm versus R0 and R6, and each adjacent addition on the primary cohort',
            'secondary_comparisons': 'Each adjacent pair on its own stable two-session cohort; R6 versus each SDK on stable two-session pairs; R6 versus SDKs on the common all-ten cohort',
            'aggregate': 'Equal-case geometric mean; secondary equal-represented-generator-family geometric mean. Report all six named family counts, including absent families.',
            'zero_policy': 'Exclude nonpositive ratios from logarithmic summaries with explicit zero counts; retain every pair for win/tie/loss. No pseudocount.',
            'bootstrap': '2000 fixture-cluster draws, seed 20261015, 95% percentile; keep all target graphs of each fixture together. Family-balanced intervals resample fixtures within represented families. These describe fixed-corpus sensitivity, not population sampling or a power guarantee. Do not pool sessions into ten exchangeable trials.',
            'strata': ['family', 'coarse_family', 'holdout_class', 'n_logical', 'topology'],
            'quality_retention': {'reference': 'R6', 'cohort': 'primary all-seven two-session cohort',
                'relative_overheads': [0, 0.05, 0.10], 'metrics': ['cx_count', 'depth', 'two_q_depth'],
                'rule': 'For every stage separately, count candidate <= reference*(1+overhead) per metric and jointly across all three. A zero reference requires zero candidate. Report denominators and zero-reference counts; speed is separate.'},
            'interpretation': 'Add-back effects are conditional on the fixed group order and pass placement. Do not add median differences or infer independent pass contributions. Compare specified recipes, not theoretical optima, all state of the art, language causality, or hardware execution fidelity. One parameter seed per family/width does not measure parameter variation.'}}


def configure(repo):
    sys.path.insert(0, str(repo / 'experiments'))
    import external_comparison as external
    from comparison_study import Worker
    external.TOOLS = TOOLS
    external.PACKAGES = (*external.PACKAGES, 'psutil') if 'psutil' not in external.PACKAGES else external.PACKAGES
    external.PROFILES = {'primary': list(TOOLS)}
    external.build_cases = LEGACY.build_cases
    external.schedule = schedule

    class RecipeWorker(Worker):
        def __init__(self, tool, binary, outdir):
            self.study_arm = tool if tool in ARMS else None
            directory = outdir / 'workers' / tool
            directory.mkdir(parents=True, exist_ok=True)
            try:
                super().__init__('qrust' if self.study_arm else tool, binary, directory)
            except Exception:
                self.close()
                raise

        def call(self, request, timeout):
            if self.study_arm:
                request = {**request, 'study_recipe': self.study_arm, 'profile_passes': False}
            result = super().call(request, timeout)
            if self.study_arm and result.get('status') == 'compiled':
                metadata = result.get('study_recipe_metadata')
                if not isinstance(metadata, dict) or metadata.get('recipe') != self.study_arm or (EXPECTED_RECIPES is not None and metadata != EXPECTED_RECIPES[self.study_arm]):
                    result = {**result, 'status': 'error', 'error': 'Missing or mismatched frozen study recipe metadata'}
            return result

        def close(self):
            super().close()
            if hasattr(self, 'log') and not self.log.closed:
                self.log.close()

    external.ProfileWorker = RecipeWorker
    return external


def sources():
    paths = sorted(Path(__file__).parent.glob('*.py'))
    paths += [Path(LEGACY.__file__), Path(LEGACY.__file__).parent / 'heldout_corpus.py']
    return {str(p.resolve()): sha(p) for p in paths}


def preparation_artifacts():
    here = Path(__file__).resolve().parent
    paths = sorted(p for p in (here / 'selection').iterdir() if p.is_file())
    paths += [here / 'preparation_protocol_v2.json', here / 'preparation_attempt_1/receipt.json',
              here.parent / 'method_review/reference_expansion_controls.json']
    return {str(p): {'bytes': p.stat().st_size, 'sha256': sha(p)} for p in paths}


def verify_clone(path, root, binary):
    clone = json.loads(path.read_text())
    files = clone['source_files']
    if not files or len({r['path'] for r in files}) != len(files):
        raise ValueError('Invalid clone source inventory')
    actual_files = {str(p.relative_to(root)) for p in root.rglob('*') if p.is_file() and p.relative_to(root).parts[0] != 'target'}
    if actual_files != {r['path'] for r in files}:
        raise ValueError('Experimental clone source inventory changed')
    for row in files:
        relative = Path(row['path'])
        if relative.is_absolute() or '..' in relative.parts:
            raise ValueError('Unsafe clone source path')
        target = root / relative
        if target.stat().st_size != row['bytes'] or sha(target) != row['sha256']:
            raise ValueError('Experimental clone source changed: ' + str(relative))
    entry = clone['binary']
    if binary.stat().st_size != entry['bytes'] or sha(binary) != entry['sha256']:
        raise ValueError('Experimental clone binary changed')
    if not isinstance(clone.get('parity_receipt'), dict):
        raise ValueError('Missing development parity receipt binding')
    old_study = Path(clone['source_root']).parent.parent
    new_study = root.parent.parent

    def check_nested(value):
        if isinstance(value, dict):
            if {'path', 'bytes', 'sha256'} <= value.keys():
                original = Path(value['path'])
                if original.is_absolute():
                    relative = original.relative_to(old_study)
                    target = new_study / relative
                else:
                    if '..' in original.parts:
                        raise ValueError('Unsafe nested clone evidence path')
                    target = root / original
                if target.stat().st_size != value['bytes'] or sha(target) != value['sha256']:
                    raise ValueError('Clone admission/build/test evidence changed: ' + str(target))
            else:
                for item in value.values():
                    check_nested(item)
        elif isinstance(value, list):
            for item in value:
                check_nested(item)
    check_nested(clone)
    if set(clone['recipes']) != set(ARMS):
        raise ValueError('Expected seven frozen recipe contracts')
    return clone


def verify_public_freeze(args):
    # Public reference binary is distinct from the experimental clone binary.
    copied = SimpleNamespace(**vars(args))
    freeze = json.loads(args.compiler_freeze.read_text())
    copied.binary = args.public_binary or Path(freeze['binary']['path'])
    LEGACY.verify_freeze(freeze, copied)
    return freeze


def prepare(args):
    external = configure(args.repo)
    if json.loads(args.plan.read_text()) != plan():
        raise ValueError('Frozen plan differs from implementation')
    freeze = verify_public_freeze(args)
    clone = verify_clone(args.clone_freeze, args.clone_root, args.binary)
    external.prepare(SimpleNamespace(corpus=args.corpus, output=args.study, binary=args.binary,
        compiler_commit=args.compiler_commit, trials=TRIALS, sessions=SESSIONS, timeout=TIMEOUT,
        seed=MASTER_SEED, machine_note='Single host, sequential requests; no concurrent CPU-heavy work, CPU affinity or frequency control.'))
    path = args.study / 'protocol.json'
    protocol = json.loads(path.read_text())
    sdk_recipes = {key: value for key, value in protocol['recipes'].items() if key in SDKS}
    protocol.update(study='Frozen cumulative reduced Q-Rust pipeline study',
        heldout_plan=plan(), heldout_plan_sha256=sha(args.plan),
        compiler_freeze=freeze, compiler_freeze_sha256=sha(args.compiler_freeze),
        experimental_clone=clone, experimental_clone_sha256=sha(args.clone_freeze),
        harness_source_sha256=sources(), selection_sha256=corpus.SELECTION_SHA256,
        preparation_artifacts=preparation_artifacts(), preparation_root=str(Path(__file__).resolve().parent.parent),
        recipes={**clone['recipes'], **sdk_recipes}, recipe_profiles={'primary': list(TOOLS)},
        profile_caveat='Seven cumulative Q-Rust recipe arms and three unchanged contextual SDK recipes. Unequal search effort; fixed group order. R6 matches full O3 only under the separately recorded development parity checks.',
        seed_policy='Five compiler trial seeds master_seed+trial, reused across sessions. Qiskit consumes the requested seed; other recipes may use internal randomness or time limits. Not consuming the requested seed does not establish determinism. Circuit generator/binding seed 53 is separate.',
        target='U3/CX; ideal bidirectional complete, line and 2x3/2x5/2x7 grid targets at 6/10/14 qubits; equal logical and physical width; free reported input/output maps.',
        validation=plan()['validation'], qualification=plan()['qualification'],
        analysis=plan()['analysis'], resource_policy=plan()['resource_policy'])
    external.dump(path, protocol)
    (args.study / 'protocol.sha256').write_text(sha(path) + '\n')
    print(json.dumps({'frozen_protocol_sha256': sha(path), 'cases': len(protocol['cases']),
        'timed_slots': len(protocol['cases']) * len(TOOLS) * TRIALS * SESSIONS}))


def verify(args):
    global EXPECTED_RECIPES
    external = configure(args.repo)
    protocol, checksum = external.load_protocol(args.study)
    expected, actual = protocol['harness_source_sha256'], sources()
    if args.allow_relocated:
        if args.command not in ('validate', 'analyze'):
            raise ValueError('Relocation is restricted to saved-output validation and analysis')
        # All bound helpers have distinct names; relocation changes paths, never bytes.
        if len({Path(p).name for p in expected}) != len(expected):
            raise ValueError('Ambiguous frozen helper names')
        expected, actual = ({Path(p).name: h for p, h in values.items()} for values in (expected, actual))
    if expected != actual or protocol['heldout_plan'] != plan():
        raise ValueError('Study source or plan changed')
    for key, path in [('heldout_plan_sha256', args.plan), ('compiler_freeze_sha256', args.compiler_freeze),
                      ('experimental_clone_sha256', args.clone_freeze)]:
        if protocol[key] != sha(path):
            raise ValueError('Frozen evidence changed: ' + key)
    for original, record in protocol['preparation_artifacts'].items():
        original = Path(original)
        path = Path(__file__).resolve().parent.parent / original.relative_to(protocol['preparation_root']) if args.allow_relocated else original
        if path.stat().st_size != record['bytes'] or sha(path) != record['sha256']:
            raise ValueError('Frozen source-preparation evidence changed')
    verify_public_freeze(args)
    clone = verify_clone(args.clone_freeze, args.clone_root, args.binary)
    EXPECTED_RECIPES = clone['recipes']
    if protocol['experimental_clone'] != clone:
        raise ValueError('Frozen clone payload mismatch')
    external.check_runtime(protocol, args.binary)
    return external, protocol, checksum


def cell_index(cells, expected_cases=None, expected_tools=None):
    index = {}
    for cell in cells:
        key = cell['case_id'], cell['tool']
        if key in index:
            raise ValueError('Duplicate cell identity')
        if type(cell.get('eligible')) is not bool:
            raise ValueError('Cell eligibility must be a JSON boolean')
        if cell['eligible'] and not isinstance(cell.get('medians'), dict):
            raise ValueError('Eligible cell has no medians')
        index[key] = cell
    if expected_cases is not None and expected_tools is not None:
        expected = {(case, tool) for case in expected_cases for tool in expected_tools}
        if set(index) != expected:
            raise ValueError('Missing or unexpected cells in analysis universe')
    return index


def stable_cohort(all_cells, tools):
    """One identical case set, requiring every listed recipe in every session."""
    if not all_cells:
        raise ValueError('No analysis sessions')
    indexes = [cell_index(cells) for cells in all_cells]
    if any(set(index) != set(indexes[0]) for index in indexes[1:]):
        raise ValueError('Session cell universes differ')
    cases = {case for case, _ in indexes[0]}
    if any((case, tool) not in index for index in indexes for case in cases for tool in tools):
        raise ValueError('Missing requested recipe cells')
    return {case for case in cases if all(index[case, tool]['eligible'] is True for index in indexes for tool in tools)}


def pair_summary(cells, candidate, reference, cohort, base, label, draws=2000):
    index = cell_index(cells)
    if any((case, tool) not in index or index[case, tool]['eligible'] is not True
           for case in cohort for tool in (candidate, reference)):
        raise ValueError('Prescribed pair cohort is incomplete or ineligible')
    pairs = [(index[case, candidate], index[case, reference]) for case in sorted(cohort)]
    result = {'candidate': candidate, 'reference': reference, 'paired_cells': len(pairs),
        'fixtures': len({a['fixture'] for a, _ in pairs}), 'case_ids': [a['case_id'] for a, _ in pairs],
        'family_case_counts': {family: sum(a['family'] == family for a, _ in pairs) for family in corpus.FAMILIES}}
    for metric in ('compile_ns', 'parse_compile_ns', *base.METRICS):
        speed = metric.endswith('_ns')
        observations = [{'fixture': a['fixture'], 'family': a['family'],
            'numerator': (b if speed else a)['medians'][metric],
            'denominator': (a if speed else b)['medians'][metric]} for a, b in pairs]
        stat = base.geometric_ratio_summary(observations, label=label + '/' + metric, draws=draws)
        stat['family_balanced'] = base.family_balanced_ratio_summary(observations, label=label + '/' + metric, draws=draws)
        stat['candidate_win_tie_loss'] = base._wins(pairs, metric)
        stat['ratio_definition'] = 'reference / candidate; >1 faster' if speed else 'candidate / reference; <1 fewer or shallower'
        tails = sorted([{'case_id': a['case_id'], 'candidate': a['medians'][metric], 'reference': b['medians'][metric],
                          'candidate_over_reference': a['medians'][metric] / b['medians'][metric] if b['medians'][metric] else None}
                         for a, b in pairs], key=lambda v: (v['candidate_over_reference'] is None and v['candidate'] > 0, v['candidate_over_reference'] or 0), reverse=True)
        stat['worst_candidate_over_reference'] = tails[:10]
        result[metric] = stat
    return result


def retention(cells, cohort):
    index = cell_index(cells)
    if any((case, arm) not in index or index[case, arm]['eligible'] is not True for case in cohort for arm in ARMS):
        raise ValueError('Prescribed retention cohort is incomplete or ineligible')
    result = {}
    for arm in ARMS:
        per_threshold = {}
        for fraction in (0, .05, .10):
            metrics = ('cx_count', 'depth', 'two_q_depth')
            counts, zero = Counter(), Counter()
            for case in sorted(cohort):
                a, b = index[case, arm]['medians'], index[case, 'R6']['medians']
                passed = {m: a[m] == 0 if b[m] == 0 else a[m] <= b[m] * (1 + fraction) for m in metrics}
                counts.update(m for m in metrics if passed[m])
                zero.update(m for m in metrics if b[m] == 0)
                counts['joint_all_three'] += all(passed.values())
            per_threshold[str(fraction)] = {'denominator': len(cohort),
                'counts': {m: counts[m] for m in (*metrics, 'joint_all_three')},
                'fractions': {m: counts[m] / len(cohort) if cohort else None for m in (*metrics, 'joint_all_three')},
                'zero_reference_counts': {m: zero[m] for m in metrics}}
        result[arm] = per_threshold
    return result


def analysis_summaries(all_cells, base, draws=2000, expected_cases=None):
    if len(all_cells) != SESSIONS:
        raise ValueError('Exactly two analysis sessions are required')
    if expected_cases is None:
        expected_cases = {c['case_id'] for c in all_cells[0]}
    for cells in all_cells:
        cell_index(cells, expected_cases, TOOLS)
    primary = stable_cohort(all_cells, ARMS)
    all_tools = stable_cohort(all_cells, TOOLS)
    adjacent = {(ARMS[i], ARMS[i-1]): stable_cohort(all_cells, (ARMS[i], ARMS[i-1])) for i in range(1, 7)}
    sdk_pairs = {sdk: stable_cohort(all_cells, ('R6', sdk)) for sdk in SDKS}
    sessions = []
    for session, cells in enumerate(all_cells, 1):
        def pair(a, b, cohort, label):
            return pair_summary(cells, a, b, cohort, base, f'session{session}/{label}/{a}/{b}', draws)
        comparisons = {'versus_R0': {arm: pair(arm, 'R0', primary, 'primary') for arm in ARMS},
            'versus_R6': {arm: pair(arm, 'R6', primary, 'primary') for arm in ARMS},
            'adjacent': {a + '_vs_' + b: pair(a, b, primary, 'primary-adjacent') for a, b in adjacent}}
        strata = {}
        for field in ('family', 'coarse_family', 'holdout_class', 'n_logical', 'topology'):
            strata[field] = {}
            for value in sorted({str(c[field]) for c in cells}):
                subset = primary & {c['case_id'] for c in cells if str(c[field]) == value}
                strata[field][value] = {arm: pair(arm, 'R6', subset, f'primary/{field}/{value}') for arm in ARMS}
        sessions.append({'session': session,
            'coverage': {tool: sum(c['tool'] == tool and c['eligible'] for c in cells) for tool in TOOLS},
            'excluded_cells': [c for c in cells if not c['eligible']],
            'primary': comparisons, 'primary_strata_versus_R6': strata,
            'quality_retention_vs_R6': retention(cells, primary),
            'secondary_adjacent_stable': {a + '_vs_' + b: pair(a, b, cohort, 'secondary-adjacent') for (a,b), cohort in adjacent.items()},
            'sdk_stable_pairs': {sdk: pair('R6', sdk, cohort, 'sdk-pair') for sdk, cohort in sdk_pairs.items()},
            'sdk_all_tool_common': {sdk: pair('R6', sdk, all_tools, 'sdk-all-common') for sdk in SDKS}})
    return {'primary_all_seven_case_ids': sorted(primary), 'all_ten_case_ids': sorted(all_tools),
        'adjacent_stable_case_ids': {a + '_vs_' + b: sorted(c) for (a,b), c in adjacent.items()},
        'sdk_stable_case_ids': {sdk: sorted(c) for sdk, c in sdk_pairs.items()}, 'sessions': sessions}


def analyze(args):
    external, protocol, checksum = verify(args)
    import analyze_comparison_study as base
    from paired_analysis import classify_evidence
    base.TOOLS = TOOLS
    validation = json.loads((args.study / 'validation_summary.json').read_text())
    warm_receipt = json.loads((args.study / 'warmup_validation_summary.json').read_text())
    if any(r['protocol_sha256'] != checksum for r in (validation, warm_receipt)):
        raise ValueError('Unbound validation receipt')
    all_cells, outcomes = [], []
    for session in range(1, SESSIONS + 1):
        directory = args.study / f'session_{session:02d}'
        info = json.loads((directory / 'session.json').read_text())
        if info['completed'] is not True or info['protocol_sha256'] != checksum:
            raise ValueError('Incomplete session')
        for kind in ('timed', 'warmup'):
            if sha(directory / f'{kind}.jsonl') != info[kind + '_sha256']:
                raise ValueError('Changed raw session file')
        if sha(directory / 'validated.jsonl') != validation['sessions'][session - 1]['validated_sha256']:
            raise ValueError('Changed validation file')
        if sha(directory / 'warmup_validated.jsonl') != warm_receipt['sessions'][session - 1]['warmup_validated_sha256']:
            raise ValueError('Changed warmup validation file')
        timed, checked, warmed = (external.read_rows(directory / name) for name in ('timed.jsonl', 'validated.jsonl', 'warmup_validated.jsonl'))
        external.check_rows(protocol, session, timed)
        LEGACY.check_warmups(protocol, session, warmed, external)
        cells = LEGACY.qualify_cells(protocol, timed, checked, warmed, base)
        all_cells.append(cells)
        outcomes.append(dict(Counter(row['tool'] + '/' + (classify_evidence(row['validation'], 'external') if row['status'] == 'compiled' else row['status']) for row in checked)))
        dump_new(directory / 'cells.json', cells)
        base.write_csv(directory / 'cells.csv', cells)
    summaries = analysis_summaries(all_cells, base, expected_cases={c['id'] for c in protocol['cases']})
    for session, counts in zip(summaries['sessions'], outcomes):
        session['timed_outcomes'] = counts
    dump_new(args.study / 'analysis.json', {'schema': 'qrust_reduced_ladder_analysis_v1',
        'protocol_sha256': checksum, 'method': protocol['analysis'], **summaries,
        'source_exclusions': protocol['corpus_exclusions']})


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('command', choices=('plan', 'prepare', 'time', 'validate', 'analyze'))
    for flag in ('repo', 'study', 'binary', 'plan', 'compiler-freeze', 'clone-freeze', 'clone-root', 'public-binary', 'corpus', 'generator-root'):
        parser.add_argument('--' + flag, type=Path)
    parser.add_argument('--legacy-helper', type=Path, default=DEFAULT_LEGACY)
    parser.add_argument('--compiler-commit')
    parser.add_argument('--session', type=int)
    parser.add_argument('--allow-relocated', action='store_true')
    args = parser.parse_args()
    load_legacy(args.legacy_helper)
    if args.command == 'plan':
        dump_new(args.plan, plan())
    else:
        {'prepare': prepare, 'time': LEGACY.time_session, 'validate': LEGACY.validate, 'analyze': analyze}[args.command](args)


if __name__ == '__main__':
    main()
