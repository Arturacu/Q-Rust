#!/usr/bin/env python3
"""Preserve raw generation; bound independently expanded source-reference checks."""
from __future__ import annotations
import argparse
from collections import Counter
import json
import os
from pathlib import Path
import select
import shutil
import subprocess
import sys
import time

import ladder_corpus as corpus
import ladder_inventory

PREPARATION_SHA256 = '12c6e8ec1c55cfeb8a90f9876cf83730b39523c808962787323cfba3a048f984'


def reference_check(request, path, repo):
    import psutil
    sys.path.insert(0, str(repo / 'experiments'))
    from comparison_study import THREAD_ENV
    corpus.dump_new(path, request)
    stderr_path = path.with_suffix('.stderr.txt')
    start, peak = time.monotonic(), 0
    with stderr_path.open('x') as errors:
        process = subprocess.Popen([sys.executable, str(Path(__file__).parent / 'reference_expansion.py'), str(path)],
            stdout=subprocess.PIPE, stderr=errors, text=True, env=dict(os.environ, **THREAD_ENV))
        try:
            while True:
                elapsed = time.monotonic() - start
                if elapsed > 120:
                    raise TimeoutError('Source normalization exceeded frozen 120-second reference limit')
                try:
                    peak = max(peak, psutil.Process(process.pid).memory_info().rss)
                except psutil.NoSuchProcess:
                    pass
                if peak > 2 * 1024 ** 3:
                    raise MemoryError('Source normalization exceeded sampled 2-GiB reference limit')
                if select.select([process.stdout], [], [], .1)[0]:
                    line = process.stdout.readline()
                    if not line:
                        raise RuntimeError('Source reference worker exited without a result; see preserved stderr')
                    result = json.loads(line)
                    process.wait(timeout=5)
                    if process.returncode:
                        raise RuntimeError('Source reference worker returned nonzero')
                    result['source_reference_resources'] = {'elapsed_seconds': time.monotonic()-start,
                        'sampled_rss_bytes': peak, 'timeout_seconds':120, 'rss_limit_bytes':2*1024**3,
                        'rss_scope': 'Child process only; sampled, not exact peak'}
                    return result
        finally:
            if process.poll() is None:
                process.terminate()
                try:
                    process.wait(timeout=3)
                except subprocess.TimeoutExpired:
                    process.kill()
                    process.wait()


def build(args):
    selection = corpus.read_selection(args.selection)
    if corpus.digest(args.preparation_protocol.read_bytes()) != PREPARATION_SHA256:
        raise ValueError('Preparation clarification changed')
    controls = json.loads(args.controls.read_text())
    if controls.get('passed') is not True or controls.get('reference_expansion_sha256') != corpus.digest((Path(__file__).parent / 'reference_expansion.py').read_bytes()):
        raise ValueError('Source-reference controls missing, failed or stale')
    sys.path.insert(0, str(args.repo / 'experiments'))
    import external_corpus as original
    from bench_baselines import normalize_qasm
    from qiskit import qpy
    import numpy as np
    integrity = original.verify_source_mirror(args.sources)
    sys.path.insert(0, str(args.sources / 'mqtbench/src'))
    from mqt.bench import get_benchmark_alg
    preparation = json.loads(args.preparation_protocol.read_text())
    initial_receipt = Path(__file__).parent / 'preparation_attempt_1/receipt.json'
    if corpus.digest(initial_receipt.read_bytes()) != preparation['attempt_1_receipt_sha256']:
        raise ValueError('Initial preparation receipt changed')
    for entry in json.loads(initial_receipt.read_text())['files']:
        path = Path(__file__).parent / entry['path']
        if path.stat().st_size != entry['bytes'] or corpus.digest(path.read_bytes()) != entry['sha256']:
            raise ValueError('Preserved initial preparation artifact changed')
    prior = ladder_inventory.inventory(args.working, args.output.parent.parent)
    prior_path = args.selection / 'prior_qasm_inventory_v2.json'
    corpus.dump_new(prior_path, prior)
    compared_prior = [r for r in prior if r['classification'] != 'explicit_output']
    args.output.mkdir(parents=True, exist_ok=False)
    raw_dir, receipt_dir = args.output / 'generated_raw', args.output / 'candidate_receipts'
    raw_dir.mkdir()
    receipt_dir.mkdir()
    request_dir = args.output / 'source_reference_requests'
    request_dir.mkdir()
    ledger, cases, new_hashes = [], [], set()
    for candidate in selection['candidates']:
        row = dict(candidate)
        family, width, name = row['family'], row['width'], row['id']
        source_path = f'src/mqt/bench/benchmarks/{family}.py'
        row.update(community_source='MQT Bench', source_revision=original.MQTBENCH_REVISION,
            source_path=source_path, generator_source_sha256=corpus.digest((args.sources / 'mqtbench' / source_path).read_bytes()),
            source_url=f'https://github.com/munich-quantum-toolkit/bench/blob/{original.MQTBENCH_REVISION}/{source_path}',
            license='Pinned upstream MIT license and embedded QUARK/IBM Apache notices retained',
            directory_width=width, generator={'api':'get_benchmark_alg', 'level':'ALG', 'random_parameters':False,
                'parameter_binding_seed':row['parameter_binding_seed'], 'options':row['generator_options'], 'no_transpile_or_mirror':True})
        try:
            # Original persisted QPY is the source. Reconstruct parameter names/bindings only.
            template = get_benchmark_alg(family, width, random_parameters=False, generate_mirror_circuit=False, **row['generator_options'])
            parameters = list(template.parameters)
            if bool(parameters) != (family in corpus.PARAMETERIZED):
                raise ValueError('Unexpected frozen generator parameterization')
            rng = np.random.default_rng(row['parameter_binding_seed']) if parameters else None
            bindings = {p:float(rng.uniform(0,2*np.pi)) for p in parameters}
            row['parameter_bindings'] = [{'parameter':str(p),'value':bindings[p]} for p in parameters]
            for suffix in ('.qpy','.qasm'):
                shutil.copy2(args.first / 'generated_raw' / (name+suffix), raw_dir / (name+suffix))
            qpy_path = raw_dir / (name+'.qpy')
            with qpy_path.open('rb') as stream:
                circuit = qpy.load(stream)[0]
            if circuit.num_qubits != width:
                raise ValueError('Original QPY width differs from declared width')
            raw_qasm = (raw_dir / (name+'.qasm')).read_text()
            row.update(raw_source_format='Original attempt-1 Qiskit QPY and raw QASM, unchanged bytes',
                raw_artifact=str(qpy_path.relative_to(args.output)),raw_source_sha256=corpus.digest(qpy_path.read_bytes()),
                raw_qasm_sha256=corpus.digest(raw_qasm),raw_qasm_bytes=len(raw_qasm.encode()))
            if row['raw_qasm_bytes'] > selection['eligibility']['maximum_raw_export_bytes']:
                raise ValueError('Raw source exceeds fixed byte limit')
            prefix,removals = original.unitary_prefix(circuit)
            source,expansion = original.canonical_source(prefix,selection['eligibility']['maximum_expanded_source_gates'])
            normalized = normalize_qasm(source)
            reconstructed = template.assign_parameters(bindings) if bindings else template
            reconstructed_prefix, _ = original.unitary_prefix(reconstructed)
            reconstructed_source, _ = original.canonical_source(reconstructed_prefix, selection['eligibility']['maximum_expanded_source_gates'])
            if reconstructed_source != source:
                raise ValueError('Reconstructed generator bindings differ from preserved original source')
            for suffix,text in (('.source.qasm',source),('.normalized.qasm',normalized)):
                previous = args.first / (name+suffix)
                if previous.exists() and previous.read_bytes() != text.encode():
                    raise ValueError('Reused compiler input differs from attempt 1: '+suffix)
                (args.output / (name+suffix)).write_text(text)
            forms = {'raw':raw_qasm,'source':source,'normalized':normalized}
            row['nonoverlap_hashes'] = corpus.audit_overlap(forms,compared_prior,new_hashes)
            row.update(source_reference_request_artifact='source_reference_requests/'+name+'.json',
                source_reference_stderr_artifact='source_reference_requests/'+name+'.stderr.txt')
            checked = reference_check({'repo':str(args.repo.resolve()),'raw_qpy':str(qpy_path.resolve()),
                'source_qasm':source,'qasm':normalized},request_dir/(name+'.json'),args.repo)
            row.update(checked)
            if checked['normalization_evidence']['passed'] is not True:
                raise ValueError('Independent normalization equivalence failed')
            new_hashes.update(corpus.lexical_digest(q) for q in forms.values())
            row.update(fixture=name,n_logical=width,source_qasm=source,qasm=normalized,
                source_sha256=corpus.digest(source),normalized_sha256=corpus.digest(normalized),
                source_artifact=name+'.source.qasm',normalized_artifact=name+'.normalized.qasm',
                normalization={'removed':removals,**expansion,'shared_gate_expansion':'Unchanged exact CRZ/RZZ expansion','optimization':'none'},
                selection_status='selected',exclusion_reason=None)
            cases.append(row)
        except Exception as error:
            row.update(selection_status='excluded',exclusion_reason=f'{type(error).__name__}: {error}')
        ledger.append(row)
        corpus.dump_new(receipt_dir/(name+'.json'),row)
        print(json.dumps({'candidate':name,'status':row['selection_status'],'reason':row['exclusion_reason']}),flush=True)
    compact=[{k:v for k,v in r.items() if k not in ('qasm','source_qasm')} for r in ledger]
    manifest={'schema':2,'cases':sorted(cases,key=lambda r:r['id']),'candidate_ledger':compact,
        'exclusions':[r for r in compact if r['selection_status']=='excluded'],'selection_sha256':corpus.SELECTION_SHA256,
        'provenance':{'source_integrity':integrity,'generator_revision':original.MQTBENCH_REVISION,'selection':selection,
            'normalizer_sha256':corpus.digest((args.repo/'experiments/external_corpus.py').read_bytes()),
            'oracle_sha256':corpus.digest((args.repo/'experiments/comparison_validation.py').read_bytes()),
            'prior_qasm_inventory_sha256':corpus.digest(prior_path.read_bytes()),
            'prior_inventory_classification_counts':dict(Counter(r['classification'] for r in prior)),
            'prior_records_compared':len(compared_prior),'lexical_nonoverlap_checked':True,
            'nonoverlap_policy':'Compare explicit inputs and conservative unclassified QASM; explicit output artifacts separately classified and not treated as prior selected inputs. Records include duplicates and are not a circuit count. Lexical comparison is not semantic independence.',
            'preparation_protocol_v2_sha256':PREPARATION_SHA256,
            'reference_controls_sha256':corpus.digest(args.controls.read_bytes()),
            'reference_expansion_sha256':corpus.digest((Path(__file__).parent/'reference_expansion.py').read_bytes()),
            'preparation_source_sha256':corpus.digest(Path(__file__).read_bytes()),
            'initial_attempt_receipt_sha256':corpus.digest((Path(__file__).parent/'preparation_attempt_1/receipt.json').read_bytes()),
            'source_reference_clarification':'Original QPY preserved. Exact recursive SDK definitions independently expand wide reference gates before unchanged numerical normalization evidence. Actual canonical/normalized inputs unchanged; previously saved pairs cross-checked byte-for-byte. No selected compiler observations.'},
        'counts':{'selected':len(cases),'excluded':len(ledger)-len(cases),'candidates':len(ledger),
            'by_family':dict(Counter(r['family'] for r in cases)),'by_holdout_class':dict(Counter(r['holdout_class'] for r in cases))}}
    corpus.dump_new(args.output/'manifest.json',manifest)
    print(json.dumps(manifest['counts']),flush=True)


if __name__ == '__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    for flag in ('repo','sources','selection','first','output','working','preparation-protocol','controls'):
        parser.add_argument('--'+flag,type=Path,required=True)
    build(parser.parse_args())
