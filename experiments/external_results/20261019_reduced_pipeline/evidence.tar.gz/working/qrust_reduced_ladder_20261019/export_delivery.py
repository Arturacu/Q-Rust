#!/usr/bin/env python3
"""Copy readable exports without changing the underlying study evidence."""
import argparse
import hashlib
import json
from pathlib import Path
import shutil

root = Path(__file__).absolute().parent
p = argparse.ArgumentParser(description=__doc__)
p.add_argument('--destination', type=Path, required=True)
args = p.parse_args()
args.destination.mkdir(parents=True, exist_ok=False)
mapping = {
    'reporting/delivery_readme.md': 'README.md',
    'corpus_work/campaign/analysis.json': 'ladder_analysis.json',
    'corpus_work/campaign/protocol.json': 'protocol.json',
    'corpus_work/campaign/validation_summary.json': 'validation_summary.json',
    'corpus_work/campaign/warmup_validation_summary.json': 'warmup_validation_summary.json',
    'compiler_freeze.json': 'compiler_freeze.json',
    'compiler_work/clone_freeze.json': 'clone_freeze.json',
    'original_preservation.json': 'original_preservation.json',
    'reporting/stage_interpretation.json': 'stage_interpretation.json',
    'reporting/variability.json': 'variability.json',
    'reporting/failure_ledger.json': 'failure_ledger.json',
    'reporting/tables/comparisons.csv': 'comparisons.csv',
    'reporting/tables/quality_retention.csv': 'quality_retention.csv',
    'reporting/tables/outcomes.json': 'outcomes.json',
}
for session in (1, 2):
    mapping[f'corpus_work/campaign/session_{session:02d}/cells.csv'] = f'session_{session:02d}_cells.csv'
for name in ('ladder_tradeoffs.png', 'ladder_tradeoffs.svg', 'ladder_tradeoffs_data.json'):
    mapping['reporting/exports/' + name] = name
for name in ('timing_completion.json', 'post_timing_freeze_checks.json',
             'postflight/final_receipt.json', 'postflight/validate_receipt.json',
             'postflight/analyze_receipt.json', 'postflight/variability_receipt.json',
             'corpus_work/preparation_final_receipt.json',
             'compiler_work/development_admission_receipt.json',
             'compiler_work/development_outcome_correction.json',
             'method_review/postflight_raw_01.json', 'method_review/postflight_analysis_01.json',
             'method_review/postflight_analysis_02.json', 'method_review/postflight_audit_controls_01.json',
             'method_review/final_report_audit_01.json', 'method_review/protocol_audit_01.json',
             'method_review/source_audit_final.json', 'method_review/method_tests_02.json',
             'method_review/reference_expansion_controls.json',
             'reporting/formal_plot_qa_receipt.json', 'reporting/plot_preflight_receipt.json',
             'reporting/tables/export_receipt.json', 'reporting/report_render_receipt_v2.json',
             'reporting/exports/render_receipt.json',
             'delivery_tests/receipt.json', 'delivery_tests/archive.log', 'delivery_tests/variability.log'):
    mapping[name] = 'audit/' + name.replace('/', '__')
records = []
for original, relative in mapping.items():
    source, target = root / original, args.destination / relative
    target.parent.mkdir(parents=True, exist_ok=True)
    with source.open('rb') as incoming, target.open('xb') as outgoing:
        shutil.copyfileobj(incoming, outgoing)
    digest = hashlib.sha256(source.read_bytes()).hexdigest()
    assert hashlib.sha256(target.read_bytes()).hexdigest() == digest
    records.append({'source': original, 'destination': relative, 'bytes': source.stat().st_size,
                    'sha256': digest})
with (root / 'reporting/delivery_exports_manifest.json').open('x') as stream:
    json.dump({'schema': 1, 'exports': records}, stream, indent=2, sort_keys=True)
    stream.write('\n')
print(json.dumps({'exported_files': len(records), 'destination': str(args.destination)}))
