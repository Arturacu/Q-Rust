#!/usr/bin/env python3
"""Run predefined development parity/checks only, before held-out compiler freeze."""
import argparse
from collections import Counter
import copy
import hashlib
import json
import os
from pathlib import Path
import select
import subprocess
import sys

HERE = Path(__file__).absolute().parent
WORK = HERE.parent.parent
REPO = WORK / 'qrust_pr_publish'
ORIGINAL = WORK / 'qrust_compile_overhead_20261018/comparison_runner_final'
EXPERIMENT = HERE / 'comparison_runner_ladder'
sys.path.insert(0, str(REPO / 'experiments'))
from comparison_study import THREAD_ENV
os.environ.update(THREAD_ENV)
from comparison_validation import validate_output

def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def save(path, value):
    with path.open('x') as f: json.dump(value, f, sort_keys=True, indent=2, allow_nan=False); f.write('\n')

def nonclock(result):
    result = copy.deepcopy(result)
    for field in ('compile_ns', 'parse_ns', 'study_recipe_metadata'): result.pop(field, None)
    for event in result.get('pass_diagnostics', []): event.pop('elapsed_ns', None)
    return result

class Worker:
    def __init__(self, binary, log):
        self.log = log.open('x')
        self.p = subprocess.Popen([str(binary)], stdin=subprocess.PIPE, stdout=subprocess.PIPE,
            stderr=self.log, text=True, bufsize=1, env=dict(os.environ, **THREAD_ENV))
        assert self.receive().get('ready')
    def receive(self):
        if not select.select([self.p.stdout], [], [], 60)[0]: raise TimeoutError('development request cap')
        text = self.p.stdout.readline()
        if not text: raise RuntimeError('worker closed unexpectedly')
        return json.loads(text)
    def call(self, request):
        self.p.stdin.write(json.dumps(request) + '\n'); self.p.stdin.flush()
        return self.receive()
    def close(self):
        self.p.terminate()
        try: self.p.wait(timeout=3)
        except subprocess.TimeoutExpired: self.p.kill(); self.p.wait()
        self.log.close()

def run(output, protocol_path):
    output.mkdir(exist_ok=False)
    protocol = json.loads(protocol_path.read_text())
    assert sha(ORIGINAL) == protocol['frozen_binary_sha256']
    bindings = {'protocol_sha256':sha(protocol_path), 'protocol_path':str(protocol_path),
        'script_sha256':sha(Path(__file__)), 'original_binary_sha256':sha(ORIGINAL),
        'experimental_binary_sha256':sha(EXPERIMENT),
        'oracle_sha256':sha(REPO/'experiments/comparison_validation.py')}
    save(output/'bindings.json', bindings)
    original, experiment = Worker(ORIGINAL, output/'original.log'), Worker(EXPERIMENT, output/'experiment.log')
    rows=[]
    try:
        with (output/'raw.jsonl').open('x') as f:
            for case in protocol['cases']:
                request={k:case[k] for k in ('qasm','n_logical','physical_width','edges','topology')}
                request['seed']=20261019
                for profile in protocol['parity_profiles']:
                    request['profile_passes']=profile
                    for label, worker, extra in [('original',original,{}),('copy_default',experiment,{}),('R6',experiment,{'study_recipe':'R6'})]:
                        row={'case_id':case['id'],'arm':label,'profile':profile,'request':dict(request,**extra),
                             'result':worker.call(dict(request,**extra))}
                        rows.append(row);f.write(json.dumps(row,sort_keys=True)+'\n');f.flush()
                for recipe in protocol['recipes'][:-1]:
                    request['profile_passes']=True
                    row={'case_id':case['id'],'arm':recipe,'profile':True,'request':dict(request,study_recipe=recipe),
                         'result':experiment.call(dict(request,study_recipe=recipe))}
                    rows.append(row);f.write(json.dumps(row,sort_keys=True)+'\n');f.flush()
                print(json.dumps({'compiled_case':case['id'],'recorded':len(rows)}),flush=True)
    finally:
        original.close();experiment.close()
    # All compilation workers are closed before independent checks.
    errors=[];parity=[];counts=Counter();cache={};validated=[];metadata={}
    by_case={c['id']:c for c in protocol['cases']}
    for case in protocol['cases']:
        for profile in protocol['parity_profiles']:
            group={r['arm']:r for r in rows if r['case_id']==case['id'] and r['profile']==profile}
            baseline=nonclock(group['original']['result'])
            for arm in ('copy_default','R6'):
                passed=baseline==nonclock(group[arm]['result']) and baseline.get('status')=='compiled'
                parity.append({'case_id':case['id'],'profile':profile,'arm':arm,'passed':passed})
                if not passed:errors.append(f'parity {case["id"]} {profile} {arm}')
    for row in rows:
        result=row['result'];case=by_case[row['case_id']]
        if result.get('status')!='compiled':
            errors.append(f'not compiled {row["case_id"]} {row["arm"]}');continue
        key=json.dumps([case['qasm_sha256'],result['out_qasm'],result['initial_layout'],result['final_layout'],case['edges']],sort_keys=True)
        if key not in cache:
            edges=[edge for a,b in case['edges'] for edge in ((a,b),(b,a))]
            cache[key]=validate_output(case['qasm'],result['out_qasm'],case['n_logical'],case['physical_width'],edges,
                result['initial_layout'],result['final_layout'])
        checked=cache[key]
        if checked.get('passed') is not True or checked.get('evidence_class')!='full_isometry':
            errors.append(f'validation {row["case_id"]} {row["arm"]} {checked}')
        counts[str(checked.get('passed'))]+=1
        validated.append({'case_id':row['case_id'],'arm':row['arm'],'profile':row['profile'],'validation':checked})
        if row['arm'].startswith('R'):
            observed=result['study_recipe_metadata']
            if row['arm'] in metadata:assert metadata[row['arm']]==observed
            metadata[row['arm']]=observed
    save(output/'validation.json',validated)
    save(output/'recipe_metadata.json',metadata)
    save(output/'receipt.json',dict(bindings,raw_sha256=sha(output/'raw.jsonl'),
        validation_sha256=sha(output/'validation.json'),metadata_sha256=sha(output/'recipe_metadata.json'),
        completed=True,passed=not errors,errors=errors,parity=parity,
        validation_counts=dict(counts),unique_checked_artifacts=len(cache),recorded_requests=len(rows)))
    print(json.dumps({'passed':not errors,'error_count':len(errors),'validated':dict(counts),'parity_checks':len(parity)}),flush=True)
    if errors:raise SystemExit(1)

if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('output',type=Path)
    parser.add_argument('--protocol',type=Path,default=HERE/'development_protocol.json')
    args=parser.parse_args();run(args.output,args.protocol.absolute())
