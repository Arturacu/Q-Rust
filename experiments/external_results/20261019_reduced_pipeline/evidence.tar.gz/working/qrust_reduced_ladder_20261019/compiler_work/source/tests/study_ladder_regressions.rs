//! Study-only checks. The production source copy's pass algorithms are unchanged.
use num_complex::Complex64 as C;
use q_rust::backend::Backend;
use q_rust::ir::{Circuit, GateType, Operation};
use q_rust::parser::parse_qasm;
use q_rust::simulator::circuit_to_unitary;
use q_rust::transpiler::{study_pipeline_plan, transpile, transpile_with_report, TranspilerConfig};

fn source(n: usize, body: &str) -> Circuit {
    parse_qasm(&format!(
        "OPENQASM 2.0; include \"qelib1.inc\"; qreg q[{n}]; creg c[3]; {body}"
    ))
    .unwrap()
}
fn base(n: usize, directed: bool) -> TranspilerConfig {
    let mut backend = Backend::new("study development", n);
    backend.set_coupling_map((0..n - 1).flat_map(|q| {
        if directed {
            vec![(q, q + 1)]
        } else {
            vec![(q, q + 1), (q + 1, q)]
        }
    }));
    TranspilerConfig::builder()
        .optimization_level(3)
        .backend(backend)
        .target_basis(["u", "cx"])
        .profile_passes(true)
        .build()
}
fn verify(source: &Circuit, output: &Circuit, initial: &[usize], final_map: &[usize]) {
    let a = circuit_to_unitary(source);
    let b = circuit_to_unitary(output);
    let embed = |basis: usize, map: &[usize]| {
        map.iter()
            .take(source.num_qubits)
            .enumerate()
            .map(|(q, p)| ((basis >> q) & 1) << p)
            .sum::<usize>()
    };
    let mut expected = Vec::new();
    let mut actual = Vec::new();
    for col in 0..1 << source.num_qubits {
        let mut column = vec![C::new(0.0, 0.0); 1 << output.num_qubits];
        for row in 0..1 << source.num_qubits {
            column[embed(row, final_map)] = a[(row, col)];
        }
        for row in 0..1 << output.num_qubits {
            expected.push(column[row]);
            actual.push(b[(row, embed(col, initial))]);
        }
    }
    let overlap: C = expected
        .iter()
        .zip(&actual)
        .map(|(x, y)| x.conj() * y)
        .sum();
    assert!(overlap.norm() > 0.0);
    let phase = overlap / overlap.norm();
    let residual = expected
        .iter()
        .zip(&actual)
        .map(|(x, y)| (*y - phase * x).norm_sqr())
        .sum::<f64>()
        .sqrt();
    assert!(
        residual < 1e-8,
        "all-input/full-physical-column residual {residual:e}"
    );
}

#[test]
fn every_recipe_preserves_unitaries_maps_ancillas_and_direction() {
    let motifs = [
        source(3, "h q[0]; cx q[0],q[2]; cu1(pi/7) q[2],q[0];"),
        source(3, "ccx q[0],q[2],q[1]; h q[2]; cx q[2],q[0];"),
        source(3, "cx q[0],q[2]; rz(0.37) q[2]; cx q[0],q[2]; barrier q; h q[1];"),
        source(3, "crx(pi) q[0],q[2]; crx(pi) q[0],q[2]; h q[0];"),
        source(3, "cx q[0],q[1]; cx q[1],q[0]; cx q[0],q[1]; h q[2]; cx q[0],q[2];"),
        source(3, "swap q[0],q[1]; cx q[0],q[2]; swap q[1],q[2];"),
        source(2, "u(0.2,0.4,0.6) q[0]; cx q[0],q[1]; u(-0.7,0.1,0.3) q[1]; cx q[0],q[1];"),
        parse_qasm("OPENQASM 2.0; include \"qelib1.inc\"; gate inner(a) x,y { h x; cu1(a) x,y; } gate outer(a) x,y,z { inner(a) x,z; ccx x,y,z; } qreg q[3]; outer(pi/7) q[0],q[1],q[2];").unwrap(),
    ];
    for recipe in 0..=6 {
        for directed in [false, true] {
            for input in &motifs {
                let cfg = base(input.num_qubits + 1, directed)
                    .with_study_recipe(recipe)
                    .unwrap();
                let plain = transpile(input, Some(cfg.clone())).unwrap();
                let (output, report) = transpile_with_report(input, Some(cfg.clone())).unwrap();
                assert_eq!(plain.to_qasm(None), output.to_qasm(None));
                for operation in &output.operations {
                    if let Operation::Gate { name, qubits, .. } = operation {
                        assert!(matches!(name, GateType::U | GateType::CX));
                        if matches!(name, GateType::CX) {
                            assert!(cfg
                                .backend
                                .as_ref()
                                .unwrap()
                                .has_directed_edge(qubits[0], qubits[1]));
                        }
                    }
                }
                assert!(
                    report.numerical_budget.charged_error
                        <= q_rust::transpiler::numerical_policy::CIRCUIT_ERROR_ALLOWANCE
                );
                verify(
                    input,
                    &output,
                    report.initial_layout.as_ref().unwrap(),
                    report.final_layout.as_ref().unwrap(),
                );
            }
        }
    }
}

#[test]
fn tiny_rotations_accumulate_without_loss_in_every_recipe() {
    let mut input = source(2, "h q[0]; cx q[0],q[1];");
    for _ in 0..128 {
        input.add_op(Operation::Gate {
            name: GateType::RX,
            qubits: vec![0],
            params: vec![9e-10],
        });
    }
    input.add_op(Operation::Barrier { qubits: vec![0, 1] });
    for recipe in 0..=6 {
        let (output, report) = transpile_with_report(
            &input,
            Some(base(3, false).with_study_recipe(recipe).unwrap()),
        )
        .unwrap();
        verify(
            &input,
            &output,
            report.initial_layout.as_ref().unwrap(),
            report.final_layout.as_ref().unwrap(),
        );
        assert!(report.numerical_budget.charged_error <= 1e-9);
    }
}

#[test]
fn canonical_terminal_readout_and_error_checks_are_mandatory() {
    let input = source(3, "h q[0]; cx q[0],q[2]; swap q[1],q[2]; measure q[0] -> c[2]; barrier q; measure q[2] -> c[0]; measure q[1] -> c[2];");
    for recipe in 0..=6 {
        let cfg = base(4, true).with_study_recipe(recipe).unwrap();
        let (output, report) = transpile_with_report(&input, Some(cfg.clone())).unwrap();
        let map = report.final_layout.unwrap();
        let readout: Vec<_> = output
            .operations
            .iter()
            .filter_map(|op| match op {
                Operation::Measure { qubit, cbit } => Some((*qubit, *cbit)),
                _ => None,
            })
            .collect();
        assert_eq!(readout, vec![(map[0], 2), (map[2], 0), (map[1], 2)]);
        let first = output
            .operations
            .iter()
            .position(|op| matches!(op, Operation::Measure { .. }))
            .unwrap();
        assert!(output.operations[first..]
            .iter()
            .all(|op| matches!(op, Operation::Measure { .. } | Operation::Barrier { .. })));
        for bad in [
            source(3, "reset q[0];"),
            source(3, "measure q[0] -> c[0]; x q[1];"),
            source(3, "if(c==0) x q[0];"),
        ] {
            assert!(transpile_with_report(&bad, Some(cfg.clone())).is_err());
        }
        let mut bad_basis = cfg.clone();
        bad_basis.target_basis = Some(["cx".to_string()].into_iter().collect());
        assert!(transpile_with_report(&source(3, "h q[0];"), Some(bad_basis)).is_err());
        let mut disconnected = cfg;
        disconnected.backend = Some(Backend::new("disconnected", 4));
        assert!(transpile_with_report(&source(3, "cx q[0],q[2];"), Some(disconnected)).is_err());
    }
}

#[test]
fn registered_groups_are_nested_and_real_pass_traces_activate() {
    let input = source(3, "h q[0]; cx q[0],q[2]; rz(0.3) q[2]; cx q[0],q[2]; cx q[0],q[1]; cx q[1],q[0]; cx q[0],q[1];");
    let activation = [
        ("GateCrystallizationPass", 1),
        ("GateFusionPass", 1),
        ("RecoverPhaseGadgetsPass", 2),
        ("RotationMergePass", 2),
        ("CrossConjugationPass", 2),
        ("CommutationCancellationPass", 2),
        ("TwoQubitBlockSynthesisPass", 3),
        ("PostBlockFusionPass", 3),
        ("EncodedSwapRecognitionPass", 4),
        ("CliffordSimplificationPass", 4),
        ("ExtractOutputPermutationPass", 4),
        ("TrailingSwapElisionPass", 4),
        ("OrientSwapDecompositionPass", 4),
        ("SwapSimplificationPass", 4),
        ("SabreLayoutPass", 5),
    ];
    let mut previous: Vec<(String, Vec<String>)> = Vec::new();
    for recipe in 0..=6 {
        let cfg = base(4, false).with_study_recipe(recipe).unwrap();
        assert!(cfg.retain_routing_candidates);
        assert!(cfg.routing_search.rank_progress);
        assert_eq!(cfg.routing_search.lookahead_size, 20);
        let plan = study_pipeline_plan(&cfg).unwrap();
        for ((old_stage, old), (stage, new)) in previous.iter().zip(&plan) {
            assert_eq!(old_stage, stage);
            let mut remaining = new.iter();
            assert!(
                old.iter().all(|name| remaining.any(|next| next == name)),
                "{recipe}: nonnested stage {stage}"
            );
        }
        let (_, report) = transpile_with_report(&input, Some(cfg)).unwrap();
        for (pass, begins) in activation {
            let registered = plan.iter().flat_map(|(_, p)| p).any(|p| p == pass);
            let executed = report
                .pass_diagnostics
                .iter()
                .any(|p| p.output.stage.rsplit("::").next() == Some(pass));
            assert_eq!(registered, recipe >= begins, "registered {recipe} {pass}");
            assert_eq!(executed, recipe >= begins, "executed {recipe} {pass}");
        }
        for mandatory in [
            "HighArityDecompositionPass",
            "BeamSabrePass",
            "TargetBasisPass",
            "BasisDecompositionPass",
            "KakSynthesisPass",
            "CxDirectionPass",
            "BasisClosurePass",
        ] {
            assert!(
                report
                    .pass_diagnostics
                    .iter()
                    .any(|p| p.output.stage == mandatory),
                "missing mandatory {recipe} {mandatory}"
            );
        }
        previous = plan;
    }
}

#[test]
fn final_recipe_matches_unchanged_public_path_in_every_report_field() {
    for body in [
        "h q[0]; cx q[0],q[2]; cu1(0.4) q[2],q[1];",
        "cx q[0],q[1]; cx q[2],q[1]; cx q[1],q[2]; cx q[1],q[0];",
        "swap q[0],q[1]; h q[2]; cx q[0],q[2]; measure q[2] -> c[1];",
    ] {
        let input = source(3, body);
        for directed in [true, false] {
            let cfg = base(4, directed);
            let (a, mut ar) = transpile_with_report(&input, Some(cfg.clone())).unwrap();
            let (b, mut br) =
                transpile_with_report(&input, Some(cfg.with_study_recipe(6).unwrap())).unwrap();
            assert_eq!(a.to_qasm(None), b.to_qasm(None));
            for trace in [&mut ar.pass_diagnostics, &mut br.pass_diagnostics] {
                for pass in trace {
                    pass.elapsed_ns = 0;
                }
            }
            assert_eq!(ar, br);
        }
    }
}

#[test]
fn selector_rejects_unsafe_or_out_of_range_configuration() {
    assert!(base(3, false).with_study_recipe(7).is_err());
    for change in 0..4 {
        let mut cfg = base(3, false);
        match change {
            0 => cfg.decompose_basis = false,
            1 => cfg.retain_routing_candidates = false,
            2 => cfg.post_routing_cleanup = false,
            _ => cfg.optimization_level = 0,
        }
        assert!(cfg.with_study_recipe(0).is_err());
    }
}
