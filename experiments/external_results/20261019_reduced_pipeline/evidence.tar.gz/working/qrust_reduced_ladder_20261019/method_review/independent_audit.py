"""Independent, standard-library audit of the study's prescribed estimands.

Inputs are explicit projections of protocol/raw fields. This module neither runs
compilers nor chooses cases. The production-schema bridge must preserve every
scheduled identity, failed outcome and requested metric; synthetic tests exercise
the policies before any held-out observation is available.
"""
from __future__ import annotations

from collections import Counter, defaultdict
from dataclasses import dataclass
import hashlib
import json
import math
from pathlib import Path
import statistics


class AuditError(AssertionError):
    pass


def require(condition, message):
    if not condition:
        raise AuditError(message)


def canonical(value):
    return json.dumps(value, sort_keys=True, separators=(",", ":"), allow_nan=False).encode()


def read_bound_json(path, expected_sha256):
    raw = Path(path).read_bytes()
    require(hashlib.sha256(raw).hexdigest() == expected_sha256, "evidence binding mismatch")
    return json.loads(raw)


METRICS = ("compile_ns", "parse_compile_ns", "cx_count", "gate_count", "depth", "two_q_depth")
TIMING = frozenset(METRICS[:2])


@dataclass(frozen=True)
class Plan:
    sessions: tuple[str, ...]
    cases: tuple[str, ...]
    recipes: tuple[str, ...]
    trials: int

    def __post_init__(self):
        for name in ("sessions", "cases", "recipes"):
            values = getattr(self, name)
            require(bool(values) and len(set(values)) == len(values), f"invalid {name}")
            require(all(type(x) is str and x for x in values), f"invalid {name} identity")
        require(type(self.trials) is int and self.trials > 0, "invalid trial count")

    def identities(self):
        return {
            (s, c, r, phase, t)
            for s in self.sessions for c in self.cases for r in self.recipes
            for phase, t in [("warmup", None)] + [("timed", t) for t in range(self.trials)]
        }


def identity(row):
    keys = ("session", "case_id", "recipe", "phase", "trial")
    require(all(k in row for k in keys), "missing identity field")
    require(all(type(row[k]) is str for k in keys[:-1]), "non-string identity field")
    require(row["trial"] is None or type(row["trial"]) is int, "invalid trial identity")
    return tuple(row[k] for k in keys)


def exact_rows(plan, rows):
    keyed = {}
    for row in rows:
        key = identity(row)
        require(key not in keyed, f"duplicate request {key}")
        keyed[key] = row
    require(set(keyed) == plan.identities(), "missing or extra prescribed request")
    return keyed


def audit_schedule(plan, rows, *, require_balanced_positions=True):
    """Check identities, warmups and within-case positions in the actual order."""
    exact_rows(plan, rows)
    positions = defaultdict(Counter)
    groups = defaultdict(list)
    warm = defaultdict(set)
    for row in rows:
        s, c, r, phase, trial = identity(row)
        if phase == "warmup":
            require(not any(groups[(s, c, t)] for t in range(plan.trials)), "late warmup")
            warm[(s, c)].add(r)
        else:
            require(warm[(s, c)] == set(plan.recipes), "timing before all case warmups")
            groups[(s, c, trial)].append(r)
    for (s, c, t), order in groups.items():
        require(len(order) == len(plan.recipes) and set(order) == set(plan.recipes), "incomplete trial block")
        for position, recipe in enumerate(order):
            positions[(c, recipe)][position] += 1
    if require_balanced_positions:
        lo, rem = divmod(len(plan.sessions) * plan.trials, len(plan.recipes))
        expected_counts = sorted([lo + 1] * rem + [lo] * (len(plan.recipes) - rem))
        for c in plan.cases:
            for recipe in plan.recipes:
                values = [positions[(c, recipe)][p] for p in range(len(plan.recipes))]
                require(sorted(values) == expected_counts, f"unbalanced positions {c}/{recipe}")
    return {f"{case}/{recipe}": dict(sorted(counts.items())) for (case, recipe), counts in sorted(positions.items())}


def metric_values(row):
    values = row.get("metrics")
    require(type(values) is dict and set(METRICS) <= set(values), "compiled request missing metrics")
    for name in METRICS:
        value = values[name]
        require(type(value) in (int, float) and math.isfinite(value), f"invalid numeric {name}")
        require(value >= 0, f"negative {name}")
        if name in TIMING:
            require(value > 0 and type(value) is int, f"invalid integer timing {name}")
        else:
            require(type(value) is int, f"nonintegral circuit metric {name}")
    require(values["parse_compile_ns"] >= values["compile_ns"], "parse-plus-compile below compile")
    return {name: values[name] for name in METRICS}


def derive_cells(plan, rows, *, replacement_warmups=()):
    """Reconstruct qualification from all raw outcomes, including warmups."""
    keyed = exact_rows(plan, rows)
    replacements, seen = defaultdict(list), set()
    for row in replacement_warmups:
        s, c, r, phase, trial = identity(row)
        require(s in plan.sessions and c in plan.cases and r in plan.recipes, "unknown replacement identity")
        require(phase == "replacement_warmup" and type(trial) is int and 0 <= trial < plan.trials,
                "invalid replacement warmup")
        require(row.get("reason") == "worker_restart", "unexplained replacement warmup")
        require((s, c, r, trial) not in seen, "duplicate replacement warmup")
        seen.add((s, c, r, trial))
        replacements[(s, c, r)].append(row)
    cells = {}
    for s in plan.sessions:
        for c in plan.cases:
            for r in plan.recipes:
                requests = [keyed[(s, c, r, "warmup", None)]] + [
                    keyed[(s, c, r, "timed", t)] for t in range(plan.trials)
                ] + replacements[(s, c, r)]
                good = []
                causes = Counter()
                for row in requests:
                    status = row.get("status")
                    require(type(status) is str and status, "missing raw status")
                    passed = row.get("validation_passed")
                    require(type(passed) is bool, "validation verdict must be explicit boolean")
                    if status == "compiled":
                        values = metric_values(row)
                        if passed:
                            good.append(values)
                        else:
                            causes["unverified_output"] += 1
                    else:
                        require(not passed, "failed request cannot pass validation")
                        causes[status] += 1
                eligible = not causes
                cells[(s, c, r)] = {
                    "eligible": eligible,
                    "requests": len(requests),
                    "qualified_requests": len(good),
                    "outcomes": dict(sorted(causes.items())),
                    "metrics": {
                        name: statistics.median([keyed[(s, c, r, "timed", t)]["metrics"][name] for t in range(plan.trials)])
                        for name in METRICS
                    } if eligible else None,
                }
    return cells


def stable_cohort(plan, cells, recipes):
    require(bool(recipes) and len(set(recipes)) == len(recipes), "empty or duplicate cohort recipe")
    require(set(recipes) <= set(plan.recipes), "unknown cohort recipe")
    require(set(cells) == {(s, c, r) for s in plan.sessions for c in plan.cases for r in plan.recipes}, "cell denominator drift")
    return tuple(c for c in plan.cases if all(cells[(s, c, r)]["eligible"] for s in plan.sessions for r in recipes))


def paired_summary(plan, cells, cohort, session, new, reference, metric, families):
    require(session in plan.sessions and new in plan.recipes and reference in plan.recipes, "unknown contrast")
    require(metric in METRICS, "unknown metric")
    require(len(set(cohort)) == len(cohort) and set(cohort) <= set(plan.cases), "invalid pair cohort")
    require(set(families) == set(plan.cases), "missing family denominator")
    positive = []
    zero = Counter()
    wins = Counter({"win": 0, "tie": 0, "loss": 0})
    family_logs = defaultdict(list)
    for case in cohort:
        a, b = cells[(session, case, new)], cells[(session, case, reference)]
        require(a["eligible"] and b["eligible"], "unqualified pair")
        av, bv = a["metrics"][metric], b["metrics"][metric]
        wins["win" if av < bv else "loss" if av > bv else "tie"] += 1
        numerator, denominator = (bv, av) if metric in TIMING else (av, bv)
        if numerator == 0 or denominator == 0:
            zero["both_zero" if numerator == denominator else "numerator_zero" if numerator == 0 else "denominator_zero"] += 1
            continue
        ratio = numerator / denominator
        require(math.isfinite(ratio) and ratio > 0, "unrepresentable ratio")
        positive.append(ratio)
        family_logs[families[case]].append(math.log(ratio))
    logs = [math.log(r) for r in positive]
    return {
        "pair_count": len(cohort),
        "positive_ratio_count": len(positive),
        "zero_exclusions": dict(sorted(zero.items())),
        "win_tie_loss": dict(wins),
        "geomean": math.exp(statistics.mean(logs)) if logs else None,
        "family_balanced_geomean": math.exp(statistics.mean([statistics.mean(x) for x in family_logs.values()])) if family_logs else None,
        "represented_positive_families": sorted(family_logs),
        "cohort_families": sorted({families[c] for c in cohort}),
    }


def assert_summary(actual, expected, *, tolerance=1e-12):
    """Fail if any denominator, zero exclusion, family or point estimate changes."""
    require(set(actual) >= set(expected), "summary missing required field")
    for key, value in expected.items():
        if key in {"geomean", "family_balanced_geomean"} and value is not None:
            observed = actual[key]
            require(type(observed) in (int, float) and math.isfinite(observed), f"invalid summary {key}")
            require(math.isclose(observed, value, rel_tol=tolerance, abs_tol=0.0), f"summary mismatch {key}")
        else:
            require(canonical(actual[key]) == canonical(value), f"summary mismatch {key}")


def expected_recipe_metadata(index):
    """Independent transcription of the reviewed, prespecified group contract."""
    require(type(index) is int and 0 <= index <= 6, "invalid recipe index")
    optimize = (["RecoverPhaseGadgetsPass"] if index >= 2 else [])
    if index >= 1:
        optimize += ["GateCrystallizationPass", "ParameterSimplificationPass"]
    if index >= 2:
        optimize += ["RotationMergePass", "CrossConjugationPass", "InverseCancellationPass", "CommutationCancellationPass", "ParameterSimplificationPass"]
    if index >= 4:
        optimize += ["EncodedSwapRecognitionPass"]
    prepare = (["ExtractOutputPermutationPass", "CliffordSimplificationPass", "ComposeOutputPermutationPass"] if index >= 4 else []) + ["HighArityDecompositionPass"]
    route = (["SabreLayoutPass"] if index >= 5 else []) + ["BeamSabrePass"]
    lower = (["TrailingSwapElisionPass", "ApplyOutputPermutationPass", "OrientSwapDecompositionPass"] if index >= 4 else []) + ["TargetBasisPass"]
    if index >= 4:
        lower += ["CliffordSimplificationPass"]
    lower += ["BasisDecompositionPass", "KakSynthesisPass"]
    if index >= 1:
        lower += ["GateFusionPass"]
    if index >= 4:
        lower += ["SwapSimplificationPass"]
    if index >= 2:
        lower += ["InverseCancellationPass"]
    if index >= 1:
        lower += ["ParameterSimplificationPass"]
    if index >= 3:
        lower += ["TwoQubitBlockSynthesisPass", "PostBlockFusionPass"]
    lower += ["CxDirectionPass", "BasisDecompositionPass", "BasisClosurePass"]
    return {
        "recipe": f"R{index}", "recipe_index": index, "enabled_groups": list(range(1, index + 1)),
        "beam_width": 8 if index == 6 else 1, "branch_factor": 5 if index == 6 else 1,
        "bidirectional_iterations": 4 if index == 6 else 1,
        "mandatory": {key: True for key in ("canonical_validation", "decompose_basis", "numerical_policy_unchanged", "post_routing_cleanup", "retain_routing_candidates")},
        "effective_search": {"commute_diagonal": index >= 2, "elide_output_permutations": index >= 4,
                             "orient_swaps": index >= 4, "layout_trials": 10 if index >= 5 else None,
                             "layout_iterations": 3 if index >= 5 else None,
                             "layout_start_seeds": "0..layout_trials" if index >= 5 else "no placement search; identity initial layout",
                             "lookahead_size": 20, "rank_progress": True, "tie_breaking": "deterministic lexicographic"},
        "registered_passes": [["optimize", optimize], ["prepare_routing", prepare], ["layout_and_route", route], ["lower", lower]],
    }


def audit_recipe_metadata(metadata, index):
    expected = expected_recipe_metadata(index)
    require(type(metadata) is dict and set(expected) <= set(metadata), "missing recipe contract field")
    for key, value in expected.items():
        require(canonical(metadata[key]) == canonical(value), f"recipe contract mismatch {key}")


def assert_r6_parity(native, experimental, expected_metadata):
    """Artifact/report parity, excluding only two clocks and event durations.

    Metadata must equal the separately frozen expected effective configuration.
    This says nothing about runtime equivalence or untested circuits.
    """
    require(native.get("status") == experimental.get("status") == "compiled", "parity requires compiled outputs")
    require("study_recipe_metadata" not in native, "native unexpectedly contains study metadata")
    require(canonical(experimental.get("study_recipe_metadata")) == canonical(expected_metadata), "R6 metadata mismatch")
    require(type(expected_metadata) is dict and expected_metadata.get("recipe") == "R6", "not terminal recipe metadata")
    audit_recipe_metadata(expected_metadata, 6)

    def strip(value, study):
        copied = json.loads(canonical(value))
        if study:
            del copied["study_recipe_metadata"]
        for key in ("compile_ns", "parse_ns"):
            require(type(copied.get(key)) is int and copied[key] >= 0, f"missing parity clock {key}")
            del copied[key]
        require(type(copied.get("pass_diagnostics")) is list, "missing pass diagnostics")
        for entry in copied["pass_diagnostics"]:
            require(type(entry.get("elapsed_ns")) is int and entry["elapsed_ns"] >= 0, "missing pass clock")
            del entry["elapsed_ns"]
        return canonical(copied)

    require(strip(native, False) == strip(experimental, True), "R6 artifact/report mismatch")
