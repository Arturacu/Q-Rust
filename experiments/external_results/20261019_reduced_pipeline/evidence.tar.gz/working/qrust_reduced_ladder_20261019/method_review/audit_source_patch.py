"""Check the experimental compiler patch without compiling or reading inputs."""
from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path

from independent_audit import AuditError, canonical, require


ALLOWED_CHANGED = frozenset({
    "src/transpiler/mod.rs", "src/transpiler/pass.rs", "experiments/src/bin/comparison_runner.rs",
})


def digest(data):
    return hashlib.sha256(data).hexdigest()


def segment(data, start, end):
    require(data.count(start) == 1, f"ambiguous protected segment {start!r}")
    first = data.index(start)
    last = data.index(end, first) if end else len(data)
    return data[first:last]


def audit(reference_root, experimental_root, source_manifest):
    reference_root, experimental_root = Path(reference_root), Path(experimental_root)
    source_manifest = Path(source_manifest)
    raw = source_manifest.read_bytes()
    manifest = json.loads(raw)
    original = manifest["files"]
    unchanged, changed = [], []
    for name, expected in sorted(original.items()):
        path = Path(name)
        require(not path.is_absolute() and ".." not in path.parts, "unsafe source-manifest path")
        before = (reference_root / path).read_bytes()
        require(len(before) == expected["bytes"] and digest(before) == expected["sha256"], f"reference source mutation: {name}")
        after = (experimental_root / path).read_bytes()
        record = {"path": name, "reference_sha256": digest(before), "experimental_sha256": digest(after)}
        if before == after:
            unchanged.append(record)
        else:
            require(name in ALLOWED_CHANGED, f"unapproved changed source: {name}")
            changed.append(record)
    require({r["path"] for r in changed} == ALLOWED_CHANGED, "expected three-file selector patch not present")
    for path in (experimental_root / "src").rglob("*.rs"):
        require(path.relative_to(experimental_root).as_posix() in original, "unreviewed production algorithm module")

    before = (reference_root / "src/transpiler/mod.rs").read_bytes()
    after = (experimental_root / "src/transpiler/mod.rs").read_bytes()
    protected = [
        (b"fn diagnostics_enabled()", b"/// Stage groups that the pipeline is partitioned into.", "KAK and native-basis implementation"),
        (b"fn resolved_target_basis(", b"/// Builds and runs a slice", "input/output validators, readout and target resolution"),
        (b"struct LoweredCandidate {", b"#[derive(PartialEq, Eq)]\nstruct RoutingContextKey", "final cost cache and candidate preference"),
        (b"fn same_circuit_bits(", b"#[cfg(test)]", "routing reuse, candidate guards, numerical forks and public execution"),
    ]
    protected_records = []
    for start, end, label in protected:
        a, b = segment(before, start, end), segment(after, start, end)
        require(a == b, f"mandatory/canonical algorithm changed: {label}")
        protected_records.append({"label": label, "sha256": digest(a), "bytes": len(a)})

    # All original pass-manager execution methods must remain byte-identical.
    old_pm = (reference_root / "src/transpiler/pass.rs").read_bytes()
    new_pm = (experimental_root / "src/transpiler/pass.rs").read_bytes()
    insertion_start = b"    /// Inspect registered names without executing or changing their predicates.\n"
    insertion_end = b"    /// Creates a new empty manager.\n"
    insertion = segment(new_pm, insertion_start, insertion_end)
    require(new_pm.replace(insertion, b"", 1) == old_pm, "pass-manager execution changed")
    return {
        "schema": "qrust_independent_source_patch_audit_v1",
        "passed": True,
        "source_manifest_sha256": digest(raw),
        "reference_commit": manifest["compiler_reference_commit"],
        "changed": changed,
        "unchanged_files": len(unchanged),
        "unchanged": unchanged,
        "protected_regions": protected_records,
        "limits": [
            "Selector/pass-registration changes require separate semantic source review and activation/correctness tests.",
            "This source audit does not establish binary provenance, R6 artifact parity, timing equivalence or correctness on all circuits.",
            "No held-out inputs or compiler outcomes are read by this audit.",
        ],
    }


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--reference-root", type=Path, required=True)
    parser.add_argument("--experimental-root", type=Path, required=True)
    parser.add_argument("--source-manifest", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    require(not args.output.exists(), "refusing to replace prior audit")
    result = audit(args.reference_root, args.experimental_root, args.source_manifest)
    result["audit_helper_sha256"] = digest(Path(__file__).read_bytes())
    args.output.write_text(json.dumps(result, indent=2, sort_keys=True) + "\n")
    print(json.dumps({"passed": result["passed"], "unchanged_files": result["unchanged_files"], "changed_files": len(result["changed"]), "protected_regions": len(result["protected_regions"])}))


if __name__ == "__main__":
    main()
