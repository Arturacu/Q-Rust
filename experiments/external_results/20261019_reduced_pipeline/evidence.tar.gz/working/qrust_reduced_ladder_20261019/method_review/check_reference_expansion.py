"""Bounded synthetic SDK-reference controls; no selected inputs or compilers."""
from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path
import sys

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE.parent / "corpus_work"))
import reference_expansion


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def run_controls():
    import numpy as np
    import qiskit
    from qiskit import QuantumCircuit
    from qiskit.circuit import Gate
    from qiskit.circuit.library import QFTGate
    from qiskit.quantum_info import Operator

    records = []
    tolerance = 1e-12

    def equivalent(name, circuit):
        before = circuit.copy()
        expected = Operator(circuit).data
        expanded, details = reference_expansion.expand_reference(circuit)
        actual = Operator(expanded).data
        residual = float(np.max(np.abs(actual - expected)))
        passed = bool(residual <= tolerance and circuit == before and all(len(i.qubits) <= 2 for i in expanded.data))
        records.append({"name": name, "passed": passed, "comparison": "complete dense operators, no global-phase alignment",
                        "qubits": circuit.num_qubits, "max_absolute_residual": residual,
                        "source_unchanged": circuit == before, "expansion": details})

    for width in (6, 10):
        circuit = QuantumCircuit(width)
        circuit.global_phase = 0.173
        circuit.append(QFTGate(width), range(width))
        equivalent(f"QFT_{width}_all_columns_dense_reference", circuit)

    inner = QuantumCircuit(3)
    inner.global_phase = 0.371
    inner.h(0)
    inner.cx(0, 2)
    inner.rz(0.239, 1)
    middle = QuantumCircuit(4)
    middle.global_phase = -0.193
    middle.append(inner.to_gate(label="inner-phase"), [3, 1, 0])
    middle.rx(0.431, 2)
    mapped = QuantumCircuit(5)
    mapped.global_phase = 0.413
    mapped.h(4)
    mapped.append(middle.to_gate(label="middle-phase"), [4, 1, 3, 0])
    mapped.cx(2, 1)
    equivalent("nested_global_phases_and_nontrivial_wire_maps", mapped)

    controlled_body = QuantumCircuit(3)
    controlled_body.global_phase = 0.437
    controlled_body.h(0)
    controlled_body.cx(0, 2)
    controlled_body.ry(-0.271, 1)
    controlled = QuantumCircuit(4)
    controlled.global_phase = -0.281
    controlled.h(2)
    controlled.append(controlled_body.to_gate().control(1), [2, 3, 0, 1])
    equivalent("controlled_definition_phase_on_superposed_control", controlled)

    local = QuantumCircuit(2)
    local.global_phase = 0.37
    local.rz(-0.17, 0)
    local.cx(0, 1)
    equivalent("one_and_two_qubit_leaves_preserve_outer_phase", local)

    def rejected(name, circuit, options, expected_text):
        try:
            reference_expansion.expand_reference(circuit, **options)
        except ValueError as error:
            records.append({"name": name, "passed": expected_text in str(error), "error": str(error)})
        else:
            records.append({"name": name, "passed": False, "error": "accepted invalid control"})

    no_definition = QuantumCircuit(3)
    no_definition.append(Gate("missing-definition", 3, []), range(3))
    rejected("missing_wide_definition_rejected", no_definition, {}, "lacks an exact SDK definition")
    recursion = Gate("recursive-definition", 3, [])
    recursion_body = QuantumCircuit(3)
    recursion_body.append(recursion, range(3))
    recursion.definition = recursion_body
    recursive = QuantumCircuit(3)
    recursive.append(recursion, range(3))
    rejected("recursive_definition_bound", recursive, {"maximum_depth": 3}, "recursion limit")
    too_many = QuantumCircuit(3)
    too_many.append(QFTGate(3), range(3))
    rejected("expanded_gate_limit", too_many, {"maximum_gates": 1}, "gate limit")
    measured = QuantumCircuit(1, 1)
    measured.measure(0, 0)
    rejected("measurement_rejected", measured, {}, "static unitary")
    reset = QuantumCircuit(1)
    reset.reset(0)
    rejected("reset_rejected", reset, {}, "static unitary")

    # Phase-sensitive controls must detect the two mistakes this expansion avoids.
    expanded, details = reference_expansion.expand_reference(mapped)
    expected = Operator(mapped).data
    wrong_phase = expanded.copy()
    wrong_phase.global_phase = mapped.global_phase
    phase_residual = float(np.max(np.abs(Operator(wrong_phase).data - expected)))
    records.append({"name": "negative_control_nested_phase_omission", "passed": phase_residual > 1e-4,
                    "max_absolute_residual": phase_residual, "expected": "must disagree"})
    wrong_map = QuantumCircuit(mapped.num_qubits)
    wrong_map.global_phase = mapped.global_phase
    wrong_map.h(4)
    wrong_map.append(middle.to_gate(), [0, 1, 2, 3])
    wrong_map.cx(2, 1)
    map_residual = float(np.max(np.abs(Operator(wrong_map).data - expected)))
    records.append({"name": "negative_control_wrong_definition_wire_map", "passed": map_residual > 1e-4,
                    "max_absolute_residual": map_residual, "expected": "must disagree"})
    return {"schema": "qrust_independent_reference_expansion_controls_v1",
            "passed": all(r["passed"] is True for r in records), "test_count": len(records), "tests": records,
            "tolerance": tolerance, "reference_expansion_sha256": sha(reference_expansion.__file__),
            "control_helper_sha256": sha(__file__), "qiskit_version": qiskit.__version__, "numpy_version": np.__version__,
            "scope": "Synthetic-only source-reference admission controls. QFT6/QFT10 compare every dense operator column without phase alignment. No selected generator input, compiler result or shared normalizer is used."}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    if args.output.exists():
        raise FileExistsError("refusing to overwrite prior control receipt")
    result = run_controls()
    args.output.write_text(json.dumps(result, indent=2, sort_keys=True, allow_nan=False) + "\n")
    print(json.dumps({"passed": result["passed"], "test_count": result["test_count"],
                      "max_equivalence_residual": max(r["max_absolute_residual"] for r in result["tests"] if "comparison" in r),
                      "reference_expansion_sha256": result["reference_expansion_sha256"]}))
    if not result["passed"]:
        raise SystemExit(1)


if __name__ == "__main__":
    main()
