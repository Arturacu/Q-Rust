"""Record the independent final report review without modifying the report."""
from collections import Counter
import hashlib
import json
from pathlib import Path
import re

HERE = Path(__file__).resolve().parent
L = HERE.parent
R = L.parent / "qrust_pr_publish"
C = L / "corpus_work/campaign"
REPORT = R / "experiments/REDUCED_PIPELINE_STUDY.md"
EXPECTED_REPORT = "6b2c8a6882d225060de0ee430a8acab821e719f33c3ae6f6bf5c54f69e69a9d0"


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def load(path):
    return json.loads(Path(path).read_text())


def main():
    assert sha(REPORT) == EXPECTED_REPORT
    assert REPORT.read_bytes() == (L / "reporting/report_v2.md").read_bytes()
    report = REPORT.read_text()
    assert "The reduced baseline R0 pipeline" in report
    assert "Every formal Q-Rust response" in report
    render = load(L / "reporting/report_render_receipt_v2.json")
    assert render["report_sha256"] == EXPECTED_REPORT
    assert render["template_sha256"] == sha(L / "reporting/report_template_v2.md")
    assert render["analysis_sha256"] == sha(C / "analysis.json")
    audit = load(HERE / "postflight_analysis_02.json")
    assert audit["passed"] is True and audit["analysis"]["analysis_sha256"] == sha(C / "analysis.json")
    analysis = load(C / "analysis.json")
    validation = load(C / "validation_summary.json")
    preparation = load(L / "corpus_work/preparation_final_receipt.json")
    interpretation = load(L / "reporting/stage_interpretation.json")
    selection = load(L / "corpus_work/selection/selection.json")
    development = load(L / "compiler_work/development_admission_receipt.json")
    assert len(load(L / "original_preservation.json")["files"]) == 1956
    assert preparation["all_raw_pairs_exactly_preserved"] == 18
    assert preparation["previous_input_pairs_exactly_preserved"] == 17
    assert preparation["candidates"]["excluded"] == 0
    assert round(preparation["normalization_max_residual"] / 1e-14, 2) == 2.35
    assert preparation["inventory_classifications"] == dict(explicit_input=44168, explicit_output=655569, unclassified_qasm=2020)
    assert development["native_parity_checks"] == 104 and development["strict_independently_verified_outputs"] == 288
    assert development["retained_unsupported_barrier_outputs"] == 24
    assert validation["unique_artifacts"] == 532
    assert validation["unique_evidence_classes"] == {"full_isometry": 172, "sampled_isometry": 360}
    assert validation["max_residual"] == 6.3488762467508525e-12
    raw_sessions = []
    for si in (1, 2):
        with (C / f"session_{si:02d}/timed.jsonl").open() as handle:
            raw_sessions.append({r["id"]: r for r in map(json.loads, handle)})
    assert len(raw_sessions[0]) == len(raw_sessions[1]) == 2700 and raw_sessions[0].keys() == raw_sessions[1].keys()
    assert all(all(left[k] == raw_sessions[1][key][k] for k in ("artifact_sha256", "output_sha256", "initial_layout", "final_layout", "output_qubits"))
               for key, left in raw_sessions[0].items())
    summary = analysis["sessions"][0]
    assert analysis["sessions"][0]["quality_retention_vs_R6"] == analysis["sessions"][1]["quality_retention_vs_R6"]
    retained = summary["quality_retention_vs_R6"]["R5"]
    assert [retained[k]["counts"]["joint_all_three"] for k in ("0", "0.05", "0.1")] == [35, 39, 41]
    cells = load(C / "session_01/cells.json")
    index = {(c["case_id"], c["tool"]): c for c in cells}
    routed = [c for c in cells if c["tool"] == "R6" and c["topology"] != "all_to_all"]
    assert len(routed) == 36
    sparse_counts = []
    for percent in (0, 5, 10):
        sparse_counts.append(sum(all(index[c["case_id"], "R5"]["medians"][m] * 100 <= c["medians"][m] * (100 + percent)
                                    for m in ("cx_count", "depth", "two_q_depth")) for c in routed))
    assert sparse_counts == [17, 21, 23]
    adjacent = interpretation["sessions"][0]["adjacent"]["R6_vs_R5"]["aggregate"]
    assert [adjacent["quality_win_tie_loss"][m]["loss"] for m in ("cx_count", "depth", "two_q_depth")] == [7, 8, 9]
    assert adjacent["any_quality_regression"] == 10
    for session in analysis["sessions"]:
        pair = session["sdk_stable_pairs"]["qiskit"]
        assert all(pair[m]["ci95"][0] <= 1 <= pair[m]["ci95"][1] for m in ("compile_ns", "parse_compile_ns"))
    links = []
    for target in re.findall(r"\]\(([^)]+)\)", report):
        if not target.startswith("http"):
            path = REPORT.parent / target
            links.append({"target": target, "exists_at_review": path.is_file(), "sha256": sha(path) if path.is_file() else None})
    paths = [REPORT, L / "reporting/report_template_v2.md", L / "reporting/report_render_receipt_v2.json",
             L / "reporting/tables/export_receipt.json", C / "analysis.json", C / "validation_summary.json",
             C / "warmup_validation_summary.json", C / "session_01/cells.json", C / "session_02/cells.json",
             L / "reporting/stage_interpretation.json", L / "reporting/variability.json",
             L / "corpus_work/preparation_final_receipt.json", L / "compiler_work/development_admission_receipt.json",
             HERE / "postflight_analysis_02.json", HERE / "postflight_audit_controls_01.json",
             L / "compiler_work/source/src/transpiler/mod.rs", L / "compiler_work/source/src/transpiler/routing.rs",
             L / "compiler_work/source/src/transpiler/block_synthesis.rs", Path(__file__)]
    result = {
        "schema": "qrust_final_report_independent_review_v1", "report_content_passed": True,
        "report_sha256": EXPECTED_REPORT, "template_sha256": render["template_sha256"],
        "review_scope": "Read-only adversarial review of report v2 and its template against frozen evidence; new receipt only.",
        "bindings": {str(p.relative_to(L.parent)): sha(p) for p in paths},
        "validated_claims": [
            "18 fixtures, 54 cases, 5400 timed requests and 1080 initial warmups; no formal exclusions or failures; all ten recipes qualify in both sessions.",
            "R0/R5 speed and quality summaries, every generated table and the conditional adjacent-group point estimates agree with independently audited medians and frozen analysis.",
            "Topology-specific percentages and placement effects match the strata; complete graphs tie for R5/R6 and sparse-only retention is 17/36, 21/36, 23/36 at 0/5/10 percent.",
            "All four adverse-case rows and QFT/VQE compile medians match saved cells; R6 worsens CX/depth/two-qubit depth on 7/8/9 cases and any metric on 10 distinct cases.",
            "Qiskit timing intervals span parity at both recorded endpoints; the approximately 6.2x QFT-line adverse runtime is consistent with the saved medians.",
            "R0..R6 group definitions, common controls, identity-placement limits, retained continuations and experiment-only timing boundary match reviewed frozen source.",
            "Routing pruning/SWAP cost and local synthesis acceptance explain absence of a monotonic guarantee; report correctly does not claim per-case internal causal traces.",
            "Selection seed/options, MQT source pin, known-family/new-generator classification, lexical inventory counts and source-preparation corrections agree with preserved evidence.",
            "Development attempt counts remain 144 pass/144 width-contract/24 unsupported then 288 pass/24 unsupported; parity is 104 each, distinct from semantic verification.",
            "Unique artifact counts and residuals agree with validation receipts; corresponding cross-session artifact/map identity is independently confirmed for all 2700 pairs."
        ],
        "remaining_scientific_limits": [
            "Sequential grouped interventions cannot isolate constituent passes or all interactions; fixed per-route budget does not fix total continuation work.",
            "Only six-qubit cases have full numerical isometry evidence; larger checks use eight fixed inputs, including seeded Haar states, and are sampled evidence.",
            "18 selected instances and one parameter seed are not a representative population or hardware workload; lexical nonoverlap is not semantic independence.",
            "One warm-process host, selected SDK recipes, shared normalized frontend and ideal graphs do not establish Rust causality, memory savings, optimality or universal superiority.",
            "The point estimates and retention were independently recomputed; confidence intervals retain the frozen prescribed bootstrap and were not independently regenerated by this review.",
            "R5 has adverse tails despite small aggregate overhead; no new recipe/default was selected and independently confirmed after observing this corpus."
        ],
        "review_corrections_applied": ["Unqualified minimal R0 wording replaced by reduced baseline R0.", "Formal response metadata statement narrowed explicitly to Q-Rust."],
        "links": links,
        "delivery_conditions": [
            "Finish populating the result directory and verify every report link before commit/delivery.",
            "Bind completed fresh-archive replay and final 1956-file historical-preservation verification in the delivery verification summary; this content review does not claim those pending delivery checks ran."
        ],
        "report_edits_by_this_reviewer": False,
        "computational_evidence_edits": False,
    }
    output = HERE / "final_report_audit_01.json"
    with output.open("x") as handle:
        json.dump(result, handle, indent=2, sort_keys=True)
        handle.write("\n")
    print(json.dumps({"report_content_passed": True, "report_sha256": EXPECTED_REPORT,
                      "receipt_sha256": sha(output), "pending_links": [l["target"] for l in links if not l["exists_at_review"]]}))


if __name__ == "__main__":
    main()
