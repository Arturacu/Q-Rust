# Independent review of the reduced-pipeline study

This review concerns the experimental protocol and its implementation. It does not select a recipe from held-out results. The reviewer may inspect source and synthetic/development controls before the final freeze, but must not inspect selected held-out inputs or measurements until the coordinating agent declares the freeze complete.

## Experimental question and interpretation

The seven recipes describe one nested construction of the compiler. R0 retains mandatory input validation, high-arity reduction, basic routing, target translation, basis decomposition, KAK lowering, direction repair, basis closure, numerical accounting and terminal-readout handling. Later groups add local simplification; algebraic/phase/dependency rules; two-qubit blocks and checked local fusion; encoded-SWAP/Clifford/permutation handling; layout search; and a larger beam/branch/bidirectional search budget.

The exact implementation and effective configuration, rather than those short names, are authoritative. Ordinary optimization levels are unsuitable controls: the production source couples them to pass membership, layout presence and routing budgets. Study controls must separate these choices without changing the underlying transformation algorithms or mandatory validity checks.

An adjacent difference is the effect of adding a group after its predecessors. It is not the independent contribution of every pass in that group. This order cannot identify all interactions, and favorable effects need not persist under another order. On an identical positive cohort, multiplicative adjacent ratios may telescope algebraically; times, percentage improvements and separately calculated medians must not be added as independent savings.

R0 uses the prescribed minimal placement/routing recipe. It is not a claim about the best low-cost compiler or the best way to route an arbitrary physical graph. Physical labels and edge ordering must remain identical across recipes.

All seven arms execute the same experimental binary, which still contains every pass group. Disabling passes tests a reduced executed pipeline; it does not demonstrate a smaller binary, smaller source code, less memory or a Rust-specific speed effect. Any description of reduced work is restricted to measured compilation and structural costs. R6 includes the study selector/configuration snapshot even when its outputs match the original production binary, so its timing is not asserted to equal that original binary's timing.

## Search effort and quality continuations

Before the explicit search groups, keep the configured per-route beam, branching, bidirectional iteration, lookahead, static-weight, progress-ranking and retention policy fixed. Keep canonical retained-input and pre-Clifford quality guards active when applicable. They can introduce additional complete route/lower continuations; therefore fixed per-route settings do not establish equal total routing work. The representation/Clifford group includes that policy consequence.

The placement group includes any canonical alternatives that placement makes available. The final group should change only the stated beam/branch/bidirectional budget. Development pass traces must retain branch names, route calls and candidate selection; use per-request totals before aggregation. Instrumented requests are separate from formal timing, with exact output/map parity checked where applicable. Full-stage parity with the original frozen compiler establishes artifact equivalence on the prescribed controls, not equality of timing overhead or equivalence on every circuit.

## Corpus and repeated measurements

The proposed corpus has 18 fixtures from six pinned generators, three widths and three fixed ideal topologies, yielding 54 circuit-target cases. One instance per generator/width provides bounded coverage but does not estimate parameter-to-parameter variation. Previously unused generator implementations within known coarse families are not independent new algorithm families. Exact-hash nonoverlap is useful provenance, not semantic independence.

Freeze generator definitions/options/seeds, parameter binding, source-only eligibility, common-input normalization, target labels and edges, all candidate exclusions and the no-replacement rule before compiler outcomes. A shared low-level input is a front-end policy, not each SDK's best native high-level pipeline. Any dialect expansion must have independent gate/definition checks and its own pinned source; do not repair inputs after seeing held-out failures.

Use two sessions, one initial warmup and five measured requests per recipe/case/session. Prescribe balanced recipe order and all trial identities before execution. With ten recipes and ten trials across sessions, each recipe can occupy each within-case position exactly once. Randomization seeds, time and memory caps, worker restart behavior and retries are part of the frozen protocol. A failed or lost request retains its planned identity and cannot become an unrecorded replacement. Only SDKs that actually consume a requested seed are seed-controlled; all cross-session artifact/quality agreement is empirical.

## Estimands and eligibility

The primary ladder trajectory uses cases complete and independently verified for every ladder recipe in both sessions. This fixes the denominator across every adjacent and baseline-relative comparison. Report adjacent-pair stable cohorts and SDK-pair stable cohorts separately, with their own denominators, and retain a four-tool common cohort where relevant. A changing cohort cannot be silently used to explain a cumulative pass gain.

A cell is complete only when each prescribed timed identity and its required warmup have exactly one outcome and every required outcome passes independent checking. Duplicate, missing, failed, timed-out, unsupported or unverified requests do not qualify. Count attempted/selected cases before filtering; report every failure before conditional means. A cell-level success flag without the complete request evidence is insufficient.

The cell estimator is the median of the five prescribed timed values. Calculate ratios of these cell medians, separately in each session. Timing ratios are reference/new; structural-cost ratios are new/reference. Zero costs remain in pair and win/tie/loss counts but are excluded explicitly from logarithmic ratios without pseudocounts. Nonfinite, negative, missing or boolean metric values are invalid. Retain gate count, CX count, total depth and two-qubit depth distinctly.

Provide equal-case and family-balanced summaries, represented-family counts, per-family/width/topology results, adverse cases and Pareto trade-offs. Fixture-cluster resampling keeps all of a fixture's targets together. Prescribed bootstrap draws and seed describe sensitivity within this fixed small corpus, not representative sampling or a guaranteed-powered hypothesis test. Do not pool two sessions into ten exchangeable trials or select a winning policy and treat the same observations as its independent confirmation.

## Timing, memory and correctness boundaries

Freeze both compile-only and parse-plus-compile timing regions. Keep process startup, serialization, transport, independent checking and instrumentation distinct. Request-wall time can remain a raw diagnostic without becoming a new post-hoc aggregate. Warm-process measurements from one host do not establish language-level causality, hardware execution performance or cross-platform behavior.

RSS is resource-cap monitoring only. There is no comparative memory endpoint. Persistent process high-water marks, allocator retention and sampled RSS cannot identify per-circuit allocation or a compiler-only peak.

The output contract is the common basis and directed-edge legality, recorded input/output maps, clean spare wires and one shared global phase. Small-width complete isometry checks are stronger than sampled larger-width checks; their counts and limitations must remain separate. Unsupported local recognition is not semantic failure. Preserve independent negative controls for wrong maps, missing edges, reversed entangling direction, input-dependent phase and spare-wire leakage. Numerical acceptance and circuit error budgets remain mandatory in every recipe.

## Required implementation checks before freeze

1. Reject unknown recipe IDs, invalid types/ranges and attempts to override a named recipe silently. Record the effective configuration.
2. Activation fixtures demonstrate pass presence, absence and ordering, not merely echoed request flags. Required lowering and validation remain present at every stage.
3. Full-stage output QASM, logical/physical maps and structural metadata match the original frozen binary on the prescribed development corpus; profile on/off also preserves artifacts.
4. Include controlled phases and `cu1`, QFT/W routines, accumulated tiny rotations, non-involutive permutations, clean spare wires, retained branches, barriers and terminal classical writes. Unsupported dynamic inputs still fail closed.
5. Branch reuse keys include study controls. Numerical ledgers, input/output maps and retained-candidate metadata cannot leak between branches.
6. Synthetic audit regressions reject incomplete/duplicate cells, denominator drift, zero/log mishandling, nonfinite values, invalid warmup qualification, changed schedules and mutated evidence bindings.
7. Bind the production revision, experimental patch/source tree, binaries/build flags, installed SDK files, fixtures/normalizer, complete schedules, verifier vectors/tolerances, analysis code/cohorts/endpoints and cap/retry policy. Freeze any selection threshold before outcomes.

Previous results are immutable. A correction after fresh compiler outcomes requires a new versioned run or an explicitly separate diagnostic; it must not rewrite the frozen evidence.

## Review status

Methodology reviewed against the production pass builder, routing-continuation code and earlier frozen-study findings. The executable audit and exact experimental source review are being prepared. This status is not an assertion that the final implementation or campaign has passed.
