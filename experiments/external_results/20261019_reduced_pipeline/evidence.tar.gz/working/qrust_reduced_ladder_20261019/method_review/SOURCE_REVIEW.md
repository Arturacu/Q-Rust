# Experimental compiler source review

The reviewed patch changes only three original files in the isolated compiler copy: `src/transpiler/mod.rs`, `src/transpiler/pass.rs`, and `experiments/src/bin/comparison_runner.rs`. `source_audit_final.json` binds the final patch and the source-copy manifest. All other 100 original files match their recorded bytes, including numerical policy, synthesis, block synthesis, Clifford transformations, layout and routing algorithms.

Four protected regions of the pipeline module remain byte-identical: KAK/native-basis implementation; target resolution and input/output/readout validation; final candidate cost/preference; and the complete routing-reuse, retained-candidate, numerical-fork and public-execution implementation. Removing the new read-only pass-name accessor leaves the pass-manager source byte-identical. These checks are mechanical, not substitutes for semantic tests of the selector or compiled artifact.

## Reviewed selector behavior

The study selector requires O3, a backend, basis decomposition, post-routing cleanup and canonical retained-candidate handling. It resets routing options to the prescribed common policy, then gates groups without altering their implementation. The normal public configuration retains `study_recipe=None`. The copied runner accepts R0 through R6 and rejects other values and unknown/free-form knobs; ordinary input/transport fields and the explicitly permitted profiling control remain available.

| Group | Registration change | Important consequence |
|---|---|---|
| R0 | Mandatory high-arity reduction, basic BeamSabre, target translation, decomposition/KAK, direction repair and closure | Identity starting placement; routing beam/branch/bidirectional settings 1/1/1 |
| R1 | Crystallization/parameter simplification and post-lowering fusion/parameter simplification | Uses unchanged numerical acceptance |
| R2 | Rotation, conjugation, inverse/commutation cancellation, phase recovery and diagonal dependency handling | Alters routing dependencies as well as algebraic simplification |
| R3 | Two-qubit block synthesis and checked post-block fusion | Both run after routed-basis lowering, with existing acceptance rules |
| R4 | Encoded SWAP/Clifford, output permutations, trailing-SWAP elision, SWAP orientation/simplification | Canonical quality continuations can add complete route/lower work |
| R5 | SABRE placement at 10 trials and 3 refinements | Includes any canonical refined-route alternatives made available by placement |
| R6 | Beam/branch/bidirectional settings 8/5/4 | The final increment changes the prescribed search budget |

Lookahead, static weighting, progress ranking and canonical retention policy remain common. Branch reuse includes the study recipe in its context key. Input/output validators, spare-wire maps, numerical forks and final candidate-selection guards are unchanged. Stage gating does not bypass high-arity decomposition, direction repair or basis closure. A registration list describes the configured passes; it is not evidence that every possible retained branch ran or that a rewrite was accepted. Those questions require actual development traces and counters.

## Timing and parity boundary

Every experimental arm uses the same binary and pays for the configuration snapshot inside the compile timer. The timer also includes backend/configuration construction and compiler-internal validation/numerical acceptance. Selector parsing and report-plan construction are outside that timer; independent output verification is outside it. R6's old-native parity excludes only documented parse/compile/pass clocks and the new recipe metadata. It must preserve every output, map, counter, ledger and other report field.

The source review identified and resolved one ambiguous metadata sentence: “excludes validation” was changed to distinguish independent output verification from compiler-internal checks. Unknown algorithm-looking fields were also made strict errors. Neither change alters a transformation algorithm.

The development admission remains qualified. The first, spare-width campaign recorded 144 independent passes, 144 declared-output-width contract failures and 24 barrier-parser unsupported outcomes. The equal-width revision matches the formal target contract and records 288 independent passes, 24 barrier-parser unsupported outcomes and 104 exact native/R6 parity pairs. These counts were communicated by the compiler-control owner and must be checked against its final receipts when packaged. The strict checker and compiler outputs were not changed to erase unsupported cases. Separate Rust spare-wire/barrier/readout tests are implementation evidence, not replacement independent-oracle verdicts.

Artifact parity does not prove runtime equivalence to the older native binary, correctness on every possible input, or support for implicit unused spare-wire serialization. A disabled-pass experiment also does not establish reduced binary/source size or memory consumption: every arm uses the same binary containing every group.

No production files or prior results were modified during this review. No selected held-out compiler observation was inspected.
