"""Independent pre-timing audit; reads frozen data but never runs a compiler."""
from __future__ import annotations

import argparse
from collections import Counter, defaultdict
import hashlib
import json
from pathlib import Path

from independent_audit import Plan, audit_recipe_metadata, audit_schedule, canonical, require

TOOLS = tuple([f"R{i}" for i in range(7)] + ["qiskit", "cirq", "tket"])
SELECTION_SHA256 = "a5caec1fc15c4ef2072a469140d84f6262174fc5856b74016d95501fda60dffb"
CLONE_SHA256 = "b8016c01400959617412bb143b53f4795163d51a2462a5c1fe86bff98a712d6b"
MASTER_SEED = 20261020


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def bound(path, expected):
    require(sha(path) == expected, f"bound file changed: {path}")
    return json.loads(Path(path).read_text())


def edges(width, topology):
    if topology == "all_to_all":
        return [[a, b] for a in range(width) for b in range(a + 1, width)]
    if topology == "linear":
        return [[a, a + 1] for a in range(width - 1)]
    require(topology == "grid" and width in (6, 10, 14), "unexpected target")
    columns = width // 2
    result = []
    for q in range(width):
        if q % columns < columns - 1:
            result.append([q, q + 1])
        if q < columns:
            result.append([q, q + columns])
    return sorted(result)


def audit(args):
    protocol_path = args.study / "protocol.json"
    protocol = bound(protocol_path, args.expected_protocol_sha256)
    require((args.study / "protocol.sha256").read_text().strip() == args.expected_protocol_sha256,
            "protocol sidecar mismatch")
    plan = bound(args.plan, protocol["heldout_plan_sha256"])
    require(canonical(plan) == canonical(protocol["heldout_plan"]), "embedded plan mismatch")
    require(plan["selection_sha256"] == protocol["selection_sha256"] == SELECTION_SHA256,
            "prespecified selection changed")
    require(plan["tools"] == list(TOOLS) and plan["qrust_arms"] == list(TOOLS[:7]), "recipe set/order changed")
    require(plan["trials"] == 5 and plan["sessions"] == 2 and plan["warmups_per_cell_tool"] == 1,
            "trial/session/warmup policy changed")
    require(plan["master_seed"] == MASTER_SEED, "schedule seed changed")
    require(plan["maximum_candidate_cases"] == 54 and plan["maximum_timed_slots"] == 5400
            and plan["maximum_initial_warmup_slots"] == 1080, "prescribed denominator changed")

    clone = bound(args.clone_freeze, CLONE_SHA256)
    require(protocol["experimental_clone_sha256"] == CLONE_SHA256, "clone binding changed")
    require(canonical(protocol["experimental_clone"]) == canonical(clone), "embedded clone mismatch")
    require(set(protocol["recipes"]) == set(TOOLS), "recipe inventory mismatch")
    for index in range(7):
        name = f"R{index}"
        audit_recipe_metadata(clone["recipes"][name], index)
        require(canonical(protocol["recipes"][name]) == canonical(clone["recipes"][name]), "protocol recipe differs from compiled clone contract")

    native = json.loads(args.reference_protocol.read_text())
    for sdk in ("qiskit", "cirq", "tket"):
        require(canonical(protocol["recipes"][sdk]) == canonical(native["recipes"][sdk]), f"contextual SDK recipe changed: {sdk}")
    freeze = bound(args.compiler_freeze, protocol["compiler_freeze_sha256"])
    require(canonical(protocol["compiler_freeze"]) == canonical(freeze), "embedded public compiler freeze mismatch")
    helper_bindings = protocol["harness_source_sha256"]
    require(bool(helper_bindings), "missing harness source bindings")
    for name, digest in helper_bindings.items():
        require(sha(name) == digest, f"harness source mutation: {name}")

    cases = protocol["cases"]
    ids = [c["id"] for c in cases]
    require(bool(cases) and len(ids) == len(set(ids)) and len(cases) <= 54, "invalid selected case denominator")
    fixture_cases = defaultdict(list)
    for case in cases:
        width, topology = case["n_logical"], case["topology"]
        require(type(width) is int and width in (6, 10, 14) and case["physical_width"] == width,
                "formal width contract changed")
        require(case["edges"] == edges(width, topology), "physical labels or edge list changed")
        fixture_cases[case["fixture"]].append(case)
    for fixture, selected in fixture_cases.items():
        require(len(selected) == 3 and {c["topology"] for c in selected} == {"all_to_all", "linear", "grid"},
                f"fixture target denominator incomplete: {fixture}")
        for key in ("n_logical", "family", "coarse_family", "holdout_class"):
            require(len({c[key] for c in selected}) == 1, f"fixture metadata differs by target: {fixture}/{key}")

    require(set(protocol["schedules"]) == {"1", "2"}, "schedule session keys changed")
    projected = []
    for session in (1, 2):
        seen_cases, current_case, case_order = set(), None, -1
        for row in protocol["schedules"][str(session)]:
            if row["case_id"] != current_case:
                require(row["case_id"] not in seen_cases, "case scheduling block is repeated")
                seen_cases.add(row["case_id"])
                current_case, case_order = row["case_id"], case_order + 1
            require(type(row["case_order"]) is int and row["case_order"] == case_order,
                    "case_order metadata differs from actual sequence")
            require(type(row["trial"]) is int and -1 <= row["trial"] < 5, "invalid scheduled trial")
            require(row["seed"] == MASTER_SEED + max(row["trial"], 0), "requested trial seed changed")
            require(row["rotation"] == (None if row["trial"] == -1 else 5 * (session - 1) + row["trial"]),
                    "cross-session rotation changed")
            require(type(row["tool_order"]) is int and 0 <= row["tool_order"] < 10, "invalid tool order")
            projected.append({"session": str(session), "case_id": row["case_id"], "recipe": row["tool"],
                              "phase": "warmup" if row["trial"] == -1 else "timed",
                              "trial": None if row["trial"] == -1 else row["trial"]})
        groups = defaultdict(list)
        for row in protocol["schedules"][str(session)]:
            groups[(row["case_id"], row["trial"])].append(row["tool_order"])
        require(all(values == list(range(10)) for values in groups.values()), "tool_order metadata differs from actual sequence")
    positions = audit_schedule(Plan(("1", "2"), tuple(ids), TOOLS, 5), projected)
    require(len(projected) == len(cases) * 10 * 6 * 2, "request denominator drift")
    require(protocol["analysis"] == plan["analysis"], "analysis plan changed")
    require(plan["analysis"]["metrics"] == ["compile_ns", "parse_compile_ns", "cx_count", "gate_count", "depth", "two_q_depth"],
            "metric endpoints changed")
    require(plan["analysis"]["per_session"] is True, "sessions pooled")
    require(plan["analysis"]["quality_retention"]["relative_overheads"] == [0, .05, .10], "retention thresholds changed")
    require("not peak RSS" in plan["resource_policy"], "RSS boundary absent")
    return {
        "schema": "qrust_independent_frozen_protocol_audit_v1", "passed": True,
        "protocol_sha256": args.expected_protocol_sha256, "clone_freeze_sha256": CLONE_SHA256,
        "reference_protocol_sha256": sha(args.reference_protocol), "compiler_freeze_sha256": sha(args.compiler_freeze),
        "plan_sha256": sha(args.plan), "helper_bindings_verified": len(helper_bindings),
        "selected_fixtures": len(fixture_cases), "selected_cases": len(cases),
        "selected_by_family": dict(sorted(Counter(c[0]["family"] for c in fixture_cases.values()).items())),
        "scheduled_requests": len(projected), "timed_requests": len(cases) * 100,
        "initial_warmups": len(cases) * 20,
        "position_check": "Every recipe occupies each of ten timed positions once per case across two sessions.",
        "position_counts": positions,
        "source_sha256": {Path(__file__).name: sha(__file__), "independent_audit.py": sha(Path(__file__).with_name("independent_audit.py"))},
        "scope": "Read-only pre-timing protocol/recipe/schedule/denominator audit. No compiler execution, selected compiler output or timing observation. Installed environments, generator mathematics and completed-campaign semantics require their separately bound checks.",
    }


def main():
    parser = argparse.ArgumentParser()
    for name in ("study", "plan", "clone-freeze", "compiler-freeze", "reference-protocol", "output"):
        parser.add_argument("--" + name, type=Path, required=True)
    parser.add_argument("--expected-protocol-sha256", required=True)
    args = parser.parse_args()
    require(not args.output.exists(), "refusing to replace prior protocol audit")
    result = audit(args)
    args.output.write_text(json.dumps(result, indent=2, sort_keys=True, allow_nan=False) + "\n")
    print(json.dumps({key: result[key] for key in ("passed", "selected_cases", "timed_requests", "initial_warmups", "protocol_sha256")}))


if __name__ == "__main__":
    main()
