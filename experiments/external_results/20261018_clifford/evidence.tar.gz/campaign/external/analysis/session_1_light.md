# Corrected-fixture compiler comparison

The prescribed corpus contains 50 fixtures and 100 fixture–topology cells. The study retained 2800 timed trials and 2800 validation records; 0 compiler–cell combinations were ineligible for paired analysis.

Only cells with every prescribed trial successful and independently validated contribute to comparisons. Results below use per-cell medians. Brackets are 95% fixture-cluster bootstrap intervals; they preserve the relationship between multiple topologies of the same fixture.

## Compilation speed

Ratios are baseline time divided by Q-Rust time; a value above 1 favors Q-Rust. These are warm API compilation measurements. Parsing is reported separately; startup, imports, serialization and validation are excluded.

| Baseline | Paired cells | Compile speed ratio [95% CI] | Parse + compile ratio [95% CI] | Q-Rust compile win/tie/loss |
|---|---:|---:|---:|---:|
| qiskit | 100 | 3.09 [2.08, 4.4] | 3.25 [2.35, 4.63] | 75/0/25 |
| cirq | 100 | 43.3 [37.4, 49.8] | 51.5 [44.3, 59.4] | 100/0/0 |
| tket | 100 | 22.9 [19.7, 26.9] | 23.6 [20.2, 27.4] | 100/0/0 |

## Output quality

Ratios are Q-Rust divided by the baseline; a value below 1 favors Q-Rust. CX count and depth are structural cost measures, not execution fidelity. Zero/zero and one-sided-zero comparisons remain in win/tie/loss counts but are excluded from geometric means.

| Baseline | CX ratio [95% CI] | CX win/tie/loss | Depth ratio [95% CI] | Depth win/tie/loss | CX zero cases (both / Q-Rust / baseline) |
|---|---:|---:|---:|---:|---:|
| qiskit | 0.921 [0.861, 0.976] | 25/68/7 | 0.876 [0.815, 0.928] | 46/47/7 | 2/0/0 |
| cirq | 0.71 [0.654, 0.768] | 65/35/0 | 0.602 [0.546, 0.66] | 83/17/0 | 2/0/0 |
| tket | 0.661 [0.567, 0.75] | 58/42/0 | 0.727 [0.625, 0.819] | 56/37/7 | 2/0/0 |

## Secondary family-balanced comparison

The primary tables weight each eligible cell equally. This secondary summary first averages log ratios within each family, then weights the represented families equally. Its intervals resample fixture clusters within each fixed family. Families with no positive ratios for a metric are excluded from that metric and recorded in the JSON.

| Baseline | Compile speed ratio [95% CI] | CX ratio [95% CI] | Depth ratio [95% CI] | Families (speed / CX / depth) |
|---|---:|---:|---:|---:|
| qiskit | 3.62 [3.27, 4.03] | 0.911 [0.898, 0.926] | 0.876 [0.867, 0.885] | 38 / 37 / 38 |
| cirq | 43.7 [42.4, 45.2] | 0.718 [0.705, 0.729] | 0.619 [0.609, 0.629] | 38 / 37 / 38 |
| tket | 23.2 [22.2, 24.3] | 0.679 [0.656, 0.703] | 0.741 [0.721, 0.764] | 38 / 37 / 38 |

Among the 100 cells eligible for all four tools:

| Metric | Q-Rust at or better than best baseline | Within 5% of best baseline | Within 10% of best baseline | Best baseline is zero |
|---|---:|---:|---:|---:|
| cx_count | 93/100 (93.0%) | 96/100 (96.0%) | 96/100 (96.0%) | 2/100 |
| depth | 87/100 (87.0%) | 92/100 (92.0%) | 95/100 (95.0%) | 0/100 |
| two_q_depth | 93/100 (93.0%) | 94/100 (94.0%) | 96/100 (96.0%) | 2/100 |

The observed best baseline is the minimum median among Qiskit, Cirq and TKET, not a proven optimum. When the best baseline count is zero, only a zero-count Q-Rust result is within 5% or 10%. The JSON additionally records ratios and bands against the best of all four tools.

## Topology and family breakdowns

| Group | Baseline | Cells | Compile speed ratio [95% CI] | CX ratio [95% CI] | Depth ratio [95% CI] |
|---|---|---:|---:|---:|---:|
| all_to_all | qiskit | 50 | 3.99 [2.84, 5.59] | 0.944 [0.878, 1] | 0.912 [0.839, 0.973] |
| all_to_all | cirq | 50 | 44.8 [38.7, 52] | 0.85 [0.785, 0.913] | 0.751 [0.689, 0.812] |
| all_to_all | tket | 50 | 22.8 [20.9, 25] | 0.733 [0.622, 0.839] | 0.774 [0.654, 0.882] |
| linear | qiskit | 50 | 2.4 [1.52, 3.71] | 0.899 [0.844, 0.954] | 0.842 [0.786, 0.9] |
| linear | cirq | 50 | 41.8 [34.3, 51.1] | 0.593 [0.53, 0.661] | 0.483 [0.422, 0.55] |
| linear | tket | 50 | 23 [17.7, 30] | 0.596 [0.506, 0.689] | 0.683 [0.592, 0.776] |
| adder | qiskit | 4 | 3.27 [1.77, 6.02] | 1 [1, 1] | 0.97 [0.942, 1] |
| adder | cirq | 4 | 72.6 [56.6, 93.2] | 0.77 [0.712, 0.834] | 0.546 [0.522, 0.57] |
| adder | tket | 4 | 16.4 [15.3, 17.7] | 0.929 [0.889, 0.97] | 0.905 [0.899, 0.911] |
| ae | qiskit | 4 | 0.882 [0.486, 1.6] | 0.904 [0.901, 0.906] | 0.923 [0.915, 0.932] |
| ae | cirq | 4 | 29 [24.2, 34.7] | 0.577 [0.534, 0.624] | 0.666 [0.66, 0.672] |
| ae | tket | 4 | 13.2 [9.8, 17.8] | 0.518 [0.5, 0.536] | 0.772 [0.761, 0.783] |
| basis_change | qiskit | 2 | 4.89 | 1 | 1 |
| basis_change | cirq | 2 | 52.2 | 0.953 | 0.956 |
| basis_change | tket | 2 | 39.1 | 1 | 1 |
| basis_trotter | qiskit | 4 | 0.628 [0.132, 2.99] | 1.34 [1.08, 1.67] | 1.23 [1.05, 1.44] |
| basis_trotter | cirq | 4 | 33.5 [16, 70.2] | 0.36 [0.266, 0.487] | 0.344 [0.243, 0.488] |
| basis_trotter | tket | 4 | 18.3 [10.8, 30.9] | 0.284 [0.217, 0.372] | 0.311 [0.25, 0.386] |
| bell | qiskit | 2 | 6.12 | 1 | 1 |
| bell | cirq | 2 | 38.3 | 0.674 | 0.577 |
| bell | tket | 2 | 28.2 | 0.714 | 0.825 |
| bv | qiskit | 2 | 2.76 | 1 | 0.728 |
| bv | cirq | 2 | 43.8 | 0.562 | 0.348 |
| bv | tket | 2 | 105 | 0.372 | 0.547 |
| cat_state | qiskit | 2 | 24.7 | 1 | 1 |
| cat_state | cirq | 2 | 108 | 0.48 | 0.33 |
| cat_state | tket | 2 | 12.5 | 1 | 1 |
| deutsch | qiskit | 2 | 23.8 | 1 | 1 |
| deutsch | cirq | 2 | 35.9 | 1 | 1 |
| deutsch | tket | 2 | 25.8 | 1 | 1 |
| dj | qiskit | 4 | 4.99 [3.4, 7.33] | 0.832 [0.775, 0.894] | 0.711 [0.697, 0.726] |
| dj | cirq | 4 | 35.9 [35.2, 36.6] | 0.795 [0.73, 0.866] | 0.485 [0.42, 0.56] |
| dj | tket | 4 | 42.5 [20, 90.3] | 0.553 [0.45, 0.679] | 0.69 [0.583, 0.816] |
| dnn | qiskit | 4 | 0.527 [0.21, 1.32] | 1 [1, 1] | 1 [1, 1] |
| dnn | cirq | 4 | 14.5 [11.7, 18] | 0.974 [0.949, 1] | 0.889 [0.79, 1] |
| dnn | tket | 4 | 26.3 [16.9, 41] | 0.167 [0.0714, 0.389] | 0.181 [0.0824, 0.396] |
| error_correctiond3 | qiskit | 2 | 2.47 | 0.408 | 0.302 |
| error_correctiond3 | cirq | 2 | 65.2 | 0.396 | 0.256 |
| error_correctiond3 | tket | 2 | 36.8 | 0.301 | 0.252 |
| fredkin | qiskit | 2 | 6.42 | 1 | 0.97 |
| fredkin | cirq | 2 | 49.5 | 0.894 | 0.578 |
| fredkin | tket | 2 | 14.6 | 0.926 | 0.943 |
| grover | qiskit | 4 | 2.99 [0.567, 15.8] | 0.707 [0.5, 1] | 0.746 [0.6, 0.928] |
| grover | cirq | 4 | 40.3 [38.2, 42.6] | 0.683 [0.5, 0.932] | 0.662 [0.6, 0.731] |
| grover | tket | 4 | 18.3 [10.6, 31.8] | 0.657 [0.5, 0.863] | 0.728 [0.6, 0.884] |
| hhl | qiskit | 2 | 0.367 | 0.929 | 1.04 |
| hhl | cirq | 2 | 27.2 | 0.878 | 0.812 |
| hhl | tket | 2 | 13.5 | 0.501 | 0.478 |
| hs4 | qiskit | 2 | 12.9 | 0.5 | 0.6 |
| hs4 | cirq | 2 | 64.2 | 0.316 | 0.308 |
| hs4 | tket | 2 | 31.6 | 0.5 | 0.6 |
| ising | qiskit | 2 | 0.899 | 0.931 | 1.26 |
| ising | cirq | 2 | 47.2 | 0.796 | 0.855 |
| ising | tket | 2 | 24.4 | 0.931 | 1.26 |
| iswap | qiskit | 2 | 18.5 | 0.5 | 0.6 |
| iswap | cirq | 2 | 41.9 | 0.5 | 0.6 |
| iswap | tket | 2 | 32 | 0.5 | 0.6 |
| linearsolver | qiskit | 2 | 10.5 | 1 | 1 |
| linearsolver | cirq | 2 | 50.5 | 0.756 | 0.775 |
| linearsolver | tket | 2 | 25.2 | 1 | 1 |
| lpn | qiskit | 2 | 17.9 | 1 | 1 |
| lpn | cirq | 2 | 51.2 | 1 | 0.8 |
| lpn | tket | 2 | 33.6 | 1 | 1 |
| multiply | qiskit | 2 | 1.44 | 1 | 0.892 |
| multiply | cirq | 2 | 52 | 0.653 | 0.494 |
| multiply | tket | 2 | 10.3 | 0.743 | 0.72 |
| pea | qiskit | 2 | 1.8 | 0.833 | 0.84 |
| pea | cirq | 2 | 30 | 0.811 | 0.857 |
| pea | tket | 2 | 17.6 | 0.383 | 0.37 |
| qaoa | qiskit | 2 | 0.704 | 0.972 | 0.921 |
| qaoa | cirq | 2 | 21.1 | 0.884 | 0.797 |
| qaoa | tket | 2 | 23.5 | 0.631 | 0.724 |
| qec_en | qiskit | 2 | 5.83 | 0.943 | 0.772 |
| qec_en | cirq | 2 | 63.4 | 0.853 | 0.477 |
| qec_en | tket | 2 | 22.1 | 0.784 | 0.788 |
| qft | qiskit | 2 | 3.7 | 0.939 | 0.965 |
| qft | cirq | 2 | 33 | 0.889 | 0.965 |
| qft | tket | 2 | 16.7 | 0.845 | 1.01 |
| qnn | qiskit | 4 | 7.02 [5.5, 8.96] | 1 [1, 1] | 0.621 [0.579, 0.667] |
| qnn | cirq | 4 | 58.9 [53.7, 64.5] | 0.698 [0.688, 0.707] | 0.443 [0.404, 0.485] |
| qnn | tket | 4 | 33.5 [31.1, 36] | 1 [1, 1] | 1 [1, 1] |
| qpeexact | qiskit | 4 | 0.906 [0.505, 1.62] | 0.871 [0.81, 0.937] | 0.831 [0.795, 0.869] |
| qpeexact | cirq | 4 | 23.9 [20.7, 27.5] | 0.689 [0.671, 0.708] | 0.689 [0.664, 0.714] |
| qpeexact | tket | 4 | 15.3 [11.5, 20.3] | 0.58 [0.561, 0.599] | 0.756 [0.739, 0.773] |
| qpeinexact | qiskit | 4 | 0.919 [0.509, 1.66] | 0.909 [0.88, 0.939] | 0.839 [0.808, 0.871] |
| qpeinexact | cirq | 4 | 23.9 [21, 27.1] | 0.696 [0.679, 0.714] | 0.675 [0.637, 0.715] |
| qpeinexact | tket | 4 | 15.1 [11.3, 20.2] | 0.618 [0.61, 0.625] | 0.816 [0.805, 0.826] |
| qrng | qiskit | 2 | 28.9 | undefined (no positive pairs) | 1 |
| qrng | cirq | 2 | 21.6 | undefined (no positive pairs) | 1 |
| qrng | tket | 2 | 45.4 | undefined (no positive pairs) | 1 |
| quantumwalks | qiskit | 2 | 12.5 | 1 | 1 |
| quantumwalks | cirq | 2 | 42.2 | 1 | 1 |
| quantumwalks | tket | 2 | 45.8 | 1 | 1 |
| qwalk | qiskit | 2 | 0.364 | 1.02 | 0.981 |
| qwalk | cirq | 2 | 38 | 0.896 | 0.76 |
| qwalk | tket | 2 | 9.13 | 0.928 | 0.933 |
| sat | qiskit | 4 | 0.783 [0.487, 1.26] | 0.983 [0.982, 0.985] | 0.917 [0.913, 0.92] |
| sat | cirq | 4 | 58.8 [53.4, 64.8] | 0.755 [0.752, 0.757] | 0.588 [0.563, 0.613] |
| sat | tket | 4 | 12 [9.96, 14.4] | 0.871 [0.84, 0.904] | 0.875 [0.849, 0.902] |
| simon | qiskit | 2 | 3.5 | 1 | 0.96 |
| simon | cirq | 2 | 54.6 | 0.844 | 0.801 |
| simon | tket | 2 | 16.3 | 0.92 | 0.935 |
| teleportation | qiskit | 2 | 18.6 | 1 | 0.8 |
| teleportation | cirq | 2 | 54.8 | 0.816 | 0.676 |
| teleportation | tket | 2 | 22.5 | 1 | 1 |
| toffoli | qiskit | 2 | 7.61 | 1 | 0.931 |
| toffoli | cirq | 2 | 52.1 | 0.837 | 0.756 |
| toffoli | tket | 2 | 18 | 0.882 | 0.901 |
| variational | qiskit | 2 | 5.96 | 1 | 1 |
| variational | cirq | 2 | 43.6 | 0.73 | 0.67 |
| variational | tket | 2 | 32.8 | 0.5 | 0.542 |
| vqe_real_amp | qiskit | 4 | 6.64 [5.14, 8.58] | 1 [1, 1] | 1 [1, 1] |
| vqe_real_amp | cirq | 4 | 123 [110, 138] | 0.721 [0.688, 0.756] | 0.44 [0.394, 0.492] |
| vqe_real_amp | tket | 4 | 41 [38.9, 43.3] | 1 [1, 1] | 1 [1, 1] |
| vqe_su2 | qiskit | 4 | 4.45 [3.39, 5.85] | 1 [1, 1] | 0.876 [0.857, 0.895] |
| vqe_su2 | cirq | 4 | 83.3 [77.7, 89.3] | 0.721 [0.688, 0.756] | 0.44 [0.394, 0.492] |
| vqe_su2 | tket | 4 | 43.5 [43.1, 43.9] | 1 [1, 1] | 1 [1, 1] |
| wstate | qiskit | 2 | 5.16 | 0.894 | 0.889 |
| wstate | cirq | 2 | 46.8 | 0.608 | 0.586 |
| wstate | tket | 2 | 16.2 | 0.596 | 0.691 |

## Tradeoffs and failure tails

A pipeline is on the Pareto frontier when no other measured pipeline is at least as good on every listed metric and strictly better on one. Frontiers use per-cell medians and count tied pipelines separately.

| Objectives | Q-Rust | Qiskit | Cirq | TKET |
|---|---:|---:|---:|---:|
| speed_cx | 84/100 | 28/100 | 0/100 | 0/100 |
| speed_depth | 87/100 | 27/100 | 0/100 | 6/100 |
| speed_cx_depth | 89/100 | 28/100 | 0/100 | 6/100 |

| Baseline | Worst CX excess case | Q-Rust CX / baseline CX | Slowest relative case | Baseline / Q-Rust time |
|---|---|---:|---|---:|
| qiskit | qasmbench__basis_test_n4__all_to_all | 10 / 6 | qasmbench__basis_trotter_n4__linear | 0.119 |
| cirq | mqtbench__dj_n10__all_to_all | 9 / 9 | qasmbench__dnn_n8__linear | 9.68 |
| tket | mqtbench__dj_n10__all_to_all | 9 / 9 | qasmbench__sat_n11__linear | 3.49 |

## Measurement scope

The measurements support comparisons of the specified compiler recipes on these corrected, static circuits and target graphs, under the recorded single-machine conditions. Speed is summarized by paired runtime ratios; output size and depth are reported separately, including cases where Q-Rust performs worse. The per-family and per-topology tables can identify useful subsets, but a subset selected after viewing these results is exploratory and needs a separate confirmation corpus.

The experiment does not isolate the effect of Rust: the tools differ in algorithms, search effort, representations and API overhead, and competitors have native implementations. Seven trials equalize repetitions, not optimization work or runtime budgets. These recipes are documented choices, not a search over every available competitor pipeline. The fixed corpus and limited widths do not establish general scalability, hardware fidelity, or closeness to a mathematical optimum. Numerical validation is evidence for the measured outputs; sampled checks are not proofs of equivalence.

## Eligibility and reproducibility

Expected trial records: 2800. Eligible cells by tool: qrust 100, qiskit 100, cirq 100, tket 100.

Validation evidence classes: `{"full_isometry": 1960, "sampled_isometry": 840}`.

Every excluded cell and its individual trial failures are listed in `summary.json`; missing trials are explicit. `cell_summary.csv` contains all compiler–cell combinations, including exclusions. The JSON also retains zero cases, subgroup intervals, Pareto membership and the ten worst tails per baseline. Aggregate geometric means give equal weight to eligible cells, so fixtures with more target topologies contribute more cells. Bootstrap intervals resample fixture clusters and condition on positive-ratio cells; they do not correct corpus-selection bias or multiple comparisons.
