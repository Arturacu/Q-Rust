# Corrected-fixture compiler comparison

The prescribed corpus contains 50 fixtures and 100 fixture–topology cells. The study retained 2800 timed trials and 2800 validation records; 0 compiler–cell combinations were ineligible for paired analysis.

Only cells with every prescribed trial successful and independently validated contribute to comparisons. Results below use per-cell medians. Brackets are 95% fixture-cluster bootstrap intervals; they preserve the relationship between multiple topologies of the same fixture.

## Compilation speed

Ratios are baseline time divided by Q-Rust time; a value above 1 favors Q-Rust. These are warm API compilation measurements. Parsing is reported separately; startup, imports, serialization and validation are excluded.

| Baseline | Paired cells | Compile speed ratio [95% CI] | Parse + compile ratio [95% CI] | Q-Rust compile win/tie/loss |
|---|---:|---:|---:|---:|
| qiskit | 100 | 3.09 [2.08, 4.4] | 3.25 [2.35, 4.63] | 75/0/25 |
| cirq | 100 | 71.8 [60.7, 83.8] | 80.1 [69.2, 93.2] | 100/0/0 |
| tket | 100 | 194 [162, 233] | 185 [156, 219] | 100/0/0 |

## Output quality

Ratios are Q-Rust divided by the baseline; a value below 1 favors Q-Rust. CX count and depth are structural cost measures, not execution fidelity. Zero/zero and one-sided-zero comparisons remain in win/tie/loss counts but are excluded from geometric means.

| Baseline | CX ratio [95% CI] | CX win/tie/loss | Depth ratio [95% CI] | Depth win/tie/loss | CX zero cases (both / Q-Rust / baseline) |
|---|---:|---:|---:|---:|---:|
| qiskit | 0.921 [0.861, 0.976] | 25/68/7 | 0.876 [0.815, 0.928] | 46/47/7 | 2/0/0 |
| cirq | 0.72 [0.667, 0.776] | 65/35/0 | 0.606 [0.551, 0.663] | 82/16/2 | 2/0/0 |
| tket | 0.901 [0.843, 0.961] | 27/65/8 | 0.958 [0.912, 1.01] | 29/48/23 | 2/0/0 |

## Secondary family-balanced comparison

The primary tables weight each eligible cell equally. This secondary summary first averages log ratios within each family, then weights the represented families equally. Its intervals resample fixture clusters within each fixed family. Families with no positive ratios for a metric are excluded from that metric and recorded in the JSON.

| Baseline | Compile speed ratio [95% CI] | CX ratio [95% CI] | Depth ratio [95% CI] | Families (speed / CX / depth) |
|---|---:|---:|---:|---:|
| qiskit | 3.62 [3.27, 4.03] | 0.911 [0.898, 0.926] | 0.876 [0.867, 0.885] | 38 / 37 / 38 |
| cirq | 71.5 [69.5, 73.8] | 0.726 [0.714, 0.737] | 0.622 [0.612, 0.632] | 38 / 37 / 38 |
| tket | 194 [189, 199] | 0.904 [0.89, 0.919] | 0.962 [0.951, 0.974] | 38 / 37 / 38 |

Among the 100 cells eligible for all four tools:

| Metric | Q-Rust at or better than best baseline | Within 5% of best baseline | Within 10% of best baseline | Best baseline is zero |
|---|---:|---:|---:|---:|
| cx_count | 88/100 (88.0%) | 93/100 (93.0%) | 94/100 (94.0%) | 2/100 |
| depth | 75/100 (75.0%) | 79/100 (79.0%) | 87/100 (87.0%) | 0/100 |
| two_q_depth | 89/100 (89.0%) | 91/100 (91.0%) | 92/100 (92.0%) | 2/100 |

The observed best baseline is the minimum median among Qiskit, Cirq and TKET, not a proven optimum. When the best baseline count is zero, only a zero-count Q-Rust result is within 5% or 10%. The JSON additionally records ratios and bands against the best of all four tools.

## Topology and family breakdowns

| Group | Baseline | Cells | Compile speed ratio [95% CI] | CX ratio [95% CI] | Depth ratio [95% CI] |
|---|---|---:|---:|---:|---:|
| all_to_all | qiskit | 50 | 3.99 [2.84, 5.59] | 0.944 [0.878, 1] | 0.912 [0.839, 0.973] |
| all_to_all | cirq | 50 | 72.4 [60.7, 86] | 0.855 [0.793, 0.915] | 0.755 [0.693, 0.818] |
| all_to_all | tket | 50 | 284 [238, 338] | 1.02 [1, 1.06] | 1.04 [1.02, 1.08] |
| linear | qiskit | 50 | 2.4 [1.52, 3.71] | 0.899 [0.844, 0.954] | 0.842 [0.786, 0.9] |
| linear | cirq | 50 | 71.1 [57.8, 87.4] | 0.606 [0.545, 0.673] | 0.486 [0.424, 0.551] |
| linear | tket | 50 | 132 [103, 168] | 0.793 [0.698, 0.888] | 0.879 [0.805, 0.954] |
| adder | qiskit | 4 | 3.27 [1.77, 6.02] | 1 [1, 1] | 0.97 [0.942, 1] |
| adder | cirq | 4 | 136 [103, 179] | 0.729 [0.651, 0.816] | 0.531 [0.499, 0.566] |
| adder | tket | 4 | 268 [220, 327] | 0.952 [0.933, 0.97] | 0.917 [0.896, 0.939] |
| ae | qiskit | 4 | 0.882 [0.486, 1.6] | 0.904 [0.901, 0.906] | 0.923 [0.915, 0.932] |
| ae | cirq | 4 | 53.1 [45.6, 61.9] | 0.589 [0.554, 0.626] | 0.673 [0.657, 0.69] |
| ae | tket | 4 | 142 [127, 158] | 0.745 [0.721, 0.769] | 0.896 [0.854, 0.941] |
| basis_change | qiskit | 2 | 4.89 | 1 | 1 |
| basis_change | cirq | 2 | 60.3 | 0.953 | 0.956 |
| basis_change | tket | 2 | 222 | 1 | 1 |
| basis_trotter | qiskit | 4 | 0.628 [0.132, 2.99] | 1.34 [1.08, 1.67] | 1.23 [1.05, 1.44] |
| basis_trotter | cirq | 4 | 52.5 [25.1, 110] | 0.431 [0.341, 0.546] | 0.397 [0.295, 0.534] |
| basis_trotter | tket | 4 | 96.3 [53, 175] | 1.38 [0.953, 2] | 1.44 [1.11, 1.86] |
| bell | qiskit | 2 | 6.12 | 1 | 1 |
| bell | cirq | 2 | 60.7 | 0.674 | 0.577 |
| bell | tket | 2 | 179 | 1 | 1.17 |
| bv | qiskit | 2 | 2.76 | 1 | 0.728 |
| bv | cirq | 2 | 78.1 | 0.562 | 0.346 |
| bv | tket | 2 | 520 | 0.372 | 0.547 |
| cat_state | qiskit | 2 | 24.7 | 1 | 1 |
| cat_state | cirq | 2 | 206 | 0.48 | 0.33 |
| cat_state | tket | 2 | 454 | 1 | 1 |
| deutsch | qiskit | 2 | 23.8 | 1 | 1 |
| deutsch | cirq | 2 | 51.4 | 1 | 1 |
| deutsch | tket | 2 | 119 | 1 | 1 |
| dj | qiskit | 4 | 4.99 [3.4, 7.33] | 0.832 [0.775, 0.894] | 0.711 [0.697, 0.726] |
| dj | cirq | 4 | 61.5 [60.9, 62] | 0.795 [0.73, 0.866] | 0.485 [0.42, 0.56] |
| dj | tket | 4 | 372 [296, 467] | 0.553 [0.45, 0.679] | 0.69 [0.583, 0.816] |
| dnn | qiskit | 4 | 0.527 [0.21, 1.32] | 1 [1, 1] | 1 [1, 1] |
| dnn | cirq | 4 | 18.8 [17.9, 19.8] | 0.974 [0.949, 1] | 0.828 [0.685, 1] |
| dnn | tket | 4 | 50.8 [50.1, 51.4] | 0.993 [0.987, 1] | 1.01 [1, 1.02] |
| error_correctiond3 | qiskit | 2 | 2.47 | 0.408 | 0.302 |
| error_correctiond3 | cirq | 2 | 114 | 0.404 | 0.259 |
| error_correctiond3 | tket | 2 | 216 | 1.28 | 1.14 |
| fredkin | qiskit | 2 | 6.42 | 1 | 0.97 |
| fredkin | cirq | 2 | 88.2 | 0.894 | 0.625 |
| fredkin | tket | 2 | 146 | 0.926 | 0.903 |
| grover | qiskit | 4 | 2.99 [0.567, 15.8] | 0.707 [0.5, 1] | 0.746 [0.6, 0.928] |
| grover | cirq | 4 | 64.7 [56.2, 74.6] | 0.694 [0.5, 0.964] | 0.691 [0.6, 0.796] |
| grover | tket | 4 | 143 [122, 168] | 0.941 [0.886, 1] | 0.95 [0.902, 1] |
| hhl | qiskit | 2 | 0.367 | 0.929 | 1.04 |
| hhl | cirq | 2 | 38.4 | 0.931 | 0.825 |
| hhl | tket | 2 | 97.4 | 0.874 | 1.04 |
| hs4 | qiskit | 2 | 12.9 | 0.5 | 0.6 |
| hs4 | cirq | 2 | 109 | 0.316 | 0.308 |
| hs4 | tket | 2 | 143 | 1 | 1 |
| ising | qiskit | 2 | 0.899 | 0.931 | 1.26 |
| ising | cirq | 2 | 83 | 0.796 | 0.855 |
| ising | tket | 2 | 261 | 0.931 | 1.26 |
| iswap | qiskit | 2 | 18.5 | 0.5 | 0.6 |
| iswap | cirq | 2 | 62.2 | 0.5 | 0.6 |
| iswap | tket | 2 | 138 | 1 | 1 |
| linearsolver | qiskit | 2 | 10.5 | 1 | 1 |
| linearsolver | cirq | 2 | 84.9 | 0.756 | 0.775 |
| linearsolver | tket | 2 | 242 | 1 | 1 |
| lpn | qiskit | 2 | 17.9 | 1 | 1 |
| lpn | cirq | 2 | 77.3 | 1 | 0.8 |
| lpn | tket | 2 | 391 | 1 | 1 |
| multiply | qiskit | 2 | 1.44 | 1 | 0.892 |
| multiply | cirq | 2 | 99.2 | 0.658 | 0.495 |
| multiply | tket | 2 | 153 | 0.743 | 0.72 |
| pea | qiskit | 2 | 1.8 | 0.833 | 0.84 |
| pea | cirq | 2 | 47.7 | 0.884 | 0.867 |
| pea | tket | 2 | 138 | 0.811 | 0.911 |
| qaoa | qiskit | 2 | 0.704 | 0.972 | 0.921 |
| qaoa | cirq | 2 | 34.1 | 0.9 | 0.746 |
| qaoa | tket | 2 | 111 | 0.842 | 1.03 |
| qec_en | qiskit | 2 | 5.83 | 0.943 | 0.772 |
| qec_en | cirq | 2 | 111 | 0.853 | 0.477 |
| qec_en | tket | 2 | 268 | 1 | 0.976 |
| qft | qiskit | 2 | 3.7 | 0.939 | 0.965 |
| qft | cirq | 2 | 58.9 | 0.889 | 0.965 |
| qft | tket | 2 | 162 | 0.845 | 1.01 |
| qnn | qiskit | 4 | 7.02 [5.5, 8.96] | 1 [1, 1] | 0.621 [0.579, 0.667] |
| qnn | cirq | 4 | 99.6 [89.9, 110] | 0.698 [0.688, 0.707] | 0.443 [0.404, 0.485] |
| qnn | tket | 4 | 371 [350, 393] | 1 [1, 1] | 1 [1, 1] |
| qpeexact | qiskit | 4 | 0.906 [0.505, 1.62] | 0.871 [0.81, 0.937] | 0.831 [0.795, 0.869] |
| qpeexact | cirq | 4 | 45.2 [40.5, 50.5] | 0.716 [0.7, 0.732] | 0.676 [0.63, 0.725] |
| qpeexact | tket | 4 | 113 [102, 125] | 0.757 [0.697, 0.821] | 0.871 [0.803, 0.946] |
| qpeinexact | qiskit | 4 | 0.919 [0.509, 1.66] | 0.909 [0.88, 0.939] | 0.839 [0.808, 0.871] |
| qpeinexact | cirq | 4 | 45.7 [41.6, 50.1] | 0.714 [0.708, 0.72] | 0.688 [0.642, 0.737] |
| qpeinexact | tket | 4 | 114 [106, 124] | 0.756 [0.693, 0.826] | 0.849 [0.79, 0.912] |
| qrng | qiskit | 2 | 28.9 | undefined (no positive pairs) | 1 |
| qrng | cirq | 2 | 21.4 | undefined (no positive pairs) | 1 |
| qrng | tket | 2 | 156 | undefined (no positive pairs) | 1 |
| quantumwalks | qiskit | 2 | 12.5 | 1 | 1 |
| quantumwalks | cirq | 2 | 41.6 | 1 | 1 |
| quantumwalks | tket | 2 | 212 | 1 | 1 |
| qwalk | qiskit | 2 | 0.364 | 1.02 | 0.981 |
| qwalk | cirq | 2 | 70.6 | 0.902 | 0.762 |
| qwalk | tket | 2 | 155 | 0.93 | 0.936 |
| sat | qiskit | 4 | 0.783 [0.487, 1.26] | 0.983 [0.982, 0.985] | 0.917 [0.913, 0.92] |
| sat | cirq | 4 | 106 [97.3, 116] | 0.756 [0.756, 0.757] | 0.574 [0.568, 0.58] |
| sat | tket | 4 | 133 [112, 158] | 0.875 [0.84, 0.912] | 0.88 [0.852, 0.908] |
| simon | qiskit | 2 | 3.5 | 1 | 0.96 |
| simon | cirq | 2 | 97.2 | 0.844 | 0.783 |
| simon | tket | 2 | 145 | 0.92 | 0.935 |
| teleportation | qiskit | 2 | 18.6 | 1 | 0.8 |
| teleportation | cirq | 2 | 91.3 | 0.816 | 0.676 |
| teleportation | tket | 2 | 341 | 1 | 1 |
| toffoli | qiskit | 2 | 7.61 | 1 | 0.931 |
| toffoli | cirq | 2 | 89.8 | 0.837 | 0.822 |
| toffoli | tket | 2 | 166 | 0.882 | 0.901 |
| variational | qiskit | 2 | 5.96 | 1 | 1 |
| variational | cirq | 2 | 74.5 | 0.73 | 0.67 |
| variational | tket | 2 | 267 | 1 | 1.08 |
| vqe_real_amp | qiskit | 4 | 6.64 [5.14, 8.58] | 1 [1, 1] | 1 [1, 1] |
| vqe_real_amp | cirq | 4 | 226 [200, 255] | 0.721 [0.688, 0.756] | 0.44 [0.394, 0.492] |
| vqe_real_amp | tket | 4 | 808 [718, 910] | 1 [1, 1] | 1 [1, 1] |
| vqe_su2 | qiskit | 4 | 4.45 [3.39, 5.85] | 1 [1, 1] | 0.876 [0.857, 0.895] |
| vqe_su2 | cirq | 4 | 151 [138, 165] | 0.721 [0.688, 0.756] | 0.44 [0.394, 0.492] |
| vqe_su2 | tket | 4 | 587 [534, 645] | 1 [1, 1] | 1 [1, 1] |
| wstate | qiskit | 2 | 5.16 | 0.894 | 0.889 |
| wstate | cirq | 2 | 82.4 | 0.608 | 0.586 |
| wstate | tket | 2 | 142 | 0.816 | 0.925 |

## Tradeoffs and failure tails

A pipeline is on the Pareto frontier when no other measured pipeline is at least as good on every listed metric and strictly better on one. Frontiers use per-cell medians and count tied pipelines separately.

| Objectives | Q-Rust | Qiskit | Cirq | TKET |
|---|---:|---:|---:|---:|
| speed_cx | 84/100 | 28/100 | 0/100 | 8/100 |
| speed_depth | 87/100 | 27/100 | 2/100 | 20/100 |
| speed_cx_depth | 89/100 | 28/100 | 2/100 | 22/100 |

| Baseline | Worst CX excess case | Q-Rust CX / baseline CX | Slowest relative case | Baseline / Q-Rust time |
|---|---|---:|---|---:|
| qiskit | qasmbench__basis_test_n4__all_to_all | 10 / 6 | qasmbench__basis_trotter_n4__linear | 0.119 |
| cirq | mqtbench__dj_n10__all_to_all | 9 / 9 | qasmbench__qrng_n4__all_to_all | 16 |
| tket | qasmbench__basis_test_n4__all_to_all | 10 / 5 | qasmbench__sat_n11__linear | 28.5 |

## Measurement scope

The measurements support comparisons of the specified compiler recipes on these corrected, static circuits and target graphs, under the recorded single-machine conditions. Speed is summarized by paired runtime ratios; output size and depth are reported separately, including cases where Q-Rust performs worse. The per-family and per-topology tables can identify useful subsets, but a subset selected after viewing these results is exploratory and needs a separate confirmation corpus.

The experiment does not isolate the effect of Rust: the tools differ in algorithms, search effort, representations and API overhead, and competitors have native implementations. Seven trials equalize repetitions, not optimization work or runtime budgets. These recipes are documented choices, not a search over every available competitor pipeline. The fixed corpus and limited widths do not establish general scalability, hardware fidelity, or closeness to a mathematical optimum. Numerical validation is evidence for the measured outputs; sampled checks are not proofs of equivalence.

## Eligibility and reproducibility

Expected trial records: 2800. Eligible cells by tool: qrust 100, qiskit 100, cirq 100, tket 100.

Validation evidence classes: `{"full_isometry": 1960, "sampled_isometry": 840}`.

Every excluded cell and its individual trial failures are listed in `summary.json`; missing trials are explicit. `cell_summary.csv` contains all compiler–cell combinations, including exclusions. The JSON also retains zero cases, subgroup intervals, Pareto membership and the ten worst tails per baseline. Aggregate geometric means give equal weight to eligible cells, so fixtures with more target topologies contribute more cells. Bootstrap intervals resample fixture clusters and condition on positive-ratio cells; they do not correct corpus-selection bias or multiple comparisons.
