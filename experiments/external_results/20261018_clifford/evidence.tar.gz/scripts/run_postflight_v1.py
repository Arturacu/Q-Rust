#!/usr/bin/env python3
"""Run only after every frozen timing session is complete and workers exited."""
from pathlib import Path
import hashlib
import json
import os
import subprocess
import sys
import time

base = Path(__file__).resolve().parent
repo = base.parent / 'qrust_pr_publish'
campaign = base / 'campaign'
completion = json.loads((base / 'timing_completion.json').read_text())
if not completion['all_four_sessions_completed'] or (campaign / 'active.lock').exists():
    raise RuntimeError('All timing must finish before analysis')
commands = [
    ('official_and_paired_validation', [sys.executable, str(repo / 'experiments/paired_analysis.py'),
        '--repo', str(repo), '--campaign', str(campaign), '--output', str(base / 'analysis'), '--official']),
    ('external_sdk_analysis', [sys.executable, str(repo / 'experiments/analyze_external_comparison.py'),
        str(campaign / 'external'), '--bootstrap-draws', '2000']),
    ('independent_paired_replay', [sys.executable, str(repo / 'experiments/paired_analysis.py'),
        '--repo', str(repo), '--campaign', str(campaign), '--output', str(base / 'analysis_replay')]),
]
with (base / 'postflight_commands.json').open('x') as stream:
    json.dump(commands, stream, indent=2)
    stream.write('\n')
env = dict(os.environ, MPLCONFIGDIR=str(base / 'matplotlib_cache'))
# Numerical libraries stay single threaded during validation as well.
for key in ('OMP_NUM_THREADS', 'OPENBLAS_NUM_THREADS', 'MKL_NUM_THREADS', 'NUMEXPR_NUM_THREADS', 'VECLIB_MAXIMUM_THREADS'):
    env[key] = '1'
receipts = []
for name, command in commands:
    print(json.dumps({'starting': name}), flush=True)
    log_path = base / (name + '.log')
    started = time.monotonic()
    with log_path.open('x') as log:
        result = subprocess.run(command, stdout=log, stderr=subprocess.STDOUT, env=env)
    receipt = {'name': name, 'exit_code': result.returncode, 'wall_seconds': time.monotonic() - started,
               'log_sha256': hashlib.sha256(log_path.read_bytes()).hexdigest()}
    receipts.append(receipt)
    print(json.dumps(receipt), flush=True)
    if result.returncode:
        print(log_path.read_text()[-5000:], flush=True)
        raise SystemExit(result.returncode)
first = (base / 'analysis/summary.json').read_bytes()
second = (base / 'analysis_replay/summary.json').read_bytes()
if first != second:
    raise ValueError('Independent analysis replay summary differs')
with (base / 'postflight_receipt.json').open('x') as stream:
    json.dump({'all_stages_completed': True, 'stages': receipts, 'replayed_summary_byte_equal': True,
               'summary_sha256': hashlib.sha256(first).hexdigest()}, stream, indent=2)
    stream.write('\n')
print('Independent full-output replay is byte-equal; SDK analysis complete.', flush=True)
