#!/usr/bin/env python3
"""Execute the four frozen timing sessions sequentially, without validation."""
from pathlib import Path
import hashlib
import json
import os
import subprocess
import sys
import time

base = Path(__file__).resolve().parent
working = base.parent
repo = working / 'qrust_pr_publish'
campaign = base / 'campaign'
common = [sys.executable, str(repo / 'experiments/paired_campaign.py'), 'time',
          '--repo', str(repo), '--binary', str(base / 'comparison_runner_fixed'),
          '--old-binary', str(working / 'qrust_external_retention_20261018/comparison_runner_fixed'),
          '--output', str(campaign)]
commands = [dict(suite=suite, session=session, command=common + ['--suite', suite, '--session', str(session)])
            for suite, session in [('external', 1), ('external', 2), ('matched', 1), ('matched', 2)]]
with (base / 'timing_commands.json').open('x') as stream:
    json.dump(commands, stream, indent=2)
    stream.write('\n')
env = dict(os.environ, MPLCONFIGDIR=str(base / 'matplotlib_cache'))
receipts = []
for entry in commands:
    name = f"{entry['suite']}_session_{entry['session']}"
    log_path = base / (name + '.log')
    started = time.time()
    print(json.dumps({'starting': name, 'utc': time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime(started))}), flush=True)
    with log_path.open('x') as log:
        result = subprocess.run(entry['command'], stdout=log, stderr=subprocess.STDOUT, env=env)
    receipt = {'suite': entry['suite'], 'session': entry['session'], 'exit_code': result.returncode,
               'whole_process_wall_seconds': time.time() - started,
               'log_sha256': hashlib.sha256(log_path.read_bytes()).hexdigest()}
    receipts.append(receipt)
    with (base / (name + '_process_receipt.json')).open('x') as stream:
        json.dump(receipt, stream, indent=2)
        stream.write('\n')
    print(json.dumps(receipt), flush=True)
    if result.returncode:
        print(log_path.read_text()[-4000:], flush=True)
        raise SystemExit(result.returncode)
with (base / 'timing_completion.json').open('x') as stream:
    json.dump({'all_four_sessions_completed': True, 'sessions': receipts}, stream, indent=2)
    stream.write('\n')
print('All four timing sessions completed; no validation started.', flush=True)
