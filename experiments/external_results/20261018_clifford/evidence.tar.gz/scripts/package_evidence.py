#!/usr/bin/env python3
"""Package completed evidence, audit a fresh extraction, and replay its analysis.

Run only after timing, postflight validation, and the final report are complete.
Every destination is new; input records and frozen harnesses remain unchanged.
Fresh verifier durations are the sole canonical replay exclusion. Compiler,
parser, transport, resource and structural metrics remain byte-exact.
"""
from __future__ import annotations

import argparse
import gzip
import hashlib
import json
import os
from pathlib import Path, PurePosixPath
import re
import shutil
import subprocess
import sys
import tarfile


EXCLUDED_PARTS = {'.git', '__pycache__', '.pytest_cache', '.mypy_cache', '.ruff_cache',
                  'venv', '.venv', 'env', 'node_modules', 'target', 'matplotlib_cache'}
ROOT_RECEIPTS = {
    'prepare_command.json', 'timing_commands.json', 'timing_completion.json',
    'postflight_commands.json', 'postflight_receipt.json', 'canonical_replay_receipt.json',
    'original_preservation.json',
}
ROOT_HELPERS = {
    'paired_campaign.py', 'paired_analysis.py', 'quality_preflight.py',
    'test_paired_campaign.py', 'test_paired_analysis.py', 'test_quality_preflight.py',
    'preserve_baselines.py', 'run_campaign.py', 'run_postflight.py', 'run_postflight_v1.py',
    'canonical_replay.py', 'test_canonical_replay.py', 'package_evidence.py',
}


def sha(path: Path) -> str:
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def dump_new(path: Path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open('x') as stream:
        json.dump(value, stream, indent=2, sort_keys=True, allow_nan=False)
        stream.write('\n')


def require(condition, message):
    if not condition:
        raise ValueError(message)


def relative_name(value: str) -> str:
    path = PurePosixPath(value)
    require('\\' not in value and ':' not in value and path.as_posix() == value
            and not path.is_absolute() and path.parts and all(part not in ('', '.', '..') for part in path.parts),
            'Unsafe archive member: ' + value)
    return path.as_posix()


def copy_file(source: Path, target: Path):
    require(source.is_file() and not source.is_symlink(), 'Missing or symlinked input: ' + str(source))
    target.parent.mkdir(parents=True, exist_ok=True)
    with source.open('rb') as incoming, target.open('xb') as outgoing:
        shutil.copyfileobj(incoming, outgoing)
    target.chmod(0o755 if os.access(source, os.X_OK) else 0o644)


def copy_tree(source: Path, target: Path):
    require(source.is_dir() and not source.is_symlink(), 'Missing or symlinked directory: ' + str(source))
    for root, directories, filenames in os.walk(source, followlinks=False):
        directories[:] = sorted(name for name in directories if name not in EXCLUDED_PARTS)
        root = Path(root)
        for directory in directories:
            require(not (root / directory).is_symlink(), 'Symlinked directory in input tree')
        for name in sorted(filenames):
            if name.endswith(('.pyc', '.pyo')) or name == '.DS_Store':
                continue
            relative = (root / name).relative_to(source)
            copy_file(root / name, target / relative)


def verify_completed(args):
    require(not args.destination.exists(), 'Destination exists; refusing to overwrite it')
    require(not args.scratch.exists(), 'Scratch directory exists; choose a fresh path')
    require(not args.destination.is_relative_to(args.scratch) and not args.scratch.is_relative_to(args.destination),
            'Destination and scratch must be separate directory trees')
    copied_trees = [args.followup / name for name in
                    ('campaign', 'clifford_diagnostics', 'verification', 'preflight_order_v2', 'analysis_replay')]
    copied_trees += [args.analysis, args.corpus, args.matched_frozen]
    require(not any(args.scratch.is_relative_to(source) or args.destination.is_relative_to(source)
                    for source in copied_trees), 'Output directory lies inside an input evidence tree')
    require(not (args.followup / 'campaign/active.lock').exists(), 'A timing session is active')
    completion = json.loads((args.followup / 'timing_completion.json').read_text())
    require(completion.get('all_four_sessions_completed') is True, 'Timing is not complete')
    postflight = json.loads((args.followup / 'postflight_receipt.json').read_text())
    require(postflight.get('all_stages_completed') is True, 'Postflight validation is not complete')
    python_stage = [stage for stage in postflight.get('stages', [])
                    if stage.get('name') == 'python_final_with_binary']
    require(len(python_stage) == 1 and python_stage[0].get('exit_code') == 0,
            'Final Python suite with the frozen binary has not passed')
    require(sha(args.followup / 'python_final_with_binary.log') == python_stage[0]['log_sha256'],
            'Final Python validation log changed')
    require(args.report.is_file(), 'Final report must exist before packaging')
    require(args.analysis.is_dir() and (args.analysis / 'summary.json').is_file(), 'Missing final analysis')
    pair_path = args.followup / 'campaign/paired_protocol.json'
    pair = json.loads(pair_path.read_text())
    require(sha(pair_path) == (args.followup / 'campaign/paired_protocol.sha256').read_text().strip(),
            'Paired protocol checksum changed')
    require(sha(args.old_binary) == pair['old_binary_sha256'], 'Old compiler is not the frozen baseline')
    require(sha(args.new_binary) == pair['candidate_binary_sha256'], 'New compiler is not the timed candidate')
    for suite, directory in [('external', args.external_baseline), ('matched', args.matched_baseline)]:
        require(sha(directory / 'protocol.json') == pair['baseline_protocol_sha256'][suite],
                'Baseline protocol changed: ' + suite)
    for name, field in [('paired_analysis.py', 'analysis_source_sha256'), ('paired_campaign.py', 'controller_sha256')]:
        require(sha(args.repo / 'experiments' / name) == pair[field], 'Frozen source changed: ' + name)
    preservation_path = args.followup / 'original_preservation.json'
    preservation = json.loads(preservation_path.read_text())
    for record in preservation['files']:
        source = args.preservation_root / relative_name(record['path'])
        require(source.is_file() and not source.is_symlink() and source.stat().st_size == record['bytes']
                and sha(source) == record['sha256'], 'Preserved historical evidence changed: ' + record['path'])
    return pair, {'files_verified': len(preservation['files']), 'manifest_sha256': sha(preservation_path)}


def stage_inputs(args, stage: Path, pair):
    for name in ('campaign', 'clifford_diagnostics', 'verification', 'preflight_order_v2'):
        copy_tree(args.followup / name, stage / name)
    copy_tree(args.analysis, stage / 'analysis')
    copy_tree(args.followup / 'analysis_replay', stage / 'analysis_replay')
    receipts = ROOT_RECEIPTS | {path.name for path in args.followup.glob('canonical_replay*.json')}
    for name in sorted(receipts):
        source = args.followup / name
        if source.is_file():
            copy_file(source, stage / 'receipts' / name)
    require((stage / 'receipts/original_preservation.json').is_file(), 'Missing preservation manifest')
    helpers = ROOT_HELPERS | {path.name for path in args.followup.glob('*_v*.py')
                              if re.fullmatch(r'(?:run_postflight|canonical_replay)_v\d+\.py', path.name)}
    for name in sorted(helpers):
        source = args.followup / name
        if source.is_file():
            copy_file(source, stage / 'scripts' / name)
    for source in sorted(args.followup.glob('*.log')):
        copy_file(source, stage / 'logs' / source.name)
    for source in sorted((args.repo / 'experiments').glob('*.py')):
        copy_file(source, stage / 'harness/experiments' / source.name)
    for source in sorted((args.repo / 'experiments').glob('requirements*.txt')):
        copy_file(source, stage / 'harness/experiments' / source.name)
    copy_file(args.new_binary, stage / 'binaries/current/comparison_runner')
    copy_file(args.old_binary, stage / 'binaries/baseline/comparison_runner')
    for suite, directory in [('external', args.external_baseline), ('matched', args.matched_baseline)]:
        for name in ('protocol.json', 'protocol.sha256', 'corpus_manifest.json', 'validation_summary.json', 'summary.json'):
            source = directory / name
            if source.is_file():
                copy_file(source, stage / 'baseline_protocols' / suite / name)
    copy_tree(args.corpus, stage / 'corpus')
    copy_tree(args.matched_frozen, stage / 'benchpress/frozen')
    for spec in args.upstream_source:
        require('=' in spec, '--upstream-source requires LABEL=PATH')
        label, raw_path = spec.split('=', 1)
        require(re.fullmatch(r'[A-Za-z0-9_-]+', label) is not None, 'Invalid upstream label')
        source = Path(raw_path).resolve()
        require(source.is_dir(), 'Missing upstream source directory')
        legal = [p for p in source.iterdir() if p.is_file() and
                 p.name.lower().startswith(('license', 'notice', 'copying', 'readme'))]
        require(any(p.name.lower().startswith(('license', 'copying')) for p in legal),
                'No upstream license found: ' + label)
        for path in sorted(legal):
            copy_file(path, stage / 'upstream_legal' / label / path.name)
    copy_file(args.report, stage / 'report' / args.report.name)
    for name in ('LICENSE', 'LICENSE-MIT', 'LICENSE-APACHE', 'Cargo.toml', 'Cargo.lock'):
        source = args.repo / name
        if source.is_file():
            copy_file(source, stage / 'compiler_source' / name)
    for name in ('src/transpiler/encoded_swaps.rs', 'src/transpiler/clifford_simplification.rs',
                 'src/transpiler/optimization.rs', 'src/transpiler/mod.rs', 'src/transpiler/report.rs',
                 'experiments/src/bin/comparison_runner.rs', 'tests/clifford_optimization_regressions.rs',
                 'tests/two_qubit_block_regressions.rs'):
        copy_file(args.repo / name, stage / 'compiler_source' / name)
    dump_new(stage / 'evidence_index.json', {
        'schema': 1,
        'compiler_commit': pair['compiler_commit'],
        'candidate_binary_sha256': pair['candidate_binary_sha256'],
        'old_binary_sha256': pair['old_binary_sha256'],
        'authoritative_timing': 'campaign/',
        'authoritative_frozen_analysis_and_adapters': 'harness/experiments/',
        'final_analysis': 'analysis/',
        'fresh_prepackage_analysis_replay': 'analysis_replay/',
        'development_diagnostics': 'clifford_diagnostics/order_v1 and order_v2 are untimed mechanism/ablation evidence; timings there are not benchmark results.',
        'development_preflight_sources': 'preflight_order_v2/source_version preserves the original preflight drivers and posthoc classification source. Final frozen drivers live in harness/experiments. They must not be substituted for one another.',
        'outside_helpers': 'scripts/ preserves all numbered run_postflight_v*.py and canonical_replay_v*.py revisions, final helpers, and test_canonical_replay.py. Root canonical_replay*.json receipts and all root logs are retained. Absolute historical paths are provenance, not portable replay inputs.',
        'final_python_validation': 'logs/python_final_with_binary.log and receipts/postflight_receipt.json retain the final suite executed with QRUST_COMPARISON_BINARY explicitly bound to the frozen candidate. Earlier development logs are not substituted for it.',
        'fuzz_history': 'verification/ retains initial harness receipts, corrected replay receipts, and unchanged compiler outputs; see pipeline_fuzz_harness_correction.json.',
        'compiler_source_scope': 'Changed compiler/test source files and Cargo manifests; frozen binaries plus the recorded Git commit identify the complete compiler.',
        'dependencies': 'Use harness/experiments/requirements-comparison.txt for this campaign. requirements.txt is an older baseline lock retained for provenance.',
        'portable_replay': 'python harness/experiments/paired_analysis.py --repo harness --campaign campaign --output NEW_ANALYSIS_DIRECTORY',
        'portable_comparison': 'python scripts/canonical_replay.py --reference analysis --replay NEW_ANALYSIS_DIRECTORY --output NEW_RECEIPT.json',
        'replay_exclusion': 'Only fresh validation.validation_ns is excluded; derived summary row hashes use canonical rows. Raw analyses and compiler/parse/request timings remain unchanged.',
        'binary_portability': 'Frozen native binaries retain their original host architecture. Analysis replay uses Python and does not execute them.',
    })


def audit_prose(stage: Path, rejected_text):
    for path in stage.rglob('*'):
        if not path.is_file() or path.suffix.lower() not in ('.py', '.md', '.txt', '.rst'):
            continue
        text = path.read_text(errors='strict')
        require(not any(phrase.casefold() in text.casefold() for phrase in rejected_text),
                'Rejected text in staged file: ' + str(path.relative_to(stage)))


def manifest_and_archive(stage: Path, archive: Path):
    records = {}
    for path in sorted(stage.rglob('*')):
        if path.is_file():
            records[path.relative_to(stage).as_posix()] = {'bytes': path.stat().st_size, 'sha256': sha(path)}
    manifest = {'schema': 1, 'files': records,
                'scope': 'Every archive payload file except this self-referential manifest. The manifest and whole archive are independently bound by checksums.json.'}
    dump_new(stage / 'sha256_manifest.json', manifest)
    with archive.open('xb') as raw:
        with gzip.GzipFile(filename='', mode='wb', fileobj=raw, mtime=0) as compressed:
            with tarfile.open(fileobj=compressed, mode='w') as tar:
                for path in sorted(stage.rglob('*')):
                    if not path.is_file():
                        continue
                    info = tar.gettarinfo(str(path), arcname=path.relative_to(stage).as_posix())
                    info.uid = info.gid = info.mtime = 0
                    info.uname = info.gname = ''
                    info.mode = 0o755 if os.access(path, os.X_OK) else 0o644
                    with path.open('rb') as stream:
                        tar.addfile(info, stream)
    return manifest


def extract_and_audit(archive: Path, destination: Path):
    destination.mkdir(parents=True, exist_ok=False)
    names = set()
    with tarfile.open(archive, 'r:gz') as tar:
        for member in tar:
            name = relative_name(member.name)
            require(member.isfile() and name not in names, 'Nonregular or duplicate archive member')
            names.add(name)
            target = destination / name
            target.parent.mkdir(parents=True, exist_ok=True)
            source = tar.extractfile(member)
            require(source is not None, 'Missing archive payload')
            with source, target.open('xb') as output:
                shutil.copyfileobj(source, output)
            target.chmod(0o755 if member.mode & 0o111 else 0o644)
    manifest = json.loads((destination / 'sha256_manifest.json').read_text())
    require(names == set(manifest['files']) | {'sha256_manifest.json'}, 'Archive file inventory differs from manifest')
    for name, record in manifest['files'].items():
        relative_name(name)
        path = destination / name
        require(path.stat().st_size == record['bytes'] and sha(path) == record['sha256'],
                'Extracted file mismatch: ' + name)
    return {'all_payload_hashes_match': True, 'payload_files': len(manifest['files']),
            'manifest_sha256': sha(destination / 'sha256_manifest.json')}


def run_command(command, cwd, log, env, timeout):
    with log.open('x') as stream:
        result = subprocess.run(command, cwd=cwd, env=env, stdout=stream, stderr=subprocess.STDOUT,
                                timeout=timeout)
    require(result.returncode == 0, 'Archived replay failed; inspect ' + str(log))
    return {'command': command, 'exit_code': result.returncode, 'log_sha256': sha(log)}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    for name in ('repo', 'followup', 'old-binary', 'new-binary', 'external-baseline',
                 'matched-baseline', 'corpus', 'matched-frozen', 'report', 'destination', 'scratch'):
        parser.add_argument('--' + name, type=Path, required=True)
    parser.add_argument('--analysis', type=Path)
    parser.add_argument('--preservation-root', type=Path)
    parser.add_argument('--python', type=Path, default=Path(sys.executable))
    parser.add_argument('--upstream-source', action='append', default=[], metavar='LABEL=PATH')
    parser.add_argument('--reject-text', action='append', default=[], metavar='PHRASE')
    parser.add_argument('--replay-timeout', type=int, default=3600)
    args = parser.parse_args()
    for name, value in vars(args).items():
        if isinstance(value, Path):
            # Resolving a venv's interpreter symlink changes sys.prefix and
            # silently selects the base environment without its dependencies.
            setattr(args, name, value.absolute() if name == 'python' else value.resolve())
    args.analysis = args.analysis or args.followup / 'analysis'
    args.preservation_root = args.preservation_root or args.repo.parent
    require(args.replay_timeout > 0, 'Replay timeout must be positive')
    pair, preservation = verify_completed(args)
    args.scratch.mkdir(parents=True, exist_ok=False)
    stage = args.scratch / 'staged'
    stage.mkdir()
    stage_inputs(args, stage, pair)
    audit_prose(stage, args.reject_text)
    archive = args.scratch / 'evidence.tar.gz'
    manifest_and_archive(stage, archive)
    extracted = args.scratch / 'extracted'
    extraction = extract_and_audit(archive, extracted)
    env = dict(os.environ, PYTHONDONTWRITEBYTECODE='1', MPLCONFIGDIR=str(args.scratch / 'matplotlib_cache'))
    env.pop('PYTHONPATH', None)
    for name in ('OMP_NUM_THREADS', 'OPENBLAS_NUM_THREADS', 'MKL_NUM_THREADS', 'NUMEXPR_NUM_THREADS', 'VECLIB_MAXIMUM_THREADS'):
        env[name] = '1'
    replay = args.scratch / 'fresh_analysis'
    command = [str(args.python), str(extracted / 'harness/experiments/paired_analysis.py'),
               '--repo', str(extracted / 'harness'), '--campaign', str(extracted / 'campaign'),
               '--output', str(replay)]
    analysis_run = run_command(command, extracted, args.scratch / 'archive_replay.log', env, args.replay_timeout)
    comparison_path = args.scratch / 'canonical_replay_receipt.json'
    comparison_run = run_command([str(args.python), str(extracted / 'scripts/canonical_replay.py'),
        '--reference', str(extracted / 'analysis'), '--replay', str(replay), '--output', str(comparison_path)],
        extracted, args.scratch / 'archive_comparison.log', env, args.replay_timeout)
    comparison = json.loads(comparison_path.read_text())
    require(comparison.get('passed') is True, 'Archived semantic replay did not pass')
    args.destination.mkdir(parents=True, exist_ok=False)
    copy_file(archive, args.destination / 'evidence.tar.gz')
    copies = {
        'sha256_manifest.json': extracted / 'sha256_manifest.json',
        'summary.json': extracted / 'analysis/summary.json',
        'original_preservation.json': extracted / 'receipts/original_preservation.json',
        'preflight_summary.json': extracted / 'preflight_order_v2/summary.json',
        'preflight_classification.json': extracted / 'preflight_order_v2/classification_receipt.json',
        'fuzz_summary.json': extracted / 'verification/pipeline_fuzz_final/summary.json',
        'rust_validation.json': extracted / 'verification/rust_validation.json',
        'postflight_receipt.json': extracted / 'receipts/postflight_receipt.json',
        'python_final_with_binary.log': extracted / 'logs/python_final_with_binary.log',
        'canonical_replay_receipt.json': comparison_path,
        'archive_replay.log': args.scratch / 'archive_replay.log',
        'archive_comparison.log': args.scratch / 'archive_comparison.log',
    }
    for name, source in copies.items():
        copy_file(source, args.destination / name)
    for source in (extracted / 'campaign/external').rglob('external_summary.json'):
        copy_file(source, args.destination / 'external_summary.json')
    receipt = {'schema': 1, 'completed': True, 'archive_sha256': sha(archive),
               'extraction_audit': extraction, 'historical_preservation_audit': preservation, 'analysis_run': analysis_run,
               'comparison_run': comparison_run, 'canonical_summary_sha256': comparison['canonical_summary_sha256'],
               'replay_scope': 'Fresh archived analysis is canonically byte-equal after excluding only verifier duration; all recorded compiler/parse/request timings remain exact.',
               'preserved_fresh_analysis': 'Fresh replay outputs remain in the explicitly selected scratch/fresh_analysis directory.',
               'packaging_source_sha256': sha(Path(__file__))}
    dump_new(args.destination / 'packaging_receipt.json', receipt)
    checksums = {path.name: {'bytes': path.stat().st_size, 'sha256': sha(path)}
                 for path in sorted(args.destination.iterdir()) if path.is_file()}
    dump_new(args.destination / 'checksums.json', {
        'schema': 1, 'files': checksums,
        'scope': 'Every deliverable except this self-referential checksum file. sha256_manifest.json binds each archive payload file.'})
    print(json.dumps({'destination': str(args.destination), 'archive_sha256': receipt['archive_sha256'],
                      'payload_files': extraction['payload_files'], 'canonical_replay_passed': True}))


if __name__ == '__main__':
    main()
