#!/usr/bin/env python3
"""Freeze and later check pre-existing reports/results without changing them."""
import argparse
import hashlib
import json
from pathlib import Path
import subprocess

BASE = Path(__file__).resolve().parent
WORKING = BASE.parent
REPO = WORKING / 'qrust_pr_publish'


def sha(path):
    with path.open('rb') as stream:
        digest = hashlib.file_digest(stream, 'sha256')
    return digest.hexdigest()


def selected_files():
    tracked = subprocess.check_output(['git', 'ls-files', '-z'], cwd=REPO).decode().split('\0')
    files = {REPO / name for name in tracked if name and (
        name.startswith('experiments/external_results/') or
        name.startswith('experiments/') and name.endswith('.md'))}
    # Raw studies and earlier native artifacts are also preserved locally. The
    # tracked evidence archives independently retain their portable snapshots.
    for name in ('qrust_external_retention_20261018/study',
                 'qrust_tket_benchpress_20261018/matched',
                 'qrust_tket_benchpress_20261018/benchpress/native_results_v2',
                 'qrust_tket_benchpress_20261018/benchpress/frozen'):
        files.update(path for path in (WORKING / name).rglob('*') if path.is_file()
                     and '__pycache__' not in path.parts)
    return sorted(files)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('action', choices=['freeze', 'check'])
    args = parser.parse_args()
    manifest_path = BASE / 'original_preservation.json'
    if args.action == 'freeze':
        records = [{'path': str(path.relative_to(WORKING)), 'bytes': path.stat().st_size,
                    'sha256': sha(path)} for path in selected_files()]
        manifest = {'schema': 1, 'baseline_git_head': subprocess.check_output(
            ['git', 'rev-parse', 'HEAD'], cwd=REPO, text=True).strip(),
            'scope': 'All previously tracked experiments Markdown reports and external_results files; complete local external-retention study, matched pilot, native v2 results and frozen inputs.',
            'files': records}
        with manifest_path.open('x') as stream:
            json.dump(manifest, stream, indent=2, sort_keys=True)
            stream.write('\n')
    else:
        manifest = json.loads(manifest_path.read_text())
        for record in manifest['files']:
            path = WORKING / record['path']
            if not path.is_file() or path.stat().st_size != record['bytes'] or sha(path) != record['sha256']:
                raise ValueError('Preserved baseline changed: ' + record['path'])
    print(json.dumps({'action': args.action, 'preserved_files': len(manifest['files']),
                      'manifest_sha256': sha(manifest_path)}))


if __name__ == '__main__':
    main()
