#!/usr/bin/env python3
"""Run only after every frozen timing session is complete and workers exited."""
from pathlib import Path
import hashlib
import json
import os
import subprocess
import sys
import time

from canonical_replay import compare_analyses

base = Path(__file__).resolve().parent
repo = base.parent / 'qrust_pr_publish'
campaign = base / 'campaign'
completion = json.loads((base / 'timing_completion.json').read_text())
if not completion['all_four_sessions_completed'] or (campaign / 'active.lock').exists():
    raise RuntimeError('All timing must finish before analysis')
commands = [
    ('python_final_with_binary', [sys.executable, '-m', 'unittest', 'discover',
        '-s', str(repo / 'experiments'), '-p', 'test_*.py', '-v']),
    ('canonical_replay_tests', [sys.executable, '-m', 'unittest', 'discover',
        '-s', str(base), '-p', 'test_canonical_replay.py', '-v']),
    ('official_and_paired_validation', [sys.executable, str(repo / 'experiments/paired_analysis.py'),
        '--repo', str(repo), '--campaign', str(campaign), '--output', str(base / 'analysis'), '--official']),
    ('external_sdk_analysis', [sys.executable, str(repo / 'experiments/analyze_external_comparison.py'),
        str(campaign / 'external'), '--bootstrap-draws', '2000']),
    ('independent_paired_replay', [sys.executable, str(repo / 'experiments/paired_analysis.py'),
        '--repo', str(repo), '--campaign', str(campaign), '--output', str(base / 'analysis_replay')]),
]
with (base / 'postflight_commands.json').open('x') as stream:
    json.dump(commands, stream, indent=2)
    stream.write('\n')
env = dict(os.environ, MPLCONFIGDIR=str(base / 'matplotlib_cache'),
           QRUST_COMPARISON_BINARY=str(base / 'comparison_runner_fixed'))
# Numerical libraries stay single threaded during validation as well.
for key in ('OMP_NUM_THREADS', 'OPENBLAS_NUM_THREADS', 'MKL_NUM_THREADS', 'NUMEXPR_NUM_THREADS', 'VECLIB_MAXIMUM_THREADS'):
    env[key] = '1'
receipts = []
for name, command in commands:
    print(json.dumps({'starting': name}), flush=True)
    log_path = base / (name + '.log')
    started = time.monotonic()
    with log_path.open('x') as log:
        result = subprocess.run(command, stdout=log, stderr=subprocess.STDOUT, env=env, cwd=repo)
    receipt = {'name': name, 'exit_code': result.returncode, 'wall_seconds': time.monotonic() - started,
               'log_sha256': hashlib.sha256(log_path.read_bytes()).hexdigest()}
    receipts.append(receipt)
    print(json.dumps(receipt), flush=True)
    if result.returncode:
        print(log_path.read_text()[-5000:], flush=True)
        raise SystemExit(result.returncode)
replay_receipt = compare_analyses(base / 'analysis', base / 'analysis_replay')
with (base / 'canonical_replay_receipt.json').open('x') as stream:
    json.dump(replay_receipt, stream, indent=2, sort_keys=True)
    stream.write('\n')
with (base / 'postflight_receipt.json').open('x') as stream:
    json.dump({'all_stages_completed': True, 'stages': receipts,
               'canonical_replay_receipt_sha256': hashlib.sha256((base / 'canonical_replay_receipt.json').read_bytes()).hexdigest(),
               'canonical_summary_sha256': replay_receipt['canonical_summary_sha256'],
               'excluded_replay_field': 'validation.validation_ns'}, stream, indent=2)
    stream.write('\n')
print('Fresh full-output replay matches after excluding only verifier duration; SDK analysis complete.', flush=True)
