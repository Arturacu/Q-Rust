#!/usr/bin/env python3
"""Compare independent analysis replays, excluding only verifier wall time.

Raw analyses remain unchanged. Compilation, parsing, request and other timing
measurements are compared exactly. The sole row exclusion is the newly
measured ``validation.validation_ns`` duration. Summary row checksums are
replaced with checksums of those canonical rows before comparing summaries.
"""
from __future__ import annotations

import argparse
import copy
import hashlib
import json
from pathlib import Path


def sha_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def canonical(value) -> bytes:
    return (json.dumps(value, sort_keys=True, separators=(',', ':'), allow_nan=False) + '\n').encode()


def normalized_rows(path: Path):
    raw = path.read_bytes()
    output = bytearray()
    count = excluded = 0
    for line in raw.splitlines():
        if not line.strip():
            continue
        row = json.loads(line)
        if not isinstance(row, dict):
            raise ValueError(f'Expected an object in {path.name}')
        validation = row.get('validation')
        if isinstance(validation, dict) and 'validation_ns' in validation:
            timer = validation.pop('validation_ns')
            if type(timer) is not int or timer < 0:
                raise ValueError(f'Invalid verifier timer in {path.name}')
            excluded += 1
        output.extend(canonical(row))
        count += 1
    return bytes(output), {'raw_sha256': sha_bytes(raw), 'canonical_sha256': sha_bytes(output),
                           'rows': count, 'verifier_timer_fields_excluded': excluded}


def compare_analyses(reference: Path, replay: Path) -> dict:
    reference, replay = Path(reference).resolve(), Path(replay).resolve()
    if reference == replay:
        raise ValueError('Reference and replay must be distinct directories')
    raw_summaries = [(directory / 'summary.json').read_bytes() for directory in (reference, replay)]
    summaries = [json.loads(value) for value in raw_summaries]
    normalized = copy.deepcopy(summaries)
    files = {}
    for suite in ('external', 'matched'):
        for session in (1, 2):
            name = f'{suite}_session_{session}.jsonl'
            canonical_rows = []
            metadata = []
            for side, directory in enumerate((reference, replay)):
                data, info = normalized_rows(directory / name)
                declared = summaries[side]['suites'][suite]['sessions'][str(session)]['validated_rows_sha256']
                if declared != info['raw_sha256']:
                    raise ValueError(f'Summary does not bind raw rows: {directory.name}/{name}')
                normalized[side]['suites'][suite]['sessions'][str(session)]['validated_rows_sha256'] = info['canonical_sha256']
                canonical_rows.append(data)
                metadata.append(info)
            if canonical_rows[0] != canonical_rows[1]:
                raise ValueError(f'Replay differs beyond verifier duration: {name}')
            files[name] = {'reference': metadata[0], 'replay': metadata[1], 'canonical_bytes_equal': True}
    canonical_summaries = [canonical(summary) for summary in normalized]
    if canonical_summaries[0] != canonical_summaries[1]:
        raise ValueError('Summary differs after substituting canonical-row checksums')
    return {
        'schema': 1,
        'passed': True,
        'comparison': 'Semantic rows and summaries are byte-identical after excluding only fresh verifier duration and substituting canonical-row checksums.',
        'excluded_row_fields': ['validation.validation_ns'],
        'summary_transform': 'Replace suites.<suite>.sessions.<session>.validated_rows_sha256 with SHA256 of canonical rows.',
        'unchanged_timing_fields': ['compile_ns', 'parse_ns', 'request_wall_ns'],
        'raw_summaries_byte_equal': raw_summaries[0] == raw_summaries[1],
        'reference_summary_sha256': sha_bytes(raw_summaries[0]),
        'replay_summary_sha256': sha_bytes(raw_summaries[1]),
        'canonical_summary_sha256': sha_bytes(canonical_summaries[0]),
        'row_files': files,
        'comparison_source_sha256': sha_bytes(Path(__file__).read_bytes()),
    }


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--reference', type=Path, required=True)
    parser.add_argument('--replay', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    receipt = compare_analyses(args.reference, args.replay)
    with args.output.open('x') as stream:
        json.dump(receipt, stream, indent=2, sort_keys=True, allow_nan=False)
        stream.write('\n')
    print(json.dumps({'passed': True, 'canonical_summary_sha256': receipt['canonical_summary_sha256']}))


if __name__ == '__main__':
    main()
