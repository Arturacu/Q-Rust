"""Independent dense-matrix audit of dependency-local source SWAP windows."""
from pathlib import Path
import json, sys, hashlib
import numpy as np
base=Path(__file__).resolve().parents[2]
sys.path.insert(0,str(base/'qrust_pr_publish/experiments'))
from comparison_validation import parse_qasm,simulate,Gate
source=(base/'qrust_external_20261018/corpus/qasmbench__error_correctiond3_n5.normalized.qasm').read_text()
n,parsed=parse_qasm(source); ops=list(parsed); removed=set(); rows=[]
expected=np.eye(4,dtype=complex)[:,[0,2,1,3]]
for start,initial in enumerate(ops):
 if start in removed or initial.name=='swap':continue
 first=initial.qubits[0]; pair=None
 for i,g in enumerate(ops[start:],start):
  if i in removed or first not in g.qubits:continue
  if g.name=='swap':break
  if len(g.qubits)==2:
   pair=(first,next(q for q in g.qubits if q!=first));break
 if pair is None:continue
 selected=[]; local=[]; entanglers=0; anchor=None
 for i,g in enumerate(ops[start:],start):
  if i in removed or not set(pair)&set(g.qubits):continue
  if not set(g.qubits)<=set(pair) or g.name=='swap':break
  selected.append(i);local.append(Gate(g.name,g.params,tuple(pair.index(q) for q in g.qubits)))
  if len(g.qubits)==2:entanglers+=1;anchor=i if anchor is None else anchor
  matrix=simulate(2,tuple(local),np.eye(4,dtype=complex));overlap=np.vdot(expected,matrix)
  residual=float(np.linalg.norm(matrix-(overlap/abs(overlap) if abs(overlap) else 1)*expected))
  if entanglers>=3 and residual<1e-13:
   rows.append({'pair':pair,'source_gate_indices':selected.copy(),'contiguous':selected==list(range(min(selected),max(selected)+1)), 'gates':[{'name':ops[j].name,'qubits':ops[j].qubits,'params':ops[j].params} for j in selected], 'full_4x4_shared_phase_residual':residual})
   removed.update(j for j in selected if j!=anchor);ops[anchor]=Gate('swap',(),pair);break
  if len(selected)>=64:break
out=Path(__file__).resolve().parent/'swap_windows.json'
out.write_text(json.dumps({'source_sha256':hashlib.sha256(source.encode()).hexdigest(),'source_indexing':'zero-based gate index in independently parsed original normalized source','method':'dependency-local source windows; independent literal dense matrix oracle; no compiler implementation imports','count':len(rows),'rows':rows},indent=2)+'\n')
for i,row in enumerate(rows):print(i,row['pair'],row['source_gate_indices'],'contiguous',row['contiguous'],row['full_4x4_shared_phase_residual'])
