Q-Rust external benchmark compatibility follow-up evidence, 2026-10-18

This separately recorded study repairs Q-Rust CU1 support and Cirq full-CZ
adapter canonicalization. It retains the same frozen community corpus,
compiler recipes, targets, seeds, schedules, repeated-trial design and oracle.
Original results are preserved, including their compatibility failures.

The archive contains byte-exact new protocol and corpus manifest, both sessions'
timed/warmup/validated outputs (including any failures), original analysis
JSON/CSV, cross-run analysis JSON, frozen harness, new analysis/regression files,
changed Rust compatibility files and explicit audit receipts. The complete Rust
project is identified by the protocol's compiler commit; binaries are omitted.
Numerical checks are not a formal equivalence proof. The corpus informed these
compatibility fixes, so this follow-up is not an untouched holdout.

The unchanged original community circuits, source archives and their licenses
remain in the original evidence archive. BASELINE_REFERENCE.json binds its
exact SHA256, immutable Git revision and repository path. The embedded corpus
manifest and protocol contain every source/normalized QASM case used for new
result analysis. No corpus reselection or regeneration is needed.

New-study analysis replay (after safely extracting this archive): rename
study/analysis to study/recorded_analysis, then use the pinned Python environment
to run: python harness/experiments/analyze_external_comparison.py study
Compare external_summary.json and all four CSV files byte-for-byte with the
recorded copies. The analyzer refuses an existing output directory.

Cross-run analysis replay also requires the hash-verified original archive,
extracted separately into baseline_original/. Keep its original study directory
unchanged. Run: python harness/experiments/analyze_external_followup.py
baseline_original/study study --output replay_followup_analysis
Compare replay_followup_analysis/followup_comparison.json byte-for-byte with
followup_analysis/followup_comparison.json. Both analyzers use 2000 bootstrap
draws by default, analyze sessions separately, and never pool repeated sessions.

Cross-run summaries separate the fixed original common cohort, newly supported
cases and the full follow-up cohort. Different cohort aggregates are not a
before/after improvement measure. Unchanged compiler timings provide descriptive
host-drift controls, not an isolated causal estimate of compatibility-fix cost.

MANIFEST.json records payload sizes and SHA256. The adjacent repository file
evidence_manifest.json binds the archive hash and fresh extraction verification.
Archive metadata is normalized; payload file bytes are preserved. The original
reports/data are hash-checked before and after packaging. Missing receipts,
changed frozen sources or an existing destination archive cause a hard failure.
Logs, caches, compiler binaries, preliminary runs and draft prose are excluded.
