#!/usr/bin/env python3
"""Package the compatibility follow-up without replacing original evidence.

Run only after both official sessions, validation and independent audits finish.
Every input is explicit; absent receipts and changed frozen files are errors.
"""
from collections import Counter
import gzip
import hashlib
import io
import json
import os
from pathlib import Path, PurePosixPath
import re
import shutil
import tarfile
import tempfile


WORK = Path(__file__).resolve().parent
REPO = WORK.parent / "qrust_pr_publish"
STUDY = WORK / "study"
DEST = REPO / "experiments/external_results/20261018_compatibility"
ORIGINAL_DEST = REPO / "experiments/external_results/20261018"
ORIGINAL_ARCHIVE_SHA256 = "d45176c9cbcf1c7645dfed44a343ec704fb34b9ab55002dcef4c62248285716f"
FILES = {}
GENERATED = {}


def sha(data):
    return hashlib.sha256(data).hexdigest()


def encoded_json(value):
    return (json.dumps(value, indent=2, sort_keys=True, allow_nan=False) + "\n").encode()


def safe_name(name):
    path = PurePosixPath(name)
    if (not name or path.is_absolute() or ".." in path.parts or "\\" in name
            or path.as_posix() != name or name == "."):
        raise ValueError("Unsafe archive path: " + name)
    return name


def read_regular(path):
    path = Path(path)
    if not path.is_file() or path.is_symlink():
        raise ValueError("Missing regular input: " + str(path))
    return path.read_bytes()


def add(path, archive_path):
    name = safe_name(archive_path)
    if name in FILES or name in GENERATED:
        raise ValueError("Duplicate archive path: " + name)
    path = Path(path)
    if not path.is_file() or path.is_symlink():
        raise ValueError("Missing regular input: " + str(path))
    FILES[name] = path


def generate(name, data):
    safe_name(name)
    if name in FILES or name in GENERATED:
        raise ValueError("Duplicate generated archive path: " + name)
    GENERATED[name] = data


def preserve_originals():
    receipt = json.loads(read_regular(WORK / "original_preservation.json"))
    if not receipt.get("sha256"):
        raise ValueError("Original-preservation receipt has no files")
    checks = []
    for relative, expected in sorted(receipt["sha256"].items()):
        safe_name(relative)
        observed = sha(read_regular(REPO / relative))
        if observed != expected:
            raise ValueError("Original result/report changed: " + relative)
        checks.append({"path": relative, "sha256": observed, "unchanged": True})
    if sha(read_regular(ORIGINAL_DEST / "evidence.tar.gz")) != ORIGINAL_ARCHIVE_SHA256:
        raise ValueError("Original archive differs from its previously published hash")
    return receipt, checks


def collect():
    if (STUDY / "active.lock").exists():
        raise ValueError("Official timing still active; packaging is prohibited")
    if (DEST / "evidence.tar.gz").exists() or (DEST / "evidence_manifest.json").exists():
        raise FileExistsError("Follow-up evidence already exists; never overwrite a recorded archive")
    original_preservation, original_checks = preserve_originals()
    protocol_bytes = read_regular(STUDY / "protocol.json")
    protocol_sha = sha(protocol_bytes)
    protocol = json.loads(protocol_bytes)
    if read_regular(STUDY / "protocol.sha256").decode().strip() != protocol_sha:
        raise ValueError("Protocol SHA256 sidecar mismatch")
    if protocol["sessions"] != 2:
        raise ValueError("Expected exactly two official sessions")
    corpus_sha = sha(read_regular(STUDY / "corpus_manifest.json"))
    if corpus_sha != protocol["corpus_manifest_sha256"]:
        raise ValueError("Embedded corpus manifest mismatch")

    required_receipts = (
        "comparison_plan.json", "original_preservation.json", "environment_receipt.json",
        "freeze_receipt.json", "independent_preflight_audit.json",
        "development_pilot_receipt.json", "independent_postflight_audit.json",
        "independent_postflight_detail.json", "warmup_validation_receipt.json",
        "warmup_validation_artifacts.jsonl",
    )
    for name in required_receipts:
        add(WORK / name, "receipts/" + name)
    plan = json.loads(read_regular(WORK / "comparison_plan.json"))
    freeze = json.loads(read_regular(WORK / "freeze_receipt.json"))
    if corpus_sha != plan["corpus_manifest_sha256"]:
        raise ValueError("Corpus differs from the before-timing comparison plan")
    if freeze["new_protocol_sha256"] != protocol_sha:
        raise ValueError("Freeze receipt belongs to another protocol")
    if freeze["new_binary_sha256"] != protocol["qrust_binary_sha256"]:
        raise ValueError("Freeze receipt and protocol disagree on compiler binary")
    if freeze["new_compiler_commit"] != protocol["compiler_commit"]:
        raise ValueError("Freeze receipt and protocol disagree on compiler revision")
    validation = json.loads(read_regular(STUDY / "validation_summary.json"))
    if validation["protocol_sha256"] != protocol_sha:
        raise ValueError("Validation receipt belongs to another protocol")

    for name in ("protocol.json", "protocol.sha256", "corpus_manifest.json", "validation_summary.json"):
        add(STUDY / name, "study/" + name)
    # Reuse the recorded integrity checks rather than accepting a merely
    # present session directory or silently archiving an incomplete row grid.
    import sys
    sys.path.insert(0, str(REPO / "experiments"))
    from analyze_external_followup import load_study
    loaded_protocol, loaded_sha, _records = load_study(STUDY)
    if loaded_protocol != protocol or loaded_sha != protocol_sha:
        raise ValueError("Independent study loading disagrees with protocol")
    for number in (1, 2):
        directory = f"session_{number:02d}"
        for name in ("protocol.json", "session.json", "startup.json", "timed.jsonl", "warmup.jsonl", "validated.jsonl"):
            add(STUDY / directory / name, "study/" + directory + "/" + name)
    for name in ("external_summary.json", "session_1_primary_cells.csv", "session_1_light_cells.csv",
                 "session_2_primary_cells.csv", "session_2_light_cells.csv"):
        add(STUDY / "analysis" / name, "study/analysis/" + name)
    followup_path = WORK / "followup_analysis/followup_comparison.json"
    add(followup_path, "followup_analysis/followup_comparison.json")
    followup = json.loads(read_regular(followup_path))
    if (followup["followup_protocol_sha256"] != protocol_sha
            or followup["original_protocol_sha256"] != plan["original_protocol_sha256"]):
        raise ValueError("Cross-run analysis does not bind the planned original and follow-up protocols")

    if len(protocol["source_sha256"]) != 11:
        raise ValueError("Frozen harness inventory differs from the expected 11 files")
    for relative, expected in protocol["source_sha256"].items():
        safe_name(relative)
        if sha(read_regular(REPO / relative)) != expected:
            raise ValueError("Frozen harness changed: " + relative)
        add(REPO / relative, "harness/" + relative)
    extra_harness = (
        "experiments/analyze_external_followup.py", "experiments/test_analyze_external_followup.py",
        "experiments/render_external_followup.py",
        "experiments/test_comparison_cirq.py", "experiments/test_diagnose_compiler_tradeoffs.py",
    )
    for relative in extra_harness:
        add(REPO / relative, "harness/" + relative)
    for name in ("LICENSE-MIT", "LICENSE-APACHE"):
        add(REPO / name, name)
    if followup["analysis_source_sha256"] != sha(read_regular(REPO / "experiments/analyze_external_followup.py")):
        raise ValueError("Cross-run analyzer changed after producing recorded results")
    analysis = json.loads(read_regular(STUDY / "analysis/external_summary.json"))
    if (analysis["protocol_sha256"] != protocol_sha
            or analysis["source_sha256"] != protocol["source_sha256"]["experiments/analyze_external_comparison.py"]):
        raise ValueError("New-study analysis belongs to another protocol/source")
    # These are the implementation/regression files changed for compatibility;
    # the complete Rust project remains identified by its recorded Git commit.
    for relative in ("src/ir/gates.rs", "src/ir/gate_def.rs", "src/transpiler/mod.rs", "tests/cu1_regressions.rs"):
        expected = protocol["compiler_provenance"]["compiler_source_sha256"][relative]
        if sha(read_regular(REPO / relative)) != expected:
            raise ValueError("Frozen compiler/regression source changed: " + relative)
        add(REPO / relative, "compiler_changes/" + relative)
    for name in ("preflight_compatibility.py", "audit_warmups.py", "package_followup_evidence.py"):
        add(WORK / name, "audit_tools/" + name)

    add(ORIGINAL_DEST / "evidence_manifest.json", "baseline/evidence_manifest.json")
    baseline_manifest = json.loads(read_regular(ORIGINAL_DEST / "evidence_manifest.json"))
    if (baseline_manifest["archive_sha256"] != ORIGINAL_ARCHIVE_SHA256
            or baseline_manifest["protocol_sha256"] != plan["original_protocol_sha256"]
            or baseline_manifest["corpus_manifest_sha256"] != corpus_sha):
        raise ValueError("Original archive manifest does not bind the same corpus and planned baseline")
    baseline_reference = {
        "archive_repo_path": "experiments/external_results/20261018/evidence.tar.gz",
        "archive_sha256": ORIGINAL_ARCHIVE_SHA256,
        "source_commit": original_preservation["source_commit"],
        "archive_url": "https://github.com/Arturacu/Q-Rust/blob/"
                       + original_preservation["source_commit"]
                       + "/experiments/external_results/20261018/evidence.tar.gz",
        "protocol_sha256": plan["original_protocol_sha256"],
        "corpus_manifest_sha256": corpus_sha,
        "purpose": "Original results and byte-identical corpus/source/licensing evidence; required for cross-run replay.",
        "new_study_replay": "The new study embeds every case and its independent source QASM; new-study result analysis requires only this follow-up archive.",
    }
    generate("BASELINE_REFERENCE.json", encoded_json(baseline_reference))
    generate("receipts/packaging_original_preservation_check.json", encoded_json({
        "status": "passed", "source_commit": original_preservation["source_commit"],
        "original_archive_sha256": ORIGINAL_ARCHIVE_SHA256, "files": original_checks,
    }))
    generate("README.txt", README.encode())
    return protocol_sha, corpus_sha, baseline_reference, original_checks


# High-confidence credential shapes only. Findings contain names and detector
# labels, never secret values or surrounding contents. No configuration files,
# unrelated files, compiler binaries, logs or cached data are collected.
SECRET_PATTERNS = {
    "private_key": re.compile(rb"-----BEGIN (?:RSA |EC |OPENSSH |DSA )?PRIVATE KEY-----"),
    "github_token": re.compile(rb"\b(?:gh[pousr]_[A-Za-z0-9]{30,}|github_pat_[A-Za-z0-9_]{40,})\b"),
    "openai_token": re.compile(rb"\bsk-(?:proj-|svcacct-)?[A-Za-z0-9_-]{35,}\b"),
    "aws_access_key": re.compile(rb"\b(?:AKIA|ASIA)[A-Z0-9]{16}\b"),
    "slack_token": re.compile(rb"\bxox[baprs]-[A-Za-z0-9-]{20,}\b"),
    "credential_url": re.compile(rb"https?://[^\s/:]{2,100}:[^\s/@]{4,100}@"),
}
NATIVE_HEADERS = {b"\x7fELF", b"\xcf\xfa\xed\xfe", b"\xfe\xed\xfa\xcf", b"\xca\xfe\xba\xbe"}


README = """Q-Rust external benchmark compatibility follow-up evidence, 2026-10-18

This separately recorded study repairs Q-Rust CU1 support and Cirq full-CZ
adapter canonicalization. It retains the same frozen community corpus,
compiler recipes, targets, seeds, schedules, repeated-trial design and oracle.
Original results are preserved, including their compatibility failures.

The archive contains byte-exact new protocol and corpus manifest, both sessions'
timed/warmup/validated outputs (including any failures), original analysis
JSON/CSV, cross-run analysis JSON, frozen harness, new analysis/regression files,
changed Rust compatibility files and explicit audit receipts. The complete Rust
project is identified by the protocol's compiler commit; binaries are omitted.
Numerical checks are not a formal equivalence proof. The corpus informed these
compatibility fixes, so this follow-up is not an untouched holdout.

The unchanged original community circuits, source archives and their licenses
remain in the original evidence archive. BASELINE_REFERENCE.json binds its
exact SHA256, immutable Git revision and repository path. The embedded corpus
manifest and protocol contain every source/normalized QASM case used for new
result analysis. No corpus reselection or regeneration is needed.

New-study analysis replay (after safely extracting this archive): rename
study/analysis to study/recorded_analysis, then use the pinned Python environment
to run: python harness/experiments/analyze_external_comparison.py study
Compare external_summary.json and all four CSV files byte-for-byte with the
recorded copies. The analyzer refuses an existing output directory.

Cross-run analysis replay also requires the hash-verified original archive,
extracted separately into baseline_original/. Keep its original study directory
unchanged. Run: python harness/experiments/analyze_external_followup.py
baseline_original/study study --output replay_followup_analysis
Compare replay_followup_analysis/followup_comparison.json byte-for-byte with
followup_analysis/followup_comparison.json. Both analyzers use 2000 bootstrap
draws by default, analyze sessions separately, and never pool repeated sessions.

Cross-run summaries separate the fixed original common cohort, newly supported
cases and the full follow-up cohort. Different cohort aggregates are not a
before/after improvement measure. Unchanged compiler timings provide descriptive
host-drift controls, not an isolated causal estimate of compatibility-fix cost.

MANIFEST.json records payload sizes and SHA256. The adjacent repository file
evidence_manifest.json binds the archive hash and fresh extraction verification.
Archive metadata is normalized; payload file bytes are preserved. The original
reports/data are hash-checked before and after packaging. Missing receipts,
changed frozen sources or an existing destination archive cause a hard failure.
Logs, caches, compiler binaries, preliminary runs and draft prose are excluded.
"""


def main():
    protocol_sha, corpus_sha, baseline_reference, original_checks = collect()
    payloads = {name: read_regular(path) for name, path in FILES.items()}
    payloads.update(GENERATED)
    findings = []
    for name, data in sorted(payloads.items()):
        if data[:4] in NATIVE_HEADERS or data[:2] == b"MZ":
            raise ValueError("Unexpected executable: " + name)
        for detector, pattern in SECRET_PATTERNS.items():
            if pattern.search(data):
                findings.append({"path": name, "detector": detector})
    if findings:
        print(json.dumps({"credential_scan": "review_required", "findings": findings}, indent=2))
        raise SystemExit(2)
    entries = [{"path": name, "bytes": len(data), "sha256": sha(data)}
               for name, data in sorted(payloads.items())]
    content_manifest = {
        "schema": 1, "files": entries, "protocol_sha256": protocol_sha,
        "corpus_manifest_sha256": corpus_sha,
        "original_evidence_archive_sha256": ORIGINAL_ARCHIVE_SHA256,
    }
    payloads["MANIFEST.json"] = encoded_json(content_manifest)
    expected = {entry["path"]: entry for entry in entries}
    expected["MANIFEST.json"] = {"path": "MANIFEST.json", "bytes": len(payloads["MANIFEST.json"]),
                                 "sha256": sha(payloads["MANIFEST.json"])}
    DEST.mkdir(parents=True, exist_ok=True)
    if DEST.is_symlink():
        raise ValueError("Destination must not be a symlink")
    with tempfile.TemporaryDirectory(prefix=".followup-package-", dir=DEST) as temporary:
        staging = Path(temporary)
        archive = staging / "evidence.tar.gz"
        with archive.open("xb") as stream:
            with gzip.GzipFile(filename="", mode="wb", fileobj=stream, mtime=0, compresslevel=9) as compressed:
                with tarfile.open(fileobj=compressed, mode="w", format=tarfile.PAX_FORMAT) as output:
                    for name, data in sorted(payloads.items()):
                        item = tarfile.TarInfo(name)
                        item.size, item.mtime, item.mode = len(data), 0, 0o644
                        item.uid = item.gid = 0
                        item.uname = item.gname = ""
                        output.addfile(item, io.BytesIO(data))
        extraction = staging / "verified_extraction"
        extraction.mkdir()
        with tarfile.open(archive, "r:gz") as packaged:
            members = packaged.getmembers()
            names = [member.name for member in members]
            if len(names) != len(set(names)) or set(names) != set(expected):
                raise ValueError("Archive member inventory mismatch")
            for member in members:
                safe_name(member.name)
                if not member.isfile() or member.size != expected[member.name]["bytes"]:
                    raise ValueError("Unsafe member or recorded-size mismatch: " + member.name)
                path = extraction / member.name
                path.parent.mkdir(parents=True, exist_ok=True)
                with path.open("xb") as target:
                    shutil.copyfileobj(packaged.extractfile(member), target)
            for name, entry in expected.items():
                data = read_regular(extraction / name)
                if len(data) != entry["bytes"] or sha(data) != entry["sha256"]:
                    raise ValueError("Extracted payload mismatch: " + name)
        for name, path in FILES.items():
            if sha(read_regular(path)) != expected[name]["sha256"]:
                raise ValueError("Input changed during packaging: " + name)
        _, final_original_checks = preserve_originals()
        if final_original_checks != original_checks:
            raise ValueError("Original results changed during packaging")
        receipt = {
            "schema": 1, "archive": "evidence.tar.gz", "archive_bytes": archive.stat().st_size,
            "archive_sha256": sha(archive.read_bytes()), "payload_file_count": len(expected),
            "uncompressed_payload_bytes": sum(entry["bytes"] for entry in expected.values()),
            "protocol_sha256": protocol_sha, "corpus_manifest_sha256": corpus_sha,
            "baseline_reference": baseline_reference,
            "files": [expected[name] for name in sorted(expected)],
            "extraction_integrity": {
                "status": "passed", "files_verified": len(expected),
                "method": "Fresh extraction; exact inventory, regular files, safe paths, every size and SHA256 verified; inputs and preserved original files rechecked.",
            },
            "original_preservation": {"status": "passed", "files_verified": len(original_checks)},
            "credential_review": {
                "status": "no_high_confidence_credential_patterns_detected", "scanned_payload_files": len(payloads) - 1,
                "detectors": sorted(SECRET_PATTERNS),
                "scope": "Explicit new-study/source/receipt allowlist; baseline archive is hash-bound and its previously recorded scan retained in baseline/evidence_manifest.json. Legitimate recorded paths retained as provenance.",
            },
            "excluded": ["worker logs", "caches and bytecode", "compiler executables", "development pilot outputs",
                         "draft prose", "unrelated workspace files", "duplicated original corpus/source bytes"],
            "top_level_file_counts": dict(Counter(name.split("/")[0] for name in expected)),
        }
        manifest = staging / "evidence_manifest.json"
        manifest.write_bytes(encoded_json(receipt))
        # Hard-link installation is atomic per file and refuses to replace an
        # existing destination; both staged files have been fully verified.
        os.link(archive, DEST / archive.name)
        os.link(manifest, DEST / manifest.name)
    print(json.dumps({key: value for key, value in receipt.items() if key != "files"}, indent=2))


if __name__ == "__main__":
    main()
