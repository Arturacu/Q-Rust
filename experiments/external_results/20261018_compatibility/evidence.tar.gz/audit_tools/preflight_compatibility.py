"""Synthetic compatibility checks; these are not official benchmark trials."""
from pathlib import Path
import hashlib, json, os, sys
ROOT=Path(__file__).resolve().parent
REPO=ROOT.parent/'qrust_pr_publish'
sys.path.insert(0,str(REPO/'experiments'))
from external_comparison import ProfileWorker, TOOLS, timed_request
from comparison_study import THREAD_ENV
os.environ.update(THREAD_ENV)
from comparison_validation import validate_output
binary=REPO/'target/release/comparison_runner'
out=ROOT/'development_pilot'
out.mkdir(exist_ok=False)
records=[]
for tool in TOOLS:
    worker=ProfileWorker(tool,binary,out)
    try:
        for label,width,body in [('full_cz',2,'cu1(pi) q[0],q[1];'),('fractional_reversed',2,'cu1(-0.37) q[1],q[0];'),('routed',3,'u3(0.3,0.7,-0.2) q[0]; cu1(-pi/3) q[2],q[0]; cx q[1],q[0]; u3(0.6,-0.4,0.8) q[2]; cu1(pi/7) q[2],q[1]; cu1(2*pi) q[0],q[2];')]:
            qasm=f'OPENQASM 2.0; include "qelib1.inc"; qreg q[{width}]; {body}'
            for topology in ['all_to_all','linear']:
                edges=[[a,b] for a in range(width) for b in range(a+1,width) if topology=='all_to_all' or b==a+1]
                request=dict(qasm=qasm,n_logical=width,physical_width=width,edges=edges,topology=topology,seed=20261018)
                result=timed_request(worker,request,60)
                record=dict(tool=tool,case=label,request=request,result=result)
                if result['status']=='compiled':
                    directed=[pair for a,b in edges for pair in [[a,b],[b,a]]]
                    record['validation']=validate_output(qasm,result['out_qasm'],width,width,directed,result['initial_layout'],result['final_layout'])
                records.append(record)
    finally:
        worker.close()
(ROOT/'development_pilot_records.json').write_text(json.dumps(records,indent=2)+'\n')
receipt={'purpose':'Synthetic compatibility preflight, not official timing observations','count':len(records),'all_passed':all(r.get('validation',{}).get('passed') is True for r in records),'max_residual':max(r.get('validation',{}).get('max_input_residual',0) for r in records),'binary_sha256':hashlib.sha256(binary.read_bytes()).hexdigest(),'records_sha256':hashlib.sha256((ROOT/'development_pilot_records.json').read_bytes()).hexdigest()}
(ROOT/'development_pilot_receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps(receipt))
assert receipt['all_passed']
